# Cloud Bongos

**Cloud Bongos is an AI-first software build platform.** A human owner sets scope, direction, and the hard gates (rank, approval, deploy); AI agents claim tasks and do the day-to-day building — code, docs, migrations, reviews. This repository is the **portable core**: the methodology, the Game Development System (GDS) that tracks all work, the platform engine, and a neutral branding template each instance fills in.

Cloud Bongos is free software under the **GNU AGPL-3.0** (see [`LICENSE`](./LICENSE)), with non-profit, AI-first governance ([`GOVERNANCE.md`](./GOVERNANCE.md)).

> **Provenance.** This core was extracted with fresh history from **Example** — the reference instance, built by Hermeslines, and the first project to run on Cloud Bongos. Example now consumes this core as a pinned dependency, the same shape as any other instance. The extraction is a redacted subtree (no instance secrets, IPs, or private identity); the exact pin — `core_version`, `source_commit`, `tree_sha256` — is recorded in [`.cloudbongos-core.json`](./.cloudbongos-core.json).

The durable framing for AI agents — methodology, working rules, session protocol, architecture — lives in [`CLAUDE.md`](./CLAUDE.md). Read it before editing code.

## What's in here

- **The GDS** (`src/`, `modules/`, `scripts/gds/`) — the build state machine: tasks, claims, versions, goals, dependencies, the claim→ship→grade→credit lifecycle, and the `/builder-*` CLI.
- **Platform modules** (`modules/`) — lifecycle, grading, economy, memory, onboarding, ideas, sessions, autonomy, security, the builders' hall + status dashboard, and Discord integration. Each is configurable (and most are toggleable) per instance.
- **Neutral branding template** (`config/*.neutral.json`, `docs/project-context.template.md`) — the identity scaffold a new instance fills in ([`docs/branding-contract.md`](./docs/branding-contract.md)). The vanilla pack in `config/branding.neutral.json` is the identity Cloud Bongos itself runs on.
- **Methodology + decisions** (`CLAUDE.md`, `docs/adr/`, `docs/recipes/`, `.claude/skills/`).

> **This is the core, not a ready-to-run instance.** An instance layers its own content, branding, and product modules on top of a pinned core (that is the whole point of the two-repo model). `server.js` and some entrypoints still reference the reference instance's product layer; standing the core up standalone — a clean vanilla boot — is deliberately the job of the consumer path, proven first by the next instance to install it.

## New builder? Start here

### Before you start (prerequisites)

You'll need three things on your machine first:

- **Git** — the tool that copies the code down. Check with `git --version`; install from [git-scm.com](https://git-scm.com/downloads) if it's missing.
- **Claude Code** — your pair-programmer for every session. Download the desktop app at [claude.com/download](https://claude.com/download) (Mac and Windows).
- **A GitHub account with access to this repo.** While the repo is private, the owner must invite you first; accept the invitation before cloning. (The bootstrap below also checks for Node ≥ 22 and Python ≥ 3.10, and prints the install command if either is missing.)

### Step 0 — get the project onto your machine

Clone the repo, then `cd` into it. Everything below runs from inside that folder.

### Step 1 — bootstrap

One command bootstraps a fresh clone end-to-end — toolchain checks, JS deps, local env file, and a GDS session via GitHub:

```sh
# macOS / Linux:
./scripts/setup-builder.sh
# Windows — or any OS (node is the one guaranteed runtime):
node scripts/setup-builder.js
```

It checks Node ≥ 22 and Python ≥ 3.10 (prints the install command if either is missing), runs `npm ci`, copies `.env.local.example` to `.env.local`, and hands off to `node scripts/gds/setup.js` to authenticate against the GDS via the GitHub Device Flow. The script is idempotent: re-running on an already-set-up checkout reports "already done" rather than clobbering.

When it finishes, open Claude Code and run `/builder-start` to see what tasks are claimable.

## Secrets scanning

We keep secrets (`.env` files, API keys, private keys) out of the repo with three layers. The CI and patrol layers are **instance topology**: `.github/` is excluded from the published core artifact, so an instance that wants them carries its own copies.

- **Prevent — the secret-gate hook** (`.claude/hooks/secret-gate.js`, wired in `.claude/settings.json`). A Claude Code PreToolUse hook that refuses to write secret-shaped content (provider-prefixed tokens, PEM blocks) into the working tree or a shell. It is the cooperative layer: it fails open on any error, so the two gates below are what actually hold.
- **Gate — the CI secret scan** (the `Secret scan` step in `.github/workflows/unit.yml`). Every PR runs a pinned, checksum-verified gitleaks over the checked-out tree against `.gitleaks.toml`. This must pass before merge. It scans current files, not history.
- **Patrol — the weekly history scan** (`scripts/gds/redteam-patrol.js`, run by `.github/workflows/redteam-patrol.yml`). Scans the full git history with the same config, which is how a secret committed and later deleted is still caught.

A local pre-commit hook is optional and an instance addition: this repo tracks `.husky/pre-push` (the ADR 0043 permission gate, a separate wall) but no secrets pre-commit hook. If your instance adds hooks under `.husky/`, activate them once per clone with `node scripts/gds/install-git-hooks.js` (it no-ops on a checkout without a `.husky/`; `node scripts/gds/doctor.js` reports which case you're in).

### If a scan blocks you, here's how to investigate

1. **Read the output.** The hook and gitleaks both name the offending file and the rule that matched.
2. **Is it a real secret?** Then it must never be committed. Remove it from the commit (`git restore --staged <file>`), and move the value out of the repo — local secrets go in `.env.local` (gitignored; run `/builder-setup`); production secrets live in your instance's secret store, never in the tree. If it was *already committed in an earlier commit*, the weekly history patrol will keep reporting it until the history is scrubbed — flag this to the owner, since rewriting shared history needs care.
3. **Is it a false positive?** (e.g. an example key in docs, a test fixture, a Stripe `pk_test_` publishable key.) Add a narrow path to the `[allowlist]` in `.gitleaks.toml`, and the matching entry to the `ALLOWLIST` in `.claude/hooks/secret-gate.js` — the two lists are kept in step. Only add one after confirming the match is genuinely not a secret.

## If your CLI starts 401'ing

GDS CLI calls (`node scripts/gds/start.js`, `claim.js`, `ship.js`, etc.) authenticate against your instance's GDS host using a session token stored under `~/.config/<configDir>/` (the neutral core uses `cloudbongos`; an instance may pin its own). CLI sessions do not expire — they last until revoked ([ADR 0294](docs/adr/0294-cli-sessions-do-not-expire.md)) — so a 401 means the token was revoked (by you from Settings → Active sessions, or by an Archon), swept by a rank demotion, or invalidated by an auth-changing deploy.

`apiCall` in `scripts/gds/cli-lib.js` detects HTTP 401 and exits with a clear recovery message rather than letting the failure cascade. When you see it:

1. **Re-auth via Device Flow:**

   ```sh
   node scripts/gds/setup.js --force
   ```

   It pre-flights `GET /api/gds/me` against your existing session first. If the token is valid, it tells you who you're authenticated as and exits. If the token is dead (401), it falls through to the Device Flow automatically — browser opens to `github.com/login/device`; paste the printed code, authorize as the right GitHub account, you're back.

2. **If something feels off and you're not sure what,** run the doctor:

   ```sh
   node scripts/gds/doctor.js
   ```

   It checks session validity (`/me` returns 200, identity + rank), git plumbing (`core.hooksPath` resolves), repo state (on a branch, working-tree status), and environment files. Green/red checklist, no arguments. Exits 0 if every check passes, 1 if any red.
