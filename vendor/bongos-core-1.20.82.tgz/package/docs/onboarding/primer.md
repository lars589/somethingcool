# The Citizen's Primer

*Read this before you claim your first work. ~10 minutes.*

You're about to build inside Example, a project that runs on a small purpose-built dev system. This primer is the one document that gives you enough context to ask Claude smart questions and ship your first task without getting lost. Read it linearly — it's short on purpose.

When you're done, open [/builders](https://example.com/builders) and run `/builder-start`. There's no separate "I have read it" step anymore — reading the primer is on your honor, and the work queue is already open to you.

---

## What this project is

This primer teaches the **platform** — how you claim work and ship it, the same on every Cloud Bongos instance. *What* you're building here — the product, its world, and its visual style — is specific to this instance and lives in **[`docs/project-context.template.md`](../project-context.template.md)**. Read that first for the product; everything below is the build system you'll use to make it.

## What Bongos is

**Bongos** is the project's internal nervous system. It's a Postgres-backed task database with a small HTTP API, a CLI (the `/builder-*` slash commands), and a public dashboard at [status.example.com](https://status.example.com). Every change to the project — code, docs, art, migrations, even direct DB writes — happens under a **claim** on a Bongos task. The claim is what makes parallel work safe (no two builders editing the same files at once) and what gives credit-tracking, cost-tracking, and the karma system something concrete to hang off.

You don't need to understand the Bongos schema to ship work. You just need to know: *claim a task, work on it inside your worktree, ship it.* The CLI handles the rest.

## The claim → ship lifecycle

Every piece of work moves through this loop:

```
backlog ─────▶ ready ─────▶ active ─────▶ completed ─────▶ confirmed ─────▶ shipped
   │             │             │              │                │               │
   │             │             │              │                │               └─ deployed to example.com, credits awarded
   │             │             │              │                └─ verification passed (not yet paid)
   │             │             │              └─ you said "done", ship.js runs the smoke tests
   │             │             └─ you ran /builder-claim (locks the task to your session)
   │             └─ dependencies all shipped (auto-promoted by a DB trigger)
   └─ task exists in the queue but isn't open yet
```

You drive the middle three states. The system handles the rest.

**One claim at a time** while you're a Xenos. New builders hold a single active claim — ship it (or release it) before opening another, so the first work gets carried through. The limit is keyed to your rank: it lifts automatically when you graduate to **Thetes** (after your third shipped task), after which you can hold parallel claims if you want.

When you ship, `ship.js` runs the project's **smoke tests** and the quality grader. If they pass, the task auto-confirms — verified, but **not yet paid**. **Credits land at the final `confirmed → shipped` hop**, when your code actually merges to `main` and deploys ([ADR 0120](../adr/0120-pay-on-land-and-builder-owned-rebase-gate.md) — you're paid for landed code, so a branch that never lands never pays). That hop is handled for you, but *what it takes to land* depends on your rank and what you changed; the next section covers it. (There used to be an up-front `touches[]` "drift scanner" here too; it was retired — `git merge` at land time is the real collision detector. See [ADR 0049](../adr/0049-split-parallel-safety-contract.md).)

## How work lands — and what auto-ships

`confirmed → shipped` is not a person clicking "merge". When you ship, `ship.js` opens a pull request and the project lands it for you — **nobody pushes to `main` by hand**. The PR has to go green on the automated checks (the test suite, a secret scan, and the **gate-review** classifier); the server then auto-merges it and `main` deploys to production. If a green PR ever stalls, a server sweep lands it within about five minutes, and `/merge-mode` is the manual fallback.

The one thing that decides whether your ship is **instant** or **waits for an Archon** is *what your change touches*, weighed against your rank by the **gate-review** step ([ADR 0058](../adr/0058-automatic-gate-surface-gatekeeper.md)):

| What your change touches | What happens |
|---|---|
| **Normal work** — game code, art, docs, tests, most of `src/` | **Auto-merges on green for any rank**, Xenos included. No approval. |
| **A protected "gate surface"** — migrations, server routes, the ship / deploy plumbing | Auto-merges **only if you are Metic or above** (rank trust). A Xenos or Thetes ship here **waits for an Archon** to approve. |
| **The safety core** — the gate's own machinery, the deploy switch, the rank / permission enforcement | **Always** waits for an Archon, whatever your rank. |

So your first tasks **ship with no approval**: the newcomer chores — a tile, a doc fix, a unit test, a batch of ideas — all sit on the safe side of that line, and a clean ship merges and deploys on its own. You only meet the Archon gate if your change reaches into the project's own safety machinery, which builders below Metic are asked to stay clear of anyway ([ADR 0043](../adr/0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md)). Landing is always Bongos's job: you never run `git push origin main`, `ssh` to the server, or deploy by hand — `/builder-ship` opens the PR and the server does the rest ([ADR 0042](../adr/0042-builder-self-deploy-ci-auto-merge.md)).

## The rank ladder

Four ranks, in ancient-Greek-civilization order:

| Rank       | What it means                                                          | What it unlocks                                                                  |
|------------|------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| **Xenos**  | Default for new builders. "Sandbox" tier.                              | Can only claim tasks flagged `newcomer_friendly`. Read everything. No mutations. |
| **Thetes** | Graduated newcomer. You reach it **automatically after your 3rd shipped task** — no one has to promote you. | Claim **any** task in the general queue (not just newcomer-friendly). Still no triage/blocker/scope powers. |
| **Metic**  | Approved working rank. The "real builders."                            | Claim any ready task. Idea triage, blocker review. Most of the work happens here. |
| **Archon** | Project keeper.                                                        | Scope mutations, rank changes, infra-level operations.                            |

So the sandbox is short: ship three small `newcomer_friendly` tasks and the city opens the whole queue to you on its own (the jump to **Metic** — with its triage/trust powers — is still a deliberate Archon promotion). Rank lives on the `builders.rank` column in the production database and is checked server-side on every privileged request — **with no caching**. A demotion takes effect on your next request. You cannot escalate your own rank by editing local files; the server is the source of truth. See [ADR 0016](../adr/0016-trust-boundary-server-enforced-permissions.md) and [ADR 0034](../adr/0034-thetes-graduated-newcomer-rank.md) for the full trust model.

## Example and karma

Two parallel reputation tracks. You don't need to *do* anything special to earn either — claim a task, do good work, ship it, and the system tracks both. The full mechanics (formulas, the kind table, the budget cap, every karma source) live in **[Example & karma — how you get paid](drachmae-and-karma.md)**; here's the shape of it.

- **Example** (called "credits" in code) are your **equity** in the project — a score and a stake, *not* a currency you spend on anything. They only go up, and they persist if you leave and come back. Most of your example now come from a **cost-plus reward on each shipped session**: the server prices the LLM tokens your work actually burned and pays you that real cost **plus 20%** ([ADR 0054](../adr/0054-session-token-reward-cost-plus.md)). On top of that, each task pays its `credits_reward` adjusted by the *kind* of work (a captured learning or a resolved blocker is worth 1.5×; cleanup 0.8×), and capturing an idea that someone else then ships earns you a 25% bonus ([ADR 0023](../adr/0023-kind-multipliers-and-idea-bonus.md)). Credits land at the `confirmed → shipped` edge — when your code actually merges and deploys, not when verification passes ([ADR 0120](../adr/0120-pay-on-land-and-builder-owned-rebase-gate.md)). Which of those two streams actually pays is per-instance config ([ADR 0146](../adr/<redacted><redacted>.md)): the default pays both, while a `cost-plus-only` instance pays the session reward alone and treats each task's `credits_reward` as an advertised estimate only. See the standings on [/builders](https://example.com/builders).

- **Karma** is a *separate* signal that measures **peer trust** — how other builders rate the *way* you work, not how much you ship. It's earned when Metic-and-above builders upvote your confirmed work (tallied weekly), when a proposal of yours is ratified, and when you capture ideas; it can also go *down* if you break things. Karma shows up on your profile (with a 30-day trend) and as a sortable column on the leaderboard, and it feeds your "builder strength" score. **It does not gate rank promotions** — those happen automatically by ship count (Xenos → Thetes after three ships) or by an Archon's deliberate decision. A builder who ships fast but breaks things gains example and loses karma; a builder who ships thoughtfully gains both.

One more thing worth knowing: builders are **uncapped by default** — your spend is tracked (it's the cost side of the same coin the reward is computed from) but never blocks you. There's no default budget. An Archon *can* set a per-builder **monthly budget cap** as a manual brake on a runaway; if one is set for you, you get a warning at 80% and `/builder-ship` pauses at 100% until it's raised ([ADR 0085](../adr/0085-remove-default-per-builder-spend-cap.md)).

## How to ask Claude about anything

Claude is your pair-programmer here, but it doesn't know the project until you point it at the right files. The cheapest way to get good answers is to **name the surface you're looking at**. Some examples that work well:

- *"Read [`CLAUDE.md`](../../CLAUDE.md) — what version are we currently building and what's the next claimable thing?"*
- *"Read [`docs/architecture.md`](../architecture.md) — explain how the WorldRoom enforces server-authoritative movement."*
- *"My task touches `src/bongos/auth.js` — read it and `docs/canonical-permissions.md`, then tell me which routes I'd need a `requireRank` gate on."*
- *"Look at the last 5 entries in [§13 of CLAUDE.md](../../CLAUDE.md#13-session-log) — what was the most recent V3 task that touched the builders' hall?"*

What doesn't work well:

- *"How does Bongos work?"* — too open. Claude will hallucinate or read everything inefficiently.
- *"What should I work on?"* — ask `/builder-start` instead. That's Bongos's job, not Claude's.
- *"Is this safe to ship?"* — ask `/builder-ship` (it runs the smoke tests and, when enabled, the quality grader). Or run `/code-review` if you want a second opinion.

**Use slash commands for plumbing, use Claude for thinking.** The `/builder-*` skills know how to talk to Bongos. Claude knows how to read your code and reason about it. Don't ask Claude to do something a slash command already does — it's slower and less reliable. And when you can't tell whether a command is ours or Claude Code's own, [**slash-commands.md**](slash-commands.md) sorts them apart — including the handful that collide.

## What the system remembers for you

As you work, Claude writes down durable facts — your standing preferences, a gotcha that cost real time, the current state of the project — so the next session doesn't start cold. You don't manage any of this by hand, but it's worth knowing the shape:

- **The map** (`MEMORY.md`) — a short index loaded at the **start of every session**: one line per memory, just enough to know *what* is known and where the detail lives. Kept deliberately small.
- **The drawer** — the full notes themselves. They live on your machine, sync to the server (so your memory follows you across machines), and are searchable with `/recall`. They cost nothing until something fetches them.

The map stays light on its own: a session-start guard warns if it's drifting large, and an auto-tidy moves the oldest, least-relevant notes off the map into the drawer when it crosses a threshold — **nothing is deleted**, it's just no longer loaded every session (a `/recall` away when a task needs it). Your standing rules, and anything pinned, always stay on the map. Full picture: [ADR 0074](../adr/0074-memory-map-stays-light.md) and [diagram 4 — the architecture](diagrams/).

## Where to find more depth

The whole project's source-of-truth index is [`CLAUDE.md`](../../CLAUDE.md). Two starting points:

- **For *what's true right now*** — go to the Bongos database via `/builder-start` or [/builders](https://example.com/builders). Tasks, claims, ranks, credits, costs all live there. CLAUDE.md is *descriptive*; the DB is *authoritative*.
- **For *why we chose what we chose*** — go to [`docs/adr/`](../adr/) (Architecture Decision Records). Each ADR is one decision with the trade-offs that drove it.

Other depth, in roughly the order you'll need it:

- [`docs/onboarding/example-and-karma.md`](drachmae-and-karma.md) — the full reward economy: how example and karma are earned, the cost-plus session reward, and the monthly budget cap
- [`docs/onboarding/slash-commands.md`](slash-commands.md) — which slash commands ship with Claude Code and which are this project's, and what to do about the ones that collide
- [`docs/architecture.md`](../architecture.md) — live system: droplet, stack, schema, API surface
- [`docs/modules-contract.md`](../modules-contract.md) — the product is built as a small core plus swappable `modules/<key>/` (the game, Discord, art, and more); this is the live roster and how a task lands inside one
- [`docs/canonical-permissions.md`](../canonical-permissions.md) — who can do what (rank gates)
- [`docs/file-map.md`](../file-map.md) — where every folder is and what it contains
- [`docs/recipes/`](../recipes/) — long-form ops gotchas (read before deploying)
- [`docs/onboarding/diagrams/`](diagrams/) — pan-and-zoom maps of the task lifecycle, rank ladder, the credit economy, the complete architecture (where your work runs and how it reaches production), and versioning

You don't need to read these now. Bookmark them; come back when something specific is unclear.

## Get set up on your machine

You don't need to be a programmer to build here. Entry to the project is **approval-gated**: a stranger can't just sign in with GitHub — you first ask for entry on the [builders' hall](https://example.com/builders) and an Archon admits you. Since you're reading this gated primer, you've already been admitted.

### Where your work runs — screen, worker, brain

Claude Code is **three pieces that can live in different places**:

- **The screen** — the window you look at and type into. Always on *your* device (the Claude desktop app, or a browser tab). It just shows files and sends your messages.
- **The worker** — the part that opens files, runs commands, edits code, runs the project.
- **The brain** — the AI model itself. **Always on Anthropic's servers**.

Today the worker runs in one place: **your own computer**, working on a clone of the project. The single map that shows the whole picture — your device, the per-builder memory layer, the server (authority *and* production), and how code travels to prod — is [diagram 4, *The complete architecture*](diagrams/).

> **Why a copy of the code at all?** The `/builder-*` commands you'll use every session aren't a separate download — they live *inside* the project's code (in `.claude/skills/`). The moment Claude Code **starts a session on a folder that already holds the code**, all the commands appear automatically. So "get the code" and "get the commands" are the same step — there's no plugin or zip to install. (One wrinkle: if you *clone the code mid-session into a folder that started empty*, the commands won't appear until you start a fresh session on that folder — step 3 handles it.)

### The steps

Take them in order — each one sets up the next, from "I'm admitted" to "I'm looking at work I can claim."

**1. Install the Claude desktop app.** Claude Code runs in a desktop app, **not** in the website — so you can't do this from a browser tab. Download it for your computer at **[claude.com/download](https://claude.com/download)** (Mac and Windows). Install it, open it, and sign in. You'll work in its **Code** tab.

**2. Accept your invitation to the code (check your email).** When the Archon admitted you, GitHub emailed you a message like *"… invited you to collaborate."* Open it, click **View invitation**, then **Accept**. GitHub then drops you on the project's repository page. That page is just the code sitting at rest — a list of folders and files. **You don't need to do anything there**; accepting the invite is the whole point of this step. (No email? Check your spam folder, or ask the Archon to (re)send the repository invite — GitHub invitations can expire after 7 days.)

**3. Open the code in Claude Code.** Back in the Claude desktop app's **Code** tab, you'll start a session on a folder. The easiest path — let Claude do the technical part for you:
   - Make a new, empty folder on your computer (anywhere — your Desktop is fine).
   - In Claude Code, point a new session at that empty folder.
   - Type this one plain-English message and send it:
     > *Clone the GitHub repository I was just invited to into this folder and open it as the project.*
   
   Claude handles the rest (this is the "git" plumbing you may have heard about — you don't need to learn it). When Claude asks for permission to reach GitHub, say yes — the repository is private, so it needs your go-ahead. If it asks which repository, paste the web address from the repo page you landed on in step 2.
   
   Once it finishes, that folder **is** the project. **One catch worth knowing:** the `/builder-*` commands came down *with* the code, but Claude Code only loads them when a session *starts* on a folder that already contains them — and this session started on an *empty* folder. So before the next step, **start a fresh Claude Code session on this same folder**: end this session and open a new one pointing at the folder. (Starting fresh is the clean way — the new session scans the folder from scratch, and the `/builder-*` commands will all be there.)

**4. Enrol yourself and begin.** In the **fresh** session, type `/builder-setup` — or just say *"set up builder"* in plain English — and follow the prompts. It signs you in with GitHub once and registers you in Bongos so the commands know who you are. Then type `/builder-start` to see the works you can claim right now.

If a `/builder-*` command ever says "no Bongos session," just run `/builder-setup` again — that re-links you. And if `/builder-setup` itself comes back **"unknown command,"** you're almost certainly still in the session that did the cloning — start a fresh session on the folder (end of step 3) and it'll be there.

> **Prefer a terminal? (the quicker path if you're technical.)** Steps 3–4 above are the no-terminal route. If you're comfortable on a command line, skip them — clone the repo yourself, `cd` into it, and run the bootstrap:
>
> **Before you start**, have three things ready: **Git** (check `git --version`; get it from [git-scm.com](https://git-scm.com/downloads)), the **Claude Code** desktop app ([claude.com/download](https://claude.com/download)), and a **GitHub account that's been invited to this private repo** (accept the emailed invite from step 2). Node ≥ 22 and Python ≥ 3.10 are checked by the bootstrap script — it prints the install command if either is missing, so you don't need them before cloning.
>
> **Step 0 — get the project onto your machine.** Clone the repo and `cd` into the folder it creates:
>
> ```sh
> git clone https://github.com/example-owner/example.git
> cd example
> ```
>
> **Then bootstrap** from inside that folder: `./scripts/setup-builder.sh` (macOS/Linux) — or `node scripts/setup-builder.js` (Windows, or any OS). It checks your toolchain, installs dependencies, and runs the same GitHub sign-in in one shot — no Claude-session juggling. Either route lands you in the same place.

## Your first task

Run `/builder-start` to see what you can claim — no acknowledgment step needed, the queue is open. New builders see only `newcomer_friendly` tasks — small, well-scoped, easy to finish in one sitting. Pick one that looks interesting, claim it with `/builder-claim N`, do the work, and ship it with `/builder-ship`.

When you ship your **first** task, example land in your column and you're inducted as a citizen of Example. Ship your **third** and you graduate to **Thetes** — the one-claim limit lifts and the whole general queue opens to you. Welcome.

## Previewing your change

Before you ship a change that touches the game, run **`/builder-stage`** to start your own private copy of the game on your computer (at `http://localhost:<port>`) with your current edits in it. Open the link, watch your change running for real, and only then ship it. Nothing you stage there touches the live game or anyone else's work.
