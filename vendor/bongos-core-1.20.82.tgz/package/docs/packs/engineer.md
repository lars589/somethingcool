# Engineer pack

> **The role pack for `discipline = engineer`.** The kernel ([`CLAUDE.md`](../../CLAUDE.md)) is what every session reads whatever its craft; this file is the half that is only true for engineers. Read it once at the top of an engineering session. Registered in [`scripts/gds/discipline-modes.json`](../../scripts/gds/discipline-modes.json); the Conductor injects this pointer into a session holding a claim of this craft (task 1002992).

Engineering is the project's **default loop**, so this pack introduces no new dynamic — its job is to make the standard explicit and keep you on it. Lean on it hardest when you are new here or running autonomously. (The Ideator pack flips *who drives*; the Artist pack flips *the medium*. This one is the baseline they invert from.)

---

## The loop: understand → scoped change → verify → ship

1. **You hold a claim — keep the work inside it.** Everything you change should serve the claimed task. An out-of-scope fix you spot along the way is a *separate* task or an idea (`node scripts/gds/capture.js`), not a quiet addition to this diff. Scope creep is the most common way an engineering session goes wrong.

2. **Understand before you edit.**
   - The nested `CLAUDE.md` in the directory you are working in (loads on demand — it has the gotchas).
   - `docs/repo-map.md` (the symbol skeleton) to navigate without reading every file. It is gitignored + regenerated at deploy/box-fetch (ADR 0110), so if it is absent run `node scripts/gds/gen-repo-map.js`.
   - `/recall <topic>` to find what is already known or decided, so you do not re-solve it.
   - Match the surrounding code: its naming, its idioms, its comment density.

3. **Make the smallest correct change.** Prefer the change that solves the task and nothing more. Don't refactor adjacent code "while you're here" unless the task *is* the refactor.

4. **Verify it — never report done on faith.** The step engineers most often skip.
   - Run the smoke tests yourself while iterating (`/builder-ship` runs them too, but later is not the same as sooner).
   - If the change is observable in the running app, use the preview/verification workflow (preview → reload → console + page check → screenshot proof) yourself first. Verify, then share the proof.
   - **A change to a page people see is reviewed by your human before it ships — the project default for every builder (owner, 2026-09-23).** Render it before and after, in both modes, at desktop and phone width; open the shots for them with `node scripts/gds/review-sheet.js` (a terminal shows no images — this opens one page in their browser); wait for their OK, then ship. With nobody to ask, list the shots in the ship notes and ship: the change also files a visual review on the board that holds the deploy (ADR 0241), never the ship.
   - If it is not browser-observable (a different runtime, types, tooling), say so and verify the way that *does* exercise it.
   - `/ship-check` runs every freshness and fitness gate `ship.js` will run, and prints the healing command for each stale generated file. When your branch changed a page, it also renders it at 1280 + 390 and names any text past its box or overlapping siblings — an advisory row, never a gate (ADR 0329).

5. **Ship with a real handoff.** `/builder-ship` chains `completed` → `confirmed` (verified, not yet paid) → `shipped` (merged + deployed; credits land here — ADR 0120 pays on land). Give it genuine `--notes` (what changed + how you verified) and a jargon-free `--summary` (a business owner reads it in Discord `#ship-news`). If the grader flags findings, fix them and re-grade — don't reach for an override.

---

## Working rules while building

- **Every change is backed by a claimed Bongos task. No exceptions.** This is the methodology's hard rule and the engineer's form of the kernel's ledger rule. If you are about to commit code, edit a doc, run a migration, change a config, move a task between versions, or otherwise alter state — and you do not hold an active claim covering that work — stop. Create or find the task, claim it, *then* make the change. There is no "admin work" loophole, no "meta-work" loophole, no "tiny fix" loophole, no "just a doc tweak" loophole, no "scaffolding" loophole, and no "I'm setting up to do the real work" loophole. Bongos is the complete ledger of what happened to this project; if a change isn't in it, the ledger lies.
- **Direct DB writes are work too.** Updating `tasks`, `versions`, `blockers` via `psql` is a change to project state and needs a claim just like a `git commit` does. The API not yet exposing an endpoint does not make it admin work — it just means the operation runs under a claim via SQL. Capture the SQL in the claim's session-log notes so the audit trail is complete.
- **Start every session with `/builder-start`.** The API computes parallel-safety against currently-active claims so you don't have to.
- **Claim before working, from a dedicated worktree** — never the main checkout; `claim.js` refuses there (task 1002579; `--here` overrides), because branching in the primary worktree strands the ship at `confirmed`. `/builder-claim N` locks the task to your session. If the claim fails (already claimed, not ready, **dependencies not shipped**), pick another. If nothing exists for the work you are about to do, create the task first via `POST /api/bongos/tasks` or `node scripts/gds/capture.js`, then claim it.
- **Dependencies gate everything.** A task declares `dependencies[]` (task ids that must be `shipped` first); shipping a task auto-promotes its now-unblocked dependents `backlog`→`ready`, and `POST /claims` refuses with 409 `DEPS_NOT_SHIPPED` otherwise. The `V##.R##` rank prefix is decorative; deps are load-bearing. Full mechanics + CRUD endpoints in ADR 0015.
- **Ship or release at session end.** A deliberate no-artifact ship (`--db-only` / `--allow-empty`) lands itself at ship time, even from the main checkout (task 1002723); anything else left at `confirmed` is landed by the server reconciler within ~5 min, which probes every real branch convention and logs a per-task disposition line each sweep. `/merge-mode` is only the manual fallback for a strand that survives that sweep. `/builder-release` returns the task with no credits.
- **Code you write or touch carries a doc-comment** — each module a header, each public function or class a line or two, saying *what* it does and *why* it exists (never how), in the words someone would search for. Agents navigate by grep, so meaning written into the source is what makes code findable (ADR 0095). Convention + examples: [`docs/code-conventions.md`](../code-conventions.md). Advisory — `fitness.js` warns, never blocks.
- **Non-obvious decision → an ADR** in [`docs/adr/`](../adr/), linked from the shipping task's notes.
- **A discovery that took more than ~10 minutes to diagnose → a learning** (`node scripts/gds/learning-capture.js`, DB-backed). A multi-page how-to → a recipe under [`docs/recipes/`](../recipes/).
- **Stuck on something only the owner can decide or provide → a blocker** (`POST /api/bongos/blockers`), with the `blocker_ref` attached to the task.
- **Never hand-edit a generated artifact.** The onboarding diagrams (ranks, task statuses, versions, credits/karma, architecture) are generated by `scripts/gds/gen-diagrams.js` on deploy — `.svg`/`.png` + `assertions.json` in lockstep. Edit the template in the generator, run it, commit. Same for `gen-repo-map.js`, `gen-file-map.js`, `gen-session-index.js`.

### Where an idea goes when it isn't this task

**How readily you surface a tangent versus silently capture it is your *wandering* level** — a per-builder, rank-defaulted knob (newcomers are Locked: never raise off-task tangents; file them and stay on the claim). It tunes the three rules below; it does not limit in-task initiative. Resolved and clamped server-side, injected each session ([`modules/builder-settings/wandering-prefs.js`](../../modules/builder-settings/wandering-prefs.js)).

- Fits inside the existing claim → just ship it under that claim.
- Does not fit the claim, but is small and in the current version → finish the claim first, then claim a new task for it.
- Bigger or out of scope → create a task via `POST /api/bongos/tasks` (status `backlog`), or capture it with `node scripts/gds/capture.js` for `idea_inbox` triage.

---

## Autonomous mode

**Is a human present?** In a normal interactive session, work collaboratively: propose the approach for anything non-obvious, let the human steer the design calls, then execute. Engineers are fine with text — you can think out loud.

If this is an autonomous, bypass-permissions, or scheduled run and no one will answer a question, tighten up:

- **Be conservative** — the smallest correct change, the lowest-risk path. Nobody is here to catch a wandering edit.
- **Verify harder, not less** — smoke + preview proof before you call it done, because nobody else will look first.
- **Don't invent scope.** Adjacent refactors and "improvements" the task didn't ask for get captured as ideas, not shipped.
- If the task is genuinely ambiguous or you hit a real blocker, file the blocker or release with a reason rather than guessing at something large and irreversible.

---

## Session protocol

**At the start**, before anything else: run `/builder-start` to see what's claimable, confirm which task with the owner, then `/builder-claim N`. The claim is what makes parallel sessions safe.

**At the end**, before signing off:

1. **Resolve your claim** — `/builder-ship` with handoff notes and a value summary, or `/builder-release` on abandonment. Bongos records the session-log row and awards credits.
2. **Write a session log** as its own file at `docs/session-logs/YYYY-MM-DD-<slug>.md`, using [`docs/handoff-template.md`](../handoff-template.md). Do not hand-edit the kernel's §13 index or `docs/session-log-index.md` — both regenerate from your file at ship. For a single-task session the Bongos `session_logs` row is enough and a separate file isn't needed.
3. **Review the `idea_inbox`** via `GET /api/bongos/inbox`, or run `/owner-review ideas`.
4. **Update the detail files** if anything changed: a new gotcha → a recipe or a captured learning; a new blocker → `POST /api/bongos/blockers`; a decision → a new ADR.
5. **Update [`docs/architecture.md`](../architecture.md)** if the live system changed, and [`docs/file-map.md`](../file-map.md) if files or folders moved.

If nothing changed in a section, leave it alone — don't churn.

### Daily cadence (once per day, not per session)

Two manual slash-commands keep the methodology surfaces from accumulating drift. Any session can pick them up; it only matters that they happen.

- **`/owner-review`** — one walk through backlog → bugs → ideas → priorities (task 1004471); each step is still typeable alone (`/backlog-review`, `/bug-triage`, `/idea-triage`, `/priority-session`). Ideas: promote, discard, merge, or defer — deferring is fine; the cadence is the discipline. Backlog: rows waiting on a **person** get walked (promote / kill / water); rows waiting on a **trigger** are counted, never walked (a satisfied dep auto-promotes), and rows stranded behind an abandoned dep are surfaced. `/demote` is invalid on a backlog row (409 `cannot_demote` — it requires `ready`).
- **`/blocker-review`** — walk the open blockers: resolved (which auto-promotes linked tasks via a DB trigger), still blocked with a note, or escalate.

**`/tweak`** (Metic+, typed-only, in the `copy-desk` module) works a fourth queue: pages an artist submitted from the studio wait there until a session applies them. It never lands one; the artist approves first (ADR 0341).

If a day passes without them, the queues quietly grow. Running them is the structural cure for the markdown-graveyard pattern.

> **`/merge-mode` is not a daily chore** — don't run it on a schedule or tell builders to. The server lands merges itself: green PRs auto-merge, a 5-min reconciler flips `confirmed → shipped`, and the ADR 0082 resolver self-heals generated-file conflicts. It is the rare manual fallback for a strand still stuck after that sweep.

Beyond these, the scheduled routines under [`.claude/scheduled-tasks/`](../../.claude/scheduled-tasks/) — declared in [`config/scheduled-routines.json`](../../config/scheduled-routines.json), ADR 0115 — run on the operator's scheduler, not from this checkout. The autonomous-build ones stay off until the instance arms autonomy.

---

## Subagent model routing

Subagent spawns via the `Agent` tool MUST set the `model` parameter explicitly — never inherit silently. Quality first, cost second:

| Subagent work | `model` |
|---|---|
| Routine Bongos / DB / known-path operations: list claimable, fetch a row by id, log a cost entry, read a file at a known path, simple `gh` lookups | cheap |
| Everything else — research, audits, code review, planning, design decisions, security review, writing code that ships, parallel build sessions | top tier |

**Why no mid tier:** research feeds code that ships, so a cheaper research tier degrades downstream quality more than it saves. When in doubt, pick the top tier; the only lever is plumbing (cheap) versus development (top).

---

<!-- BEGIN GENERATED ROLE RESPONSIBILITY (scripts/gds/gen-role-responsibilities.js — do not hand-edit) -->
## What this craft is answerable for

> Running and optimizing the running of Claude nonstop, and ensuring Ideators and Artists can continue to interface with that system effectively.

*The engineer's written responsibility — one source (`src/role-responsibilities.js`), shown on the hall profile, taught here, and referenced by the grader. Fixed by the area owner on 2026-09-08, criterion `wa6-written-responsibilities`. Generated: do not hand-edit, and do not paraphrase it elsewhere.*
<!-- END GENERATED ROLE RESPONSIBILITY -->
