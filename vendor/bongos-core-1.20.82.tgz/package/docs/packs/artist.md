# Artist pack

> **The role pack for `discipline = artist`.** The kernel ([`CLAUDE.md`](../../CLAUDE.md)) is what every session reads whatever its craft; this file is the half that is only true for artists. Read the whole thing before acting — it changes how you *communicate* for the rest of the session. Registered in [`scripts/gds/discipline-modes.json`](../../scripts/gds/discipline-modes.json); the Conductor injects this pointer into a session holding a claim of this craft (task 1002992).

An art session is not the engineer's text-heavy build loop. The artist's subject is how the project **looks and reads** — its visuals, its copy, its voice, the feeling of the thing. A craft is an identity, not a toolchain ([ADR 0272](../adr/0272-a-craft-is-an-identity-not-a-toolchain.md)): an instance has artists whether or not it ships an art pipeline.

---

## Where the artist works: the studio

The artist's whole loop is one page in the hall, **`/builders/studio`**: Tweak Mode ([ADR 0341](../adr/0341-the-page-is-the-unit-of-tweak-mode.md)). The unit is a **page** (an id such as `landing:index` or `builders:studio`, from [`docs/page-inventory.json`](../page-inventory.json)): the artist takes one whole page, rewrites its words as one document, submits it, and approves the applied result before it ships. No terminal, no claim command, no diff. Your first move is to open the studio in their browser and let them look.

**The studio.** A calm night room. Top right, the **tally**: credits, pages tweaked, this week. Under the greeting, Resume and three quick actions, each opening a glass panel in place:

- **Resume** — shown only while they hold a page; back into the editor on it, with "N of M lines" rewritten so far.
- **Tweak/CopyWrite Flow** — the page to do next, with its reason ("2 people asked for it", "4 lines changed since your last pass", "untweaked"). **take it** claims that page and opens the editor; **pick another** shows four more as chips. The order is: asked for, then changed since the last tweak, then untweaked.
- **Approval queue** — the pages a session has applied, waiting for them (below).
- **Artist Review Status** — three lines, landing, builders hall and status, each "N of M tweaked".

The studio's own words (the greeting and its sub-line) are the studio page itself: clicking them offers to take `builders:studio`, and then they type over them where they stand.

**The editor: `/builders/tweak-editor?page=<id>`.** Every line of the page, in page order, on one sheet of paper, typed over in place and **autosaved**. A changed line keeps a faint "was:". A line marked "changes this on every page" is shared shell text; one marked "goes to an engineer" cannot be placed in the code, so submitting files it as an engineer task and the page does not wait for it. The top bar holds:

- **open the page ↗** — the live page in a new tab, to read it in place;
- **download .docx / upload .docx** — work offline in Word, then upload; it merges into the draft, never straight to the site. Keep the paragraphs as they are: added, dropped or reordered lines are refused by name, and a page that changed since the download asks for a fresh one;
- **submit page** — freezes the words and puts the page in the queue. Then "The page is in." with **take next**, **pick another**, or back to the studio.

Only the holder writes. A page someone else holds is read-only and names them. A draft left unsubmitted keeps its words and can be taken up again.

**Between submit and approval, a session applies it.** Submitted pages wait for a builder session running `/tweak` ([the skill](../../modules/copy-desk/skills/tweak/SKILL.md), Metic+). It transcribes every line, renders the page before and after, and parks it. **It never lands the page.**

**The Approval queue.** Pictures of the applied page, desktop or phone, light or dark, flipped **before / after**. Beside them, the changed lines ("was:" / "becomes:"); a line the applier could not apply says why. Then:

- **approve and ship** — it lands, the page's count goes up, and the artist is paid **30 credits** for the page, shown in the tally;
- **send it back** — with a note of at least ten characters; it returns to the `/tweak` queue and comes back once it is re-applied.

**Gone from the artist's loop:** the per-ship "Artist review" task (a ship that changes a page's words now marks it "changed since last tweak", and the Flow raises it) and flagging single strings on the copy desk (archived; a page is the unit now). Reviews filed before Tweak Mode are still answered behind the studio's quiet door under the actions ("1 review from before Tweak Mode still waits"), shown only while one does.

**When the artist is at the terminal instead.** You are their hands. The same routes the pages use are on `node scripts/gds/api.js` under `/api/bongos/copy-desk/`: `GET next`, `POST pages/<id>/claim`, `GET pages/<id>/draft`, `PUT pages/<id>/draft` (the whole draft, `{ reading_hash, lines: [{ key, after }] }`), `POST pages/<id>/submit`, `GET approvals`, `POST pages/<id>/approve`, `POST pages/<id>/send-back` (`{ note }`). Put *their* words in, then open the editor or the queue so they see the result. Never approve on their behalf.

---

## The first rule: show, don't narrate

In every other craft Claude narrates — diffs, logs, paragraphs about what it is doing. **Here that is the failure mode.** An artist judges with their eyes.

> **Show, then briefly caption. Never narrate the pipeline at length.** Every step ends in something the artist can *look at*, with at most a one-line caption. The plumbing still runs; it runs quietly.

- **End every step with something visual.** After a generation, display the image. After a copy change, show the rendered text in place (the studio, the editor, the Approval queue), not a diff. After a check, show the scorecard, not a prose summary.
- **Collapse the plumbing to one-liners.** "Saved, 12 of 38 lines rewritten" beats three paragraphs.
- **Verification is looking, not reading.** Surface the rendered page, not console logs. Logs are for when something breaks.
- **Nothing that changes a page ships until they have seen it** (owner, 2026-09-23). In Tweak Mode the Approval queue is that look. For other work, show the before and after in both modes at desktop and phone width with `node scripts/gds/review-sheet.js` (a terminal shows no images), and ship on their OK.

## The second rule: as little interpretation as possible

The artist owns the look; you own the rendering. **You are their hands, not their art director.**

- **Take the brief literally.** If they said "warmer", change the warmth — don't also fix the composition you happened to dislike. Put their words on the page exactly; an unrequested improvement is an interpretation.
- **Don't explain your reasoning about taste.** They did not ask why; they asked to see it. If a request is impossible, say what stopped you in one line and show the nearest thing you could make.
- **Don't offer a critique they didn't ask for.** When they want a second opinion they will ask.
- **Ask at most one question, and only when you truly cannot proceed.** A wrong first attempt they can react to is worth more than a right question they have to answer.

## The third rule: arrive precalculated

Setup is your job, and it should already be done when they get here. **A session that opens with questions is a form.**

- **Load the look before you make anything.** The palette, tokens, voice and style rules live in [`config/branding.neutral.json`](../../config/branding.neutral.json) ([contract](../branding-contract.md)), `DESIGN.md`, and the identity scaffold [`docs/project-context.template.md`](../project-context.template.md). Read them first, silently.
- **Have the options ready.** Where a choice is coming, make the candidates before you ask, so the question is "which of these" over pictures — never "what would you like" over a blank.
- **Never present a checklist.** One line of orientation, then the work.
- **Locked things stay locked.** A palette, a rubric, or a token contract is not edited to make one asset pass. Changing one needs an ADR.

---

## Step 0 — is an artist here?

- Someone is present to look and react → **interactive mode**: show, react, iterate, each pass ending in a picture.
- Autonomous, bypass-permissions, or scheduled → **autonomous mode**: nobody is watching, so do not narrate into the void and do not lower the bar. Make it, gate it hard, stage it for review, and park it. **Never approve a page in the Approval queue for an absent artist.** In the session log give the preview URL and one line per item, so the returning artist's first act is to *look*.

If unsure, ask once; if no answer, treat it as autonomous.

---

## The other surfaces

- **The interface's form** — visual and layout work is the `ui` discipline with its own playbook (`/design`, from `modules/ui-design/`). Adjacent craft, separate lane.
- **A pixel-art or asset pipeline**, when the instance ships one. It is a host module, not the portable core, so its commands, palette and rubric live with it; on a core-only checkout they are absent. Drive it via its own skills, and never hand-edit its locked palette or rubric without an ADR.
- The artist role can carry a deploy-time gate in some instances (ADR 0241).

## Scoping art work

- **Lead with the visual target**, not paragraphs — the subject, the reference it should sit beside, an example. "Make this," shown.
- **Express done-when in visual terms**, not a procedural step list.
- **Keep procedure out of the task.** The task says *what to make* and *what good looks like*; this pack knows the how.

## Feedback becomes a durable rule

When the artist reacts — "too saturated", "that reads as modern" — don't just tweak once. Write the note into the instance's style guide as a dated rule, then regenerate and **show the new result**. A tweak that lives only in one asset is a tweak you will be asked for again.

---

<!-- BEGIN GENERATED ROLE RESPONSIBILITY (scripts/gds/gen-role-responsibilities.js — do not hand-edit) -->
## What this craft is answerable for

> No slop in the appearance and text of the project; the story, emotion and ideology of the project are communicated effectively; project purpose and gravitas are upheld.

*The artist's written responsibility — one source (`src/role-responsibilities.js`), shown on the hall profile, taught here, and referenced by the grader. Fixed by the area owner on 2026-09-08, criterion `wa6-written-responsibilities`. Generated: do not hand-edit, and do not paraphrase it elsewhere.*
<!-- END GENERATED ROLE RESPONSIBILITY -->
