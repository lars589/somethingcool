# Recipe — the Render pilot, on a throwaway `mercury` clone

The executable half of [task 1004142](https://cloudbongos.com/builders#/task/1004142): stand one Bongos instance up on Render, end to end, and answer the questions [task 1004183](https://cloudbongos.com/builders#/task/1004183) (the standup leg) will be written against. Governed by [ADR 0327](../adr/0327-a-cloud-host-runs-on-the-owners-account-and-the-key-is-borrowed.md); platform choice from [ADR 0323](../adr/0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md).

**Who runs this.** Whoever holds the Render key — under ADR 0327 that is the *project owner*, and for the pilot it is the platform owner. An agent session cannot run it unless someone has put a key in front of it, and a key must never be pasted into a chat.

**The API shape below was read from Render's own reference on 2026-09-23** (`api-docs.render.com`), not inferred. Where this recipe and a live response disagree, the response wins and this file is the bug.

> **Corrections, checked against mercury's vendored core (1.19.305) on 2026-09-28 (task 1004142).** Six things in §4–§6 below would have failed on the real repo; §4's payload now carries all of them, and the list says why. Where the prose below still disagrees with this box, this box wins:
>
> 1. **There is no `npm start`.** An adopted instance's `package.json` has only the `@bongos/core` dependency, no scripts. The start command is `node node_modules/@bongos/core/src/platform-server.js`, the same thing the box's unit runs (`serviceUnit` in `scripts/gds/provision-units.js`). Set it explicitly, because the repo's `Procfile` starts the owner's Python app.
> 2. **The env prefix is the instance's own pack, not the neutral one.** mercury's `config/branding.json` pins `envPrefix: "CLOUDBONGOS"`, so every `BONGOS_*` in §4 and §5 is `CLOUDBONGOS_*` for this repo. A wrong prefix is silently ignored and the hall never loads.
> 3. **Set `BUILDER_SECRET_KEY`.** Without it `src/bongos/secret-box.js` falls back to a key file in the config home, and Render wipes the disk on every deploy. Each deploy would mint a new key and orphan every stored per-builder secret. A random 32-byte hex value held in Render's env is enough.
> 4. **Migrations run as Render's pre-deploy command**, as `bash node_modules/@bongos/core/scripts/migrate.sh`. `migrate.sh` addresses the database as `psql -d "$PGDATABASE"`, so set `PGDATABASE` to the same connection URL as `DATABASE_URL`. Whether Render's Node runtime ships `psql` is one of the things the pilot measures.
> 5. **The OAuth callback is `<origin>/api/gds/auth/web/callback`** — what `GET /api/gds/auth/web/start` actually sends (`src/bongos/routes/auth.js`). The `/builders/auth/github/callback` in `src/bongos/auth.js`'s header comment is stale; GitHub refuses it with "redirect_uri is not associated with this application". If the sign-in app is a GitHub App rather than an OAuth App, its Callback URL field must be filled in too, or GitHub answers "must be configured with a callback URL". Also set `NODE_VERSION=22`, because the core declares `engines.node >=22`.
> 6. **Set `HOST=0.0.0.0`.** `src/platform-server.js` binds `127.0.0.1` unless `HOST` is set. On the box Caddy is on the same machine, but Render's router is not: the server logs "listening", the health check never reaches it, and the deploy sits at `update_in_progress` while the URL answers `502` with `x-render-routing: no-deploy`. Measured live 2026-09-28.
>
> **One more, about §2: clone a stripped copy, not the whole repo.** §2's full clone would copy willHermesLines' warehouse application into a repo they never agreed to. The pilot needs only the Bongos layer (`package.json`, the lockfile, `vendor/*.tgz` and `config/`), plus the `Procfile` and a stub `app.py` so the hybrid shape is kept. Twelve files are enough.
>
> **What the 2026-09-28 run actually did.** The owner chose to deploy from `willHermesLines/mercury_bongos` itself instead of a clone. That is safe in a narrower sense than a clone: Render only *reads* the repo, the service and its database are new, and live `mercury` (row 31) is untouched. But it needs the platform owner to have Render access to someone else's private repo, which a real customer standup will not have. Both paths are valid for a pilot. The stripped clone is the one to use when you don't have that access. The `envPrefix` above is mercury's; a greenfield instance on the neutral pack uses `BONGOS_*`.

---

## 0. Before you start — three things worth knowing

**The pilot costs money, and the free tier cannot prove it.** Done-when clause 4 is "its database is backed up by Render rather than by our timer". Render's **free Postgres has no backups of any kind** — no logical backups, no PITR. Only paid databases are continually backed up (3 days of recovery window on Hobby, 7 on Pro). So the pilot must run a **paid** Postgres or clause 4 is unprovable. Budget `0.1c-256mb` ($6/mo) + `0.5c-512mb` web ($7/mo), prorated for the hours the pilot is up, and tear it down when finished.

**The key is account-wide, not workspace-wide.** `GET /owners` returns every workspace the key's *user* can reach, including other people's teams. This is the finding that produced ADR 0327, and step 1 exists to confirm it on live responses before anything is created.

**Do not touch live `mercury`.** Row 31 is a real owner's project, serving from our box today. Clone its *repo* to a scratch repo under an account we control, and stand the clone up under a scratch slug. Nothing in this recipe writes to row 31, to `willHermesLines/mercury_bongos`, or to that owner's Render account.

Set up once:

```bash
export RENDER_TOKEN=...   # in your shell, not in a file, not in chat
export R="curl -sS -H \"Authorization: Bearer $RENDER_TOKEN\" -H 'Content-Type: application/json'"
```

Base URL is `https://api.render.com/v1`; auth is `Authorization: Bearer <key>`.

---

## 1. The `ownerId` guard — confirm the finding BEFORE creating anything

This is the pilot's most important output, because every call the standup leg later writes depends on it.

```bash
curl -sS -H "Authorization: Bearer $RENDER_TOKEN" https://api.render.com/v1/owners | jq
```

Each element is `{ owner: { id, name, email, type }, cursor }`, where `type` is `user` or `team`.

**Record:** how many workspaces come back, which are not ours, and their ids. Then pick the Bongos workspace's `id` and pin it:

```bash
export RENDER_OWNER_ID=...
```

**Then prove the hazard rather than assuming it.** List a resource *without* `ownerId` and check whether another workspace's resources appear:

```bash
curl -sS -H "Authorization: Bearer $RENDER_TOKEN" 'https://api.render.com/v1/services?limit=100' \
  | jq '[.[].service | {id, name, ownerId}] | group_by(.ownerId) | map({ownerId: .[0].ownerId, n: length})'
```

If more than one `ownerId` comes back from a key that was only ever meant for one workspace, the finding is confirmed and the guard is mandatory. **Record the actual output either way** — a negative result is just as useful and would narrow ADR 0327's §"required guard".

**The rule the standup leg must implement, whatever this shows:**

- Send an explicit `ownerId` on every call. It is *required* on `POST /services` and `POST /postgres`, and it is *optional* on the list calls — which is exactly where the hazard lives.
- Assert `ownerId` on the **response**, not the request. A request you got right tells you nothing about a response that came from elsewhere.
- Treat missing or mismatched as a hard error. Never default it, and never derive the workspace by taking the first element of `/owners`.

---

## 2. Clone the repo

`mercury`'s instance row carries `target_ref=willHermesLines/mercury_bongos` and `onboard_mode=adopt`. Clone it to a scratch repo you own — this is the pilot's subject and it is disposable.

```bash
git clone https://github.com/willHermesLines/mercury_bongos /tmp/mercury-clone
cd /tmp/mercury-clone && git remote remove origin
gh repo create <you>/render-pilot --private --source=. --push
```

**Record:** whether the repo is public or private, and under which account. That feeds the open question in step 5.

---

## 3. Create the Postgres

```bash
curl -sS -X POST -H "Authorization: Bearer $RENDER_TOKEN" -H 'Content-Type: application/json' \
  https://api.render.com/v1/postgres -d '{
    "name": "render-pilot-db",
    "ownerId": "'"$RENDER_OWNER_ID"'",
    "plan": "basic_256mb",
    "region": "virginia",
    "version": "16"
  }' | jq
```

`plan`, `ownerId`, `name` and `version` are all required. `databaseName` and `databaseUser` are generated if omitted. **`plan` must not be `free`** — see §0. Region `virginia` is the closest US region to the current droplet (`PROVISION_REGION=nyc3`).

Then read the connection string:

```bash
curl -sS -H "Authorization: Bearer $RENDER_TOKEN" \
  https://api.render.com/v1/postgres/<postgresId>/connection-info | jq
```

Returns `password`, `internalConnectionString`, `externalConnectionString`, `psqlCommand`, and optionally the pooled variants. **Assert the `ownerId` on the create response before going further.**

---

## 4. Create the web service

Bongos reads `DATABASE_URL` first and falls back to the `PG*` family (`src/bongos/pool.js:56`), so Render's connection string wires in directly — **none of the `PGHOST`/`PGDATABASE`/`PGUSER`/`PGPASSWORD` lines `webEnvBody` writes on the box are needed here.** That is the single biggest simplification Render buys, and it is worth stating in the standup leg's comments.

The env prefix is **`BONGOS`** (`config/branding.neutral.json` → `envPrefix`). The variables below are the Render translation of `webEnvBody` in `scripts/gds/provision-units.js:192` — read that function, not this list, if the two ever disagree.

```bash
curl -sS -X POST -H "Authorization: Bearer $RENDER_TOKEN" -H 'Content-Type: application/json' \
  https://api.render.com/v1/services -d '{
    "type": "web_service",
    "name": "render-pilot",
    "ownerId": "'"$RENDER_OWNER_ID"'",
    "repo": "https://github.com/<you>/render-pilot",
    "branch": "main",
    "autoDeploy": "yes",
    "serviceDetails": {
      "runtime": "node",
      "plan": "starter",
      "region": "virginia",
      "healthCheckPath": "/healthz",
      "envSpecificDetails": {
        "buildCommand": "npm ci",
        "startCommand": "node node_modules/@bongos/core/src/platform-server.js",
        "preDeployCommand": "bash node_modules/@bongos/core/scripts/migrate.sh"
      }
    },
    "envVars": [
      { "key": "NODE_VERSION",            "value": "22" },
      { "key": "HOST",                    "value": "0.0.0.0" },
      { "key": "DATABASE_URL",            "value": "<internalConnectionString>" },
      { "key": "PGDATABASE",              "value": "<internalConnectionString>" },
      { "key": "PGPOOL_MAX",              "value": "5" },
      { "key": "BUILDER_SECRET_KEY",      "value": "<64 random hex chars>" },
      { "key": "CLOUDBONGOS_GITHUB_CLIENT_ID", "value": "" },
      { "key": "CLOUDBONGOS_GITHUB_CLIENT_SECRET", "value": "" },
      { "key": "CLOUDBONGOS_FIRST_ADMIN", "value": "<your-github-login>" },
      { "key": "CLOUDBONGOS_PUBLIC_ORIGIN",   "value": "https://render-pilot.onrender.com" },
      { "key": "CLOUDBONGOS_BUILDERS_ORIGIN", "value": "https://render-pilot.onrender.com" },
      { "key": "CLOUDBONGOS_STATUS_ORIGIN",   "value": "https://render-pilot.onrender.com" },
      { "key": "CLOUDBONGOS_OAUTH_ORIGIN",    "value": "https://render-pilot.onrender.com" }
    ]
  }' | jq
```

Notes that matter:

- **`PORT` is not set by us.** Render injects it; `webEnvBody` writes it because the box allocates ports itself. One more line the standup leg drops.
- **The four origin overrides are load-bearing, not cosmetic.** Without them `src/branding.js` stays on neutral localhost and the hall never loads (task 1972). They must be the Render hostname, and they must all four be the same host — a single-host instance has no separate `builders.`/`status.` subdomain.
- **`CLOUDBONGOS_FIRST_ADMIN` is what seats you as Archon** on first sign-in. Omit it and the instance has no owner and you can never claim it (the 2026-07-07 `demo` regression).
- **OAuth creds start blank** and are filled after the app exists — see step 5.
- `PGPOOL_MAX` is read bare and still applies. On `basic_256mb` the connection ceiling is low; if the app struggles to connect, set it small (the box uses `PROVISION_INSTANCE_PGPOOL_MAX`).
- Do **not** send a `secretFiles` entry for the GitHub App PEM until you know whether the App path is in scope for the pilot; blank OAuth is enough to prove boot.

---

## 5. Sign-in, and the open question the pilot exists to answer

Create a GitHub OAuth app (or App) whose callback is the Render hostname, then set `BONGOS_GITHUB_CLIENT_ID` / `_SECRET` via `PATCH /services/{id}/env-vars/{key}` and redeploy.

**The question ADR 0327 left for this pilot:** can Render's GitHub App reach a repo under a **personal** account rather than an org, and what does that mean for a project whose repo we do not own? Record:

- Which GitHub account/org the pilot repo sits under, and whether Render's GitHub App installed onto it without friction.
- Whether a *private* repo under someone else's personal account is reachable at all.
- What the owner has to click, since under ADR 0327 the repo and the Render account are both theirs.

This is the answer that decides whether `cloud-host` standup is one API sequence or a sequence plus a human step — and therefore how much friction `cloud-host` actually removes over `byo-host`.

---

## 6. Migrations

Run `migrate.sh` against the Render database. Prefer a Render **job** or the service's own shell over your laptop, so the run happens from inside Render's network on the `internalConnectionString`; the `externalConnectionString` works from outside but is not what production will use.

Then confirm no schema lag:

```bash
curl -sS https://render-pilot.onrender.com/version | jq
```

---

## 7. Custom domain (optional for the pilot, required for the model)

ADR 0323 keeps **Cloudflare DNS as the front door** and drops the Caddy site block, because Render terminates TLS. Prove the chain end to end at least once:

```bash
curl -sS -X POST -H "Authorization: Bearer $RENDER_TOKEN" -H 'Content-Type: application/json' \
  https://api.render.com/v1/services/<serviceId>/custom-domains -d '{"name": "render-pilot.cloudbongos.com"}' | jq
```

Then point the Cloudflare record at Render and confirm the response header is **no longer `via: 1.1 Caddy`** — that header is precisely how we established the live `mercury` instance is still on our box, and its absence is the cleanest proof the front door moved.

---

## 8. Capture the evidence — the five done-when clauses

Record each in the session log, with the actual output, not a claim that it worked:

| # | Clause | Evidence |
|---|---|---|
| 1 | Boots | `GET /healthz` → 200, and the header does **not** say `via: 1.1 Caddy` |
| 2 | Signs in | the OAuth round trip completes and seats you as Archon |
| 3 | Migrations run | `migrate.sh` completes; `/version` reports no schema lag |
| 4 | **Render backs up the DB** | a backup exists in Render's dashboard/API that we did not create — this is the clause that retires `provision-units.js`'s backup service + timer, and it needs a **paid** database |
| 5 | GitHub App reach | written answer to §5 |

Plus the three the standup leg is written from: the **exact call sequence** above with real request/response shapes, the **`ownerId` guard's live behaviour** from §1, and whether the **default plan sizes** held or mercury's larger choice was right.

---

## 9. Tear the clone down

The pilot is disposable and it is costing money. Delete the web service, delete the Postgres, delete the scratch repo, and remove the Cloudflare record if you made one.

**Note the asymmetry deliberately:** you are deleting resources in *your own* account, by hand. ADR 0327 decision 3 says the platform must never hold the ability to destroy infrastructure it does not own — `provision-teardown.js` retargets to *forgetting*, not to a Render delete call ([task 1004183](https://cloudbongos.com/builders#/task/1004183)). The fact that this step is manual is the design working, not a gap in it.

---

## Sources

- [Render API reference](https://api-docs.render.com/reference/introduction) — endpoints, required fields, plan and region enums, read 2026-09-23
- [Render Postgres Recovery and Backups](https://render.com/docs/postgresql-backups) — free plans have no backups; paid plans get PITR with 3-day (Hobby) / 7-day (Pro) windows
