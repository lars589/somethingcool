# Recipe — deploying a Cloud Bongos instance on a pinned core (`git reset` → `npm ci`)

> ADR [0108](../adr/0108-instance-composition-configurable-root.md) §4 (configurable-root W4, task [#1884](https://example.com/builders#/task/1884)). How a **consumer instance** — one that installs `@bongos/core` as a versioned npm dependency rather than living in the monorepo — deploys. This is the target the live droplet deploy converts to; the reference implementation is `scripts/deploy/deploy-instance.sh` (instance-side).

## The two models

| | Pre-split (today, `example`) | Post-split (consumer instance) |
|---|---|---|
| Core code | in-tree (the monorepo) | `node_modules/@bongos/core` (a pinned version) |
| Deploy | `scripts/deploy/deploy-prod.sh` (instance-side): `git reset --hard origin/main` on a shared checkout | `scripts/deploy/deploy-instance.sh` (instance-side): `git pull` the instance repo → `npm ci` → migrate → restart |
| Upgrade the core | (n/a — one tree) | bump the pin in `package.json` → `npm ci` → migrate → restart (ADR 0108 §4; the R86 channel, task [#1690](https://example.com/builders#/task/1690)) |
| `cloudbongos.com` | a 2nd service on the **same** checkout (why it ran stale) | its **own** consumer repo + its own `deploy-instance.sh` |

## The flow (`deploy-instance.sh`)

1. **`git pull --ff-only origin main`** the *instance* repo — host content only: `config/`, `migrations/instance/`, and the pinned core version in `package.json`.
2. **`npm ci --omit=dev`** — installs the pinned `@bongos/core` + instance deps. This is what replaces `git reset --hard`: the core is a dependency, so an upgrade is a pin bump + `npm ci`, not a source merge.
3. **`sh <core>/scripts/gds/deploy-main-audit-gate.sh`** — the SEC #863 gate (ADR 0043). Refuses the deploy if a below-Metic author touched a permission-sensitive path in the delta being deployed, and on refusal **restores the checkout** to the previously-deployed SHA. See below; it is not optional and it is not last.
4. **`bash <core>/scripts/migrate.sh`** — the core's **three-root** migrate (W5 / ADR 0108 §5) merges `<core>/migrations` + `<instance>/migrations/instance` + each enabled module's migrations, keyed by namespaced filename stems (`core_NNN_`, `<key>_NNN_`, bare instance) so the two repos never collide. It resolves core-root vs instance-root via `src/instance-config.js`.
5. **restart the platform** — a systemd unit runs `node <core>/src/platform-server.js` (Bongos-only) with `WorkingDirectory` = the instance root (so `resolveInstanceRoot()` resolves to the instance) + `PORT`/`HOST` env; then poll `/healthz`.

`docker-compose.yml` + `.github/workflows/selfhost-boot.yml` already model this shape (fresh Postgres → `npm ci` → `migrate.sh` → `platform-server`), so the flow is validated end-to-end there.

## The audit gate: where it goes, and why exactly there

**Between `npm ci` and `migrate`.** Both neighbours are load-bearing (task 1001426):

- **After `npm ci`**, because the gate runs `main-audit.js` out of the core it is deploying. Run it before the install and it audits with the *previous* core's copy — which, until this task, had a `--db` roster read pointing at a function the per-domain `db.js` carve had moved, so it resolved nobody and passed everything.
- **Before `migrate`**, because nothing from the new commit has EXECUTED yet at that point. `npm ci` installs; `migrate` and the restart are what run. A gate placed after either of them is a report, not a gate.

**The deployed marker is the checkout's HEAD, and it advances only on success.** There is no marker file. The gate can only audit what was pulled, so the tree has already moved when it runs; if a refusal left it moved, the next deploy would compute its "previously deployed" SHA from the refused commit, never re-audit that delta, and find it already checked out. So the gate resets the tree back to `OTB_DEPLOY_PREV_SHA` before exiting non-zero. That restore lives inside the gate rather than in each caller's `~/deploy.sh`, so a new caller cannot forget it. `tests/deploy_audit_gate.mjs` pins it.

Capture the previous SHA **before** the pull:

```sh
PREV_SHA="$(git rev-parse HEAD)"          # BEFORE git reset/pull
git reset --hard origin/main
npm ci --omit=dev
export OTB_DEPLOY_PREV_SHA="$PREV_SHA"
sh node_modules/@bongos/core/scripts/gds/deploy-main-audit-gate.sh || exit 1
```

**`OTB_AUDIT_STRICT` stays off.** Ranks resolve on `github_login` only — deliberately, since `display_name` is builder-controlled and keying it let one builder alias another's rank. A deploy lane whose commits are authored under a human display name (`Firstname Lastname`) rather than the builder's `github_login` therefore resolves to nothing, and strict would refuse every deploy forever. Non-strict still hard-blocks the incident class this exists for: a *resolved* below-Metic author on a protected path. Turn strict on once the lane commits under logins.

**Known limit, stated rather than buried.** If the roster cannot be read at all, every author is unresolved and non-strict passes. `main-audit.js` now announces that loudly and falls through to the public roster instead of silently returning an empty map. Availability is chosen over a hard stop on purpose — a database blip must not freeze deploys — so read the stderr.

## Status — ready, not yet the live path

`deploy-instance.sh` is **additive and inactive**: the live `example` droplet still deploys via `deploy-prod.sh` (`git reset --hard`). The cutover is deliberately deferred:

- **First run: Mercury (R85, task [#1689](https://example.com/builders#/task/1689))** — a greenfield consumer on a pinned core proves the flow.
- **`example` cutover: R89 (task [#1728](https://example.com/builders#/task/1728))** — "Example splits last", **behind a security review** (ADR 0108 §6). It **must** land in lockstep with cutting the shared-checkout dual-instance deploy, or `cloudbongos.com` breaks (ADR 0108 §Consequences item 2).

`ship.js` needs no change: its deploy **trigger** SSHes `~/deploy.sh` (or fires the CI workflow) and is agnostic to what that script does internally — a consumer instance installs `deploy-instance.sh` as its `~/deploy.sh`.

**The audit gate is the exception, and it is live.** Do not read the paragraph above as covering it: the deferred thing is the `deploy-instance.sh` *model*, not the gate. The gate was wired into `cloudbongos.com`'s existing `~/deploy.sh` under task 1001426 — between its `npm ci` and its `migrate`, with the previous SHA captured before the pull — and verified both ways against that real script on a throwaway clone. That host's `~/deploy.sh` is host state and lives in no repository, so **this diff is not where you can see it**; the wiring, its backup path and its one loose end are recorded on the task. The loose end: until a core carrying `scripts/gds/deploy-main-audit-gate.sh` is published and pinned there, the host runs a byte-identical transitional copy beside `~/deploy.sh`, and `deploy.sh` prefers the core's copy the moment it appears.

## Wiring it on a consumer host (R85/R89)

1. Install the script as the droplet's `~/deploy.sh` (the CI deploy key is forced-command-locked to `~/deploy.sh` — ADR 0043 — so it stays hand-installed, like `deploy-prod.sh`).
2. Create a systemd unit for the instance: `ExecStart=/usr/bin/node <instanceRoot>/node_modules/@bongos/core/src/platform-server.js`, `WorkingDirectory=<instanceRoot>`, `Environment=PORT=… HOST=127.0.0.1 <PREFIX>_INSTANCE_ROOT=<instanceRoot>`.
   **`bongos serve` now writes exactly this unit for you** (plus the DB/migrate/health legs) — see [`server-bring-up.md`](server-bring-up.md) / [ADR 0169](../adr/0169-bongos-serve-server-bring-up.md). Step 5 of the flow above ("restart the platform") is `systemctl restart bongos-<db>` once it has.
3. Set `INSTANCE_SERVICE=<unit>` + `PORT=<port>` in the deploy environment.
4. Front it with TLS and point the origins at the real domain (see [self-host.md](self-host.md)).
