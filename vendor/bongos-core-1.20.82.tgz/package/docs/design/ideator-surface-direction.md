# Design direction — the ideator surface

> **Status:** agreed 2026-09-19 with the area owner. Planning session meta task 1004076; the decisions live on idea 1001072; the scope is `docs/specs/<redacted>.md`.
>
> This file is the **visual** half. The spec is the build; the criteria on goal 1000095 are the done-when. Where this file and the spec disagree about behaviour, the spec wins; where a criterion and either of them disagree, the criterion wins.
>
> **Superseded for the sky (2026-09-24).** The Sky artboard in [`mocks/ideator-surface/`](mocks/ideator-surface/) is superseded by the adopted prototype at [`mocks/sky/`](mocks/sky/), which is the design of record and the pixel contract for the build ([ADR 0331](../adr/0331-the-sky-is-the-ideators-home.md)). The direction's rules were kept, not dropped: the **five objects** are the prototype's five states with the same ledger facts behind them; **size and brightness stay two channels** ("size is credits", never falling; brightness is the live share); **gravity** is the goal that lights as you type in the composer, and letting a thought float is still a real answer. What changed is the sky's standing — it is the ideator's home now, so "arrives last" and "never load-bearing" below are amended; the surviving rule is that the sky is never the *only* path, since the room is one key away and every drawn thing is a row in it.

## The problem this answers

An idea, today, is a container for work. When it succeeds — when it names a goal and becomes a task — it leaves the ideas world entirely and lives on as a task. So the better aimed the thought, the faster it disappears from the person who had it. The ideas page is named after the leftovers.

The session that produced this direction started from a real confusion: a filed thought silently became a task under a goal, the confirmation line vanished on the next keystroke, and the owner could not find what they had written five minutes earlier.

## The shift

**An idea stops being a container and becomes a permanent origin tag** — never edited, never editing, and the only thing that can answer where a piece of work came from. It can become a task, a criterion or a goal depending on scope, but the tag itself never changes.

Two flows, not one:

- **New ideas file fast.** One line, one gesture. Aiming is optional. Nothing about filing gets slower.
- **Past ideas are explored as a descent** — one thought at the top, everything that grew from it falling away below.

## The world

The project's own design system (`DESIGN.md`, "Cloud Bongos — The Chrome World") already supplies the vocabulary: a pure black void, hairline structure, and one warm salmon accent whose single law is that it **lights only what is pressable or live**. That law is why this direction reads as a sky without inventing anything: a living thing glows, a dead thing does not, and the accent's rarity is what makes it believed.

### Gravity

The project's open goals are gravity wells. A thought released near one is caught by it and becomes work inside it; a thought nothing catches floats in open space.

This is **not new machinery**. It is the capture-time routing that already runs, drawn instead of hidden inside a `<select>`. The invisible dropdown is the direct cause of the confusion that started the session, so making the catch visible is the fix, not a decoration on top of it.

A goal's **criteria are the rings inside its well**, closing as each is satisfied.

### The five objects

Dim and dark are different states and must be different objects, not one dot at two opacities.

| Object | What it means |
|---|---|
| **star** | caused work that is still alive. it dims as pieces of that work are removed |
| **protostar** | filed, not yet ignited. inside a well it awaits a nod; in open space nothing has claimed it |
| **satellite** | folded into another thought. it orbits that one now, and its value counts there |
| **remnant** | it burned, then the project removed it. it keeps every bit of its size |
| **cold body** | declined at triage. it never ignited, so it has no size at all |

Position carries a distinction the object alone cannot: a protostar **inside a well** has a home and is waiting for a nod; a protostar in **open space** has no home at all. That makes the nod queue something a person can see rather than a list someone must remember to open.

### Size and brightness are two channels

- **Size** is what a thought caused — the ideator's total payout from its descent — and it **never falls**.
- **Brightness** is how much of that work is **still alive**.

Two facts, two encodings. A thought that caused a great deal of work which the project later tore out renders **large and dead**: a big hollow ring. A single number would have made that look identical to a thought that never mattered, which is the failure this split exists to prevent.

Karma is not the basis. `karma_log` carries no task key and no idea key and never has, so "the karma a thought caused" is not a quantity the system can compute. Credits are already idea-attributed at ship, so they are.

Size is long-tailed, so it is **compressed for drawing** while the true figure is shown in the panel.

## Four surfaces

The mockup sources are committed at [`mocks/ideator-surface/`](mocks/ideator-surface/) — see that folder's README. They are the agreed shape, not a pixel contract.

1. **File** — the fast path. One line, an optional aim, and a receipt that does not evaporate. Filing never gets slower than it is today.
2. **The room** — the plain, everyday overview: what you filed, what it became, its size and whether it is still burning. This is the page a person opens daily, and it does the real work.
3. **The descent** — one thought at the top and everything it caused falling away below, through rewrites, splits and merges, including the branches that went out.
4. **The sky** — the ideator's home. It is drawn from numbers the other three already produce, and **it is never the only path to anything it shows**. *(Amended 2026-09-24 — it no longer "arrives last"; see the note at the top and ADR 0331.)*

## What this direction refuses

- **A galaxy is not trivial, and it is never the only path.** Every fact the sky shows is also a row in the room. *(Amended 2026-09-24 from "must never be load-bearing" — ADR 0331.)*
- **Filing does not get slower to serve the picture.** A spark's whole value is that it costs nothing to have; the sky redraws in the background.
- **The sky will be dominated by large dead rings in a project that churns.** That is honest, and it is the accepted trade — failure is fine, and a bright sky should be earned.
- **Brightness never claws back credits.** The ledger is not rewritten when the project changes its mind; only the picture changes.

## Provenance

Owner-led ideation, 2026-09-19, following the Ideator pack's stance (the human drives, Claude is the sounding board). Every decision above is the owner's, recorded as it was made on idea 1001072. The clickable mockup lives on claude.ai and is linked from that idea; the committed sources beside this file are what survives if that link does not.
