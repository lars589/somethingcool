# The hall in the world — verification walk (task 1003309, goal 1000081)

Walked 2026-09-02 against origin/main `88baa433` (the tree with every goal-1000081 redesign task landed, through PR 518). This folder is the record the task asked for: every page, every rank, both modes, the gates, keyboard and focus, reduced motion, console errors, residual palette, and the unit gate — with one contact sheet per page-lane and the defect list filed as tasks.

## Verdict

**Passed with four defects filed** (tasks 1003495, 1003496, 1003497, 1003498 — all `ready`, all under goal 1000081). Nothing found blocks the hall; nothing found was left unfiled.

## What was walked

The 26 pages that carry a `*.states.json` (`modules/hall-ui/public/`), each rendered through the ui-design kit (`modules/ui-design/kit/render.js`, ADR 0197) at 1440 / 390 / 320 in dark and light plus a reduced-motion pass per mode, against three preview harnesses serving the same fixtures as **xenos**, **metic** and **archon** (`scripts/hall-preview/server.js --fixture-me --rank <r>`). The kit's own signed-out stub rendered each page's signed-out states. The archon lane rendered every width; xenos and metic skipped 320 (the floors there are rank-independent).

| | |
|---|---|
| renders | **1,232** (78 page-lanes: 26 pages × 3 ranks) + 2 reduced-motion passes per page-lane |
| floors measured per render | console-errors · failed-requests · horizontal-overflow · one-header-main-h1 · controls-24px · top-bar-80px · reduced-motion |
| page-lanes with a problem | 19, every one classified below |
| real defects | 4 (filed) · harness limitations: 3 kinds · correct rank refusals: 7 pages |

Sheets: `<page>--<rank>.webp`, one per page-lane — dark rows above light, 1440 → 390 → 320 left to right, one tile per state. (The atlas sheets are from the second run, with `atlas.json` generated.)

The `harbor` and `pair` sheets were deleted when those two pages were removed with the dev box ([ADR 0346](../../../adr/0346-dev-boxes-are-retired.md)). The counts and lists below are as walked on 2026-09-02, with both pages in them.

## Page × rank

| page | xenos | metic | archon |
|---|---|---|---|
| atlas | 20 renders · clean · 3 tells | 20 renders · clean · 3 tells | 30 renders · clean · 3 tells |
| collab | 8 · clean | 8 · clean | 12 · clean |
| copy-desk | 20 · clean | 20 · clean | 30 · clean |
| diagrams | 8 · harness (sign-in redirect) | 8 · harness | 12 · harness |
| drachmae | 16 · stub (signed-out feeds) | 16 · stub | 24 · stub |
| gate | 12 · refused (metic+) | 12 · clean | 18 · clean |
| goals | 20 · clean | 20 · clean | 30 · clean |
| government | 20 · refused (permissions view is archon) | 20 · refused (same) | 30 · clean |
| idea | 8 · clean | 8 · clean | 12 · clean |
| ideas | 8 · clean | 8 · clean | 12 · clean |
| index | 16 · clean | 16 · clean | 24 · clean |
| modules | 20 · clean | 20 · clean | 30 · clean |
| not-ready | 8 · clean | 8 · clean | 12 · clean |
| people | 12 · clean | 12 · clean | 18 · clean |
| primer | 12 · harness (sign-in redirect) | 12 · harness | 18 · harness |
| profile | 20 · **defect 1003497** (signed-out links) | 20 · **defect 1003497** | 30 · **defect 1003497** |
| ranks | 8 · clean | 8 · clean | 12 · clean |
| roadmap | 8 · clean | 8 · clean | 12 · clean |
| roster | 12 · clean | 12 · clean | 18 · clean |
| sessions | 8 · refused (metic+) | 8 · clean | 12 · clean |
| settings | 16 · clean | 16 · clean | 24 · clean |
| task | 12 · clean | 12 · clean | 18 · clean |
| watch | 16 · refused (metic+) | 16 · clean | 24 · clean |
| work | 24 · clean | 24 · clean | 36 · **defect 1003498** (320, filters open) |

"clean" = every floor held in every render of that lane. Tells (the kit's advisory lines, never problems) are summarised under *Tells* below.

## Every problem, classified

| kind | count | where | what it is |
|---|---|---|---|
| `failed-requests` on `/api/gds/auth/web/start?return=…` | 236 | diagrams, primer — all lanes | **harness limitation.** The sign-in redirect target has no fixture on the preview harness, so each signed-out render logs one failed request per navigation. Live answers that URL with the real sign-in door (see *Gates*). |
| `dispatchClick: nothing matches #svg .ab-node` / `#ab-index-rows …` | 28 | atlas — all lanes, first run | **harness limitation.** The atlas reads a generated, gitignored `atlas.json`; `atlas.states.json` says to run `scripts/gds/gen-atlas.js` first. Re-run with it generated: **all three lanes clean** (the sheets here are that run). |
| `failed-requests` on `drachmae-and-karma.md` + `public/repo-info` (`127.0.0.1`) | 28 | drachmae — all lanes | **stub limitation.** The kit's own signed-out stub carries no hall feeds; `drachmae.states.json` does not list these two as expected 404s the way `atlas.states.json` does. States-file hygiene, not a page defect (the page renders its honest empty). |
| `controls-24px: a "roster" 37x18 \| a "sign in" 40x18` | 14 | profile `out` — all lanes, both modes | **defect → task 1003497.** The signed-out empty state's two inline links are 18px tall. Never rendered before: the harness always answers `/me`, so this state only appears against the kit's stub. |
| `horizontal-overflow: scrollWidth 358 > 320` | 2 | work `filters-open` @320 — archon, both modes | **defect → task 1003498.** The filter drawer's goal `<select>` (332px) will not shrink; measured on the harness, it and its label are the elements past the edge. |
| `expected visible: #gov-rank-list` | 8 | government `permissions` — xenos, metic | **correct refusal.** `GET /government/ranks` is `government.manage` (archon); the view does not render for a metic. |
| `expected visible: #gate-body` / `#harbor-body` / `#sessions-scroll` / `#stats-scroll` / `#watch-*` / `#pane-*`, `page.click: Timeout` | 32 | gate, harbor, sessions, watch — xenos | **correct refusal.** These pages are `requireGovernmentPage` (metic+); the harness serves the shell, the API 403s, the page shows nothing. On live the page gate refuses the shell itself (below). |

## Gates

- `tests/hall_page_gate_map.mjs`, `government_page_gates.mjs`, `auth_page_gate.mjs`, `scouting_page_gate.mjs`: **21 / 21 pass** — every hall URL is wired to the gate the oracle names.
- Live, signed out (`curl`, no cookie): **every** `/builders/*` URL probed — work, pair, settings, atlas, modules, goals, roadmap, primer, diagrams, watch, harbor, gate, sessions, people, government, roster, `/builders/`, ranks, drachmae, profile, not-ready, task/1003491, idea/1000904, ideas — answers **401** with the instance's own sign-in door (`noindex`), and so does the apex `/`. That is wider than the oracle's router-level map (which leaves roster, ranks, drachmae, profile, not-ready and `/builders/` ungated) because this project runs `project.platformVisibility = gated` — the member door in `src/bongos/platform-visibility-gate.js` (task 1003043, ADR 0190) refuses strangers on every surface before any page gate runs. Both layers behave as designed.
- Rank refusals on the harness (the table above) match the catalog floors: gate, harbor, sessions, watch, government → metic+; government's permissions view → archon.

## Keyboard and focus

- Measured on the harness as archon, after a real `Tab` (keyboard modality): every visible focusable element (`a[href], button, input, select, textarea, summary, [tabindex]`) focused in turn and its computed outline / box-shadow read — **work board 140 / 140 ringed, profile 47 / 47, task page 46 / 46** (the new grade panel and session-log disclosure included); first Tab stop on all three is the skip link, and the kit's focus-order fact on all 1,232 renders reads `Skip to content › Builders' Hall › Home › Roadmap …`.
- Static: three `outline: none` sites in the hall's sheets. `diagram-viewer.css:47` is restored by `.dgv__stage:focus-visible` (inset ring); `style.css:531` `main:focus` is the skip link's programmatic target; **`style.css` `.palette__input` has no replacement → task 1003496** (the command palette input, hidden until Ctrl+K, so the measured pages could not reach it).
- `controls-24px` held on every render except the profile's signed-out state (task 1003497).

## Reduced motion, console, overflow, structure

- Reduced motion: **every page-lane, both modes: `dead — running 0, rAF 0`** (nothing animates and no frame loop runs under `prefers-reduced-motion`).
- Console errors: **none** on any of the 1,232 renders (the floors' `console-errors` never fired; the states files' `ignoreConsole` lists cover only the expected 401/403/404 noise).
- Horizontal overflow: none except work @320 with the filter drawer open (task 1003498).
- One `<header>`, one `<main>`, one `<h1>`, top bar ≤ 80px: held on every render.

## Residual palette (hex / rgb outside `style.css`)

`grep -nE "#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\(" modules/hall-ui/public/*.{css,html,js} | grep -v ^style.css`, comments removed:

| site | verdict |
|---|---|
| `builders.js:563–568` — Standing's recent-grades column: `color:#a04040`, `var(--olive,#5b7a4d)`, `var(--ink-soft,#8a8577)` inline | **defect → task 1003495** (verification state must wear `--ok/--danger`) |
| `copy-desk.css:76` — `.cd-dialog::backdrop { background: rgba(0,0,0,.55) }` | **folded into 1003495** |
| `atlas.css:24–51`, `atlas.js:22–56` — the `--ab-*` node palette | **exempt** — the atlas's semantic node palette is fixed by ADR 0094 (its own states file says so) |
| `settings.css:157–158` — `#5865F2` on the Discord button | **accepted** — a third-party brand colour |
| `diagram-viewer.css:10`, `work.css:11,209` | comments only |

## Tells (advisory, reviewed, not filed)

- `tiny-type` on `#shell-user-rank`, `.fact-pill`, `.task__tag`, `.prow__tag`, `.sessions-row__badge`, `.badge`, `.rm-goal__ready`, `.gate-reason__floor`, `small` — all **10.5px**, the world's label tier (`--label-size`), 0.5px under the kit's 11px line. A token decision, consistent everywhere; flagged for the owner to raise the tier if wanted, not a defect.
- `proportional-numerals` on date and id cells (profile ledger, sessions, gate) — cosmetic; worth `tabular-nums` on ledger cells in a later polish.
- `prose-measure` on `li.rank-card` (~146ch) on the ranks page; `headline-lines` (an h1 at 4 lines) on the task page at 320 with a long title — inherent to the content.

## Unit gate

- CI `unit` (npm test + fitness + knip + audit) **green on this exact tree**: PR 518 (`88baa433`) and PR 516 before it.
- Local, this worktree: the hall's own 18 suites `tests/hall_*.mjs` — **285 / 285 pass**; the four gate suites 21 / 21; `fitness.js` all checks passed. A full local `npm test` on this Windows box reports 28 suite failures, none in hall-ui: generated-artifact freshness (`api_client`, `copy_inventory`), worktree/git path resolution (`next_number`, `box_infra_resolve`, `lib_sh_resolution`, `migrate_root_resolution`…) and Windows process aborts (`0xC0000409`) — environment, not the tree; CI is the gate of record.

## Reproduce

```bash
# in a checkout at the verified tree
node scripts/gds/gen-atlas.js                                   # the atlas's generated feed
node scripts/hall-preview/server.js --port 4641 --fixture-me --rank xenos   # and 4642 metic, 4643 archon
for s in modules/hall-ui/public/*.states.json; do
  node modules/ui-design/kit/render.js --states "$s" --base-in http://builders.localhost:4643 \
       --sizes 1440,390,320 --out /tmp/walk/archon/$(basename "$s" .states.json)   # no --base-out: the kit's stub renders signed-out
done
# sheets: normalise every <mode>-<width>-<state>.png to 480×300 (ffmpeg scale+pad), then tile=6xN → <page>--<rank>.webp
node --test tests/hall_page_gate_map.mjs tests/government_page_gates.mjs tests/auth_page_gate.mjs tests/scouting_page_gate.mjs
node --test tests/hall_*.mjs
```

Lanes must be launched as async processes — a synchronous spawn serialises the three ranks.
