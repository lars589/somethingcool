# Gate Navigation — Direction

> ## ⚠ REVISED the same day — read this first
>
> This document's central premise — **the gate is the front door** — was **superseded within hours**
> by [`front-door-and-hub-direction.md`](front-door-and-hub-direction.md) (task 1002746, owner,
> 2026-08-13). Under that decision `/` serves a real landing page, and **`/projects` becomes a project
> hub** that absorbs the map/grid, managing your projects, and creating them. The orb sky is no longer
> a front door — it is a **view inside the hub**.
>
> **What still stands:** the temporary `basic_auth` wall, removing the type-`bongos` entry ritual, the
> requirement for persistent navigation, and owner-orbs. **What changed:** those land inside the hub
> rather than on a standalone gate, and the "door out to `/projects`" becomes the hub's own internal
> navigation. The full disposition is in that document's §6.
>
> Everything below is preserved as the **evidence base** — the live navigation trace, the five-view
> map, the sign-in-awareness findings, and the shipped-door analysis are all still accurate and still
> load-bearing for the build. Only the framing changed.

> **Task 1002741** (goal 1000059 "Projects surface revamp") · direction decided with the owner 2026-08-13.
> Owner finding, 2026-08-12, minutes after the task 1002696 redesign went live: *"cloudbongos.com/gate
> is the landing page and there's no way to get there from the landing page."*
> Evidence base: the acceptance re-walk (task 1002697) finding **N9**, plus a live trace of every
> public path on the apex.

Scope: how a human arriving at **cloudbongos.com** reaches the owner surfaces — `/projects` and
`/create`. Covers the gate's entry ritual, a persistent navigation door, sign-in-aware states, and
whether an owner's own projects get an identity in the sky. Does **not** cover how the sky moves or
feels — that is goal 1000031 (§7).

---

## 0. Starting point — what exists today

Every claim here was verified live on core 1.19.85 (the version prod serves) or read from
`origin/main`.

### The public navigation map

| Path | Live status | Links out to |
|---|---|---|
| `/` — what a person types | **302 → `/gate/` → 401** | — |
| `/gate/`, `/world/*` | **401** Caddy `basic_auth` (realm "restricted") | — |
| `/index.html` | 200, public | only `builders.cloudbongos.com` |
| `/create` | 200, public | `/projects` |
| `/projects` | 200, public | `/create` |

**Nothing public links into `/create` or `/projects`.** They link only to each other. An owner
reaches their projects today by typing a URL from memory, via the `sessionStorage`-bound done panel,
or through a corner pill inside one view of a password-walled gate.

There is also a public landing page at `/index.html` that no one can reach by typing the domain —
the apex redirects straight past it into the walled gate.

### The wall

`/etc/caddy/Caddyfile` on the live host matches `@gate path / /gate /gate/* /world/*` and applies
`basic_auth` (user `cloudbongos`), with `X-Robots-Tag: noindex, nofollow` on the whole host.
`/create` and `/projects` fall through to the unprotected handler. Caddy runs its `redir` **before**
`basic_auth`, which is why `/` answers 302 unauthenticated and the visitor meets the 401 at `/gate/`
(the ordering ADR 0152 §:44-46 documents). The app carries its own apex redirect as well —
`src/platform-server.js:115-121`, conditional only on `isApexHost(req)` and the gate file existing,
with no session check and no query bypass.

**The live Caddyfile is not mirrored in this repo** (`infra/` held only `box-*.sh` and has since been removed with the dev box); ADR 0152 gives
the intended shape as prose and marks the lock *"optional pre-launch"*, and several references to
`infra/Caddyfile` elsewhere in the tree are dead. Treat the host config as the source of truth.

**Owner's call (2026-08-13): the wall is temporary and comes off at launch** — so this direction
designs the gate as the real front door for strangers and owners alike, not as a private preview.

### The gate itself

- **Five views**, switched by a whole-value `body` class assignment (no state-machine object), so
  they are mutually exclusive by construction: `view-entry`, `view-space`, **`view-table`**,
  `view-download`, `view-detail` (`public-landing/gate/space.js`). The page loads in `view-entry`
  (`index.html:141`, re-asserted `space.js:1827`). `view-table` is a full peer **browse view** — a
  sortable project directory with its own search and create button (`space.js:1248`) — and any
  navigation decision has to answer for it, not just for the sky.
- **The entry ritual runs on every visit.** `ENTRY_TARGET = 'bongos'` (`:1339`); keystrokes are
  matched one at a time (`entryKey()` `:1347-1356`), a wrong key shakes the bar, Enter fires
  `enterSite()` (`:1359`). ESC in `view-space` returns to it (`:1736`, `backToEntry` `:1394`).
  **There is no cookie or storage anywhere in the gate** — a returning signed-in owner re-types
  `bongos` every single time. A skip flag exists (`?entered=1` → `openSpaceDirect()` `:1402-1417`),
  but **it cannot survive an apex arrival: the `/` redirect drops the query string** (`:155-159`).
  So for anyone who types `cloudbongos.com`, the ritual is effectively unskippable.
- **The gate already knows who you are, and already acts on it.** `space.js:1124-1139` fetches
  `/api/bongos/me` same-origin and resolves `signedIn`/`ME` (`:1047-1049`, task 2094). That flag
  already drives four behaviours through `refreshCreateAffordances()` (`:1099-1104`): the identity
  chip, the ghost orb's label + `.locked` state, the table's create button, and the create
  interception that opens a sign-in prompt (`openCreate()` `:1160`).
- **The orbs are real projects** — one seeded self-orb (Cloud Bongos, `:30-36`) plus
  `loadProjects()` fetching `/api/bongos/projects/featured` (`:1812`, task 1002260). But the feed is
  a **curated public catalog**: it returned 3 projects (Demo, Emersonian Circles, Example),
  and the server projection selects exactly four columns — `origin, name, tagline, art_url`
  (`modules/platform-identity/platform-identity.js:242-250`). The route is `rank: public` and takes
  `_req` — **it never reads the request, so it cannot vary by viewer**. No owner, no slug, no
  membership. "This orb is yours" does not exist in any form.
- **The door that shipped** is `.space-projects` (`index.html:203-205`), static markup hidden by
  `body:not(.view-space){ display:none }` (`space.css:285-296`) — a pill in the corner of a drifting
  field, in one view, rendered regardless of sign-in state. `space.js` never references it: **zero
  matches**. That is finding N9.

**The precise shape of the bug.** The gate is sign-in aware *everywhere except this door*. Every
other affordance was wired into `refreshCreateAffordances()`; the `/projects` link landed as static
markup and was never added. Meanwhile the sign-in chip renders across four views
(`space.css:562-563`) while the door renders in one — so on the Table view a visitor sees their own
avatar and **no way to reach their projects**. This is a gap in a working mechanism, not a missing
capability. Note also that the task 1002696 direction already specified *"the gate gets a **signed-in**
'Your projects' door"* (`projects-surfaces-redesign-direction.md:108`) — the implementation diverged
from its own written direction, which is what produced this task.

### The asymmetry that explains the bug

Goal 1000031 already shipped a first-class **spatial** affordance for *creating*: a ghost
"create a project" orb in idle empty space, a live preview orb while creating, and a `?name=`
handover into `/create`. The *managing* path got a text pill in one view. Create earned a place in
the world; manage did not.

---

## 1. Decisions (owner, 2026-08-13)

1. **The entry ritual is removed.** Every visitor lands directly in the sky. The
   "type bongos in any AI" metaphor is not lost — the self-typing logo already cycles
   `claude / gemini / chatgpt …` and retypes **bongos** (`space.js:1477-1478`), which is where the
   idea belongs. The ritual stops being a toll gate in front of the projects.
2. **A persistent header door, carried by every view.** Not a corner pill and not one view — a real
   navigation element present in every view the gate can be in. With `view-entry` retired (decision 1)
   that means `view-space`, **`view-table`**, `view-download`, and `view-detail` — matching the reach
   the sign-in chip already has, so a visitor never sees their own avatar without a way home.
3. **A signed-in owner's own projects get a distinct identity in the sky** — worth building the
   owner-scoped data path for. The sky stops being purely someone else's showcase.
4. **The gate's password wall is temporary** (§0) — design for a public front door.

---

## 2. Principles

1. **The way home is always visible.** From any view, at any scroll position, a person can see how to
   reach their own projects. Wayfinding is not a reward for reaching a particular view.
2. **The door states what it does for *this* visitor.** Signed-out and signed-in are different
   sentences, never the same generic link.
3. **Nothing stands between a visitor and the projects.** No ritual, no toll, no required keystroke.
   Theatre may accompany the sky; it may not gate it.
4. **Create and manage are peers.** The sky already offers a way to make a project; it owes an equally
   real way to return to one.
5. **The sky tells the truth about ownership.** An orb marked as yours must actually be yours,
   resolved from the server — never inferred client-side.

---

## 3. Surface · the entry ritual (removal)

- The page loads directly into `view-space`. `view-entry` and its typed terminal are **retired**, not
  merely skipped — the `?entered=1` branch collapses into the default path, and with it go the
  door-visitor special case (`:1079`), the `<head>` anti-flash script (`index.html:15-25`), and the
  two flows that set the flag on the user's behalf (sign-out `:1086`, sign-in return `:1061`), which
  become redundant once the sky is the default.
- `<body class="view-entry">` in `index.html:141` must change too — the boot class is asserted in
  **two** places (markup and `space.js:1827`), and leaving the markup behind would flash the dead view.
- **ESC no longer returns to an entry gate.** In `view-space` it should do nothing (or clear an open
  search); `backToEntry()` is removed. A visitor must not be able to fall back into a view that no
  longer exists.
- The self-typing logo **stays** — it is now the sole carrier of the "type bongos in any AI"
  metaphor, and its job gets more important, not less.
- **Verify on removal:** `fitToView()` was previously mis-measuring because it ran while
  `body.view-entry` was active and the sky measured 0×0 (`space.js:1570`). Removing the entry view
  changes that timing — the fix must be re-verified, not assumed to survive.

## 4. Surface · the persistent door

**Which surface it points at.** The apex **`/projects`** (`public-landing/projects.html`, the owner's
provisioning instances) — *not* the hall's `my-projects` (`modules/hall-ui/`, federation memberships
via `GET /my-projects`). Two different pages answer to "your projects"; the task 1002696 direction
put the hall one out of scope and fixed the apex surface on the apex host. This door inherits that
boundary.

**Form.** A header element belonging to the page shell rather than to the orb field, so it does not
drift, scale, or pan with the sky, and does not depend on `view-space`. It replaces
`.space-projects`; the `body:not(.view-space)` hide rule is deleted rather than extended.

**States** (resolved from the existing `/api/bongos/me` call, never guessed):

| Visitor | The door reads | Goes to |
|---|---|---|
| Signed out | **Sign in** + a secondary **Start a project** | `auth/web/start?return=…` · `/create` |
| Signed in, has projects | **Your projects** (the primary door) | `/projects` |
| Signed in, no projects yet | **Start a project** | `/create` |

- **Wire it into `refreshCreateAffordances()`** (`space.js:1099-1104`) rather than inventing a second
  mechanism. That function already relabels the ghost orb and the table's create button off the same
  `signedIn` flag; the door is the one affordance that was never added to it. This is the smallest
  correct change, not a rebuild.
- While `/me` is still in flight the door renders in its signed-out form and settles when the answer
  arrives — it never renders a "Your projects" link it has not earned. (Principle 2, and the same
  truth discipline the projects surfaces adopted in the task 1002696 direction §3.)
- The door is present in all four remaining views, including **`view-table`**, where today a visitor
  sees their signed-in avatar and no route to their projects. In `view-download` and `view-detail` it
  keeps the same position and wording — a person deep in a project's detail page can still get home.
- **Signed-out click-through is currently a doubled ask:** `/projects` renders its own sign-in gate
  (`projects.html:71-72`, identity-only per ADR 0143) even though the gate already knew the visitor
  was signed out. With the door stating sign-in up front, that second prompt becomes the expected
  continuation rather than a surprise — but the door must send a signed-out visitor to
  `auth/web/start?return=/projects` directly, not to `/projects` to be asked again.

## 5. Surface · the owner's own orbs

**The data path is the work.** `/api/bongos/projects/featured` is a public catalog and cannot answer
"is this mine" — it carries no owner and no slug. So this needs an owner-scoped source: either a
signed-in variant of the feed, or the gate merging `GET /provisioning/instances` (which the owner
already reads on `/projects`, and which carries `slug`, `domain`, `status`, and the
`last_verified_at`/`last_verified_up` overlay).

**Design:**

- A signed-in owner's projects appear in the sky as orbs **visually marked as theirs** — a distinct
  treatment, not a duplicate of a catalog orb. If a project is both featured and owned, it renders
  once, marked as owned.
- Clicking an owned orb goes to **manage** (`/projects`, anchored on that project), not to the
  project's public site — that is the difference between an owned orb and a catalog orb, and it is the
  "click-to-manage path" the task asked for.
- An owned orb should carry the same **verification truth** the manage view shows (live · checked Xm
  ago / live? / unreachable). An orb that looks alive for a project that stopped answering is exactly
  the failure the task 1002696 direction existed to kill; the overlay already exists, so the orb must
  use it rather than invent a second story.
- Signed-out visitors see the catalog exactly as today.

**Delivery:** this is the largest piece and is **spun out as its own task** (§6) — the header door
(§4) and the ritual removal (§3) must not wait on it.

## 6. Delivery split

| Piece | Where |
|---|---|
| Entry-ritual removal (§3) + persistent door with sign-in states (§4) | **task 1002743** — the implementation carrier |
| Owner-scoped feed + owned-orb identity + click-to-manage + verification overlay on orbs (§5) | **task 1002744** — spun out; gated on nothing, but sequenced after 1002743 |
| Removing the Caddy `basic_auth` at launch | **infra, not this direction** — an owner/operator act, tracked with the launch, not by a surface task |
| `/index.html` being publicly served but unreachable from `/` | **idea 1000713** — a launch-shape question (retire it, or make it the public front with the sky behind), deliberately not decided here |
| `gate/README.md` + `space.css` claiming space-bar opens search when the shipped trigger is SHIFT | **idea 1000714** — doc drift left by task 1001901, unrelated to navigation |

Nothing in §§3–5 is promised without a task id above. If a later reader finds a commitment in this
doc with no carrier, that is a bug in the doc.

## 7. Boundary with goal 1000031

Goal 1000031 ("landing page — interactive polish") is nearly all shipped: panning, scroll/pinch zoom,
SHIFT search + spotlight, the self-typing logo, hover-card lifecycle, the ghost create orb, the
minimap, the space-whale.

**The rule:** if it changes how the sky *moves, looks, or feels*, it belongs to **goal 1000031**. If
it changes where a person can *go*, it belongs to **this direction**.

- The **ghost "create a project" orb** stays 1000031's (it is an existing shipped behaviour); this
  direction only observes that it is the create-side twin of the door we are adding.
- **Owned-orb identity (§5)** is this direction's, because it is about reaching your own project —
  even though it renders in 1000031's sky. Its *visual polish* once it exists is 1000031's again.
- The **entry ritual's removal** is this direction's: it is a barrier to reaching the projects, not a
  polish item.

## 8. What this direction does not decide

- **The gate catalog's contents and curation** — which projects are featured, and how a project earns
  a place in the sky. That is goal 1000031's surface and a separate product question.
- **The launch-shape question** of `/index.html` vs the sky as the public front door (idea 1000713).
- **The wall's removal date** — an owner/operator decision tied to launch.

## 9. Sign-off dispositions (owner, 2026-08-13)

Four calls were made in session; none are left open.

1. **The gate's password wall is temporary** and comes off at launch — so this direction designs a
   public front door rather than a private preview. (Had the answer been "the wall stays", the right
   move would have been the opposite: invest in `/create` and `/projects` as the real front doors and
   leave the gate alone — building a hallway behind a locked door is the failure mode this question
   was asked to avoid.)
2. **The entry ritual is removed outright** — land on the sky. The owner declined the softer options
   (skip-for-returning-visitors, auto-complete); the metaphor lives on in the self-typing logo.
3. **The door is a persistent header carried by every view**, not a signed-in-only element and not a
   corner pill.
4. **Owner-orbs are worth the data path** — the owner explicitly chose to build the owner-scoped feed
   rather than defer it, accepting that it is the larger half of the work (task 1002744).

**One correction landed during the session and is reflected above:** the premise that the gate is
sign-in blind was wrong. It already resolves `/me` and already gates the create path on it — so the
door is a one-line omission from a working mechanism, and the build in task 1002743 should be
correspondingly small. The premise that the gate has four views was also wrong; there are five, and
`view-table` is the view where the gap is most visible (avatar present, door absent).
