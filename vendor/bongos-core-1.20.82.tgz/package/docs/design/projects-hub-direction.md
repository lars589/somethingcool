# The /projects Hub — Direction

> **Task 1002758** (goal 1000061 "Apex UI pass") · decided with the owner 2026-08-13.
> The mock this approves: [`mocks/projects-hub-mock.html`](mocks/projects-hub-mock.html).
> Ground comparison sheet: [`mocks/projects-hub-variants.html`](mocks/projects-hub-variants.html).

Scope: the **look and view model** of `/projects` once it becomes the project hub. Structure was already
settled by [`front-door-and-hub-direction.md`](front-door-and-hub-direction.md) §1–2, whose §7 deferred the
visual design to this pass and told it to take the structure as given. This document does not reopen which
URL serves what, what the hub contains, or what redirects where.

It also does **not** cover *how the sky moves* — panning, zoom, the Shift-search spotlight, the hover-card
lifecycle, the ghost orb, the minimap and the whale are goal 1000031. The line: **if it changes where a
person can go it is this pass; if it changes how the sky moves it is not.**

---

## 0. Starting point — what exists today

Verified live on core 1.19.91 and read from `origin/main` at `3458c70`, 2026-08-13.

**Three surfaces that do not know about each other.**

| Path | What it is | Nav out |
|---|---|---|
| `/gate/` | the orb sky, behind the pre-launch `basic_auth` (401) | a corner `.space-projects` pill — **and it is hidden in the table view** |
| `/projects` | a hero + a sign-in card. Signed out, that is the entire page | wordmark, "+ New project" |
| `/create` | the buddha, a 4-step rail, a sign-in card | "Exit `esc`" |

**Four defects this pass found on shipped files**, recorded here because the build inherits them:

1. **`/projects` promises a sky it does not have.** Its lede reads *"The same sky as the front door — every
   project you own is an orb here"*, and the page renders a flat marigold ground with one card. The copy
   describes the gate, which a visitor to `/projects` never sees.
2. **`?view=` is inert.** `public-landing/index.html:240` and `:430` — both "Start a project" CTAs on the
   landing page shipped in `d53f51b` — link `/projects?view=new`, and `projects.html` reads **no query
   string at all** (`grep -c "searchParams\|location.search" ` → 0). Both land on the plain list. This is a
   live navigation bug on the front door, and §1.5 fixes it here because the hub is the surface that owns it.
3. **The table view has no verification overlay and no way back.** The gate's table shows Project / Builders
   / Type / Tags and no liveness chip, and its `body:not(.view-space)` rule hides the only projects door —
   so the one view where a person is scanning for their own project is the view that cannot say whether it
   is up, or get them to it.
4. **The landing hero's shadow inverts in dark mode.** `public-landing/index.html:276` fills the drums'
   ground shadow with `var(--ink)`, which is `#fdeedd` in dark — a glowing cream puddle rather than a
   shadow. Filed as its own task (§8) because it is a fault on the *landing* page, not a hub decision.

`projects.html` also bakes two platform claims into a file that ships to every instance — `<title>Your
projects — Cloud Bongos</title>` (`:6`) and the commons footer (`:93`) — and contains **zero** apex-only
sentinels. §7 C5 and the mock's `C` preview settle which side of the line each block sits on.

## 1. Decisions (owner, 2026-08-13)

1. **The map is what you land on.** Signed in or out, `/projects` opens on the map.
2. **An "only mine" filter lives in the map *and* the table.** The catalog is four projects and not all of
   them are the viewer's; one control filters both browse views in place.
3. **The ground is `B` — dual-mode full-bleed.** The sky is the page and follows light/dark.
4. **`/gate/` retires at the apex flip.** The landing page already replaces it as the front door.
5. **The buddha is dropped.** The bongo pair is the mark on every surface.
6. **"Your projects" stays a distinct view, not a filtered map** (§3).
7. **`?view=map|mine|new` is the hub's deep-link contract** (§4), which fixes defect 2 above.

## 2. The ground — why dual-mode beat a framed panel

Three grounds were built as the *same mock* under a switch and compared as rendered pages; all three are
preserved in `projects-hub-mock.html` behind `html[data-ground]`, and the contact sheet is the record.

**B · dual-mode full-bleed won because cosmos.css had already decided it.** `--sky-bg` is
`#f9d9a8` in light and `#150c06` in dark, and `--star-display` flips `none`/`block` (`cosmos.css:61-62`,
`:99-100`). The shared stylesheet was built expecting a sky that changes with the mode; a hub that ignored
that would have been the only surface where the persistent ☾/☀ toggle does nothing.

- **A · framed window** — the sky as a bounded panel on a document page — was rejected because a ~540px
  window onto a gravity field reads as a widget. The sky's whole appeal is that it is somewhere you *are*.
- **C · locked deep space** — the status quo, blue-violet in both modes — was rejected on two counts: the
  mode toggle would silently do nothing on the hub's main view, and the hub would read as a different
  product from the marigold landing page a visitor just came through.

**Dark mode is warm, not blue.** The map's dark ground is `--sky-bg` `#150c06` (warm umber), **not** the
gate's `--space-deep` `#05060f`. The locked space palette (`cosmos.css:47-49`) stays available and
platform-fixed, but the hub does not reintroduce the blue-violet the marigold pass moved away from.

> **Its risk, recorded so the build can watch for it:** light mode loses the starfield entirely
> (`--star-display:none`), so the map becomes a calm diagram rather than a place. If light mode ends up
> feeling inert, the fix is *not* to force stars onto a marigold ground — it is to give the light sky its
> own depth cue (the gravity grid carries most of it already; a soft vignette or warm haze layer is the
> next lever).

## 2b. What "mine" means — and the fact that nothing is

The owner's "only mine" toggle sounds like one predicate. It is not, and the platform had already decided
the vocabulary before this pass asked the question.

**Authority is the memberships table, not the catalog's owner column.**
`<redacted>` (ADR 0141 §3) carries `role IN ('owner','builder','visitor','pending')`,
and `GET /my-projects` already returns the split — `{ owned, building }`, with `pending` excluded
(`modules/platform-identity/routes/my-projects.js:25-38`). Meanwhile
`platform_identity_projects.owner_github_id` describes itself in its own migration as *"advisory attribution
(not an authority)"*. **The build must read memberships. It must not read `owner_github_id`.**

So the filter keeps `owner` **and** `builder`, and the map says the two differently — a solid accent ring
and a filled **yours** badge for owned; a softer ring and an outlined **you build here** badge for building.
Claiming ownership the membership row does not assert would be the same class of lie as the verification
overlay's (C6).

**And today the honest answer is that nothing is anyone's.** Verified 2026-08-13 as the platform's own
archon: `GET /my-projects` → `{"owned":[],"building":[]}`. Of the three catalog rows, `Demo` is owned by
another GitHub id and `Emersonian Circles` and `Example` have `owner_github_id` **NULL**. The
memberships directory is written only by the server-to-server check-in a *federated* instance posts on
sign-in — and the apex is not a federated client of itself.

That makes the empty state the **day-one** state, not an edge case, so the mock designs it: `0 projects`,
"You don't own or build on anything here yet", and a way out (turn the filter off, or start one). The
mock's rail carries a **real memberships** switch that reproduces it exactly, so the build cannot forget.
The data gap itself is **task 1002760** (§8), which now blocks carrier 1002744.

> **Its risk, recorded so the build can watch for it:** the sample data in the mock is *illustrative* —
> it marks one project owned and two built-on so the feature can be judged. Do not read it as a fixture.
> The switch, not the default, shows the truth.

## 3. Why "your projects" is a view and not a filter

The owner's "only mine" toggle could have replaced the manage view outright. It does not, because the two
answer different questions and only one of them fits on an orb.

The manage card is **contractual**, and its order is fixed by
[`projects-surfaces-redesign-direction.md`](projects-surfaces-redesign-direction.md) §8: orb → name +
status chip → meta row → address row → optional attach-domain input → optional error paragraph → progress
strip → last-action message → actions. Behind it sit **eight** chip outcomes, **four** progress flows
(standup / revive / teardown / address) × three stages, a teardown confirm that swaps the actions row, and
**eleven** named refusal messages. None of that survives being drawn as a dot in a starfield.

So: the map answers *what exists and is any of it mine*, and the toggle makes that fast. "Your projects"
answers *what do I do about it*. The filter is a lens on the browse surface; the view is where the controls
live.

## 3b. Search and filtering in the manage view

Added on the owner's ask, 2026-08-13: *"we should probably have some sort of search and filtering on the
Your Projects tab."* It is the one view that grows without bound — a builder with twenty projects has no
way to find one — and it was the only browse surface with no way to narrow.

**Search** matches name, repo slug and address, so `example-owner/spike` finds Spike Harbor and
`emersonian.cloudbongos.com` finds Emersonian Circles. Same predicate for all three fields; substring, not
fuzzy.

**The filter groups the chip outcomes; it never relabels them.** Five pills, each carrying a live count:

| Pill | Holds | Why |
|---|---|---|
| **All** | everything | |
| **Live** | `live` **and** `live?` | neither is known-down |
| **Needs you** | `unreachable`, `snagged` | the two that will not resolve on their own |
| **Working** | `queued`, `standing up`, `tearing down` | the platform is mid-flight; wait |
| **Torn down** | `torn down` | |

**This does not collapse the three active outcomes (C6).** Grouping `live` with `live?` under one *filter*
is not the same as printing one *label*: every card still says which it is, with its own recency. The rule
forbids a badge that claims more than the probe knows — it does not forbid a filter whose question is "is
this known to be down". A pill named "Up" would break it; "Live" holding both, with the cards unchanged
underneath, does not.

**Counts recompute against the search**, so typing a query and seeing `Needs you 0` is a real answer rather
than a stale one. An empty result says so and offers to clear.

## 4. Navigation — one shell, three destinations, and a real URL

The persistent header is fixed in form by [`gate-navigation-direction.md`](gate-navigation-direction.md) §4:
a header belonging to the **page shell**, not the orb field, so it does not drift, scale or pan with the
sky. It replaces `.space-projects`, and the `body:not(.view-space)` hide rule is deleted rather than
extended — which is what closes defect 3.

`?view=` carries `map` (default) / `mine` / `new`, pushed with `history.replaceState` so a view is
linkable and back-button-able. `/create` redirects to `?view=new`, and the landing page's two existing
`/projects?view=new` links start working the day this ships.

**The nav carries a `Home` item, and it is not a view.** The first draft had only the three hub views, on
the assumption that the wordmark's link to `/` was door enough. Owner review killed that: *"I dont see
exactly how a landing page is going to fit in here. Theres no 'home' page at the top tabs."* A wordmark that
happens to be a link announces nothing, and after the apex flip `/` is a real destination with real content.

So the nav reads `Home │ Map · Your projects · New project`, with a hairline after Home. The two kinds of
destination are deliberately not levelled: **Home is a page**, so it navigates and never takes the
current-view pill; the other three are **views of this page**, so they swap in place and one of them is
always current. The relationship between the two surfaces is one-way by design — the landing page is the
stranger's front door and sends people *into* the hub (its "Start a project" and "See what's building" CTAs
both point here); the hub is where they stay. `Home` is the way back out, not a tab someone is expected to
live on.

> **A trap the build must not walk into, found while mocking:** the wordmark **types**, so its width changes
> every ~190ms. With the nav as the middle child of a `space-between` row, the tabs visibly slide left and
> right while the logo animates. Both flanks take `flex:1 1 0` so they compute to equal width and the nav is
> pinned dead centre regardless of what the mark is currently spelling. Measured: 0px drift across seven
> typed states. Below 820px the three groups stack and the nav takes its own centred row.

## 5. The content spine

Ordered. **Portable** = true on every instance; **apex-only** = true of Cloud Bongos the platform.
Press `S` in the mock to outline the apex-only blocks, `C` to see the child-instance shape.

| | Section | Portable? |
|---|---|---|
| S0 | Head metadata — title + description from `{{productName}}`/`{{tagline}}` | server-stamped |
| S1 | Shell — self-typing wordmark, **Home │ Map · Your projects · New project**, hall link, mode toggle, identity chip | portable (hall link apex-only) |
| S2 | Toolbar — Sky \| Table, **only mine**, search + count | portable |
| S3 | Map · sky — orb field, owned marking, verification chip on owned orbs, hint rail | **catalog apex-only** |
| S4 | Map · table — Project / Builders / Type / Tags / **Status** / open | **catalog apex-only** |
| S5 | Your projects — **search + state filter**, then the manage cards (§3) | portable |
| S6 | New project — 4-step rail, the bongo pair, AGPL fine print | portable |
| S7 | Footer | split — commons claim apex-only |

Copy notes:
- The create pitch is verbatim from `create.html`, and the AGPL sentence from `create.html:391` — both
  already public-facing and owner-approved. **Not newly invented.**
- **`/projects`' current lede is retired**, not reworded: "The same sky as the front door" described a page
  the visitor never reached, and after the apex flip there is no separate front-door sky to be the same as.
- The self-typing wordmark **stays** — it is the sole carrier of the "type `bongos` in any AI" metaphor and
  the one gate flourish that survives the ritual's removal (owner disposition, gate-navigation §4).
- **The entry ritual's copy dies with it**, including the table footer's "`esc` back to entry".

## 6. The design system

The mock **links `cosmos.css`** and adds a page-local sheet. It does not fork it. The chips are literally
the `.chip .live/.maybe/.down/.bad/.busy/.calm` vocabulary the manage list already ships, the manage cards
are `.proj`/`.projHead`/`.addr`/`.strip`, and the buttons are `.btn`/`.btn-space` — the map and the
management page share components rather than resembling each other.

**These are authored page-locally in the mock and must GRADUATE into `cosmos.css` in the build**, not be
copied into the page (each is marked ★ in the mock's stylesheet):

| Component | What it is |
|---|---|
| `.shell` / `.navrow` | the persistent hub header + its three-destination nav, incl. the equal-flanks rule (§4) |
| `.toolbar` / `.seg` | the per-view control strip and the segmented Sky \| Table control |
| `.switch` | the two-state "only mine" filter |
| `.search` | the glass search field + result count — used by the map toolbar **and** the manage bar |
| `.mineBar` / `.filters` | the manage view's search + state-filter pills with live counts (§3b) |
| `.field` / `.worldOrb` | the orb field and a project rendered as an orb, incl. `.badge` and the owned ring |
| `.tbl` | the directory table |
| `.steps` | the 4-step create rail |
| `.fieldNote` | the honest empty / not-available-here state |

**Orb colour must be tokenized.** `projects.html:221-231` hashes five hardcoded hexes and five rgba glows
off the instance slug; two happen to equal `--sun-lit`/`--gold-soft`, three are orphans, and none follow a
re-theme. Keep the per-project variety — it is what makes a sky legible — but re-express the five as
`color-mix()` derivations off `--accent`, `--sea`, `--terracotta` and the locked `--sun-lit`/`--gold`, so
every orb accent lands inside the contrast test.

## 7. Constraints the build must respect

- **C1 · One `:root`.** `injectBrandingGlobal()` splices the pack's `:root` at the **end of `<head>`, after
  the stylesheet link** (`src/bongos/serve-internal.js:138-146`) — equal specificity, later in order, so the
  pack wins. A page-local `:root` silently outranks it and defeats re-branding. Page-local custom properties
  stay scoped to their component. The mock has **no** `:root` block; follow that.
- **C2 · Dark changes are made twice.** `:root[data-mode="dark"]` and the `prefers-color-scheme` twin are
  byte-identical duplicates in `cosmos.css`. Both, every time — a `deepEqual` lockstep test compares them.
- **C3 · The page must ship a `.sky` element.** `themeMarkup()` emits `body{background:#f9d9a8}` after
  cosmos.css in **both** modes and not mode-aware (`serve-internal.js:119`); `.sky` is the only mode-aware
  full-page paint. Never ground the hub on `body`.
- **C4 · Never pin `--accent`, `--accent-deep`, `--sea`, `--terracotta` to a literal hex in a dark block**
  (dark blocks are (0,2,0) and would outrank the pack permanently), and add every new fg/bg pair to
  `tests/cosmos_token_contrast.mjs`'s `PAIRS` array — 32 pairs at 4.5:1 in **both** modes, CI-enforced.
- **C5 · Instance portability.** `public-landing/` ships wholesale to every instance. The catalog of other
  instances, the "this platform" self-badge and the commons footer line are **apex-only** and go inside
  `<!--apex-only:start--> … <!--apex-only:end-->` (server-stripped by `stripApexOnly()`,
  `src/platform-server.js:75-97`) — removal, not CSS-hiding. The `<title>` becomes
  `{{productName}}`/`{{tagline}}`. On a child, provisioning is `"default": false`, so the hub renders the
  plain "projects aren't managed from this instance" state rather than falling into the generic alert.
- **C6 · Verification truth is load-bearing.** Three active outcomes stay three — `null` = never probed →
  "live?", `false` = probed and down → "unreachable" (`modules/provisioning/provisioning.js:151`: *"Never
  collapse the two."*). Liveness is an **overlay, never a lifecycle state**; an unreachable instance is
  still `active` and still teardownable. Every liveness claim carries recency, and "live" only appears
  inside `FRESH_MS` (12 min). **Map and list are two views of one truth** — never alive on one and
  unreachable in the other.
- **C7 · Real markup, not JS-built.** The hub must read correctly to a crawler and with JavaScript off —
  the exact failure task 1002746 had to repair on the gate.
- **C8 · The map must not run when it is not visible.** The gate's `requestAnimationFrame(tick)` at
  `space.js:1847` writes a transform to every orb node with **no view guard** (`:631-654`), and `space.js`
  assigns `document.body.className` **wholesale in 10 places** (`904, 961, 974, 979, 1241, 1248, 1374, 1394,
  1406, 1827`), which would destroy any hub-level body class on every view change. Those become `classList`
  operations, `render()` gets a view guard, and the design does not rely on a persistent `body` class —
  `data-mode` lives on `<html>`.
- **C9 · Motion respects `prefers-reduced-motion`.** The gate honors it throughout (`space.css:802-809`);
  the typing wordmark, the chip pulse and any orb drift must too.

## 8. Follow-on tasks this direction produced

| Task | Goal | What it does |
|---|---|---|
| **task 1002743** | 1000061 | **Build carrier 1 — the shell.** Retires the entry ritual, builds the persistent header + `?view=` contract across every view including the table, and carries the apex flip (part 3) with `platform_boot` unparked in the same change. Now **depends on 1002758**. |
| **task 1002744** | 1000061 | **Build carrier 2 — the map.** Owner-scoped feed, owned-orb identity with click-to-manage, and the verification chip on owned orbs. Now **depends on 1002758**. |
| **task 1002759** | 1000059 | **The dark-mode hero shadow** found in §0.4. Filed separately because it is a live fault on the shipped *landing* page and should not be buried inside a hub commit — the same reasoning that split task 1002749 out of task 1002747. |
| **task 1002760** | 1000061 | **The membership data gap** found in §2b — `GET /my-projects` is empty for the platform's own archon, and two of three catalog rows have a NULL owner, so "only mine" and owned-orb identity have nothing to render on the apex. **Blocks 1002744**, which is why it is a dependency rather than a note. |
| **task 1002761** | — | **`docs-entropy.js` is a silent no-op on Windows.** Found running it as a pre-ship check here: `git ls-files '*.md'` keeps its quotes through the shell Node uses on Windows, so git matches 0 of 339 tracked files and the tool reports a clean run. Unrelated to the hub, filed on its own. |

This document plus the approved mock are the contract for 1002743 and 1002744: **build what the mock shows;
do not redesign it.**

Also settled by this pass, for the carrier that lands it: **criterion 1000253 previously had no design
task.** Its only linked tasks were the two build carriers, both with empty `dependencies`, so nothing gated
the hub build on an approved mock and the criterion was unsatisfiable as written. Task 1002758 now carries
the criterion link and both carriers depend on it.

## 9. What is deliberately still open

- **How the sky moves.** Pan, zoom, spotlight search, hover cards, the ghost orb, the minimap and the whale
  are goal 1000031. The mock places orbs statically on purpose.
- **`view-detail` and `view-download`.** The gate has five views; the hub names three. The recommendation on
  the table — not yet an owner decision — is to delete `view-download` (a 2.75s descent cinematic, a temple
  `.stage` with non-functional tiles, a 44-frame buddha loop and a 190-line drag IIFE at
  `gate/index.html:378-630`) and make the self-orb open the **same** detail card every other orb opens, kept
  as an overlay *inside* the map rather than a fourth destination. That is ~380 lines and two sprite files.
- **Whether light mode needs a depth cue** beyond the gravity grid (§2's recorded risk).
- **What the light sky does at 40 projects.** Four orbs sit comfortably; the mock does not prove a crowd.

## 10. Sign-off dispositions (owner, 2026-08-13)

1. **Map first**, for signed-in owners too — asked as a two-option question, answered with a correction
   worth keeping: *"The map shows 4 total projects, not all of which the user is a part of."* The four are
   the platform's own orb plus `Demo`, `Emersonian Circles` and `Example` (verified via
   `GET /projects`). The premise of the question — that the catalog held one project — **was wrong**, and
   the "only mine" toggle exists because the owner corrected it.
2. **The "only mine" toggle appears in the table too**, not just the sky — stated explicitly.
3. **`/gate/` retires at the apex flip** rather than surviving as a redirect or an easter egg, *"since we
   have already designed a landing page."*
4. **The buddha is dropped** in favour of the bongo pair everywhere — chosen against the recommendation to
   keep it in the create view.
5. **The ground was not decided in the abstract.** The owner declined to pick from a description —
   *"we should run through these where you publish versions and I approve"* — so all three were built and
   rendered, and **B** was approved from the walked mock.
6. **The nav-drift bug was caught by the owner in review**, not by the mock's author: *"the top tabs move
   with the cloud ____ typing."* Fixed in §4 and pinned as a build constraint.
7. **The invented ownership was caught by the owner in review**, and it turned out to be the biggest finding
   of the pass: *"example and emersonian circles arent owned by me and i am not apart of them yet they
   appear in only mine."* The mock had asserted ownership no row supports. Chasing it produced §2b — the
   owner/builder vocabulary, the rule that `owner_github_id` is not the authority, the day-one empty state,
   and **task 1002760**, which blocks carrier 1002744. The owner's second phrasing — *"not owned by me
   **and** i am not a part of them"* — is exactly the `{ owned, building }` split the API already returns,
   arrived at independently.
8. **A missing door home was caught by the owner in review** (§4): the nav offered no route back to the
   landing page. `Home` added, and deliberately set apart from the three views.
9. **Malformed table controls were caught by the owner in review:** "Manage →" wrapped to two lines and the
   status chip's recency dropped below its label, because nothing stopped the action and status cells
   breaking. Both now claim their width and refuse to wrap; the name cell absorbs the slack (§6 `.tbl`).
10. **Search + filtering on the manage view was asked for by the owner** and is §3b. The mock gained a
    fifth card (`Mercury`, standing up) so the "Working" filter has a real member — and, incidentally, so
    the standup progress flow is shown somewhere, which no other card did.
11. **Approved to ship** on the owner's word, 2026-08-13, after four review rounds against the live mock.
