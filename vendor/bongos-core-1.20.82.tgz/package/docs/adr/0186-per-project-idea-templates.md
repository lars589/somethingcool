# 0186 — Per-project idea templates: the seam is already built; the economics are the open problem

- **Status:** Accepted (spike outcome — decisions below; no implementation in this task)
- **Date:** 2026-08-23
- **Tasks:** [#1002932](https://cloudbongos.com/builders#/task/1002932) (BV1.R156, goal 1000062 — three grades of idea). Spike output: this ADR plus the downstream task list in §7. Gates criterion `abi-full-idea-base-template`.
- **Builds on:** [ADR 0172](0172-per-craft-compensation-ideator-credit-lane.md) (the ideator credit lane), [ADR 0185](0185-spark-handoff-credit-split.md) (the 70/30 split), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (module boundary + module-owned migrations)
- **Related:** R141 (`modules/ideas/templates.js` — the template declaration), R142 (`modules/ideas/completeness.js` — the deterministic scorer)

## 1. Context

The owner's philosophy for this platform, recorded on goal 1000062: **the best
possible simple base, already designed to be altered.** R141 shipped `base-v1` —
five fields, declared as data — and R142 shipped a scorer that walks that
declaration rather than hard-coding five names. This spike asks the question those
two deliberately deferred: *how does a project founder define their own idea
shape — different fields, different weights — without a schema change and without
forking the scorer?*

## 2. The finding that matters: the seam is already there

The answer to the literal question is short, because R141 built for it:

- **Every template function already takes an optional `registry`**
  (`templateFor`, `validateFieldValues`, `fieldOrder`, `scoreFieldValues`),
  defaulting to `BUILTIN_TEMPLATES`. Validation and scoring both read the
  declaration as data. Swapping the registry changes what both accept with no
  code change in either consumer, and `tests/idea_templates.mjs` already proves
  it by injecting a different registry.
- **The store is already project-ready.** `ideas_grades.template_key` is per-row
  with `CHECK (template_key ~ '^[a-z][a-z0-9-]*$' AND length <= 64)` — its own
  migration comment says a project-defined key "stays addressable".
- **A per-project settings home already exists**: `provisioning_instances.settings
  jsonb NOT NULL DEFAULT '{}'` (provisioning_009).

So: **no schema change is required, and the scorer does not need forking.** That
part of the task's question is answered by work already shipped. What the spike
actually found is a different problem, in §4.

## 3. Decision A — where a project template comes from

A new **`project-settings` kernel port**, the sibling of the existing
`builder-settings` port, reading `provisioning_instances.settings` under a
namespaced key (`settings.ideas.templates`).

- The `ideas` module resolves it with `resolveOptional`, so a vanilla instance
  with no `provisioning` module **degrades to the built-in registry** rather than
  failing — the same graceful posture `lifecycle` takes toward `reward` and
  `onboarding` (ADR 0093 §2).
- `base-v1` remains the default and the **fallback for any row whose
  `template_key` does not resolve**. An unresolvable key already renders raw
  rather than throwing (`templateFor` returns null by design, after the R143
  prototype-pollution fix); that behaviour is kept.

**Rejected:** a new `ideas_templates` table (a second home for a thing that
already has one, and a module-owned table for data the project owner edits in
project settings); a config file (`config/idea-templates.json` is per-*instance*,
and one instance hosts many projects — wrong granularity).

**Boundary note, load-bearing for whoever implements it:** goal 1000062's
`scope_modules` is `['ideas','hall-ui']`. The port lives in `provisioning` +
kernel, which is **outside this goal's scope wall**. The port task therefore
cannot be claimed under goal 1000062 — see §7 T1.

## 4. Decision B — the economic lever (the real finding)

Completeness is normalised **0–100 within its own template**: the scorer takes the
mean of per-field ratios and multiplies by 100. Karma reads that relative number
against an absolute bar — `IDEA_FULL_PASS_BAR = 60`, `IDEA_FULL_PASS_CREDIT = 5`.

Those two facts together mean **template choice becomes a credit-minting lever**:

| Template | Required text for a passing score | Credits |
|---|---|---|
| `base-v1` (5 fields × substanceMin 40) | ~200 characters of real content | 5 |
| a project template: 1 field, substanceMin 10 | ~10 characters | 5 |

A ~20× arbitrage, available to any project that can define its own shape — and
per-project templates are exactly what this ADR enables. Shipping Decision A
without addressing this would make the feature a way to print credits.

**Decision:** separate the two questions the single number is currently answering.

- **Completeness stays relative** and keeps its present meaning: *did you fill in
  YOUR project's form.* That is the right signal for triage ordering (R148) and
  the hall's live meter (R152), and it must stay comparable within a project.
- **Karma stops reading it.** Credit eligibility reads an **absolute substance
  total** instead — which the scorer already computes per field (`fields[].substance`)
  and currently discards after averaging. No new measurement is needed; the number
  is there.

**Rejected:** making completeness itself absolute (it would break the meter and
the ordering, which want "how complete is this form"); leaving karma relative and
policing templates by review (unenforceable, and the platform should not depend on
someone noticing).

**Interim guard**, cheap and shippable before the karma change: a project template
is karma-eligible only if it declares **≥3 required fields and ≥120 total
`substanceMin`**. This does not fix the arbitrage, it bounds it — and it is worth
having on day one because it is a data check, not an economics change.

## 5. Decision C — per-field weights

The task asks for "different fields, different weights". Today the scorer is an
**unweighted** mean (`fields.reduce((s,f) => s + f.ratio, 0) / fields.length`).

**Decision:** an optional `weight` on the field declaration, default `1`, and a
weighted mean in the scorer. Today's behaviour is the special case where every
weight is 1, so this is a pure data addition with one arithmetic line changed and
no migration. Weights are declared alongside `substanceMin`, which keeps the whole
shape of a template in one declaration.

## 6. Decision D — do the five base fields stay mandatory?

**No.** A project may define any shape; forcing the five would make "define your
own" cosmetic, and the base fields are the owner's wording for *this* project's
concerns, not universal truths.

Two constraints stand in their place:

1. **A template must declare at least one required field.** A template with none
   makes completeness vacuous (an empty submission scores 100).
2. **A stored template is validated at write time**, so a malformed registry is
   refused when the project saves it — not discovered later inside the capture
   path, which must never throw (R142's hard requirement).

## 7. Downstream tasks (the spike's other output)

| # | Task | Scope / goal note |
|---|---|---|
| T1 | `project-settings` kernel port, sibling of `builder-settings`, reading `provisioning_instances.settings` | `provisioning` + kernel — **outside goal 1000062's wall**; needs a goal whose scope covers it |
| T2 | `ideas` resolves that port and merges the project registry over the built-in; `resolveOptional`, degrading to built-in | `ideas` — in this goal's wall |
| T3 | Optional per-field `weight` (default 1) + weighted mean in the scorer | `ideas` |
| T4 | Karma eligibility reads an absolute substance total, not the relative completeness score | `economy` — outside this goal's wall |
| T5 | Interim guard: a project template is karma-eligible only at ≥3 required fields and ≥120 total `substanceMin` | `ideas` |
| T6 | Write-time validation of a stored project template | `ideas` (+ wherever project settings are saved) |

T1 → T2 is the ordering dependency; T3, T5, T6 are independent. **T4 is the one
that must not be skipped** — T5 bounds the arbitrage, only T4 removes it.

## 8. What this ADR deliberately does not do

No customization UI, per the task's own instruction ("Do not build the
customization UI from this task"). No implementation of any row above. The spike's
deliverable is this decision record plus §7, and the reason the platform builds
the seam before the surface is ADR 0062 §7's core↔host split: the core ships the
mechanism, the host supplies the content.
