# 0175 — The Board Room: Full Idea ratification as the first upward-pointing gate

- **Status:** Accepted
- **Date:** 2026-08-17
- **Task:** [#1003014](https://cloudbongos.com/builders#/task/1003014) (R01 of goal 1000069 — the Board Room)
- **Related:** ADR 0151 (permissions-as-atoms), 0157 (Archon is rank and identity only), 0162 (review gates retired — no human approval in the land path), 0158 §2 (a verdict is advisory, never self-executing), 0172-per-craft (the ideator credit lane — stream 3), 0174 (government, not governance; "role" means a craft), 0037 (Discord channel layout), 0016 (trust boundary), 0086 (goals + scope walls)
- **Spec:** [`docs/specs/bongos-v1-board-room.md`](../specs/bongos-v1-board-room.md) — the planning session that produced this decision, with the full interview record
- **Source ideas:** 1000738 (the Board Room), 1000754 (scoping brief)

## Context

**Every gate in this system points down the rank ladder.** Rank floors, protected paths,
the grader, Archon approvals — each one constrains someone below the person who set it.
Nothing points up. An Archon can ship whatever they want, and on 2026-08-16 the owner named
that as a loophole they can walk through at will:

> *"I am a little unsure about just implementing without team buy-in… Otherwise I can just
> ship and build as I want, finding loopholes."*

The most senior person on the project asked for a structure that can slow **them** down. That
framing is the specification, and it is why the decision below is about *legitimacy* rather
than about permissions — the permission system (ADR 0151) already works, and adding a rank
floor would only point the gate downward again.

Three constraints shaped what could actually be built.

**1. The ADR 0162 discipline.** No human approval sits in the land path (ADR 0162), and a
verdict is advisory and never self-executing (ADR 0158 §2). A gate that
blocks a seeding until a quorum is reached would violate that; a gate that merely records an
opinion would be theatre. The resolution turned out not to be a compromise between them —
see Decision 1.

**2. Franchise cannot be role-derived.** ADR 0174 §5 freed the word "role" for the three
crafts (Artist, Ideator, Builder), which makes a craft-scoped voting chamber superficially
attractive: an Ideator chamber for ideas, a Builder chamber for seedings. It is not viable.
`PATCH /me/disciplines` is deliberately ungated — *"a builder owns their own profile"*
(`src/bongos/routes/me.js`) — so self-selecting into a chamber would be a one-request
privilege escalation. Role also gates nothing anywhere in the codebase today; authority runs
rank → rank-role → permission, end to end. **Franchise therefore derives from rank**, and the
role-chamber model is rejected.

**3. The scale is the "circle" rung.** The governance synthesis this session worked from
(*The Six Variables of Governance*, Verro Labs, Aug 2026) argues that formality is adopted
only where informal coordination breaks, and that the thresholds are set by human cognitive
constants: an executive differentiates around 9 people, written law separates around 50,
adjudication separates around 150. This project sits at 3–8. A seven-preset Charter Builder
is a 150-rung constitution, and shipping one now would be building the wrong rung.

## Decision

### 1. The board's subjects are exactly two, and both are rare by construction

The board votes on a **Full Idea** (`modules/ideas`, goal 1000062 — the five-field graded
deliverable), and on a **change to the constitution itself**. Nothing else. Claims, seedings,
promotes, ships and grades behave exactly as they do today; Quick Ideas and Sparks keep
promoting straight to a task, untouched.

Idea 1000738 also wanted votes on task-set seedings and *"anything a member puts up"*. The
owner narrowed it — *"only Full Detail Ideas (E.g. new goals) should need ratification,
everything else should function as is"* — and then re-widened it by exactly one subject, so
that the rule constraining the owner cannot be weakened by the owner alone.

**This is what dissolves the ADR 0162 tension rather than compromising on it.** A board vote
gates no build path, so nothing self-executes because there is nothing downstream to execute.
Ratification confers legitimacy and triggers a credit award; it does **not** auto-create the
goal (goal 1000062 already settled that a Full Idea is not auto-converted — the conversion
recommendation stays a human step).

Board items carry a `subject_type` (`full_idea` | `constitutional_amendment`) **from day one**.
A third subject should be a row, not a migration.

### 2. A vote is a timed sitting, not a quorum

Asking *"how many votes must we collect"* produces deadlock — Linz's problem, no
constitutional exit. We invert it: members are notified that a vote is wanted within a window,
and **an unvoted window nulls that member's vote** — they drop out of the denominator. They
are never counted as a no.

**The clock is the deadlock exit.** This is why no shotgun buy-sell or fork-with-treasury-split
clause is needed at this scale: absence cannot stall anything, so there is no state for such a
clause to resolve.

Default window: **90 minutes**, closing early the moment every member has voted, so latency is
`min(full turnout, window)`. Stored in minutes and set per project.

Stated plainly because it is the owner's explicit intent, not an accident: **a short window
means whoever is awake governs.** Standing accrues to those actively governing. The window
length is a governance lever, not a UX detail.

### 3. Consent, not majority — and a zero-vote close passes

Silence is consent. A **single reasoned objection** returns the idea to its author. A window
that closes with **no votes at all passes** — the idea already cleared the completeness gate to
reach the board, and absence never blocks.

This makes both halves of the owner's intent true at once: pace is never obstructed, and only
an active participant can change an outcome. It also makes the feedback mechanism in Decision 4
load-bearing rather than decorative — an objection must carry a reason and a section flag to
count at all.

Trade-off recorded deliberately: with five members, 4-yes/1-no returns the idea. That is real
minority-block power. The cost of a wrong objection is one revision cycle, not a kill.

### 4. A rejection carries a reason and one of the five sections — and that forces the surface

A Full Idea that fails, **whether on completeness grade or on the vote**, returns to its
originator rather than dying or stalling. Every rejection carries free text **plus exactly one
of the five Full Idea sections** flagged as the cause. A sub-bar grade flags its weakest
section automatically, using the per-field scores `completeness.js` already computes — which
also means a resubmission can be checked against the flagged section.

**This requirement is what makes the hall the only possible voting surface.** A Discord
reaction can express yes or no and nothing else, so reaction-voting would make every
Discord-cast rejection feedback-free — precisely what this decision exists to prevent. The hall
is not the *richer* surface; it is the only one that satisfies the rule.

Resubmission is unbounded in v1 — the grade gate already bounds spam — and every past rejection
stays visible on the item's history.

### 5. The completeness grade is the floor; the vote is the merit

A Full Idea must clear the completeness pass bar (60, ADR 0172-per-craft) before a window can
open, and a window opens **automatically** on that pass.

Two gates doing two jobs: the deterministic scorer asks *is the thought fully expressed*, the
board asks *is it worth doing*. Board time is never spent on what a free, reproducible check
could bounce.

Consequence to design for, and a direct result of automatic opening at a 90-minute default:
**concurrent windows are normal.**

### 6. Who governs is configuration, and day one is monarchy

The membership predicate, the pass rule, and the window live in `config/government.json`,
resolved **per request and uncached** so the ADR 0016 instant-demotion property survives.

Day one this instance runs `membership: rank:archon`, `pass_rule: first_ratifier`, no clock —
**monarchy, expressed as configuration on the real machinery rather than as a separate code
path.** The board path therefore executes from the first ratification, and flipping the switch
later changes numbers, not a code path that has never run. The documented recommended starting
point for a new project is: all Archons, one vote each, consent, 90-minute window.

### 7. Amendments are decided under whatever rule the current constitution names

Changing the constitution is a board subject (Decision 1). It is decided by **whatever rule is
currently in force** — so under monarchy, "the board must ratify" resolves to "the Archon
ratifies", and flipping *out* of monarchy is a legal act of the monarchy. Every change after
that belongs to the board.

**No bootstrap special case is required**, and none should be added. This is how a
constitution's own amendment procedure normally works, and inventing an exception here would
create exactly the loophole this ADR exists to close.

### 8. Discord is an outbound notification mirror that casts nothing

On window open, the board channel receives an announcement mentioning the members whose vote is
wanted, carrying a deep link to that item in the hall. State changes — closed, outcome — are
mirrored. **Discord reads nothing inbound and casts no vote.**

The mention *is* the "vote within X" notice, and Discord's own mobile app *is* the mobile push
— **no mobile surface needs to be built.** The bot has no DM capability today, and a channel is
the better shape regardless: it is a room, it is auditable, and deliberation sits beside the
vote. Per-rank view access follows ADR 0037.

`modules/discord/discord-approvals.js` (task 1100) is the precedent for **how to broadcast and
how to re-check a live rank** — *"the bot asserts only who reacted; the GDS decides what they
may do"* — and explicitly **not** for how to vote, per Decision 4.

### 9. Open ballot

Member, direction, timestamp, and objection reason are visible to all members. A board whose
votes are invisible cannot constrain anyone, which is the entire purpose of an upward-pointing
gate. It also makes the vote-karma in Decision 10 auditable.

### 10. Voting earns karma

A small award per vote cast in-window (proposed `+1`); the Full Idea's author earns karma on
ratification, mirroring `KARMA_RATIFY_DELTA` (`+3` — tuned down from `+5` in V3.R28 / task 248;
do not copy the stale `+5` still printed in `planning-session/SKILL.md` and `openapi.json`).

**Decided against the recommendation, with the risk accepted knowingly.** Under consent a *yes*
is one click while a *no* requires a written reason and a section flag, so equal pay for unequal
effort tilts toward assent. Accepted because **the item volume is too low to farm** — the
board's only subjects are Full Ideas and constitutional amendments, both rare by construction.
Revisit if item volume grows; the award is one constant.

### 11. An author may never vote on their own item

Server-side, on the `peer_votes` anti-self precedent (migration 058, `UNIQUE(voter, target)`).
This is the bright line that keeps ratification from being ceremonial, and it is the one rule
that survived from a much larger scrutiny mechanism the owner cut.

## Consequences

**Goal 1000067 (IC5, task 1002999) is unblocked by the pass event, and by nothing else.** ADR
0172-per-craft is explicit that stream 3 *"consumes the Board Room's pass event; invents no
parallel vote."* There is exactly one vote surface in this system. The event fires once per
ratified idea and must be idempotent across replays, re-closes, and a resubmission that passes
again. `economy` is deliberately outside this goal's scope: we emit, 1000067 pays.

**The permission keys must land with their grant migration in the same deploy as the code
constant.** `government_rank_permissions.permission_key` stores the key as text while
`catalog.js` holds it as a constant; if the rows change while old code is serving, the check
fails closed — on the very tab an owner would use to investigate (ADR 0174 §Consequences). The
grant migration is load-bearing, not bookkeeping: `governance_002` is run-once, so an
already-migrated database never learns a key added only in code.

**Board state lives in `modules/government/`, which is protected.** All board work is therefore
Archon-gated. This was chosen over `modules/ideas/` (subject-ownership) on the grounds that the
board is an authority mechanism. The rename that created that folder landed on `origin/main` in
`14dcedd`; note that task 1003005 reads `abandoned` but was *absorbed* into 1003004 and shipped
there — read the note, not the status.

**Goal 1000069 is walled to the `governance` alias, not `government`.** Prod served core
1.19.179 while the new scope key landed in 1.19.180, so the live server rejected the new key at
goal-creation time. The alias carries identical globs. **Re-point `scope_modules` once 1.19.180
is deployed.**

**The charter library ships without the Charter Builder.** The Government page presents all
seven constitutions, the three trajectories and the ladder thresholds, marking which are
selectable today. This is the reference half only — the configuration machinery is deliberately
absent, per the scale argument in Context 3. At two builders this is the half that earns its
keep, and its stated purpose is getting a team up to speed before deciding when to flip the
switch.

**The agora auto-link from idea 1000738 is deferred, not dropped.** Linking discussion *in*
would mean reading Discord inbound, contradicting Decision 8. Once goal 1000064 makes the Agora
a hall surface, the link is hall→hall and needs no adapter. Filed as idea 1000757.

**Rejected: quadratic vote weighting and the attribution-economy knobs.** The synthesis doc's
Part V spends its length on meter-weighted franchise — the Solon problem, compressing whales
with √credits, the drift from timocracy toward isonomia. None of it applies here, because v1's
franchise is a flat membership rule and is not weighted by credits at all. Hop decay (γ), time
half-life (τ), the 30% stack cap and vote coupling belong to the ideator credit lane, not to
this decision.

**Rejected: eternity clauses in v1.** Fork rights with an asset-split rule, meter transparency,
and a dead-man's switch on founder inactivity are real and worth having — Germany's Basic Law
Art. 79(3) and MolochDAO's ragequit are the precedents — but nothing in v1 depends on them, and
an unamendable floor written before the amendable part has ever run would be guesswork.

**Rejected: any legal-entity integration.** Equity issuance, Rev. Proc. 93-27 profit interests,
Subchapter T patronage, and the Howey posture are a later version's problem. v1 credits stay
reputation- and governance-weighted only, which is also what keeps the Howey question asleep.
