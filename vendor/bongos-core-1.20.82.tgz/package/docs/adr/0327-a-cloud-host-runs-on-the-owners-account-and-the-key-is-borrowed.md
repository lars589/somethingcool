# ADR 0327 — A cloud-host runs on the owner's own account, and the key is borrowed, not stored

- **Status:** accepted, **superseded in part by [ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md)** (2026-09-28): what a cloud-host puts on the owner's Render account is their **app**, not the hall, which we host. The borrowed-key mechanism (§2) and never destroying an owner's infrastructure (§3) stand. Also **one Context finding retracted 2026-09-23** ([task 1004186](https://cloudbongos.com/builders#/task/1004186)): `mercury` was *not* already on Render, and the first Consequences bullet that rested on it is retracted with it. Decisions 1–5 are unaffected and stand. See the correction in Context.
- **Date:** 2026-09-22
- **Task:** [task 1004175](https://cloudbongos.com/builders#/task/1004175) (goal 1000106 — working area 1, Project creation)
- **Deciders:** Lars (Archon) — decisions 1, 3 and 4 are the owner's. Decision 2 is Claude's design answer to the owner's question "is there a simpler way", and decision 5 records a measurement.
- **Supersedes in part:** [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) §1 (three shapes) · §3 (who pays) · §7 (the capped trial) · [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md) §4 (one credential, "never per-customer")
- **Depends on:** [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) (Render as the platform, and the not-the-landlord posture this completes)
- **Related:** [ADR 0111](0111-instance-hosting-provisioning-module.md) §2 (the trust boundary, whose enforcement §5 below corrects) · [ADR 0133](0133-github-app-manifest-onboarding-signin.md) (the short-lived-value pattern decision 2 reuses) · [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) (the credential-free liveness pull) · [ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md) (the deploy door, which needs no platform credential)

## Context

[ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) moved a `cloud-host` off our droplet and onto Render so that we would stop being an infrastructure landlord. It left one thing unexamined: **whose Render account.** Its §3 priced a `cloud-host` at ~$14/month and its §7 capped the free tier *because we were paying*; [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md) §4 then ruled the platform token is ours, "root-only on the control plane … and never per-customer".

Standing that up exposed what the unexamined assumption costs. A Render API key is issued against a *user* and carries that user's rights in **every workspace they belong to**. The owner's key reached three workspaces, one of them another builder's, holding their live production services. We would have been one bug away from acting on a third party's infrastructure with a credential they never gave us.

The same check found what was recorded here as a second thing: "**`mercury` was already on Render**, run by its own owner from their own repository. Under ADR 0323 we would have migrated a working project *off* a correct setup and onto our bill."

**Correction, 2026-09-23 ([task 1004186](https://cloudbongos.com/builders#/task/1004186)). That finding is wrong; the sentence above is kept only to show what was claimed.** The Bongos instance is on our own box, and always was. Measured against the live fleet and the live endpoint:

- Fleet row 31: `hosting_shape='standalone'`, `domain=mercury.cloudbongos.com`, `db_name=mercury`, `port=3018`, `onboard_mode=adopt`, `target_ref=willHermesLines/mercury_bongos`, last verified up 2026-09-24.
- `GET https://mercury.cloudbongos.com/healthz` → `200`, carrying the header **`via: 1.1 Caddy`** — our Caddy, our control-plane box, behind Cloudflare. `/version` reports core 1.19.312.

**What was actually seen, and why it misled.** `mercury_bongos` is a *hybrid* repository: its owner's own Python warehouse application (`app.py`, plus a `Procfile` reading `web: gunicorn app:app`) with an **adopted** Bongos instance layered onto it (`package.json` depends on `@bongos/core` as `file:vendor/bongos-core-1.19.305.tgz` — the vendoring path). It carries no `render.yaml`. So the live production services in that workspace are most plausibly the owner's *Python app* — a real Render deployment that is simply not the Bongos instance. A workspace listing and an instance row were read as the same object; they are two systems sharing a name and a repository.

That last step is the likeliest reading, not a measurement — confirming it needs the owner, or a look inside their workspace, and neither was available. What *is* measured is the half that matters: **the Bongos instance is on our box and has not moved.**

**The decision below does not depend on the retracted half.** The first finding — that a Render API key carries its user's rights into every workspace they belong to — is measured, and on its own it is sufficient. The remaining landlord relationship was never the servers; it was the **account**.

## Decision

### 1. Each project brings its own platform key

The project's owner supplies their own Render credential. Bongos does not operate a platform account that customer projects are created inside, and does not hold a billing relationship for anyone's compute.

This retires the ~$14/project line from [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) §3 as *our* cost. It is still the owner's cost, and it is still the right number to show them — see the consequences.

It also makes the blast radius of a leaked key exactly one account: its own owner's. That property comes from this decision, not from any cryptography, and it is the strongest security property in the design.

### 2. The key is borrowed for standup and cleared — never stored

The credential is needed **only to create the services**. Nothing afterwards needs it:

| Afterwards | How it works without a credential |
|---|---|
| Routine deploys | Render auto-deploys from Git. Render talks to GitHub; we are not in the loop. |
| The owner's deploy door ([ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md)) | Moves the core pin and pushes. Render deploys on its own. |
| Liveness and status | The [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) pull against the instance's own public manifest. Already shipped. |
| Teardown | We disconnect. We do not delete — see decision 3. |

So the key rides the existing queue as a short-lived value: the web tier validates it, encrypts it with `src/bongos/secret-box.js` as it already exists, and the runner consumes it within one drain and **clears the column**. This is the same shape as the GitHub App Manifest handshake ([ADR 0133](0133-github-app-manifest-onboarding-signin.md)) — a value that lives in a row only long enough for the runner to spend it.

**What this deliberately does not build**, because nothing is stored: no asymmetric sealing module, no per-row credential binding, no rotation or revocation flow, and no separate-unix-user precondition. Each was designed and then deleted when the retention question was asked instead of assumed. A design that stores nothing has no storage to protect.

**What it honestly does not buy.** Encrypting the value protects it from a database dump or a nightly backup, which is the realistic threat. It does **not** defend against a compromised web tier, because the owner's key arrives there in plaintext before anything can encrypt it. That defence was never available at any retention length; only browser-side encryption would reach it, and it is not worth its cost here. Say so rather than implying the encryption is a boundary.

**The cost of not storing it:** a failed standup is retried by the owner re-entering their key, not silently by us. For a once-per-project action that is the better default — an unattended retry holding someone else's cloud credential is not a thing this platform should do.

### 3. We never destroy a customer's infrastructure

Teardown disconnects the instance. The owner deletes their own Render services, in their own account, when they choose to stop paying.

This is why decision 2 works, but it is a safety property first: **the platform should not hold the ability to delete infrastructure it does not own.** A force-teardown that reaches into a customer's account is a capability worth not having.

### 4. Two shapes, not three; and the free tier is free

`dedicated-cloud-host` is removed. On the owner's own account a larger plan is a setting they choose, not a hosting shape we model. [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) §1 already called it "a plan size, not a second code path" — this finishes that thought by deleting the shape as well as the code path. The shapes are:

| Shape | Meaning |
|---|---|
| `byo-host` | The owner runs the instance. |
| `cloud-host` | We stand it up, on the owner's own platform account. |

`control-plane` is unchanged and stays unrequestable. `co-tenant` stays retired and remains a valid *stored* value ([ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) §1).

**The free tier is free.** [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) §7 capped it because an indefinite subsidy at ~$14/project was not viable. We no longer pay for customer compute, so the premise is gone. Whatever caps exist are about the hub and the hall — our own costs — and are not this decision's to set.

### 5. The ADR 0111 §2 boundary is a convention, not an operating-system boundary — recorded, not fixed here

[ADR 0111](0111-instance-hosting-provisioning-module.md) §2 says the internet-facing web tier holds no cloud token, and [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md) §4 describes the token file as "root-only on the control plane". Measured on the box, 2026-09-22:

- `cloudbongos.service` runs `User=lars` with **no** sandboxing directives — no `ProtectHome`, no `ProtectSystem`, no `ReadOnlyPaths`.
- `/etc/cloudbongos/box.env` is mode `600`, owned by **`lars`**, not root.
- The runner units also run `User=lars`.

So the web tier process **can** read the DigitalOcean, Cloudflare and platform tokens. The separation is real in the *code* — the web tier only enqueues intents — but it is enforced by that code's discipline, not by the kernel. ADR 0325 §4's "root-only" is not what is on the box, and this ADR corrects it.

**Correction, 2026-09-23 (task 1004176).** This section originally carried a second finding — that `~/.config/otb/builder-secret.key` is mode **777** on a box with a second shell account. **That finding is void.** The path is a *symlink* to the real key, and `lrwxrwxrwx` is the only thing a symlink's mode ever displays on Linux; access is governed by the target, which is mode 600 owned by `lars`. The "49 bytes" was the length of the target path, not of a key. It was inferred from an `ls` listing rather than from an attempted read, which is exactly the mistake the verification note below exists to prevent. The retraction itself was then confirmed the way the original claim should have been: as the box's *other* shell account, both `cat` and a write test against that path are refused. The legacy read path in `src/instance-config.js` is real but carries no exposure.

**Resolved 2026-09-23 by [task 1004176](https://cloudbongos.com/builders#/task/1004176)**, and more narrowly than this section proposed. The remedy is not the unix-user split sketched below — that would mean relocating the checkout, the config dir, `web.env` and the secret-box master key, which the web tier *legitimately* needs for per-builder AI keys. It is a systemd drop-in carrying `InaccessiblePaths=/etc/cloudbongos/box.env`, which puts an empty mode-000 node over the file in the web tier's own mount namespace. Verified after applying: refused as the service user inside that namespace, still loaded by the runner units in the host namespace, no errors, site up. The drop-in lives at `scripts/gds/cloudbongos-token-isolation.conf`.

**A verification trap worth carrying forward:** the first check read the file as **root**, which bypasses a mode-000 over-mount via `CAP_DAC_OVERRIDE` and reported "no effect" against a working configuration. Prove an isolation as the process's own user, never as root.

**It was recorded here rather than fixed here.** It is a real pre-existing exposure of *our own* tokens, and it is emphatically **not** a precondition for decisions 1–4 — that is the point of storing nothing. Had we stored per-project keys sealed with a private key in `box.env`, this finding would have made the sealing worthless, and the two would have had to land together.

## Consequences

- ~~**The migration shrinks to an adoption.** `mercury` is already in the target state; its instance record needs pointing at a deployment its owner runs, not a move.~~ **Retracted 2026-09-23 ([task 1004186](https://cloudbongos.com/builders#/task/1004186)) — see the correction in Context.** The migration does not shrink: `mercury`'s Bongos instance runs on our box and still has to move, like the other three. Because the project is someone else's, that move needs its owner's agreement and their own Render account, which makes it the courtesy call this ADR's closing thought was reaching for. <redacted> remains a real distinction — `scripts/gds/provision-repo.js` already draws it for repositories and the platform leg still needs it — but nothing in the fleet is currently an example of it, so it has to be built from the spec rather than from a live case. The pilot is [task 1004142](https://cloudbongos.com/builders#/task/1004142) and the moves are [task 1004184](https://cloudbongos.com/builders#/task/1004184).

- **The fleet cost ledger's question changes, and it is no longer "what do we owe".** [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md) §6 filed [task 1004148](https://cloudbongos.com/builders#/task/1004148) because `costEstimateUsd` returns 0 for a project "the platform is about to be billed for". The platform is not going to be billed for it. A ledger reporting our spend should read ~$0 per `cloud-host` and be *correct*; what an owner is worth telling is **their** estimated Render cost, which is a different column with a different meaning. Reporting one as the other is the defect now.

- **Metering and charging lose their forcing function.** [task 1001949](https://cloudbongos.com/builders#/task/1001949) was sized against recovering ~$14/project/month. There is nothing to recover. Cost *visibility* — showing an owner what their project costs them — survives as a product feature; billing for hosting does not, because we do not host.

- **`dedicated` becomes dead code, and — measured — no data at all.** Its stored value must be dropped rather than merely orphaned. Pointer corrected 2026-09-23: that work split out of task 1004142 into [task 1004182](https://cloudbongos.com/builders#/task/1004182). The same check found the fleet carries **zero** `dedicated` rows, so the "runs over live rows" caution belongs to the 22 `standalone` rows being renamed to `cloud-host`, not to `dedicated`, whose migration is a no-op. Re-verify before writing one.

- **Our own token exposure is now the largest unmitigated item in this area.** Decision 5 is filed as its own task. It was not urgent while it protected only tokens we could rotate ourselves; it stays that way, but it should not stay unowned.

## Alternatives considered

- **Store each project's key, sealed with a key pair.** The web tier holds a public half and can only lock; the runner holds the private half and can open. Designed in full, then rejected: it buys permanent automation we found no use for, and it requires the decision-5 unix split first, because a private key in `box.env` is readable by the web tier exactly like everything else there. Three days of work and a live-site infrastructure change, to keep a value we established is needed once.

- **One platform account, ours, with every project inside it** — [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md) §4 as written. Rejected: it keeps us the billing landlord, it makes one leaked credential reach every customer, and the account-wide scope of a real Render key means it would have reached workspaces we were never given.

- **Never take a key at all — generate a Blueprint and have the owner click once in Render.** Genuinely the simplest, and tempting. Rejected because the manual click is the exact friction `cloud-host` exists to remove: an owner clicking through Render's dashboard has bought very little over `byo-host`.

- **Keep the key only in the browser and have it call Render directly.** Rejected: standup is a multi-step runner job with retries and an audit trail, not a page that stays open.
