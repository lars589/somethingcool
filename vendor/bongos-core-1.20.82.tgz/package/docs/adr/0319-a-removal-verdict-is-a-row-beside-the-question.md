# ADR 0319 — A removal verdict is a row beside the question, because both answers close it the same way

**Status:** accepted · **Date:** 2026-09-20 · **Task:** [task 1004095](https://cloudbongos.com/builders#/task/1004095) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0313](0313-a-removal-is-proposed-by-the-ship-and-confirmed-by-a-person.md) (the decision of record — the system proposes, a person confirms) · [ADR 0242](0242-a-cascade-is-a-declaration-table-on-the-event-that-already-exists.md) (the runner a rule is appended to, and may not fan out) · [ADR 0299](0299-the-nod-queue-stays-scoped-to-routed-filings.md) (why the nod queue is not widened) · [ADR 0312](0312-provenance-is-a-second-ideas-owned-edge-table.md) (the descent a confirmed removal dims)

## Context

[ADR 0313](0313-a-removal-is-proposed-by-the-ship-and-confirmed-by-a-person.md) settled that a ship which deletes an earlier shipped task's files files a **question**, and that a person answers it: Metic+, `task.promote`, on the existing awaiting-nod surface, with an unanswered proposal rotting on the normal clock. Task 1004090 built the question. Nothing could answer it.

Answering turns out to have one property that decides the whole design: **both answers close the proposal the same way.** The proposal is a question, not work — confirming leaves nothing to build, and so does dismissing. Either way the only sensible end state for that task row is `abandoned`, the ledger's one spelling of "finished with the project, not delivered" (`modules/lifecycle/task-status.js`).

So a status alone cannot be the record. "Yes, that work is gone" and "no, that was a refactor" would be the same row, and brightness — the live share of a descent, the next task in this chain — would have no way to tell the star it must dim from the one it must not. ADR 0313 already ruled out the obvious alternative: a `removed` task status, because `shipped` is terminal by design and a removal is "a fact about work's fate, recorded beside it, not a new terminal state that ship rollup would have to learn."

## Decision

### The verdict is its own row, and there is exactly one of them per proposal

`lifecycle_removal_verdicts` (migration `lifecycle_009`) holds `proposal_task_id` (**primary key**), `ship_task_id`, `verdict ∈ {confirmed, dismissed}`, `decided_by`, `decided_at`, `note`. It is the "beside it" ADR 0313 asked for. The verdict write and the status change commit in **one transaction**: a verdict with no closed task would be re-answerable, and a closed task with no verdict is precisely the erasure this exists to prevent.

The primary key on `proposal_task_id` is a decision, not a default. A second answer is **refused** (`ALREADY_DECIDED`, 409), never upserted and never treated as an idempotent success, because overwriting destroys the only record that a person answered differently. The proposal row is locked `FOR UPDATE` before any of the row-scoped checks, so two people pressing Confirm and Dismiss at the same moment cannot both read "undecided"; the second loses on the refusal rather than winning on write order. Amending a verdict is deliberately not built: if it is ever needed it is a second row and an append-only history, not an UPDATE.

`ALREADY_DECIDED` is checked **before** `PROPOSAL_CLOSED`, because an answered proposal is also abandoned — checking status first would tell someone "this is not an open question" when the useful answer is "it was dismissed, by builder 7, yesterday".

### The verdict is what this ships; the target list is not

The proposal names the affected tasks and paths as **prose in its body**, because a cascade files one task per rule per ship with no field for a target and ADR 0242 forbids widening the runner to fan out (owner decision, 2026-09-20, recorded in `cascade.js:removalProposalBody`). This ADR does not change that and does not parse it. A body is written for a person to read; a reader that silently depends on its line shape breaks the day somebody improves the wording.

What brightness gets from here is structured: the verdict, and `ship_task_id` — denormalised out of the proposal's `source_ref`, which encodes it as `cascade-removal-proposed-on-ship-<id>`, a string nothing can join on (the same complaint `ideas_007` makes about the same field). Brightness designs its own storage for targets when it needs one, which is where the owner put that decision.

A ref that cannot be parsed still yields an answerable proposal, with `ship_task_id` NULL. The verdict is the point; refusing to record one because a convenience column could not be filled would be the tail wagging the dog.

### The proposals get their own slice on the attention card, not a row in the nod queue

Spec decision 15 says "the existing awaiting-nod surface". The **surface** is the hall's one Needs-your-attention card; the **queue** is `listRoutedAwaitingNod`, which filters `origin = 'route'` on `ideas_task_lineage` and which [ADR 0299](0299-the-nod-queue-stays-scoped-to-routed-filings.md) decided — on live numbers — stays scoped to routed filings and is honestly named for that population. A removal proposal has no idea lineage at all, so widening that predicate to reach it would both break ADR 0299 and make an ideas-owned table answer a lifecycle question.

So: same card, same floor, separate slice (`#attention-removals`, straight after the nod), fed by its own routes.

### The permission is reused; the verb is not

`GET /removal-proposals` and `POST /removal-proposals/:id/decide` both gate on the **existing** `task.promote` atom — Metic+, the same floor as the nod, so a caller who can see the queue can act on it by construction rather than by coincidence. No new permission and no new page, as spec decision 15 requires.

A new *route* is nonetheless needed, and that is not a contradiction. The nod could reuse `POST /tasks/:id/promote` because promoting is exactly what a nod does; there is no existing route that means "that work is genuinely gone". `/tasks/:id/abandon` would close the question without recording which answer was given — the one thing this feature exists to produce.

The path is top-level (`/removal-proposals`, the `/override-requests` precedent) rather than `/tasks/removal-proposals`, because the manifest mounts the `tasks` route file first and its `/tasks/:id` would swallow a literal single segment declared in a later file — the trap `modules/ideas/routes/inbox.js` documents for `/inbox/awaiting-nod`, avoided here by not sharing the prefix.

### Rot is inherited, not rebuilt

An unanswered proposal sits at `backlog`, which is in `rot.TASK_ROTTABLE_STATUSES`, so it enters the existing rot feed on the project's clock with no code written for it — spec decision 14, and why that decision had no competing option. Answering it writes `abandoned`, which is terminal and not rottable, so it leaves the feed by the same mechanism. Both halves are pinned against the rot module's own exported vocabulary rather than asserted in a comment.

## Consequences

**A confirmed removal still changes nothing else.** No status on the removed work moves, no credit is clawed back, `shipped` stays terminal. The verdict is a fact recorded beside the work, and brightness is the only thing that will read it.

**A cascade task created before this shipped is answerable.** The predicate is `source = 'cascade'` plus the removal rule's ref prefix, both read from `cascade.js` rather than re-typed, so any proposal the rule has ever filed qualifies. In practice the set is empty: the rule could not fire in production until task 1004090's final commit.

**The rot feed shows these only to the owner.** A cascade-filed task has `created_by = NULL`, and `rottingFor` addresses a null-creator row solely to a caller holding `builder.roster.read` — the core_227 convention, deliberate rather than accidental, since there is no person a system-filed row could honestly be addressed to. The attention slice is not scoped that way: it shows every open proposal to every Metic+.

**A verdict cannot be corrected through the API.** Stated plainly because it will be noticed: the recovery for a mis-answered proposal is currently a row deletion by someone with SQL, and the right fix — should it ever be asked for — is an append-only amendment, not an UPDATE on this table.

## Alternatives rejected

- **The status alone as the record.** Both answers close the same way, so it records neither.
- **A `removed` task status, or reusing `merged_into_task_id`.** ADR 0313 rejected the first; the second is CHECK-constrained to `abandoned` rows and describes work cut *before* it landed.
- **Parsing the affected tasks out of the proposal body at confirm time.** Couples a machine read to prose written for a person, and the owner already placed that storage decision with brightness.
- **Widening the nod queue to carry removal proposals.** Breaks ADR 0299 and makes an ideas-owned lineage table answer a lifecycle question.
- **Two routes, `/confirm` and `/dismiss`.** The same act with opposite content; splitting it invites the halves to drift in what they close, record and refuse.
- **Upserting a second verdict, or treating it as an idempotent 200.** Destroys the record that a person answered differently.
- **A `LIKE 'prefix%'` match on `source_ref`.** A rule key may contain an underscore, and an underscore is a LIKE wildcard — a silent widening of the read that decides what may be answered.
