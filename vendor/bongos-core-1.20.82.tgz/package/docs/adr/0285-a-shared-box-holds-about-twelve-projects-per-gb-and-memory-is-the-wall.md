# ADR 0285 — A shared box holds about twelve projects per GB, and memory is the wall

- **Status update 2026-09-28 — load-bearing again ([ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md) decision 7).** Project halls stay on the shared box, so the ceiling below gates project creation again: at the ceiling the create route refuses `box_full` up front. The resize ([task 1003923](https://cloudbongos.com/builders#/task/1003923)) is not a prerequisite today, and becomes the next step when the project count nears the ceiling. The "no longer load-bearing" status below is superseded.
- **Status:** accepted; **no longer load-bearing as of [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md)** (2026-09-21). The measurements below are correct and still describe the box — it simply stops holding customer projects, so the ceiling no longer gates project creation and the queued resize ([task 1003923](https://cloudbongos.com/builders#/task/1003923)) is held rather than spent.
- **Date:** 2026-09-15
- **Task:** [1003877](https://cloudbongos.com/builders#/task/1003877) (goal 1000106), a spike. Informs [1003923](https://cloudbongos.com/builders#/task/1003923) (the resize) and [1001949](https://cloudbongos.com/builders#/task/1001949) (managed billing).

## Context

Every live project is `hosting_shape='standalone'`: its own checkout and pinned core, one Node process on its own port and one Postgres database, all on the `s-1vcpu-2gb` control plane beside the control plane itself. Nothing recorded what one more project costs, so creation could not refuse, overflow or price honestly.

The task asked for a throwaway droplet filled one instance at a time. The owner chose instead to **measure the live box read-only**: eleven real projects already give the data points, and nothing was changed to get them.

## Measurement (2026-09-15, live control plane, read-only)

Sources: `/proc/<pid>/smaps_rollup` (`Pss` + `SwapPss`, which avoids `ps` double-counting shared pages), each unit's cgroup `memory.peak`, `/proc/<pid>/stat` CPU ticks over a 60-second `vmstat 5 12` window, `pg_stat_activity` joined to backend PSS, sysstat history (`sa12`–`sa15`) and the kernel journal (retained since 2026-07-14). Box at the time: 1967 MiB RAM, 4 GiB swap, 11 project processes + the control plane, 1.09 GB available.

**One project process:**

| State | Resident (PSS) | Swapped | Total |
|---|---|---|---|
| fresh boot, 10 min old (test4) | 65 MB | 0 | 65 MB |
| same, after 150 local requests | 70 MB | 0 | 70 MB |
| idle for 33 h+ (ten projects) | 12–28 MB | 21–35 MB | **45–49 MB**, a tight band |
| boot peak, cgroup `memory.peak` (includes page cache) | — | — | 118–134 MB |

- **CPU:** 0.02–0.05% of one core per project, the same over the 60-second window and over each process's lifetime.
- **Postgres:** **zero** backends per idle project (pg's pool releases an idle client after 10 s). A busy backend is 7–10 MB PSS.
- **Disk:** a checkout is 77–140 MB, including an unshared 63 MB `node_modules`. An adopted repo with its own dependencies runs larger (hermeslines-marketing: 936 MB). A fresh database is 45 MB.

**Fixed cost of the box, whatever the project count:** kernel unreclaimable memory ~98 MB (slab, page tables, stacks), OS daemons ~112 MB, Caddy 38 MB, Postgres 139 MB (`shared_buffers` 160 MB), and the control-plane process ~116 MB (boot peak 233 MB). That totals **~500 MB**, and we reserve **~250 MB of page cache** on top (an allowance, not a measurement) so module loads and Postgres reads stay off the disk. **~750 MB fixed**, or ~630 MB on a box that does not run the control plane.

**History:** the box has never OOM-killed a project. The only OOM kill on record was Prometheus on 2026-09-04 (812 MB anon), since removed ([ADR 0284](0284-the-control-plane-carries-no-metrics-stack.md)). The worst pressure since then (2026-09-14 11:40: 279 MB available, commit 316%, load 6.82) came during operator ssh sessions while no fleet unit changed state. It was work on the box, not the fleet. The day-average 4–6% user CPU is the control plane's own 1–2-minute intent-runner and deploy timers, each a fresh Node start, and it does not grow with project count.

## Decision

### 1. The number: ~80 MB per project, about 12 projects per GB above the fixed base

Price a project at its **warm** size, 70 MB for the process plus ~10 MB for one busy Postgres backend. **Swap is not capacity.** An idle project shrinks to ~25 MB resident only because the kernel swaps its cold pages out, which is why the box looks roomier than it is. A reboot (the resize in [1003923](https://cloudbongos.com/builders#/task/1003923) needs one), a fleet core upgrade or a burst of traffic brings every project back to warm at once, on top of a ~130 MB boot peak each.

### 2. The ceiling per tier: `floor((usable MiB − fixed) / 80)`

| Tier | $/mo | Box role | Ceiling | $/project |
|---|---|---|---|---|
| `s-1vcpu-2gb` (today) | 12 | control plane | **15** | 0.80 |
| `s-2vcpu-4gb` | 24 | control plane | **39** | 0.62 |
| `s-2vcpu-4gb` | 24 | overflow box, no control plane | **41** | 0.59 |
| `s-4vcpu-8gb` | 48 | control plane | 90 by RAM, **only with a pool cap** (§3) | 0.53 |

Today's box holds **11 of 15**. Resize (or open the next box) when it reaches **12**, which is 80% of the ceiling.

### 3. Memory binds first; connections bind second

- **RAM is the binding constraint** at every tier up to 4 GB.
- **Postgres connections are the next wall.** `max_connections` is 100 (97 for non-superusers), and every instance pool uses pg's default of `max: 10` with no override ([`src/bongos/pool.js`](../../src/bongos/pool.js)). At idle this costs nothing, but nine projects busy at once can exhaust it, and at 8 GB it binds long before RAM does. Filed as [1003928](https://cloudbongos.com/builders#/task/1003928): cap the provisioned instances' pool size.
- **Walls that do not bind:**
  - CPU: 0.03% per idle project.
  - Ports: lowest-free from 3003 up to the 32768 ephemeral floor, about 29,700.
  - systemd: three units per project; `TasksMax` is 2315 per unit.
  - Disk: 26 GB free at ~200 MB per project with its database and dumps, room for ~130.
  - The 04:00 backup cluster: all twelve timers fire in one window with a 5-minute random delay, adding ~4 points of user CPU for ten minutes. Ten of eleven instance backups currently fail on the size floor ([1003925](https://cloudbongos.com/builders#/task/1003925)), so the per-dump cost is not yet observable, but a dump of a 45 MB database is small.

### 4. The shapes: keep three, and add placement as its own question

The measured cost is the same **unit** for `co-tenant` and `standalone`. What separates them is repository layout, not what they cost the box. So no new shape is needed. What the three shapes never answer is **which box**, and the rule is **standalone until the box reaches its ceiling, then the next box**. The box is the unit of spend, and this ceiling governs placement. Filed as [1003927](https://cloudbongos.com/builders#/task/1003927): the runner refuses to place a control-plane-local project past the ceiling. The create route answers the same ceiling up front, as a 409 `box_full` before any row exists ([1003938](https://cloudbongos.com/builders#/task/1003938), [`capacity-gate.js`](../../modules/provisioning/capacity-gate.js)). The runner stays the wall, because only the runner can measure a remote box and the live memory floor.

`dedicated` stays behind `provisioning.fleet.manage` ([`paid-shape-gate.js`](../../modules/provisioning/paid-shape-gate.js)). It has never been provisioned, and it should not be offered to anyone paying nothing: at $6/mo minimum ($24 at the runner's default tier), one dedicated project costs **8–40× a shared slot**.

`costEstimateUsd` prices a shared project at $0, a visibility choice ([ADR 0111](0111-instance-hosting-provisioning-module.md) §6). It can now become honest: a shared slot costs **box price ÷ ceiling**, $0.62–0.80/mo at today's tiers. That change belongs to the billing work ([1001949](https://cloudbongos.com/builders#/task/1001949)), not this ADR.

## Alternatives considered

- **A throwaway droplet filled one instance at a time** (the task's original method). Declined by the owner. The live box already carried eleven instances at two ages (33 h idle and 10 min fresh), which is the slope data a lab box would have produced, with none of the spend.
- **Price by idle resident memory (~25 MB, about 40 per GB).** Rejected. It counts swap as capacity, and it breaks exactly when every project wakes at once: on reboot, on a fleet upgrade, or under traffic.
- **Price by the boot peak (~130 MB).** Rejected. The peak includes reclaimable page cache and lasts seconds, so it would understate capacity by ~40%.

## Consequences

- **+** Provisioning has a number to act on (15 today, 39 after the resize), and the resize in [1003923](https://cloudbongos.com/builders#/task/1003923) has a trigger: 12 projects.
- **+** Billing has a unit cost for a shared slot.
- **−** The page-cache reserve is an allowance, not a measurement. If a ceiling is ever approached, re-measure `MemAvailable` then instead of trusting the 250 MB.
- **−** These are **idle-fleet** numbers. A project with real traffic or large data will sit above 80 MB, so the ceiling is an upper bound for quiet projects. Re-measure the same way (`Pss` + `SwapPss` per unit, `memory.peak`, `pg_stat_activity`) as projects gain users.
