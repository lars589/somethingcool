# ADR 0256 — The visibility ceiling binds the SIGN-IN gate too, and the knob reader moves to the composer

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1003579](https://cloudbongos.com/builders#/task/1003579) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-join-policy`)
- **Deciders:** Claude, under the Archon's standing scope
- **Closes:** [ADR 0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md)'s written *KNOWN LIMIT* — *"the door narrows, the sign-in gate does not"*
- **Implements:** [ADR 0182](0182-project-visibility-two-axes.md) D6's **Self-join** column (the half ADR 0247 enforced was the *Applications* column)
- **Related:** [ADR 0194](0194-joinability-one-door-decision.md) (the one-reader move this repeats one level up; D2's fail-closed rule) · [ADR 0192](0192-platform-visibility-member-door.md) §2 (where that fail-closed rule comes from) · [ADR 0050](0050-device-flow-admission-invite-gated-by-default.md) (the legacy `OPEN_XENOS_ENROLLMENT` flag) · [ADR 0190](0190-settings-apply-in-place-env-patch.md) (how a knob reaches the instance)

---

## Context

ADR 0182 D6 gave the project plane a two-column table — who may **self-join**, and who
may **apply** — and one composition rule: *visibility sets the ceiling; join policy may
only narrow it.* ADR 0247 built that composition (`src/bongos/project-door.js`,
`projectJoinDoor()`) and wired it to the **applications** column: the public
`POST /access-requests`, and through it the hall's landing form, the CLI and the hub's
join relay.

It did not wire the **self-join** column, and said so in as many words:

> **KNOWN LIMIT — the door narrows, the sign-in gate does not.** `openEnrollmentEnabled()`
> is still `joinabilityMode() === 'open'` … Closing it means composing the ceiling into
> `src/bongos/auth-admission.js`, a kernel admission surface this task was scoped out of
> touching.

So an owner who took their project off the map — `visibility: private`, or `stealth`, or
`joinGrant: view` — while leaving `joinability: open` got two surfaces answering the same
stranger differently: the application endpoint queued a request for review, and a
first-time GitHub sign-in handed the same person a `xenos` account with no request and no
invite. Half of D6's table held only where the owner had never explicitly opened enrolment.

The gap's direction was safe — the door was *stricter* than the gate, never looser, so
nobody was admitted whom `joinability` alone had not already admitted — which is why
ADR 0247 shipped it as a written limit rather than halting.

## Decision 1 — `openEnrollmentEnabled()` reads the composed door, and nothing else moves

```js
function openEnrollmentEnabled(deps = {}) {
  return effectiveJoinDoor(deps) === 'open';
}
```

That one expression is the whole behavioural change. It is deliberately the *same* SR-19
move ADR 0194 D1 made when `joinabilityMode` replaced the raw env flag, one level further
up: the four sign-in call sites (`auth-github.js` web + device, `auth-idp.js` federated
twins), `firstTimeAdmissionBlocked`, `webAdmissionStatus` and the manifest's
`admission.policy` all read this one function, so they follow without being touched. Two
surfaces that ask the same function cannot answer one stranger differently; two surfaces
that each read "the relevant knob" always eventually do.

**Nothing changes for any existing project.** `src/branding.js` normalises an absent
`visibility` to `public` and an absent `joinGrant` to `full` (ADR 0247 D1's "the default
is the value that narrows nothing"), so `public` + `full` puts the ceiling at `open` and
the composed door is `joinability` verbatim. Every live project is `public`; a self-hosted
instance carrying the legacy `OPEN_XENOS_ENROLLMENT` flag (ADR 0050) still resolves to
`open` through the same branch it always did.

**The ceiling closes self-enrolment and nothing else.** An invited first-timer, an
existing builder and the configured `firstAdmin` are all admitted to a `private` or
`stealth` project exactly as before — `firstTimeAdmissionBlocked`'s other three terms are
untouched. An owner taking their project off the map is closing the front door, not
evicting the people they let in, and a `private` project that locked out its own founder
would be the R62 bootstrap dead-end all over again.

## Decision 2 — The manifest's `admission.policy` reports the GATE; `brand.project` keeps reporting the SETTING

`GET /instance` carries both, and after this change they can differ: a `private` +
`joinability: open` project reports `brand.project.joinability: "open"` and
`admission.policy: "invite-only"`.

That is not a contradiction, it is the two questions the manifest has always been
answering — *what did the owner set?* and *what will the gate do?* — finally giving
honest answers to both. Before this, `admission.policy` said `open` while the gate would
have refused, and a CLI reading it to decide whether to offer `bongos login` believed it.

**The narrowed value leaks no state.** `admission.policy` is binary and `invite-only` is
already what every `apply` project reports, so `private`, `stealth`, a `view` grant and a
plain `invite_only` project remain indistinguishable through it — ADR 0247 D3's rule that
a refusal may never be read backwards into a state, preserved because the field had only
two values to begin with. Keeping the read-back honest on `brand.project` is the other
half of the same rule (ADR 0194 D1: the manage page's *"did my save take effect?"* must
show the owner's own value, which is why the ceiling is composed on the instance rather
than folded into what the platform pushes).

## Decision 3 — The knob reader moves to the composer, because the alternative is a require cycle

`joinabilityMode()` and its `legacyOpenEnrollmentFlag()` helper moved from
`src/bongos/auth-admission.js` into `src/bongos/project-door.js`. `auth-admission`
**re-exports** `joinabilityMode`, so `auth.js`, the doorway's `api.joinabilityMode` and
every existing import keep resolving; the doorway surface is unchanged, so this needs no
`module.json` floor bump (contrast ADR 0194 D7, which added an export).

The reason is mechanical and worth writing down, because the obvious patch does not
compile past the gate. `project-door.js` resolved its own `joinability` input with a lazy
`require('./auth-admission')`. The moment the admission gate requires the door back, the
two files point at each other — and `fitness-ratchets.js` counts require cycles from the
**source text**, so a lazy require inside a function body is still an edge. The
`require_cycle_count` ratchet is shrink-only at 4; adding a fifth is a hard build failure,
and it would be right to fail: a cycle here is a real one, not a measurement artifact.

Three ways out were considered:

1. **Duplicate the composition in the gate.** Rejected on sight — it is the exact drift
   SR-19, ADR 0194 and ADR 0247 were each written to prevent, and the ratchet would only
   be measuring that we had hidden it.
2. **Make `joinabilityMode` a required argument of `effectiveJoinDoor`, supplied by the
   doorway.** Zero new files and no cycle, but it turns `effectiveJoinDoor()` — the
   no-argument call ADR 0247 D2 published as *the* one call a door surface makes — into a
   footgun that silently answers `invite_only` for any future caller who forgets.
3. **Move the reader to the composer** (chosen). The file whose header already says it is
   *"composed from every knob that can close it"* now owns the readers for all of them.
   The dependency runs one way — gate → door → branding/env — `effectiveJoinDoor()` keeps
   working with no arguments, and one lazy cross-require disappears rather than a second
   appearing.

`joinabilityMode` was only ever in the admission file because the admission gate was its
first caller (ADR 0194); the layering was accidental, and this task is what surfaced it.
Its `[auth]` log prefix is kept verbatim across the move — operators grep sign-in refusals
by it, and the child logger's `src` field already says which file emitted the line.

## Decision 4 — `locked` still cannot fire from the sign-in gate

`openEnrollmentEnabled` passes **no** `publishable` verdict, so the tri-state stays `null`
— *no verdict* — and the door is answered on the three stored knobs alone. ADR 0247 D4's
finding has not changed: neither plane holds a live, correct dark-matter verdict, the
instance's branding pack carries no `description`, and the hub's cached copy says every
live project is dark matter. A gate that read that column would refuse every first sign-in
on the platform. The `deps` object is forwarded verbatim, so wiring a verdict later is one
argument at one call site, not a redesign.

## Decision 5 — The sign-in refusal page tests the door, not the knob

`routes/auth.js` chose between its two refusal pages on
`joinabilityMode() === 'invite_only'`, which was equivalent to the door only while the
knob *was* the door. Under Decision 1 the ceiling can close a project whose `joinability`
still reads `apply` — `stealth`, or a `view` grant — and that page would have handed
the stranger a "request access at the hall" form the application endpoint 403s. The test
becomes `effectiveJoinDoor() !== 'apply'`: `apply` is the only door that accepts an
application, so everything else lands on the invite-only page.

**Both closed doors show the same sentence, and that is the point.** Distinguishing them
would be the state read-out ADR 0247 D3 forbids; showing one honest "this project takes no
applications, an invite is the way in" for all of them is the same indistinguishability
the application endpoint already has. `open` cannot reach this branch (the gate would have
admitted) and `locked` cannot fire at all (D4), so in practice it is `invite_only`.

## What was deliberately not built

- **No new refusal COPY.** The two existing pages are reused verbatim; only which one is
  chosen changed (Decision 5). Saying *"this project is private"* would be the state
  read-out ADR 0247 D3 forbids, and a sentence written for this case alone would make the
  refusals distinguishable — the same leak by another route.
- **The hall landing's door copy is left on the raw knob — a NAMED limit, in the same
  shape ADR 0247 named this one.** `modules/hall-ui/public/hall-render.js` renders one
  landing per `window.__BRANDING__.project.joinability`, and its own comment already calls
  that *"cosmetic — the server refuses on its own terms either way"*. After this change
  a `private` + `open` project's landing still reads "sign in and you're in" while the gate
  refuses, so the visitor meets the truth one click later instead of on the page. Fixing it
  properly means the server injecting the COMPOSED door into the pack the browser reads
  — re-deriving the composition in browser JS is the drift this whole line of ADRs
  exists to prevent — which is a public-field addition, not a side effect of this one.
  It is reachable only on a project whose owner has taken it off the map, and every live
  project is `public` (ADR 0247's own Consequences).
- **No `webAdmissionStatus` special case.** It reads `openEnrollmentEnabled()` like the
  gate does, and `tests/web_admission_status.mjs` already sweeps the input space asserting
  the probe and the gate agree. The composition arrives there for free; a second code path
  would be a second thing to keep in sync.
- **No manage-page control for the grant.** Still a rendering task, unchanged from
  ADR 0247's "what was deliberately not built".

## Consequences

- ADR 0182 D6's table is enforced in **both** columns, from one function, on every surface
  that admits or refuses a stranger.
- `tests/admission_ceiling_gate.mjs` boots a real instance on `visibility: private` +
  `joinability: open` — the exact pair ADR 0247's limit paragraph named — through the
  production channel (`<PREFIX>_VISIBILITY` / `<PREFIX>_JOINABILITY` in the environment,
  read once through the memoized pack, as the provisioning runner writes them into
  `web.env`). It then sweeps all 75 knob combinations asserting `openEnrollmentEnabled()`
  equals *"the composed door is `open`"*, and that **exactly one** combination —
  `public` / `full` / `open` — self-enrols.
- `src/bongos/project-door.js` no longer imports `src/bongos/auth-admission.js`; the
  `KERNEL_FILES` note in `fitness.js` that described that import is updated with it.
  `require_cycle_count` stays at 4.
- A surface that genuinely wants the owner's *setting* rather than the *door* — the
  manifest read-back, the hall's door copy — still calls `joinabilityMode()`. The
  distinction is now written on the function itself, because "read the knob" and "decide
  admission" being the same call is what produced this bug.

## Alternatives rejected

- **Composing the ceiling into the `joinability` value the platform pushes**, so the
  instance needs no second reader. Rejected here for the same reasons ADR 0247 rejected
  it: stored and pushed values would disagree, the manage page's read-back would break,
  and it cannot express `locked`. This task is additional evidence for that call — the
  read-back is exactly what `tests/admission_ceiling_gate.mjs` now pins.
- **Leaving the gap and documenting it harder.** It was already documented; a written
  limit that survives two releases is a bug with good manners. The direction being safe
  bought the deferral once, not indefinitely — and the owner-facing statement *"my project
  is private"* is false while any stranger can still sign themselves in.
