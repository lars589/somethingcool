# ADR 0295 — The registry is the witness the publish lane cannot be

**Status:** accepted · **Date:** 2026-09-16 · **Task:** [task 1003916](https://cloudbongos.com/builders#/task/1003916) (goal 1000090)

## Context

On 2026-09-13 eight consecutive publish runs failed between 09:54 and 13:02 UTC on a
mis-scoped leak gate. For three hours `@bongos/core` received nothing. It was found
because a person happened to read the npm version list and noticed a hole between
1.19.715 and 1.19.724 — ten days of exposure closed by luck.

[Task 1003914](https://cloudbongos.com/builders#/task/1003914) fixed the *lossiness*:
the bump commit is now pushed AFTER a successful publish, so a failure retries the same
version instead of burning it. It deliberately left the *silence*, which is structural
rather than an oversight — and every layer involved was working correctly:

- a failed publish is one red row in the Actions tab, and nobody watches the Actions tab;
- `main` keeps looking healthy, because the next work merge bumps past the failure and
  publishes normally — the repo self-heals in a way that **erases the evidence**;
- the lane's own `Publish verdict` step writes ✅/⬜ to the job summary, correctly, and
  is read by nobody.

This is the same shape as the nightly auto-upgrade sweep that died on 2026-08-25
reporting `failed=0`. In both cases the machine knew and no human path existed.

## Decision

**A separate reader asks the registry what the lane only ever asserted.** Two sources
that should agree: *announced* — every version a `release: core X.Y.Z` commit exists
for — and *published*, what the registry actually holds. A version in the first and not
the second is a **phantom**.

**"Announced" is deliberately BROADER than the publisher's own `RELEASE_COMMIT_RE`, and
the gap between the two questions is the reason.** That constant is narrow by design: it
is the cascade terminator, and it must *not* match a human release commit, because a
human release is a version that still needs publishing. That is the correct answer to
the publisher's question ("is this HEAD already done?") and the wrong answer to this
one ("what did we tell the world we released?"). Human carriers exist on main —
`release: core 1.19.3 — CLI/init ergonomics carrier`, `release: core 1.18.19 — carrier
bump for the 32 commits since 1.18.18` — and `publish.yml` fires on any main HEAD with a
bumped `CORE_VERSION`, hand-edited or not. Matching only the CI shape would have left a
failed *human* release invisible to the very check meant to catch a failed release. The
watcher therefore anchors on `^release: core <semver> ` (so a commit merely quoting a
release line cannot match) and records which lane announced each version, so a finding
can say which one broke.

**Why this can exist now, when the publisher's own design says it cannot.** The lane
publishes through OIDC trusted publishing, which carries no read credential and
authenticates `npm publish` and nothing else; that is precisely why
`laneReleasedVersions` infers released versions from git rather than asking the
registry. **That constraint never bound a reader.** Since
[task 1003872](https://cloudbongos.com/builders#/task/1003872) the package is public, so
an anonymous read needs no credential at all (verified 2026-09-16). The publisher must
still infer; the watcher can simply look. Keeping them separate is the point — a lane
that graded its own homework is what produced the silence.

**Daily, not hourly, and stated as a cost trade rather than a preference.** Actions
minutes on this repo are billable and already oversubscribed. Hourly is ~720 runs a
month; a publish outage is measured in hours (09:54→13:02), so a daily sweep bounds the
silence to about a day where the alternative was ten days and luck. Raise it if a second
outage is missed. The cadence and the cron are pinned to each other by
`routine-schedule.js`, so they cannot drift apart silently.

**Deliberately NOT on the session-start path.** `deploy-divergence.js` already runs
there and would have been the cheapest place to surface this, but it would put a network
call to a third party on the hot path of every session start, behind a hook timeout. A
check that makes every session slower is one someone eventually removes.

**A healthy day says nothing.** Findings go to stdout, which `run-routine.js` posts to
Discord `#ship-news`; the healthy line goes to stderr, so a person running it by hand
still sees it and the channel does not accrue a daily "all fine". A channel of
reassurances is a channel nobody reads, which is the failure being fixed.

## Two ways this could cry wolf, and what stops each

**A closed incident is permanent git history.** 1.19.716..723 are announced-and-absent
today and always will be; an all-history check would fire forever. Only the last 3 days
are considered — **by time, not by a commit count**, which a burst of releases would
outrun (the rate varies from ~5 to ~20 a day).

**npm acknowledges a publish before its listing shows it** — the CLI says so outright:
*"Your package is being processed and may take a few minutes to become available."* This
was not reasoned about in advance; **the check found it by running.** On its first live
run it flagged 1.19.794 as a phantom fifteen minutes after a publish whose own log ended
`published @bongos/core@1.19.794` and whose per-version endpoint answered 200 while the
aggregate listing still omitted it. Untreated, it would have alarmed on every healthy
release — a self-defeating monitor. Two guards: a **30-minute grace period**, and a
**per-version confirmation** before anything is called a phantom. The aggregate listing
only ever nominates suspects; it never returns a verdict.

## Consequences

- **A failed read is never a clean result.** `publishedVersions` throws rather than
  returning an empty list. Exit codes are the contract: 0 clean, 1 found **and
  delivered**, 2 could not run, 3 found and could **not** deliver. 2 and 3 are red.
  Reporting an unreachable registry as "nothing missing" is exactly the `failed=0` bug
  that hid the upgrade sweep's death; exit 3 is the same principle applied to the alarm
  itself, since a finding that reached nobody has reproduced the original defect.
- **The scheduler calls the script directly rather than through `run-routine.js`, which
  every other routine uses.** Not a shortcut — a correction, and the second bug this work
  found by running rather than reading. `run-routine` shells out with `execFileSync`
  (throws on any non-zero exit) and its catch does an unconditional `process.exit(1)`, so
  a real exit 2 or 3 arrives at the workflow as 1: the two cases that must be loud would
  have printed a reassuring notice and gone green. Measured, not inferred — a forced
  exit-3 run returns 1 through `run-routine` and 3 directly. The same property made the
  first wiring drop findings entirely: `run-routine` aborts a failed step *before*
  routing its stdout, so the original `sink: discord` step would have thrown away every
  finding it produced. The script now delivers for itself. Where a routine's exit code
  carries meaning, `run-routine` is the wrong harness.
- **The alarm is armed but mute until one owner action.** The repo has no
  `DISCORD_SHIP_NEWS_WEBHOOK` secret (checked 2026-09-16), so a real finding takes the
  exit-3 path — loud in CI, absent from Discord. Adding that secret is the whole fix.
- **The detector is proven against a real failed publish, not a synthetic one.**
  `tests/publish_watch.mjs` replays the 2026-09-13 outage out of this repo's history and
  the live registry: the eight carrier commits exist, the eight versions do not, the
  check names all eight as of that date and is quiet about them today.
- **It does not detect a lane that has stopped being TRIGGERED.** It compares what was
  announced against what was delivered; a publish workflow that never fires announces
  nothing and looks identical to a quiet day. That is a different check.
- Rejected: asking the registry from inside the publish lane (it has no read credential,
  and self-witnessing is the original defect); an all-history sweep (permanent false
  alarm); hourly (cost, for a failure measured in hours); wiring it into session start
  (a third-party network call on every session's hot path).
