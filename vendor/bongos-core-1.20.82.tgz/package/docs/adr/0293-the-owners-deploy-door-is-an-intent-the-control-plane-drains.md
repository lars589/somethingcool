# 0293 — The owner's deploy door is an INTENT the control plane drains, not a web tier with a shell

- **Status:** Accepted
- **Date:** 2026-09-16
- **Tasks:** [#1003159](https://cloudbongos.com/builders#/task/1003159) (goal 1000090) — *"The owner has no path to deploy"*
- **Related:** 0016 (authority is resolved server-side, never from a local file), 0043 (the control plane is a separate privilege domain), 0128 (how the runner escalates), 0130 (the runner drives remote boxes over ssh), 0136 (channel policy), 0137 / 0161 (the three publish gates), 0111 (the provisioning intent queue this reuses)
- **Supersedes in practice:** the manual leg of [#1003156](https://cloudbongos.com/builders#/task/1003156) — that bump stays valid, it just stops being the *only* way

## Context

The owner, 2026-08-22, verbatim: **"I don't think I can make anything live."** The same sentence arrived again on 2026-09-16, phrased *"this is above my paygrade."*

Moving an instance's core pin is gate 3 of the release pipeline and the **only** act that makes shipped work visible to users. Today it is reachable from exactly one place: a shell on the control-plane box, holding an ssh key, running

```
bongos upgrade --registry --to <ver> --service <unit> --health-url <url> --commit-pin
```

There is no route and no hall control. So a release reaching users depends on one person being at one machine. And an agent cannot close the loop either — the permission classifier blocks an agent from a mutating `sudo -u lars` over ssh, by design.

That is a structural mismatch with the platform's own premise. Cloud Bongos is AI-first: agents write the code, the human owner holds the hard gates. **Deploy is the owner's gate, and it is the one gate with no instrument.**

The concrete cost, measured the day this was written: `cloudbongos.com` served core 1.19.754 while 1.19.757 — carrying a shipped fix to the claimable-task feed — sat published and unreachable. Four releases of shipped work that nobody could see, and no one present could act.

## Decision

### D1 — The door is an INTENT. The web tier never gets a shell.

The hall writes a row to `provisioning_intents`; the control-plane timer
(`provision-intent-runner.timer` → `provision.js run-intents --apply`) drains it and does
the privileged work. The web process gains no sudo, no ssh key, and no new capability
whatsoever — it gains the ability to *ask*.

This is not a new mechanism. It is the seam ADR 0111 already built and that `provision`,
`teardown`, `domain-attach`, `settings-apply` and `restart` already ride. `enqueueIntent`
already carries `requested_by`, so the actor requirement is satisfied by the existing
shape rather than bolted on.

**Rejected: giving the web tier sudo.** ADR 0043 makes the control plane a separate
privilege domain on purpose. An HTTP-reachable process that can restart services is the
single highest-value target in the system; the whole point of the split is that
compromising the web tier must not hand over the box. The intent queue crosses that
boundary through one narrow, auditable, append-only row.

**Rejected: a new bespoke queue for upgrades.** A second queue is a second set of
claim/settle/retry semantics to get right, and the failure modes of this one are already
understood in production.

### D2 — The control plane is enrolled as a self-row, and that row is NOT teardownable

`provisioning_intents.instance_id` is `NOT NULL REFERENCES provisioning_instances(id)`.
To ride the queue at all, the control plane needs a row. It does not have one today — the
table holds only tenant projects.

So the control plane is enrolled, with `hosting_shape='control-plane'`: a shape that
exists to be **excluded**, not to be operated on. The non-negotiable that comes with it:

> **Every destructive intent action MUST refuse a `control-plane` row.** `teardown` on the
> self-row would destroy the platform from inside the platform's own UI.

This is the load-bearing risk of D2 and the reason the shape is a distinct value rather
than reusing `standalone`. A test asserts the refusal for every action in `INTENT_ACTIONS`
except the ones explicitly allowed on the self-row (`core-upgrade`, `restart`).

**Rejected: a nullable `instance_id` meaning "the control plane".** A null that means
something is the kind of implicit encoding that reads as a bug at every later call site,
and it would silently widen every existing query that assumes the FK holds.

### D3 — The target version comes from the registry, never from the request

The request names a version; the runner refuses any version that is not **published** and
not permitted by the channel policy (`update-channel.js`). Free text never reaches
`bongos upgrade`.

This is not theoretical tidiness. The release lane mints a git tag **before** the npm
publish completes — measured at 8–13 minutes on 2026-09-16, against ~100 seconds recorded
earlier (learnings 1000263, 1000266). A door that accepted "whatever main says" would
routinely queue a version that does not exist yet and fail with `npm error notarget`. The
registry is the only honest source of "can this actually be taken".

### D4 — Two-step: preview, then confirm. The owner's choice, 2026-09-16.

The control shows what a bump would move — live version → target, and what sits between
them — and fires only on an explicit second act.

Auto-rollback (task 2149) already guards the *bad release* case. This guards the different
one: the **wrong button**. A single click that restarts the live service is recoverable but
not free, and the owner asked for the confirmation. Rejected: typing the version to arm it
(strongest, but friction on an action that should be routine once trusted).

### D5 — Archon-gated server-side, ledgered with an actor

`requireRank`-equivalent on the route, resolved server-side per request with no caching
(ADR 0016). Nothing about this is reachable by editing a local file.

`core_upgrades` gains an actor column. The ledger records **who asked**, not merely what
moved — a privileged action with an unattributed row is not acceptable, and today the table
carries only a free-text `note`.

### D6 — The truth read back is the BOX's, not the tool's

Success is `curl http://127.0.0.1:<port>/version` **on the box**, matching the requested
version — the DONE-WHEN task 1003156 already established. The apex sits behind pre-launch
basic_auth and its HTML rides a CDN, so an apex read can report a stale or gated answer
with total confidence. The health gate and auto-rollback inside `bongos upgrade` are
reused unchanged; this decision is only about what the *control* believes and displays.

## Consequences

- The owner can move the pin from the hall, and read back the version the box actually
  serves, without a shell or an ssh key. That is the whole point.
- **Tenant instances are NOT in this change.** The queue supports them and the follow-up is
  small, but the control plane is where the pain is and mixing the two doubles the surface
  of a first cut on the most privileged action in the system. Filed separately.
- The runner upgrades the box it runs on. This is safe for a reason worth stating rather
  than assuming: the runner and the web service are **different systemd units**, so
  restarting the web service does not kill the run in progress. The running process also
  keeps the code it already loaded, so an upgrade that rewrites the runner's own files
  takes effect on the *next* tick, never mid-run.
- Re-running a settled-but-unconfirmed intent is safe: `bongos upgrade`'s same-version
  guard makes the leg a no-op when the box already serves the target.
- **What this does not do:** it does not make deploys automatic. ADR 0137's three gates
  stand — land, release, deploy — and this only gives the third gate a handle. An owner who
  never presses it ships nothing, exactly as today.
