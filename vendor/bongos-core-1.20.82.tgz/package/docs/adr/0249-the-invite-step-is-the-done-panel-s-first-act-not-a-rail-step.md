# ADR 0249 — The invite step is the done panel's first act, not a rail step — and the same widget is the way back

- **Status:** accepted
- **Date:** 2026-09-04
- **Task:** [task 1002346](https://cloudbongos.com/builders#/task/1002346) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-invite-builders` / C6), BV1.R27
- **Deciders:** Claude, under the Archon's standing scope
- **Depends on:** [ADR 0246](0246-catalog-membership-is-a-projection-not-a-federation-side-effect.md) (a control-plane project is a catalog row keyed on its slug — what makes `client_id` resolve at all) · [ADR 0248](0248-a-hub-project-s-owner-is-the-provisioning-row-carried-on-a-port.md) (the project's own owner may invite — what makes the wizard's audience anything but a 403)
- **Related:** [ADR 0245](0245-the-way-back-into-an-optional-step-is-that-step-s-own-answer-route.md) (an optional step is a default rather than a dead end only if there is a way back) · [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md) / [ADR 0240](0240-a-skipped-module-picker-stores-nothing-and-resolves-the-bundle-on-read.md) (the wizard's other skippable steps) · [ADR 0182](0182-project-visibility-two-axes.md) D2a (a refusal may not identify a stealth project)

---

## Context

BV1.R27 asks for a **skippable invite-builders step in creation**, using the existing
per-individual invite. The wizard is a numbered rail — name · type · about · modules · home ·
address · create — and every other optional step (About, Modules) is one of those numbered
panels, answered *before* the project is filed and carried into the create request.

An invite cannot be. `POST /projects/invite` takes `{ client_id, github_login }` where
`client_id` **is the project's slug**, and it resolves that slug against a catalog row. Per
ADR 0246 that row is a **projection of the provisioning row, written at create** — so before
the Create step there is no row, and any invite filed on a numbered panel would either 404 or
have to be queued client-side and replayed after the create, inventing a second, unaudited
invite path whose failures arrive after the owner has left the screen.

The route also has no "invite later" queue and no bulk form: it pre-seeds exactly one
`pending` membership per call, for a GitHub login that already has a platform account.

## Decision

**The invite step is the FIRST act of the done panel, not a step in the rail** — shown the
moment the created-instance record carries an id and a slug, and skippable there. Four parts:

1. **It is keyed on the created record, not on `instanceId`.** The done panel already
   resumes from `sessionStorage`'s created record on reload, and `startProgress` sets
   `instanceId` *after* `renderDone()` runs. Keying the step on the record is what makes it
   appear on the first paint and again on a resumed watch, with no new state to keep in step.

2. **The rail is not renumbered.** "A wizard step renumbering couples in four places" is a
   captured learning on this exact file, and the draft key has been bumped twice for it. A
   step that can only run after the terminal step is not a step in the rail — putting it there
   would buy the coupling and still have to be re-ordered to sit after Create.

3. **The same widget is mounted twice**, the ADR 0245 argument: an optional step is a default
   rather than a dead end only if there is a way back, so the project's own page carries an
   *Invite a builder* section beside *Its extras*, on the same route with the same behaviour.
   One implementation, two mounts, keyed state per mount — never two copies of the refusal
   vocabulary that could drift apart.

4. **The widget answers neither "is anyone signed in" nor "is this their project."** Each call
   site already knows and hands over a slug or nothing, which is the widget's only door in
   (`setInviteSlug`). The wizard's answer is the created record; the manage page's is that
   the per-id provisioning read is own-scoped and 404s for everyone else, so *reaching*
   `renderManage` IS the ownership answer. A page that re-derived ownership would be a second,
   weaker copy of a server rule ([ADR 0016](0016-trust-boundary-server-enforced-permissions.md)).

### The 403 is quoted carefully, and that is the point

ADR 0248 made the invite refusal **byte-identical and identically slow** whether the project is
real, stealth, absent, or the body malformed — deliberately, so a stranger cannot use it as a
membership oracle over private projects (ADR 0182 D2a). A surface is free to undo that in
copy: *"you don't have permission on this project"* asserts the project exists. So the page
says only what it knows — **"This account can't invite people here."** — and the pin against
that wording is a test, not a comment, because the tempting rewrite is the wrong one.

The other three refusals are said in the route's own vocabulary: `account_not_found` becomes
*"that builder hasn't signed in here yet"* (V1 requires an existing account, and the sentence
says what to do about it); `unknown_project` becomes *"this project isn't on the map yet — give
it a moment"*, because the catalog row is projected at create, so this is a moment rather than
a dead end; anything else falls through to the **server's own message** rather than a reason
the page invented.

### What it publishes of an invitee

The 201 row is `{ id, client_id, github_id, membership_kind }`. The pending line is drawn from
the login the inviter typed plus the row's own `membership_kind` — **never the `github_id`**,
which identifies someone who has accepted nothing yet, and never a state word this page
invented: a kind other than `pending` is shown verbatim rather than papered over.

## Consequences

- **Creation is never blocked by an invite.** The project is filed before the step is shown at
  all, so every refusal leaves a created project and a re-tryable box. Skip sends nothing and
  hands focus to the human-steps heading rather than stranding it in the box it just hid.
- **One builder per call, by design.** Bulk invite, an invite queue, and inviting someone with
  no platform account are the route's own follow-ups, not this surface's to simulate.
- **The pending lines are session-local and per-project.** They are a receipt for what this
  session filed, not a membership directory: switching the mount to another slug clears them,
  because following them across projects would be a lie. The real directory is the project's
  hall, and reading it back here would need a route this task does not add.
- **The R30 proof ([task 1002349](https://cloudbongos.com/builders#/task/1002349)) can run
  without creating a project**, because the manage mount is the same widget on the same route.
- **A wizard step that must run after Create now has a home.** Anything else in that shape —
  the first-invite nudge, a post-standup choice — belongs in the done panel beside this one
  rather than in the rail, and the rail's seven numbered steps keep meaning "answered before
  the project is filed".

## Alternatives rejected

- **An eighth numbered rail step, before Create.** Rejected: there is no project to invite to
  yet, so the step could only collect names and replay them after the create — a second invite
  path, unaudited, whose failures surface after the owner has moved on. It also buys the
  four-place renumbering coupling for a step that must run last anyway.
- **A numbered step AFTER Create.** Rejected: the rail's contract is "answered before the
  project is filed" (`paintRail` reads the whole rail as finished once the project lands), and
  a step numbered 8 would have to be exempted from both the rail's back-navigation and its
  finished state — the coupling with none of the meaning.
- **Only the manage page, with a pointer from the done panel** (the task 1002342 shape).
  Rejected: R27 asks for the step *in creation*, and the moment an owner most wants to invite
  people is the moment their project stands up. The pointer is kept as well, not instead.
- **Read the project's membership back and render the real directory.** Rejected: no
  own-scoped read of a project's pending memberships exists on the hub, and inventing one is a
  route change this task is not scoped for. The session receipt is honest about being one.
- **Word the 403 as "you don't have permission on this project."** Rejected: see above — it
  reopens the existence oracle ADR 0248 paid two equalised reads per request to close.
