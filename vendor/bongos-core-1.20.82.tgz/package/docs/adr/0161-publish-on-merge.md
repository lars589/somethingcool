# 0161 — Publish on merge: every merge to core `main` auto-publishes `@bongos/core`

- **Status:** Accepted. **Amended by [ADR 0361](0361-merges-publish-as-candidates-release-decides-what-others-are-offered.md)** (task 1004298): merges publish as candidates under `next`; `latest` moves only on Release.
- **Date:** 2026-08-08
- **Deciders:** the owner (Archon), Claude. The owner chose this directly after reviewing the pipeline end-to-end: "any merge can publish, we can add in more complexity later."
- **Task:** task 1002620 (BONGOS-V1, goal 1000024 — build-pipeline integrity)
- **Supersedes:** [ADR 0137](0137-upstream-publish-policy-manual-owner-gated.md) (manual owner-gated publish)
- **Builds on:** [ADR 0134](0134-private-first-npm-distribution.md) (private-first npm), [ADR 0136](0136-update-channel-subscription-policy.md) (channel policy), [ADR 0159](0159-merge-gate-reconciliation.md) (the required `unit` check)

## Context

ADR 0137 kept publishing a manual, owner-gated step: no npm write token at rest, the owner runs `package-core.js --publish --live` when they decide to cut a release. Its own "When to revisit" clause said to re-evaluate when the manual step becomes a real bottleneck.

It became one twice in three weeks, measured:

- **171 commits / 10 days** unreleased (blocker 1000097) — an entire governance permission system sat on `main` while the live platform served the previous version and every pipeline layer reported success.
- **104 commits / 5 days** unreleased immediately after — including a `CORE_VERSION` bump (`1.19.0`) that was landed but never packaged, so the version number existed while no artifact carried it.

The consumption side (ADR 0136's subscription) was never the problem; supply was. The owner reviewed the full pipeline on 2026-08-08 and reversed 0137's trade-off explicitly.

## Decision

1. **Every merge to `main` publishes.** A `publish` workflow fires on the `unit` check succeeding on a main push (never on a red suite), builds via `package-core` — the fail-closed no-leak gate and `--self-verify` pin check run inside the build — publishes (restricted), and tags `core-v<version>`.
2. **CI bumps PATCH only.** When a merge lands without a human bump, `scripts/gds/bump-version.js` bumps the patch and writes the changelog line (shape-preserving; pinned by `tests/bump_version.mjs`). A **minor or major stays a deliberate in-task human edit** — it is a statement about the doorway surface, and it decides what patch-channel subscribers receive unattended (ADR 0136). CI is not allowed to make that call.

   **The promise was unkeepable until task 1003526 (2026-09-17).** A branch that hand-bumped had no commit shape the lane recognised, so `tests/bump_version.mjs`'s LIVE check failed its own PR's `unit` check by construction — that is what killed task 1003044's first ship (PR #391) — and had one merged, `publish.yml`'s record step (point 5) fires only when *CI* bumped, so the hand-cut version would have been re-packed by every later merge and **nothing new would ever have published again**. A stalled lane, not just a blocked PR. The owner chose to teach the lane the human shape rather than retire the promise.

   A human release is now a first-class commit: `release: core X.Y.Z — <reason>`, matched by `HUMAN_RELEASE_COMMIT_RE` — deliberately the complement of the CI carrier's `RELEASE_COMMIT_RE`, so no subject reads as both. The two predicates now answer **different questions**, which is the correction: `isReleaseCommit` (the cascade terminator) says **no** to a human carrier, because that version is new and still needs packaging; `laneReleasedVersions` says **yes**, because the number is claimed and the lane must not publish onto it. Forcing them to agree was the defect.

   The cost is one version number: declaring 1.20.0 publishes **1.20.1**, because `publish.yml` reads `taken=true`, bumps one patch past the claim, and records its own carrier — which is exactly what keeps the lane moving. Publishing the declared number *exactly* would mean teaching the record step to fire without a bump, and `.github/` is a protected surface on the lane that already minted-and-lost 1.19.716–723; the digit is not worth that edit. The minor/major signal downstream consumers actually read is preserved.
3. **Token custody reverses, knowingly.** A standing npm **write** Automation token (`NPM_TOKEN`) and a fine-grained **contents:write** PAT (`RELEASE_PUSH_TOKEN`, for the bump commit — the default `GITHUB_TOKEN` cannot push past the required `unit` check) live as GitHub Actions secrets. This is exactly the surface 0137 declined; the owner accepted it with the incidents as evidence. **Superseded for the npm half at task 1003202 (2026-08-25):** the write token is gone — the lane publishes via OIDC trusted publishing (ADR 0180), so no long-lived npm credential exists to steal. `RELEASE_PUSH_TOKEN` remains, as the bump commit still needs contents:write. Mitigations: the lane is **default-inert** behind the repo variable `PUBLISH_ON_MERGE=1` (an owner kill-switch symmetrical to `gating.js`), packages publish `restricted`, and the no-leak gate structurally cannot upload a leaking artifact.
4. **Idempotent by version-compare.** The bump commit re-triggers `unit` → `publish`, which then finds HEAD's version already on npm and no-ops. npm's duplicate-version rejection is the backstop; concurrent merges queue behind a no-cancel concurrency group.
5. **The bump commit is pushed only after the tarball is on the registry** (amended at task 1003914, 2026-09-13). The bump is *committed* before `package-core` runs — it stamps the version found at the ref — but the **push is the last step**, after `npm publish` returns. Originally it ran first, which made a pack or publish failure permanently lossy: `main` declared a version the registry never had, and the cascade terminator (point 4) then no-opped every following run, so only a fresh work merge could move on — bumping *past* the hole. Versions 1.19.716–723 were minted and lost exactly that way during a three-hour leak-gate fault (task 1003873). Pushing last makes the failure discard a purely local commit, and the next run retries the **same** version.

   The inverse failure — published, push then rejected because `main` moved — is closed by promoting point 4's backstop into a recovery path: the publish step treats *"this version is already on the registry"* as **success** and falls through to the record step, committing the release line `main` was missing. The tolerance is deliberately narrow (only the publish-over-existing-version refusal; auth and transport failures still fail the run), and the rejection is **not** retried with `git rebase` — the tarball was built from the pre-rebase tree, so rebasing would leave `source_commit` in the artifact manifest naming a SHA that is not on `main`. A loud, rare, self-healing failure beats a quiet provenance lie.

## Consequences

- A merged change is on npm within minutes, unattended. Combined with the subscription (ADR 0136), patch-channel instances take it on their next sweep — the full merge→live path has no human step for patches.
- The bump commit is authored by `github-actions[bot]` directly on `main` (admin-exempt push, `enforce_admins: false`). It re-runs `unit` as a safety net.
- `deploy-divergence.js`'s UNRELEASED gap should now hover near zero; a growing gap means the lane is disarmed or red — both loud.
- One-time owner arming step (filed as a blocker): create the two secrets, set `PUBLISH_ON_MERGE=1`.
- Revisit toward *more* ceremony (environments, provenance attestation, trusted publishing/OIDC to npm — which would retire the standing token) when the fleet grows; revisit toward *less* (auto-minor) never without a human surface-diff check.
