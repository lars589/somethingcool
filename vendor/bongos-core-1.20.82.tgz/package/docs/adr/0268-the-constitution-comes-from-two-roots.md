# 0268 — The constitution comes from two roots, and a decision that did not take must say so

- **Status:** Accepted
- **Date:** 2026-09-09
- **Tasks:** [#1003739](https://cloudbongos.com/builders#/task/1003739) (goal [#1000111](https://cloudbongos.com/builders#/goal/1000111) — Government). Found while shipping [#1003733](https://cloudbongos.com/builders#/task/1003733) ([ADR 0267](0267-unanimity-and-the-revise-and-re-sit-loop.md)).
- **Builds on:** [ADR 0108](0108-instance-composition-configurable-root.md) §1 (the two configurable roots), [ADR 0175](0175-the-board-room-full-idea-ratification.md) §7 (a passed amendment becomes the live constitution), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (a module reaches core only through the doorway).

## 1. What happened

On 2026-08-25 cloudbongos.com's board ratified a constitutional amendment:
`rank:metic+` · `consent` · a 1440-minute sitting. It passed, it was recorded,
the proposer was paid the ratification karma — and **the constitution never
changed.** Two weeks later `GET /government/constitution` still answered the
day-one monarchy, with the passed amendment sitting in its own `history` array
directly beneath the `board` block that contradicted it.

Every Board Room sitting in those two weeks was decided under a rule the board
had voted to replace. It also quietly un-shipped [ADR 0191](0191-majority-and-the-author-who-may-not-decide-alone.md)
(majority) and would have un-shipped ADR 0267 (unanimity) the same way: both
shipped as code, and neither could reach anybody.

Nobody noticed, because nothing was broken enough to notice. No error, no failed
write, no missing row.

## 2. The cause: one root where there are two

`modules/government/config.js` resolved both of its files from one place:

```js
const ROOT = path.resolve(__dirname, '..', '..');
const NEUTRAL_PATH  = path.join(ROOT, 'config', 'government.neutral.json');
const INSTANCE_PATH = path.join(ROOT, 'config', 'government.json');
```

The comment above it said the two roots coincided *today* and that the instance
path would route through `resolveInstanceRoot()` when ADR 0108's split landed.
**The split had landed.** cloudbongos.com is a standalone instance: its systemd
unit runs `node_modules/@cloudbongos/core`'s server with
`WorkingDirectory=<instance repo>`, so at runtime `__dirname` is *inside the core
package*. Which makes:

| file | resolved to | correct? |
|---|---|---|
| `government.neutral.json` | `…/node_modules/@cloudbongos/core/config/` | ✅ — it really is core content |
| `government.json` | `…/node_modules/@cloudbongos/core/config/` | ❌ — the host's is at `<instance>/config/` |

So two things were true at once, and each hid the other:

1. **The host's own constitution was never read.** An instance authoring
   `config/government.json` — the documented way to set one — was ignored.
2. **`applyBoardAmendment` wrote the ratified amendment into `node_modules`,**
   where it worked until the next core upgrade deleted it. The nightly upgrade
   sweep (ADR 0161 cuts a release per merge) did exactly that, within a day.

**Nothing threw, and nothing could have.** Both paths exist, both are writable,
and an absent instance pack is a legal state — a vanilla instance has none — so
the read fell through to the neutral monarchy precisely as designed. This class
of bug has no error to catch. `src/branding.js` had it right the whole time and
was three files away: neutral from `resolveCoreRoot()`, instance from
`resolveInstanceRoot()`.

## 3. The fix, and the doorway it needed

`NEUTRAL_PATH` now resolves from the core root and `INSTANCE_PATH` from the
instance root, reached through `src/module-api` — because ADR 0083 forbids a
module requiring a core internal, and until now the doorway exposed neither
resolver. That absence is *why* the module re-derived a root from `__dirname`:
the only tool it had was the wrong one. Both are now exported, with the failure
above written into the export comment.

Two smaller decisions travel with it:

- **Resolved at load, not per call.** `resolveInstanceRoot()` falls back to
  `process.cwd()`, so resolving lazily would let a `chdir` mid-process move the
  constitution — a worse failure than the one being fixed.
- **`applyBoardAmendment` creates the directory.** The write now targets a
  directory the core does not own, and an instance that has never been branded
  has no `config/` of its own. A ratified amendment lost to `ENOENT` is the same
  failure in a different coat.

The single-checkout case is byte-identical, and a test asserts that rather than
the prose claiming it.

## 4. The detector, because the fix alone is not the lesson

Fixing the path fixes *this* cause. The thing worth keeping is that **the API
held both facts in one payload for two weeks and never compared them.**

`constitutionView` now carries a `divergence` block: the newest **passed**
amendment's proposal, sanitized the way an apply would have written it, compared
field by field against the constitution actually in force. Null when they agree.
The hall renders it above the dials — in words, not config keys — as *"the board
ratified a change that is not in force."*

Three properties, each chosen against a plausible alternative:

- **It reports; it never heals.** Re-applying automatically was refused: the
  instance pack is *also* the file a human editing the constitution touches (ADR
  0175 §7), so a silent re-apply would revert a legitimate hand edit with no way
  to tell the two apart — trading a visible wrong constitution for an unstoppable
  one. Naming the divergence is what those two weeks actually lacked.
- **A returned amendment is never compared.** That is the whole meaning of
  *returned*; comparing against it would fire on every rejected proposal, i.e. on
  the system working.
- **It compares the SANITIZED proposal.** Comparing the raw one would report a
  phantom divergence on any field the sanitizer legitimately normalises — and a
  warning that can never be cleared is a warning people learn to scroll past.

## 5. What this does not do

**It does not put the 2026-08-25 amendment back in force.** That is a board act,
not a deploy: once this ships, cloudbongos.com's Constitution tab will *say* the
amendment is not in force, and the remedy is to put it back to the board (now
that a pass will stick) or for an operator to author the instance's own
`config/government.json`. Choosing between those is the owner's, not this task's.

**It fixes one module, and the sweep for siblings was run rather than promised.**
Every other module deriving a root from `__dirname` was checked, and all but one
are reading genuine CORE content — `scripts/`, `infra/`, the UI kit — which the
core root is the *right* answer for. The exception is
`modules/security/artifact-scan/quarantine.js`, whose "a quarantine site must not
be inside the repository" refusal resolves to the core package on a standalone
instance and so does not refuse a site inside the instance repo itself. That is a
real, narrow weakening of a security guard; it is filed as
[#1003745](https://cloudbongos.com/builders#/task/1003745) on the Security area
rather than absorbed here, and the doorway exports this ADR adds are what its fix
will use.

**The rule to carry forward:** a `__dirname`-derived root is correct for reading
what the core ships and wrong for reading what the host owns, and on a
single-checkout instance the two are indistinguishable — which is why this kind
of bug is always found in production and never in a test that runs at home.
