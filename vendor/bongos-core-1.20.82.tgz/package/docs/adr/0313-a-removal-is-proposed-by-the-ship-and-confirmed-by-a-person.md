# ADR 0313 — A removal is derived from the server's own merge diff and confirmed by a person

**Status:** accepted · **Date:** 2026-09-19 · **Task:** [task 1004081](https://cloudbongos.com/builders#/task/1004081) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0311](0311-an-idea-is-a-permanent-origin-tag.md) (deferred exactly this) · [ADR 0312](0312-provenance-is-a-second-ideas-owned-edge-table.md) (the descent this dims) · [ADR 0242](0242-a-cascade-is-a-declaration-table-on-the-event-that-already-exists.md) (the runner a rule is appended to) · [ADR 0055](0055-server-mediated-branch-publish.md) (why the server holds the authoritative diff) · [ADR 0049](0049-split-parallel-safety-contract.md) (`touches[]` is advisory)

## Context

Brightness is the live share of a descent (spec decision 20), so something has to be able to say that shipped work was later removed. **Nothing records that today.** `shipped` is terminal — `modules/lifecycle/rot.js` says so in as many words — there is no reverted status, and `tasks.merged_into_task_id` is CHECK-constrained to `abandoned` rows (`core_232`), so it can only ever describe work cut *before* it landed.

The owner settled the shape and not the detail (spec decision 13): **the system proposes, a person confirms.** A derived-only signal dims the sky for refactors, renames and file moves; a declared-only one rots because nobody remembers. This ADR settles the detail.

## What the spike found

**1. `cascade.js` no longer ships with an empty rule set.** The task description says it does; that was true when the task was written and is not true now. `CASCADES` carries a production rule (`artist-review-on-ship`), and ADR 0242 fixed the extension contract: *append an entry, never touch the runner.* This strengthens the decision rather than weakening it — there is a working precedent to copy, including the anti-recursion guard (`source !== CASCADE_SOURCE`) that a removal rule needs for the same reason.

**2. `netNegativeBonusAmount` cannot be the trigger.** The task names it as the nearest existing signal, and it is — in spirit. Structurally it is unusable:

- **It has no target.** `removed > added` over a whole ship says *that* deletion happened, never *what* was deleted or whose work it was. Brightness needs the target; the boolean carries none.
- **It is client-supplied.** It reads `signals.diff_stats`, which arrives in the grade request body. `grader-score.js` documents the exact forgery it already defends against — a `diff_stats` claiming a net-negative that the submitted diff does not support.
- **Brightness affects money.** Size is a payout sum and brightness sits beside it. Deriving either from a forgeable, target-less counter would be wrong even if it were convenient.

**3. There is no durable record of what any ship touched.** `committed_files` exists at grade time for the protected-path check and `diff_stats` for the bonus, both client-supplied, and **neither is persisted** — no table stores them. `touches[]` is advisory by ADR 0049. So a removal cannot be reconstructed from history at all; it can only be derived at the moment a ship lands.

## Decision

### The signal's source is the server's own merge diff

Landing is server-mediated (ADR 0055): the server holds the repository and performs the merge, so it can compute the real diff rather than be told about one. The removal signal is derived **there**, from the merge the server just made, and never from a client-supplied signal. This is the only reason the derivation can be trusted with something that moves credits.

### Attribution runs through `claims.published_head_sha`, not commit text

To say *whose* work was deleted, the deleted hunks are blamed back to the commit that introduced them, and that commit is resolved to a task through **`claims.published_head_sha`** (`migrations/171`) — the server-pushed tip, already persisted per claim.

The obvious alternative, parsing `(task NNNN)` out of commit messages, was rejected: of the last 15 commits on `main`, **7** carry a task id. Merge commits and release carriers do not, and a convention that holds most of the time is not a basis for a payout. The sha mapping is written by the server at publish time and cannot be forgotten by an author.

`published_head_sha` is nullable, so attribution can come back empty — a ship that predates `migrations/171`, or one that rode in on another branch. **An unattributable deletion files no proposal.** Silence is the correct output: a wrong removal proposal costs a person's attention and dims a real star.

### What counts as removed

Only **work that shipped and was later deleted**. Three exclusions, each of which the Sky artboard already draws:

- A **rename or move is not a removal.** Git's own rename detection resolves it; the work still stands.
- A **rewrite in place is not a removal.** Lines changing is how code lives.
- A **cold body is not a remnant.** An idea declined at triage never ignited — nothing was built, so nothing was lost. Removal applies only below a task that actually shipped.

### The proposal, the confirmation, and the clock

- **Propose:** a new entry appended to `CASCADES` on the ship trigger. It files a *question*, never a verdict, and carries the anti-recursion guard the existing rule uses.
- **Confirm:** Metic+, `task.promote`, on the existing awaiting-nod surface (spec decision 15). No new permission and no new page.
- **Rot:** an unanswered proposal enters the existing rot feed on the normal clock (spec decision 14), so the queue cannot silently grow.

Only a **confirmed** proposal dims a star. A pending one changes nothing the ideator sees.

## Consequences

**Brightness can only fall forward from here.** The derivation runs at merge time and nothing durable records the past, so removals before this ships are not recoverable. That is consistent with spec decision 17 — pre-existing ideas get lineage backfilled but not payouts — and it means a historical marker is required on those sizes, or the number quietly lies about what it means.

**The server gains a git-reading step on the merge path.** It is the one place with both the repository and the authority, but it is also the path a stranded ship already fails on. The rule must be non-blocking: a derivation that errors files nothing and never fails the merge. Landing work is more important than dimming a star on time.

**Two signals now exist over the same diff, and they must not be confused.** `netNegativeBonusAmount` rewards a builder for simplifying, and this one records that an origin's descendant work is gone. The same net-negative ship can legitimately trigger the bonus and no removal at all.

## Alternatives rejected

- **Derived-only, no confirmation.** The owner's decision, and correct: refactors, renames and moves would dim the sky continuously.
- **Declared-only** (a human marks work removed). Rots because nobody remembers — the same reason the descent edges are not left to memory in ADR 0312.
- **`netNegativeBonusAmount` as the trigger.** Target-less, client-supplied, already known-forgeable.
- **Commit-message parsing for attribution.** Holds for under half of `main`'s recent commits.
- **A `removed` task status.** `shipped` is terminal by design and much of the ledger leans on that. A removal is a fact about work's *fate*, recorded beside it, not a new terminal state that ship rollup would have to learn.
