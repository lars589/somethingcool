# 0233 — A copy proposal is a task carrying a patch, and the applier is the only writer

- **Status:** Accepted
- **Date:** 2026-09-02
- **Tasks:** [#1003114](https://cloudbongos.com/builders#/task/1003114) (R03 of goal 1000074, the artist's loop) — builds on [#1003112](https://cloudbongos.com/builders#/task/1003112) (R01, the registry) and [#1003113](https://cloudbongos.com/builders#/task/1003113) (R02, the flag and the queue)
- **Extends:** [ADR 0081](0081-tool-agnostic-design-layer.md) — the repo is the source of truth, with swappable tool adapters that land their output as a committed diff. This applies that contract to TEXT.
- **Extends:** [ADR 0178](0178-the-copy-desk-flag-and-queue.md) — which pinned that `copy_desk_flags` may never hold replacement text, and named this task as the one that would have to keep that true while adding an editing affordance.
- **Amended by:** [ADR 0341](0341-the-page-is-the-unit-of-tweak-mode.md) (task 1004332) — a proposal may also be a whole-page batch (the `page-tweak` blocks, D4); every rule below still holds for each of its lines.
- **Related:** 0083 (module system, ports), 0086 (goals), 0016 (authority resolved server-side), 0158 §2 (a verdict is advisory, never self-executing), 0162 (review gates retired — no human approval in the land path), 0197 (the ui-design module)

## Context

Goal 1000074 asks for two things that pull against each other, and says so in its own text.

The artist must be able to **change copy without an engineer** — that is the criterion
`artist-edits-land-as-tasks`. And there must be **no live CMS**: "every copy change is a claimed,
graded, shipped GDS task ... never a write path that bypasses the ledger."

R02 built the half that needs no reconciliation: the **flag**, a judgement with a pointer. It
deliberately shipped with no way to say what the copy *should* say, because the obvious place to put
that — a column beside the flag — is one plausible read away from making the copy desk a copy source.
ADR 0178 §3 pinned the absence and named the erosion path: not a dramatic "add a CMS" commit, but one
plausible column, then one plausible read of it, and the ledger rule is dead with nobody having
decided to kill it.

So R03 is the load-bearing one. An affordance that edits, and a ledger that must record every edit,
are one bad column apart from being incompatible.

## Decision

### 1. The shape is borrowed from the design half, not invented

ADR 0081 already solved this exact problem for *form*. A tool authors; `adapter.export()` lands the
tool's output into the repo as a committed diff under a claimed task, inside a path guard; the repo
stays the source of truth and the tool never writes to production. The `ui-design` module has run
that contract for design tokens and component surfaces since ADR 0197.

**A copy proposal is that same contract for text.** The artist is the tool, the copy desk is where
they author, and the proposal is the export. Nothing about this needed a new idea — it needed the
existing one applied to the other half of the design contract, which is what makes the two halves
read as one system rather than two features that happen to share a goal.

### 2. The proposal lives on the TASK, as a fenced patch — not in a table

`POST /copy-desk/proposals` creates a **GDS task** whose description carries a ```` ```copy-proposal ````
block: schema, string id, surface, file, line, render path, the current wording and the proposed one.

This is the whole answer to the tension, and every part of it is doing work:

- **The ledger is where a proposal belongs anyway.** The methodology already requires every change to
  be a claimed task. A proposal is a change that has not happened yet, so the task IS the record —
  not a shadow of one kept somewhere else and reconciled later.
- **Nothing renders a task description as product copy**, so the wording has no path to a reader that
  does not pass through a claim, a diff and a grade.
- **A fenced block is readable by the reviewer and parseable by the applier.** The point of a proposal
  is that it is arguable before it lands; a reviewer has to be able to see the change without running
  anything.
- **`copy-desk` gains no migration.** `tests/copy_no_cms.mjs` asserts the module still has exactly one,
  because the obvious-but-wrong implementation of R03 is a `copy_desk_proposals` table — which is
  ADR 0178's forbidden column with extra steps.

The module's manifest gains `consumes: ["lifecycle"]` and calls `lifecycle.createTask` through the
kernel port. That direction is the safe one and is the point: this module can put a work request
**into** the ledger, and nothing can pull copy **out** of this module. `provides` stays empty.

### 3. The applier re-derives the position; the registry never stores one

`scripts/gds/copy-apply.js` is what whoever claims the task runs. It does **not** trust the patch's
line number. It re-runs R01's own extractor over the working tree, finds the occurrence there, and
replaces exactly the characters that string occupies.

That required teaching the extractor to record a **source span** alongside every string it finds —
and deliberately **dropping it from the committed registry**. An offset goes stale the moment anything
above it in the file changes, while the registry's id is designed to survive precisely that movement;
a committed offset would be wrong far more often than the id ever is. So the span is a live fact,
recomputed at the moment of the edit, by the same code that decided the string was copy in the first
place. One set of matching rules, in one file, used by both the inventory and the applier — which is
what stops the applier from editing a byte the inventory would never have called copy.

The registry's committed bytes are unchanged by this; `--check` and `tests/copy_inventory.mjs` are
what prove it.

### 4. The placeholder arithmetic is the rule that makes a patch mechanical

The registry writes `{…}` where the source has `${expr}`, so an artist edits a readable sentence with
holes in it. The applier puts the source's **own** expressions back, the k-th hole taking the k-th
expression — so an artist may move a value within a sentence (`Hello ${name}, welcome back` →
`Good to see you, ${name} — welcome back`) but may not add or drop one. The count is checked when the
proposal is made **and again against the real source** at apply time, because the source is what is
about to be written.

That single rule is what turns "a note for an engineer" into "a change that lands with one command",
which is the difference between meeting the criterion and describing it.

### 5. Every ambiguity is a named refusal, because a wrong edit is worse than no edit

The applier refuses, by name and with the reason on one line, when: the wording is already gone
(`target_gone`), the sentence appears at several sites and the line does not disambiguate
(`ambiguous_target`), the literal is escaped so no exact span exists (`no_exact_span`), the
placeholder count does not hold (`placeholder_mismatch`), or the file is outside the surface the
registry defines (`path_outside_surface` — the direct analogue of the design adapter's path-escape
guard, derived from R01's own `SURFACES` rather than a second list).

None of these means the wording was wrong. They mean a person should look. And after writing, the
applier regenerates the registry and **checks that what it wrote is what the inventory now reads** —
an independent read of the file it just edited.

### 6. The command takes no id, because the task cannot know its own

A proposal task has to print the exact line that lands it, and its description is composed *before*
the row exists. Every way of closing that gap is worse than the rule it would paper over — a
placeholder is a step for the claimer to get wrong, and a second write to patch the description in
afterwards buys a port widening and a failure mode for a string.

So the bare call, `node scripts/gds/copy-apply.js`, acts on **the task the caller is holding**.
Holding no claim is a named refusal that says to claim it first. The command may only run under a
claim — that is the whole feature — and a claim already names a task, so the constraint and the
ergonomics are the same fact. `--task <id>` remains for someone holding several — and it is *checked*
against the same claim list the bare call reads, refusing `claim_not_held` for a task the caller does
not hold. It shipped unchecked (task 1003493 fixed it): a rule stated in this ADR, in the module's
`CLAUDE.md` and in the script's own header, enforced on one of its two paths, is the kind of claim
that rots. The one path with no claim to prove is `--patch-file`, a local JSON patch used by the
tests, which lands nothing a proposal task authorised.

### 7. Proposing is open to every rank, and lands in `backlog`

Same floor as filing, for ADR 0178 §4's reason: an artist is a craft, not a rank, and a rank floor
would hide the loop from the people most likely to use it. The quality gates are the required `why`
(the same judgement floor a flag's reason carries), the placeholder arithmetic, and the fact that the
target is resolved **server-side from the registry** — a caller cannot describe a change to a
sentence that does not exist.

The task is created at `backlog`, so a proposal is a *request*: it needs the board's ordinary triage
before anyone can claim it. Landing it `ready` would let anyone with an opinion mint claimable work.

## Consequences

- **The write surface of `copy-desk` is now three verbs, not two**, and `tests/copy_no_cms.mjs` says so
  in a diff a reviewer can see — which is exactly what R02 built that list for. To be exact about what
  that test proves (task 1003493): it pins that no route **in this module** can write a rendered
  string, which is narrower than "no route can write a rendered string to production directly". That
  is the right scope for the feature — the module is the write surface this ADR adds — but the wider
  claim is not something a module-scoped test can carry, and reading it as if it were is how a
  no-CMS guarantee quietly becomes an assumption.
- **A proposal lands only in the version being BUILT.** `proposals.resolveTargetVersion` returns the
  `building` version or `null`, and the route refuses `no_open_version` — there is deliberately no
  "first version in the list" fallback (task 1003493), because that row can be a shipped version, and
  a proposal landing on sealed history is worse than a proposal that was not accepted.
- **`scripts/gds/copy-apply.js` is the only thing in this feature that writes a surface file**, it is a
  command rather than a route, and the test asserts no file in the module's request path imports it.
  Naming it is fine and required: the task tells its claimer the exact line to run.
- **The `lifecycle` port gained `findTaskBySourceRef`** so a double-submitted proposal resolves to the
  task it already made. A genuinely different second attempt at the same string is a new task, which
  is right — two people can disagree about the fix, and the board should hold both.
- **A proposal targets ONE occurrence.** When a string is shown in several places the caller must say
  which, and the refusal points at the duplicates the copy desk already surfaces. Rewording a sentence
  said in seven places is usually the wrong answer to it being said seven times.
- **A quoted literal containing an escape has no span**, so ~9 of ~1,600 inventoried strings cannot be
  patched by command and are refused by name. Buying them would mean an escape-aware index map — a
  second place for the escaping rules to be wrong, for nine strings.
- **The copy desk route file moved off `console.error` to the doorway's `api.logger`**, the seam
  builder-settings / dev-box / ideas / government already use. Structured, attributable, and it keeps
  an error's stack instead of stringifying it.
- **R05 still owns the hard question.** Nothing here gates a ship. Whether an artist's judgement can
  ever block, and how that coexists with ADR 0162, is R05's to decide — a proposal is a work request
  by construction until it does.
