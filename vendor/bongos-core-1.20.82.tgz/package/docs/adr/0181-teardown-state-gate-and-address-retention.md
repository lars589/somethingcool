# ADR 0181 — Teardown accepts every state but `torn_down`, and deliberately keeps the address

- **Status:** Accepted
- **Date:** 2026-08-19
- **Task:** [task 1003042](https://cloudbongos.com/builders#/task/1003042) (BONGOS-V1, goal 1000058 — *Non-cloudbongos project lifecycle*)
- **Deciders:** jaxri (Archon), Claude
- **Supersedes nothing. Bounds:** [task 1002897](https://cloudbongos.com/builders#/task/1002897) (address reclaim) owns the half this ADR deliberately does not do.
- **Related:** [ADR 0111](0111-instance-hosting-provisioning-module.md) (the provisioning module + intent/runner split), [ADR 0157](0157-archon-is-rank-and-identity-only.md) (permission floors)

---

## Context

Walk finding **N5** (`docs/audits/project-creation-gap-list.md`): an instance at `status='error'` could never be removed. The owner's `POST /provisioning/instances/:id/teardown` answered 409 `not_teardownable`, and the archon `force-teardown` — which exists precisely as the escape hatch — answered the **same** refusal, because both read one shared constant:

```js
const TEARDOWN_FROM = new Set(['provisioning', 'active', 'tearing_down']);
```

`requested` and `error` were absent. There was therefore **no supported path, for any role**, to remove such a row; the only remedy was direct DB surgery. Errored rows accumulated permanently — instance 15 (`swag`) sat in its owner's list from 2026-08-07.

The whitelist's comment justified itself as "a requested/torn_down/error instance has nothing running to tear down via the happy path." That premise is **false for `error`**. A provision that fails mid-run lands at `error` *after* the runner may already have created the database, allocated the port, written the systemd unit, written the Caddy site block, and UPSERTed the DNS A record. An errored row is frequently a *partial standup*, which is exactly the thing most in need of reclaiming.

## Decision 1 — the gate is derived, not hand-kept

`TEARDOWN_FROM` is now every state except the one where there is provably nothing left:

```js
const TEARDOWN_FROM = new Set(INSTANCE_STATES.filter((s) => s !== 'torn_down'));
```

Deriving it is the load-bearing part. The bug was not a typo — it was a **hand-maintained allow-list that silently omitted states**, with no test asserting completeness. Derivation inverts the default: a seventh lifecycle state added tomorrow is teardownable unless someone deliberately excludes it. For a failure mode whose signature is "a row with no exit", the safe default is *an exit exists*.

The runner needed no change. Every step in `teardownInstance` (`scripts/gds/provision.js`) is individually `allowFail`, so it already reclaimed whatever a partial standup happened to hold and settled the row at `torn_down` either way. **Only the web-tier guard refused.**

`torn_down` still refuses, and that refusal is now one shared helper used by both routes. They had drifted: the owner route carried a plain sentence, while force-teardown used the positional `res.fail(code, status, details)` form with no message — and `envelope()`'s `message || code` fallback then put the bare string `not_teardownable` on the wire as the human-facing text, violating the plain-sentence rule (§5.1). One helper, one wording, no second copy to drift.

**"Force" means across ownership, not past the state machine.** `force-teardown` skips the owner check; it deliberately shares the state gate. (Its permission `provisioning.fleet.manage` has a **metic** floor per ADR 0157, despite older route comments saying archon.)

## Decision 2 — the port and the domain are deliberately NOT released

Task 1003042's description listed "releases the DB row, port, DNS record". We release the row's *state* and stop there. **The `port` and `domain` columns are kept.**

This is not an omission — releasing the port alone would be **actively worse than the status quo**:

- Teardown has no DNS leg and no Caddy leg. The per-instance `<slug>.caddy` snippet is written at standup (`provision.js`, step 6) and **survives teardown**; the Cloudflare hook is UPSERT-only and is never called on the teardown path. Verified live on 2026-08-19: `walk-beacon.cloudbongos.com` and `qa-private-repo.cloudbongos.com` were both `torn_down` since 2026-08-13 and both still resolved.
- That surviving Caddy block reverse-proxies the hostname to a **port number**, not to an identity.
- `allocatePort` selects `WHERE port IS NOT NULL` with **no status filter**. Null the port and it returns to the pool.
- So a later, unrelated instance handed the same port would begin **answering at the torn-down project's still-live address** — one owner's project served under another owner's hostname.

Today the same stale block yields a harmless 502, because the port stays held. Holding it is what keeps the address inert.

The port and the address are therefore **one coupled decision**, and [task 1002897](https://cloudbongos.com/builders#/task/1002897) owns it: give the runner a DNS DELETE counterpart, remove the stale Caddy block, and decide with the owner whether a torn-down address 404s or serves an honest "this project ended" page. Retention also happens to be *correct* for the revive path — `PROVISION_ENQUEUE_FROM` includes `torn_down`, and a revive re-uses exactly this hostname, so clearing `domain` would break bringing a project back at its own address.

The user-facing copy was corrected to match. It previously promised "the server goes away and **the address stops answering**" — untrue. It now says the address **stays reserved for this project and shows an error page until you bring it back**, which is both honest and accurate.

**Update (task 1002897).** Teardown now reclaims the address itself. It parks the hostname at the RFC 5737 blackhole through the same release a re-point uses ([ADR 0200](0200-re-point-a-bring-your-own-domain.md) §2: parked, not deleted), and it removes the `<slug>.caddy` block and reloads Caddy (`scripts/gds/provision-teardown.js`). Both steps are best-effort, and a platform-reserved hostname is never parked. `port` and `domain` are still held, so the address is inert without releasing the claim, and a revive's standup UPSERTs the same hostname straight back. The copy now says the address stays reserved and **nothing answers there until you bring it back**. The database and its dumps remain operator-only.

## Consequences

- An owner can remove a project in any state from the manage page; the 409 `not_teardownable` class is gone except for the one honest case.
- Instances 15 (`swag`) and 20 (`walk-lantern`) become removable once the live pin carries this change.
- `tests/provisioning_teardown_states.mjs` pins both decisions and mounts the **real** error envelope, so the bare-code regression is caught on the wire rather than in the call shape.
- **A torn-down project still holds its address and its port.** That is the known, deliberate remaining gap; it is not fixed here, and the copy no longer claims otherwise. Task 1002897 closes it.
- Teardown still leaves the database, the backup dumps, and the repo checkout in place — unchanged policy, data is precious.
