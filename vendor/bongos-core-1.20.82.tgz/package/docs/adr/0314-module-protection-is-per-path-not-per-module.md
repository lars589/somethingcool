# ADR 0314 — A module owns a protected path without the whole module becoming protected

- **Status:** accepted — **implemented** by [task 1004109](https://cloudbongos.com/builders#/task/1004109) (2026-09-20)
- **Date:** 2026-09-20
- **Task:** [task 1004070](https://cloudbongos.com/builders#/task/1004070), goal 1000095 — BONGOS-V2
- **From:** idea 1000689; owner decision 2026-09-19 — *option 1, narrow what counts as protected*
- **Supersedes nothing.** Refines the derivation in [ADR 0086](0086-goal-scoped-work-hierarchy.md) §7.

## The question

`protected` on a module is DERIVED — a module is protected iff any of its globs
overlaps `PROTECTED_GLOBS` ([ADR 0086](0086-goal-scoped-work-hierarchy.md) §7,
the SEC #863 "second list that drifts" rule). A protected module makes creating a
goal scoped to it Archon-only.

Three modules derive protected because of exactly one file that is not their
domain — a CLI they own that happens to sit on a protected path:

| Module | Protected solely by | of N globs |
|---|---|---|
| `onboarding` | `scripts/gds/setup.js` | 1 of 5 |
| `autonomy` | `scripts/gds/conductor-dispatch.js` | 1 of 6 |
| `copy-desk` | `scripts/gds/copy-inventory.js` | 1 of 4 |

`onboarding` is the case that raised it: a public goal was <redacted>
for a Metic because the module owns one CLI that installs the pre-push hook.

## Two corrections to the numbers the task was written on

Re-measured on this tree (`isProtectedModule` over `moduleKeys()`, 2026-09-20):

- **12 of 26 modules derive protected, not 11.** The task's re-measurement of
  2026-09-19 was already one short.
- **`agents` is the twelfth**, protected by `modules/agents/` — which is itself a
  `PROTECTED_GLOBS` entry. It is absent from the task's list of seven that "stay
  protected", so a reader working from that list would have been surprised by it.

Both corrections argue for the same thing, below: **pin the set by name.**

`government` and `agents` are each protected by exactly one glob too — so "1 of N"
is not the discriminator. The real one is **whether the protecting glob is the
module's own territory**: `modules/government/` and `modules/agents/` *are* those
modules; `scripts/gds/setup.js` merely lives near `onboarding`.

## The options, and why the obvious one is wrong

You cannot subtract. The glob format has no wildcards, so "onboarding minus
setup.js" is inexpressible. And you cannot delete the glob: `MODULE_GLOBS` is also
the territory deciding **who may author a task touching that path**, and the shared
floor is only `tests/` — so an unowned path is authorable by no goal at all.

That left **(a) reassign each incidental CLI to an already-protected module**. It
was measured rather than reasoned about, by applying the edit to the source and
re-requiring in a fresh process — `MODULE_SCOPE_MAP` is frozen and built from a
copy at load, so mutating `MODULE_GLOBS` in-process proves nothing.

With `copy-inventory.js` and `conductor-dispatch.js` moved to `devsecops`:

| Goal scoped to | Authoring | Before | After (a) |
|---|---|---|---|
| `copy-desk` | its own generator | authorable | **denied, out_of_scope** |
| `autonomy` | its own conductor | authorable | **denied, out_of_scope** |
| `devsecops` | the generator **and its two outputs** | — | **denied, out_of_scope** |

The third row is the one that decides it. `docs/copy-registry.json` and
`docs/copy-inventory.md` stay `copy-desk`'s, so the generator and the artifacts it
writes end up either side of a module boundary and **the routine "change a UI
string, regenerate the registry" becomes authorable by no single goal.** That is
not a hypothetical workflow: it is the ship-check freshness gate every UI task
hits, because every row in the registry carries a line number and any edit to a
scanned file shifts them.

So (a) does not relocate a cost. It converts a correct ownership statement into a
false one, damages the authoring wall for two of the three modules, and buys the
flip with a workflow the project runs daily. It is right for exactly one of the
three — `setup.js` → `devsecops`, which already owns `.husky/` and the hooks.

## Decision

**Protection becomes per-path at the goal-scope wall, as it already is at the
other three walls.** A module may own a protected path; owning one no longer makes
the whole module Archon-only to scope a goal to.

The derivation is not weakened and no flag is hand-set — the rule stays computed
from `PROTECTED_GLOBS`, the single source. What changes is the *question* the
derivation answers: not "does this module touch the trust core" but "is the
territory this goal is being scoped to, itself protected".

Three reasons this is the honest shape rather than the convenient one:

- **Per-path is already the rule everywhere else.** `matchProtected` /
  `checkPermissionPaths` decides task-authoring ([ADR 0086](0086-goal-scoped-work-hierarchy.md) wall 2),
  the grader and gate decide ship, and the post-push main audit decides the
  dishonest case. All three ask about the path. Only goal-creation asks about the
  module, and that inconsistency is the whole defect.
- **The wall that matters does not move.** A Metic-floor path stays Metic-floor:
  a sub-Metic builder touching `scripts/gds/setup.js` is refused exactly as
  before, by the same check. What changes is who may *create a goal* whose
  territory happens to include it — a question about scoping, not about writing.
- **It keeps a command with its domain** (design 02§1), which is why those three
  globs are where they are.

## Not built here

Per the task: an ADR first, implementation as a follow-up. This decision builds no
new derivation mechanism. Filed separately:

- ~~The implementation of the per-path goal-scope wall.~~ **Landed** in
  [task 1004109](https://cloudbongos.com/builders#/task/1004109): `isProtected` now
  filters a module's protecting globs to those that are not CLI entrypoints (a
  structural path test — directories under `scripts/` are territory and still
  protect), narrowing the derived set from twelve to the nine predicted below.
  Nothing was unprotected to achieve it and the path wall did not move.
- ~~**`builder-settings`, deliberately out of scope.**~~ **Resolved** by
  [ADR 0318](0318-listing-a-file-for-task-affinity-is-not-owning-it.md)
  ([task 1004110](https://cloudbongos.com/builders#/task/1004110)), and by neither
  of the two routes predicted here. Its overlap was `src/bongos/routes/me.js`
  caught by the blanket `src/bongos/routes/` prefix — but that glob was a task
  AFFINITY listing, not an ownership claim, on a file `MODULE_GLOBS` itself
  called a core facade. Ownership moved to `kernel`, where the aggregator
  belongs; the blanket glob was left alone (all eighteen route files are
  protected by it and nothing else) and no strangler move was needed (the
  aggregator resolves ten module ports). The derived set narrows nine to eight.
- **Nine protected paths are owned by no module at all** — `gen-repo-map.js`,
  `gen-file-map.js`, `gen-session-index.js`, `install-git-hooks.js`, `cli-lib.js`,
  `run-unit-tests.js`, `git-merge-regen.js`, `scripts/gds/hooks/` and
  `.gitattributes`. By the rule above, no goal can author a task on any of them.
  Found while checking whether deletion was viable; it is a pre-existing hole,
  not one this decision opens.

## Shipped with this ADR

One thing is built, because it guards the decision rather than implementing it:
a test pinning the **full protected key set by name**. A count assertion passes on
the wrong twelve, and both corrections above are exactly the drift it catches — a
future glob edit that silently unprotects `kernel` or `lifecycle` now reds the
build.

## Does not decide

The floor a protected path carries (unchanged, Metic, from the surface registry);
whether `scripts/gds/` should have a shared-floor entry the way `tests/` does;
or whether the nine unowned paths are assigned or given a home of their own.
