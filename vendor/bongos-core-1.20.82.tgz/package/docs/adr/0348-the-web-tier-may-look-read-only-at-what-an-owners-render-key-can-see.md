# ADR 0348 — The web tier may look, read-only, at what an owner's Render key can see

- **Status:** accepted
- **Date:** 2026-09-29
- **Task:** [task 1004352](https://cloudbongos.com/builders#/task/1004352) (goal 1000106 — working area 1, Project creation)
- **Deciders:** Lars (Archon) chose both decisions in chat on 2026-09-29, from options Claude laid out. Claude wrote the record.
- **Amends:** [ADR 0111](0111-instance-hosting-provisioning-module.md) §2 ("the internet-facing web process never calls a cloud API") — one narrow, read-only exception
- **Keeps:** [ADR 0327](0327-a-cloud-host-runs-on-the-owners-account-and-the-key-is-borrowed.md) §2 (the key is borrowed, never stored) and §3 (we never destroy an owner's infrastructure) · [ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md) (we host the hall; the app goes where the owner chooses)

## Context

The setup wizard's app step lets an owner put their app on their own Render account ([task 1004351](https://cloudbongos.com/builders#/task/1004351), [task 1004352](https://cloudbongos.com/builders#/task/1004352)). Two things the owner must see before Create can only come from Render itself:

- **Whether the key works.** A refused key discovered after Create is a project with a broken promise on its done screen.
- **Which workspaces the key reaches.** A Render key belongs to a *user*, and reaches every workspace that user is in — measured on 2026-09-22 at three, one of them another builder's (ADR 0327). The owner has to choose one. Picking the first would be exactly the mistake ADR 0327 exists to prevent.

ADR 0111 §2 says the web process never calls a cloud API; the runner does, from the intent queue. The runner can't answer an owner who is still on the page, and keeping the key between a check and a Create would break ADR 0327 §2.

There was a second, related problem. Create queues the project's own `provision` run, and a project has one open-intent slot, so a separate `render-standup` request made a moment later collides with it.

## Decision

### 1. One read-only look, on the owner's own key

`POST /provisioning/render/lookup` (`modules/provisioning/render-lookup.js`) may call Render from the web tier, and nothing else may. Its limits are the whole exception:

- **GET only, two calls:** the workspace list, and the web services in one named workspace. Nothing in it can create, change or delete anything.
- **The key is the owner's own, held for that one request.** It travels in a POST body, never a URL; it is never stored, logged or sent back. Nothing encrypts it, because nothing keeps it.
- **Every service in the answer is checked to carry the workspace asked about.** One that doesn't voids the whole answer. This is the runner client's guard (`scripts/gds/render-api.js`), carried here as two GETs because a module may not require that file (ADR 0083).
- **It is capped per builder** (20 a minute): a wizard needs a handful.

What this does *not* change: every write to an owner's Render account still happens in the runner, from the queue, on a key borrowed for one run.

### 2. The key rides the project's own setup run

When the wizard sends the key right after Create, and the project's `provision` run holds the open slot, the key is attached to **that** run (`attachToProvision`). It goes in one statement, only onto a run that holds no key yet, and the table's CHECK still refuses a key on a resolved run. After the project is up, the runner sets the app up on Render in the same drain (`afterProvision`) and clears the key whatever happens:

- **Project up, app set up:** done.
- **Project up, app failed:** the run is still a success, since the project is live. The app's failure is recorded on `app_host` and in the run's note.
- **Project failed:** Render is never called. The key is cleared at once, so a provision retry never carries it into a later run, and the owner connects Render again once the project is live.

## Consequences

- The web tier now makes outbound calls to one third party, on user-supplied credentials. That is a new egress path, and the reason decision 1 is drawn so narrowly: read-only, one host, capped, key never kept.
- A compromised web tier could read keys from lookup requests. It could already read them from the setup request (ADR 0327 §2 says so plainly), so this adds no new exposure of the key.
- The key waits on the provision run for as long as the project takes to stand up: minutes, and at most the leg's 30-minute limit, after which it is refused and cleared.
- A resumed wizard draft asks for the key again, because the key never enters the draft.

## Alternatives considered

- **Keep the rule strict: no check before Create.** The owner types a workspace id, and a refused key surfaces after Create. The owner rejected this: it fails the task's done-when and leaves the workspace choice to guesswork.
- **Let the browser call Render directly.** It depends on Render allowing cross-origin calls from our page, which we can't rely on. It would also move the workspace guard somewhere we can't test on the server.
- **Ask for the key on the project page once the project is live.** Simpler, but not one wizard pass. It stays available as the fallback when an app fails to set up ([task 1004184](https://cloudbongos.com/builders#/task/1004184)).
