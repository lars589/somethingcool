# ADR 0303 — Provisioning verifies the base Caddyfile, and never edits it

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1002860](https://cloudbongos.com/builders#/task/1002860) (goal 1000106 — project hosting & fleet; from idea 1000524)

**Related:** [ADR 0111](0111-instance-hosting-provisioning-module.md) §4 (on-demand ACME behind the tls-check ask) · [ADR 0128](0128-provisioning-runner-privilege-and-db-auth-model.md) (the runner writes snippets under `sudo install`; it found the live Caddyfile missing the ask)

## Context

The provisioning runner writes one `<slug>.caddy` site snippet per instance and reloads Caddy. It
depends on two lines in the box's base `/etc/caddy/Caddyfile` that it never checked:
`on_demand_tls { ask …/provisioning/tls-check }` and `import /etc/caddy/sites/*.caddy`. Both were
hand-applied on the live boxes. The reload ran with `allowFail: true`. So on a box missing
either line, provisioning reported success and the instance was simply unreachable, with no
signal to anyone. The base Caddyfile is not in this repository. It is host configuration, and
it also serves the platform's own apex.

## Decision

1. **Detect and refuse, never edit.** The runner reads the base Caddyfile and does not write it.
   A missing directive stops the run with the exact line to add and the file to add it to.
   An automatic edit was rejected for two reasons. `on_demand_tls` has to sit inside the
   global options block, which an append cannot place and a rewrite could corrupt. And a bad
   write to that file takes down every site on the box, the control plane's own apex included.
   The directives are a one-time setup per box, so the refusal only ever fires on a box that
   was never configured.
2. **Read Caddy's resolved config, not the file's text.** The check runs
   `caddy adapt --config <Caddyfile> --adapter caddyfile`. That command reads config files only,
   so it needs no privilege and never touches certificate keys, and the runner's scoped sudo is
   not widened. It inspects the JSON. The ask must appear under `apps.tls.automation.on_demand`,
   which covers both Caddy 2.7's `ask` string and 2.8+'s `permission` module. The domain must
   appear under `apps.http`. Because this is the resolved config, it doesn't matter how the operator
   wrote the directives: an absolute or relative import, a split across imported files, a
   `/api/gds` alias. The base path is `PROVISION_CADDYFILE`, default `/etc/caddy/Caddyfile`.
3. **Two checkpoints.** A preflight checks the ask before the box is touched, in both the
   provision and domain-attach legs, beside the DNS-scope preflight. The import can only be
   proven once a snippet exists, so a second check runs after the write and requires the domain
   to be served. It fails the run before any reload. A snippet in a directory nothing imports
   is inert, so leaving it on disk is safe.
4. **The reload is loud.** `systemctl reload caddy` no longer passes `allowFail`. Caddy's
   graceful reload validates and swaps atomically, and it keeps the old config when it rejects
   the new one. A failed reload fails the run and never leaves Caddy half-configured. There is
   no separate `caddy validate` step: it would load certificate keys, which needs root, and
   `caddy adapt` plus the reload already cover what it would catch.

## Consequences

- A box that was never set up gets a named instruction instead of a silently unreachable project.
- Domainless instances, dry runs and dedicated droplets (Caddy comes from cloud-init) skip the check.
- `caddy` must be on the runner's `PATH` on the box that serves the snippet. Every supported shape already has it there, because it reloads that Caddy.
