# 0234 — Idea routing: capture-time promotion, the landing matrix, and the homeless-only inbox

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1003064](https://cloudbongos.com/builders#/task/1003064) (R14 of goal 1000071, "Idea routing") — records the mechanism R01/R02/R05/R07 built and the identity R13 gave the inbox
- **Spec:** [`docs/specs/<redacted>.md`](../specs/<redacted>.md) — "Design decisions & assumptions" + "Interview decisions"
- **Related:** ADR 0084 (auto-derived per-task rank floor), ADR 0086 (goal-scoped work hierarchy), ADR 0016 (trust boundary, server-enforced), ADR 0172 (ideator credit lane, the lineage this feeds)

## Context

Idea 1000771 named the failure this goal exists to close: Discord `#bugs` created tasks **directly**
(`createTask`, no `idea_inbox` row) against a **hardcoded, already-shipped** version id. Every bug
reported through that channel landed in a version catch-all nobody would ever reopen, and — the worse
half — no `captured_by`, no `ideas_task_lineage` row, so the ideator-credit lane (goal 1000067) had
nothing to ever pay against. The reporter vanished from the record the moment their report became work.

Meanwhile the *other* 49 open `idea_inbox` rows sat waiting for a human triage pass that, on
promotion, dropped the resulting task into "`<version> — general`" — because nothing in the capture
path had ever named a goal. Work that plainly had a home (a bug in a live feature, a feature request
against an open goal) got no closer to that home than a homeless idea did.

This ADR records what shipped to fix both: five tasks (R01–R03, R05, R07) plus the promote-path change
(R13), all now `shipped`.

## Decision

### 1. Routing is capture-time promotion, inside `captureIdea` — never a second door

`inbox.captureIdea` (`modules/ideas/inbox.js:225`, task 1003065 / R01) is documented in its own header
as **"THE ONE CAPTURE CHOKEPOINT"** — every filing vector (hall, `capture.js`, the Discord `#ideas`
inbound via the `ideas.capture` port, agents, seeds) already funnels through it, so routing was added
as one optional argument (`goalId`) rather than a sibling `captureAndRoute` function. The module's own
comment names the reason explicitly: *"A `captureAndRoute` sibling would have been the same code with
an invitation to bypass it."* That is the direct, structural answer to the Discord `#bugs` lesson — a
second creation path is exactly the shape idea 1000771 was.

When the landing matrix (below) says **don't route**, `captureIdea` runs the pre-routing INSERT
unchanged — `idea_inbox` status `'open'`, no task. This is the default path and is what every
goal-unaware caller still gets (routing is strictly additive).

When the matrix says **route**, `routeIdeaToGoal` (`modules/ideas/inbox.js:303`) runs **one
transaction**: the idea row (`status='promoted'`, `reviewed_at` stamped — routing's whole claim is
that this row never needed a triage pass), the task via the `lifecycle.createTask` kernel port, and an
`ideas_task_lineage` row with `origin='route'`. The order is forced by foreign keys (idea → task →
lineage), and the module's own comment states the stakes: *"THE TRANSACTION IS THE POINT, not an
optimisation... A route that committed the task but lost the lineage row would manufacture exactly
that bug, at scale, on the path whose whole promise is that attribution survives (criterion C3)."* If
any step fails, the whole thing rolls back and the filer's report is never silently lost mid-flight.

`captureIdea` treats `filerRank`/`grade` as **read-only inputs to the decision** — it performs no
authority check itself; that is R05's job (below), a deliberately separate, load-bearing gate.

### 2. The landing matrix, as shipped (`modules/ideas/routing.js`, task 1003065 / R01 + task 1003066 / R05)

`decideLanding()` is a pure, DB-free function — no clock, no rank lookup — so every cell is pinned by
`tests/idea_routing.mjs` without touching Postgres. Its posture is explicitly **fail-closed**: every
uncertainty resolves toward "don't route" or "route to backlog", never toward `'ready'`.

| Filed thing | Filer rank | Landing (as shipped) |
|---|---|---|
| No goal named | any | `idea_inbox`, `status='open'` — the default path (reason: `no_goal`) |
| `grade='full'` (Full Idea) | any | Never routes — the Board Room's subject (reason: `full_idea_never_routes`) |
| `kind` ∈ {`criterion-proposal`, `decision`} | any | Never routes — judgment work (reason: `judgment_kind`) |
| `kind='bug'` with a goal | Metic or Archon | Task in the goal, `status='ready'` (reason: `bug_trusted_filer`) |
| `kind='bug'` with a goal | sub-Metic / unknown | Task in the goal, `status='backlog'` (reason: `bug_awaiting_nod`) |
| Anything else with a goal (feature, cleanup, refactor, infra, or an unrecognised kind) | any | Task in the goal, `status='backlog'` (reason: `soft_landing`) |

This matches the spec's table (`docs/specs/<redacted>.md` "Landing matrix") exactly for the
hard-land/soft-land split. Priority on a routed task defaults to the idea's own `suggested_priority`,
clamped to 1–5, else `3` (`routedPriority`) — precisely the "decided without interview" line the spec
records.

`decideLanding` only decides the **status**; it grants nothing. `authorizeRoutedLanding`
(`modules/ideas/routing.js:169`, task 1003066 / R05) is the **binding** gate `routeIdeaToGoal` calls
before it writes anything, and it closes a hole the matrix alone left open: a routed task declares no
`touches[]`, so the ordinary ADR 0084/0085 rank-floor derivation would land it at `xenos` even when the
goal's `scope_modules` reach protected territory (the permission/ship-grade/deploy/migration core).
Two rules, ordered and fail-closed (the `authorizeGoalTaskCreate` precedent):

- **Touches declared** (a programmatic filer that knows its own blast radius) → `goalScopeCheck.check`
  runs verbatim, refusals and all — the same wall `POST /goals/:id/tasks` applies to an authored task.
- **Touches absent** (every human filing — demanding touches[] as the price of reporting a bug is
  exactly the triage tax this goal removes) → protection moves to the **claim side**: a goal whose
  scope reaches protected territory raises the task's `requires_rank` floor to `metic`
  (`PROTECTED_SCOPE_FLOOR`), and — the part R05 tightened after its first cut — a **sub-Metic filer is
  refused outright** (`ROUTE_NOT_AUTHORIZED` / `protected_scope`, HTTP 403) rather than merely having
  the floor stamped on afterward. The refusal costs the filer nothing they had before: omit `goal_id`
  and the report files to the inbox exactly as it always did.

**Membership is deliberately not required to route into a goal**, and the module's comment names this
as the one place the routed path diverges from the authored one on purpose: `authorizeGoalTaskCreate`
refuses a non-member (`not_a_member`) because *authoring* inside someone's workspace is a member's
privilege, but *reporting* is not — criterion C5's promise ("the filer never has to know the goal map")
and C1's ("a bug filed anywhere lands in its home") both require that a non-member can still route a
report in. The safety membership would have carried moves instead to the rank floor (claim side) and
the matrix (ready side), and is pinned by a test rather than left to erode quietly.

### 3. The schema: one advisory hint column, one widened CHECK (task 1003060 / R02)

`migrations/core_222_idea_inbox_suggested_goal.sql` adds `idea_inbox.suggested_goal_id` (nullable FK
`ON DELETE SET NULL`) — **not** where a routed idea's goal lives (that is `tasks.goal_id`, set by
construction), but the leftover hint for rows that did **not** convert: soft-landed/homeless ideas, a
Discord classifier's guess, Full Ideas and criterion-proposals. The migration's own comment is explicit
that the column is "load-bearing for NOTHING — no rank check, no scope wall, and no payout may read
it." It lives in **core** migrations, not a module migration, because `idea_inbox` is a core table and
`fitness.js`'s `checkModuleMigrationsAdditive` forbids a module `ALTER TABLE` against it.

`modules/ideas/migrations/ideas_003_lineage_origin_route.sql` widens `ideas_task_lineage`'s CHECK to
admit a third `origin`: `'route'`, alongside the pre-existing `'promote'` (a human triaged it) and
`'develop'` (a spark became a Full Idea). The distinction is deliberate — "how much triage routing
actually saved" (criterion C6) is only answerable if capture-time conversions are tagged differently
from later human promotions in the ledger.

### 4. The suggester answers "which goal" *before* anything is created (task 1003062 / R07)

`modules/lifecycle/goal-suggest.js` lifts the candidate logic `buildGoalAdvisory` already had (goal
1000071's "Reuse, do not rebuild" table) into a **pure, creation-free read**: `suggestGoals(goals,
draft, opts)` ranks open goals against a draft title/body by weighted token overlap (title terms
weight 2, body terms weight 1 — the `criterion-suggest.js` precedent), returning `[]` rather than five
arbitrary goals when nothing scores (the `includeZero` default). `GET /goals/suggestions` exposes it to
a human picker (the hall filing surface, the CLI prompt); `suggestGoalForCapture({ title, body })`
collapses the same ranking to a **single confident answer or null**, for a vector with nobody to choose
— currently Discord `#bugs` (below). It ranks across **every** version still open to work
(`versionAcceptsNewWork`, task 1003061 / R03), not one, because an earlier "decline if more than one
version is open" design would have returned null on every report this instance (which runs two
building versions concurrently) ever files.

### 5. The inbox's new identity: homeless-only (task 1003071 / R13)

`scripts/gds/triage.js`'s `resolveGoalDefault(idea, versionId)` gives the promote path a goal by a
strict precedence — `idea.suggested_goal_id` (a human or filing surface already named this goal; a
heuristic must not overrule it) **before** the R07 suggester (only when there is no stored hint) — and
`createTask({ ..., goalId })` finally sends `goal_id` on `POST /tasks`, a field the route has accepted
since task 1763 with no client ever sending it. `.claude/skills/idea-triage/SKILL.md` states the
contract plainly: *"the inbox holds only HOMELESS work — bugs and goal-bound captures now route to a
task at filing time and never reach the inbox."* Triage shrinks to the judgment calls a routing rule
cannot make for itself: Full Ideas (Board Room material), `criterion-proposal`/`decision` rows, and
anything nobody could suggest a home for.

## Divergence from the spec, recorded rather than silently reconciled

The spec's interview decision 2 says: *"Discord-filed bugs soft-land with a suggested goal. The report
files as an idea with a classifier-suggested goal attached and surfaces in the pending queue for a
one-click route. Nothing lands unvetted."* **That is not what R11 shipped.** `modules/discord/discord-bugs.js`
(task 1003067 / R11, retiring the hardcoded-`GDS-V3` path idea 1000771 named) instead resolves a
suggested goal via `suggestGoalForCapture` and hands it straight into `captureIdea` as `goalId` — so a
**linked Metic+ builder's Discord bug hard-lands `'ready'` immediately**, through the *same* landing
matrix every other filing vector uses, rather than always parking at `'backlog'` pending a one-click
nod. The file's own header explains the choice: a local copy of the rank split would only ever drift
from the one definition in `modules/ideas/routing.js` (`tests/filing_abuse_matrix.mjs` exists precisely
to prevent that divergence), and "same outcomes as before" (the pre-routing #bugs behaviour already
hard-landed a trusted linked builder's report). An **unlinked** Discord author still gets no goal and
no rank, so the matrix cannot route their report into work at all — it lands as a homeless idea, same
as `#ideas` has always given that person, which is the actual "nothing lands unvetted" guarantee that
survived.

The companion interview decision — **"Discord `#ideas` files with HINTS only (`suggested_goal_id`),
never routes"** — is what R12 (task 1003068, "Discord `#ideas` carries routing hints") shipped, correcting
this ADR's earlier divergence note (which read `status='ready'` at the time it was written).
`modules/discord/discord-inbound.js`'s `#ideas` capture now sets `suggested_goal_id` (a classifier guess
via `suggestGoalForCapture`) and `suggested_version` (defaulting to the most-recently-started open
version even when no goal matches) on the filed idea row — both READ-ONLY hints for a human triaging via
`/idea-triage` (R13) — and never sets `goalId`, the only field that would make `captureIdea` actually
route. Every `#ideas` filing still lands in `idea_inbox` exactly as the pre-routing path did, now
carrying a hint rather than none, consistent with every other "classifier guess, not a route" vector
this ADR documents — the second bypass idea 1000771 named did not reopen.

## Consequences

- **Attribution survives routing by construction, not by discipline.** `tests/idea_routing.mjs` pins
  the matrix; `tests/filing_abuse_matrix.mjs` (task 1003073 / R06) pins that a Xenos mass-filing bugs
  never lands anything claimable, never lands in protected scope, and never escalates via filing;
  task 1003072 / R04 is the proof that a routed bug's lineage + `captured_by` survive end-to-end to a
  shipped task.
- **A caller lying about `filerRank` moves a bug from `'backlog'` to `'ready'` and nothing else** — the
  matrix's own header states this as the reason R06's abuse matrix tests the *route* (server-derived
  rank), not `captureIdea` (which trusts whatever rank it is handed, by design, because the route is
  the only legitimate caller).
- **The inbox count is now a real signal.** With bugs and goal-bound features routed away at filing
  time, `idea_inbox`'s open count should trend toward "things that genuinely have no home yet" —
  measured by task 1003074 / R15's before/after sweep of the ~50 rows open when the spec was written
  (not yet shipped at the time of this ADR).
- **R08–R10, R12, R15 remain open** (hall filing surface, CLI `--goal`, hall reassignment affordance,
  Discord `#ideas` hints, the reclassification-sweep proof). This ADR documents the mechanism and the
  matrix those tasks build against; it does not claim the whole spec is delivered.
