# ADR 0208 — Building the application lifecycle: the handle waits for its writer, and the vouch D2.1 describes has no minter that can express it

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1002284](https://cloudbongos.com/builders#/task/1002284) (R08, goal 1000045 — criteria C3/C4)
- **Resolved by:** [ADR 0333](0333-the-application-vouch-is-a-third-token-spent-once-and-bound-to-its-login.md) (task 1002285) — D1's handle and D2's minter, verifier tightening and jti choice are built there.
- **Relates to:** [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) (the design this builds — D1, D3.2, D4), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (descriptive analytics are never authority), [ADR 0141](<redacted>.md) (identity federated, authority local), [ADR 0171](0171-profile-rollup-join-and-consent.md) D2 (the non-numeric principal guard), [ADR 0116](0116-api-error-envelope-and-code-taxonomy.md) (a refusal names the action available), [ADR 0202](0202-connections-graph-and-bounded-degree.md) D4 (the `account-visibility.js` "its own small file" precedent this reuses)

## Context

ADR 0201 decided the cross-project application: it is the target project's own `access_requests` row, vouched for by a hub-signed assertion in a header, with the applicant's record resolved live in the reviewer's browser and never stored. Its dependency table splits the build: **R08 (this task) owns D1 + D4 + D3.2** — the migration, the row, the lifecycle, the atom — and **R09 ([task 1002285](https://cloudbongos.com/builders#/task/1002285)) owns D2 wholesale**: the assertion, the header, the live browser read, and the handle.

Building R08 surfaced one place where the ADR contradicts itself, one place where its central mechanism cannot be written as described against the code that exists, and a handful of small questions it simply did not reach. This ADR records those, in the shape [ADR 0207](0207-connections-implementation-departures-and-honest-limits.md) set for the connections wave: departures first, then the limits the shipped code is honest about.

## Decision

### D1 — `applicant_handle` is **not** in this migration. R09 adds it in the same change that first writes one.

ADR 0201 says two incompatible things about one table:

- **D1.2:** "The migration adds **exactly** what a vouch needs: `applicant_github_id text` and `vouched_at timestamptz`, both nullable."
- **D2.6:** "The vouch carries the `handle` as well as the `github_id` … **The handle at apply time is stored on the row**."

Both cannot be true of `core_230`. The call is that the handle waits, for four reasons, in descending weight:

1. **The ADR's own dependency table already routes it.** R09's row reads "D2 wholesale — the assertion, the header, the live browser read, **and the handle**". D2.6 *is* the handle. The contradiction is therefore about sequencing, not design: D1.2 constrains *this* migration, and D2.6 says the row ends up carrying a handle without saying which migration puts it there.
2. **A column with no writer is worse than no column.** R08 ships no vouch writer at all — the assertion and the header are R09's — so `applicant_handle` would be permanently NULL. Any reader added in between would render "no record" for a reason that has nothing to do with the applicant actually lacking a handle, which is exactly the honest-degrade case D2.6 wants to be able to distinguish.
3. **Migrations are cheap and additive; a wrong-looking column is not.** `<redacted>` and `core_230` cost one file each. R09 adding `applicant_handle` beside its own writer costs one more and zero coordination, and the console wave (spike 1002786 R2) is already adding `kind` / `created_by` to this same table in a third additive migration — the pattern is established, and only a shared column name (`kind`) would collide.
4. **The vouch MARK does not need it.** D1.2's own reasoning — one column, no second flag free to disagree with the first — is satisfied by `applicant_github_id` alone. The handle is a *rendering* input for the live profile read, which is a D2 concern by construction.

This is recorded in the migration's own header, so the next reader of `core_230` finds the reasoning where the apparent omission is.

### D2 — `mintHubAssertion` cannot express D2.1, and the gap is wider than "it takes no `purpose`". R09 needs a third mint/verify pair **and** a tightening of `verifyHubAssertion`.

D2.1 says the relay carries a hub-signed assertion "reus[ing] `mintHubAssertion` … with a `purpose: 'application'` marker — the discriminator `mintHubLogoutToken` already established, so a captured device-login assertion cannot be replayed as an application vouch or the reverse."

Read against the code, that does not hold, and the reason is structural rather than a missing parameter:

- `mintHubAssertion({ clientId, githubId, githubLogin, displayName, avatarUrl })` takes no `purpose` and emits none. `mintHubLogoutToken({ clientId, githubId })` emits `purpose: 'backchannel-logout'` and **no identity**. The two are told apart because each verifier demands what the other lacks: `verifyHubAssertion` throws on a payload with no `github_login`, and `verifyHubLogoutToken` throws on a payload whose `purpose` is not the logout marker.
- **An application vouch needs identity *and* a purpose.** That is the collision. It shares the login assertion's identity fields, so the asymmetry that protects the logout token does not reach it.
- **And `verifyHubAssertion` does not reject a payload that carries a `purpose`.** It checks alg, signature, issuer, audience, expiry, and the presence of `sub` + `github_login` — nothing more. So an assertion minted as `{ …identity, purpose: 'application' }` verifies **as a login assertion** today. Adding the marker to `mintHubAssertion` would therefore buy one direction of the separation and neither of the two D2.1 claims: a captured application vouch would still be replayable as a device login.

So R09 hits this on line one. What it needs, stated so the next session does not rediscover it:

1. A **third** mint/verify pair (`mintHubApplicationVouch` / `<redacted>`) that requires `purpose === 'application'` **and** identity, rather than a `purpose` argument bolted onto the login minter.
2. A **tightening of `verifyHubAssertion`** to reject any identity payload that carries a `purpose` at all. This is backward-compatible precisely because no minter in the tree emits one today — which is the narrow window in which it is free, and it closes as soon as anything starts adding purposes to identity tokens.
3. A decision about the single-use `jti` store: the login path consumes a `jti` once per exchange, and reusing that store for a vouch makes one vouch good for one application, which is the right answer but should be chosen rather than inherited.

R08 mints nothing and verifies nothing, so it takes no position beyond writing this down. It is filed against R09 rather than fixed here because inventing the vouch's wire format inside the task that owns the *row* is exactly the sequencing this goal split to avoid.

### D2b — a rescind REFUSES once the applicant has signed in. It may not report a removal that did not happen.

Found by adversarial review before ship, and it is the most consequential thing in
this task. ADR 0201 D4.2 says the rescind "must never pretend to remove a member",
and the first implementation did exactly that.

`firstTimeAdmissionBlocked` short-circuits on an existing `builders` row, so once
the applicant has signed in, `hasInvitedAccessRequest` is irrelevant to their
admission. Nothing anywhere flips the `invited` row at sign-in — every writer of
`access_requests` was enumerated: this route, `POST /access-requests/invite`, the
public POST, and the Discord reaction handler; none of them touch it. So
`status='invited'` beside a live `builders` row is a **permanently reachable
state** on any instance, and dismissing that row changes nothing at all. The owner
would get `200 {ok:true, status:'dismissed'}`, the hall would say "Request
dismissed", the row would leave the invited history — and the member would keep
full access.

That is a **false negative on an admission control**, which is worse than a
refusal: a refusal makes the owner go and do the right thing, while a false
success makes them stop looking.

So the rescind carries a member check, as a `NOT EXISTS` **inside the UPDATE's own
WHERE** rather than a read-then-write, and a blocked rescind answers `409
already_member` naming `/builder-exit` — the act that does remove a member. The
guard is on the **rescind only**: dismissing a *pending* row for someone who is
already a member is housekeeping, not a removal, and stays allowed.

### D3 — the echo's read joins the project catalog; the echo's **table** is still the three columns D1.3 named.

D1.3 says the echo "carries `(github_id, client_id, applied_at)` and **never a status**". The table does exactly that, keyed on the pair. But a `client_id` alone cannot render "you applied to *X*", so `listRecentApplications` `LEFT JOIN`s `platform_identity_sso_clients` for the name and origin — the same join `listMembershipsForAccount` already makes for the same reason. Nothing new is *stored*; a de-registered project degrades to a null name beside a real date rather than vanishing.

### D4 — three questions D1.3/D1.4 and D4.4 left open, answered.

1. **A re-application refreshes `applied_at`.** D1.4 makes re-applying a success; D1.3 gives the echo a 30-day read window. Left un-refreshed, an applicant who re-asks watches their own card go quiet while their request is still open on the project. The window is therefore measured from the most recent ask, and the upsert says so.
2. **An idempotent PATCH does not re-stamp the audit trail.** D4.4 says a PATCH to the state already held "returns the row, not a 409". It does not say whether `resolved_by_builder_id` / `resolved_at` move. They do not: the row records who *actually* resolved it, not who clicked the button again afterwards. The response carries `unchanged: true` so a caller can tell a no-op from an act.
3. **`dismissed → invited` is refused with `409 already_dismissed`, naming `POST /access-requests/invite`.** D4.2 rules that the reverse correction needs no new path; ADR 0116 requires the refusal to name the action available there, so the message does.

### D4b — leaving a project forgets the echo.

Also from review. Membership hides an echo from `applied` (D5) rather than
deleting it, so apply → approved → sign in → **leave** resurrected the original
application on the applicant's own card for the rest of the 30-day window: "you
applied on ⟨date⟩" about a project they had already joined. The echo means "I
asked and have not yet joined", and someone who joined and left has neither, so
`POST /my-projects/:clientId/leave` drops it (best-effort — a stale echo must not
fail a leave that already happened).

### D5 — the hub's `applied` list drops any project the caller now builds on.

`GET /my-projects` returns `applied` beside `owned` / `building`. A project appearing in both would let a card claim "applied" about a project the applicant is already a member of — the hub implying an outcome it is not allowed to hold (D1.3). Membership is the *only* approval signal the hub may show, so it wins and the echo drops out.

## Consequences

- The queue's `vouched` flag is **false for every real row until R09 lands**, because R08 ships no writer. That is the correct reading — no assertion has been verified — but it means the two-class queue the ADR's Consequences describe is, for now, one class. `tests/application_lifecycle.mjs` seeds a vouched row directly so the distinction and its powerlessness are both proved before the writer exists.
- `core_230` and `<redacted>` are both purely additive and forward-safe: the previous code release ignores every new column and table, so a rollback is a no-op and no federated instance needs to upgrade in step.
- The rescind (`invited → dismissed`) is a real behaviour change on a live route: an approval can now be revoked before first sign-in. After sign-in the row is history and offboarding is the instance's own act, which the route documents and does not attempt.

## Honest limits

- **The vouch is proved powerless, not proved absent from the future.** The proof is behavioural — a seeded vouched row and an unvouched twin take the identical statement and the identical admission read, asserted byte-for-byte, plus a structural check that no statement on the approve or admission path names `applicant_github_id` or `vouched_at`. That catches the vouch being wired into *these* paths. It does not stop a new admission path being written elsewhere; the thing that does is `firstTimeAdmissionBlocked` remaining the single gate, which is ADR 0201 D1.1's whole reason for extending this table instead of adding one.
- **`already_approved` still reaches the hub as "already_member" prose.** The project's public POST answers `409 already_approved` to an applicant who was approved but has not signed in; `joinRelayOutcome`'s bare-409 branch reads that as `already_member`, so the hub says "You already build on this project — sign in to it". The instruction is right and the noun is wrong. Fixing it means adding a sixth outcome to the relay, which is R10/R12's surface, so it is named here rather than changed under a row-and-lifecycle task.
- **The tests are DB-free by construction, so the SQL is executed by an interpreter, not by Postgres.** The interpreter builds each statement's filter from that statement's own `WHERE` text and refuses any predicate it cannot read, and nine mutations were run to confirm it bites: dropping the PATCH's transition guard reds 3 tests (a declined applicant becomes admissible), dropping `requirePermission` reds 6, writing the echo unconditionally reds 4, dropping the echo's read-time window reds 2, dropping the echo's own-scope `WHERE` reds 2, adding a hidden `AND ar.applicant_github_id IS NOT NULL` to the queue reds 1, dropping the rescind's member guard reds 6, dropping `resolved_by_builder_id = $2` from the `SET` reds 11 (it red **nothing** before review — see below), and making a leave stop forgetting the echo reds 1.

- **Two mutations found real holes in the instrument itself, which is why they are listed.**
  The fake pool matched the `UPDATE`'s `SET` list as `.*?` and applied its effect
  from JS, so deleting `resolved_by_builder_id = $2` from the real statement — a
  plain audit-trail regression — passed every test. The `SET` is now matched
  exactly, and that mutation reds 11. And:
- **The `WHERE` sweep was narrower than its own docstring said.** The interpreter refuses a predicate whose *placeholder* it did not consume — so a predicate carrying **no** placeholder is invisible to it, and a filter that silently hid every unvouched row from the owner passed all 26 other tests. The queue is the one read where that matters (and the one legitimately allowed to name the vouch columns, in its `SELECT` list), so its `WHERE` is now pinned exactly rather than inferred. Elsewhere the placeholder rule is enough, because every filter that decides anything binds a value. What it cannot check is anything only a real engine decides, and **nothing in this change is executed by Postgres anywhere** — there is no integration test for `access-requests` at all, and CI has none. So the partial unique index is *modelled* rather than exercised, the `ON CONFLICT` target is asserted as text, and the PATCH's new transition guard reuses `$1` as both the `SET` value and a comparison, which is why it is spelled `$1::text` — the type is stated rather than left to an inference no test observes. The first real exercise of the rescind path is the first rescind on a deployed instance, and the handoff names it as the manual check to run.

- **A rescind overwrites the approver, and this route writes no `audit_log`.**
  `resolved_by_builder_id` / `resolved_at` become the rescinder's, so who
  originally approved is not recoverable from the row. Approve and decline lose
  nothing only because they start from `pending`, which has no resolver to lose —
  the rescind is the first transition here that overwrites one. Carrying the prior
  value out means a CTE on the one statement in this change that no engine
  executes in CI, so it is named rather than coded, and belongs with the queue UI
  that would display an approval history (R11, [task 1002287](https://cloudbongos.com/builders#/task/1002287)).
- **There is no UI path to the rescind.** `watch.js` fetches only
  `?status=pending`, so the invited history is not rendered and nothing offers the
  action. The route is correct and reachable by API; surfacing it is R11's queue
  page. The handoff's manual check says so, rather than implying a button exists.
  (The same review found `patchJson` was not unwrapping the ADR 0116 envelope, so
  every refusal from this route rendered as `[object Object]` — a pre-existing bug
  that *this* change made user-visible, since its whole point is refusals that name
  the action available. Fixed here by copying the unwrap its sibling `postJson`
  already had; without it, D4.3's claim would be true of the payload and false of
  the product.)
- **`applied` is not rendered anywhere yet.** Neither the hall's My Projects page
  nor the orbs front door reads it — R10 ([task 1002286](https://cloudbongos.com/builders#/task/1002286))
  and R12 ([task 1002288](https://cloudbongos.com/builders#/task/1002288)) own
  those renders, and D1.3 is listed as their dependency. The read exists so they do
  not have to invent it.
- **ADR 0201 D4.3 — the read-time 30-day expiry of `invited` — is deferred, not
  done.** `hasInvitedAccessRequest` still admits an `invited` row of unbounded age.
  D4.3 is part of the D4 this task claims, but the ADR's own `What this unblocks`
  table scopes R08's D4 to "the statuses, the rescind gap, idempotency", and the
  expiry touches the admission gate itself rather than this route. It is the
  natural companion to the rescind — both are "an approval should not stand
  forever" — and should be claimed as its own task against `db-kernel.js`.
- **`config/fitness-baselines.json`'s `console_call_count` is left at 161 although
  the real count is now 159** (two `console.error` became `log.error` in code this
  task rewrote), so `fitness.js` prints a standing "ratchet-down available" WARN.
  Lowering it is the convention, but three sessions were in flight; a branch that
  merges main and adds one `console.*` would go red at 160 through no fault of its
  own. Deliberately left for a session that is not racing.

## Rejected

- **Adding `applicant_handle` to `core_230` anyway, to satisfy D2.6 literally.** A permanently-NULL column whose NULL means "R09 has not shipped" rather than "this account has no handle" is a column that lies to its first reader.
- **Adding a `purpose` argument to `mintHubAssertion` in this task.** It would look like D2.1 shipped while leaving both replay directions open, which is worse than the gap being visible.
- **A `status` column on the echo, "just for the applicant's own view".** The whole reason the echo is allowed to exist on the hub is that it holds no admission fact; a status is the one addition that would make it authority on the wrong side of the boundary.
- **Refusing `dismissed → invited` with the existing `not_pending`.** True but unhelpful: the code names the wrong state and points nowhere.
- **A new permission atom for "project owner".** `access_request.review` at floor archon already pins all three routes, and ADR 0201 D3.2 forbids a third atom for one door. This task mints none, and a test pins the atom and its floor to the catalog so a later widening is a deliberate act.
- **Re-stamping `resolved_by` on an idempotent PATCH** to keep the write path branchless. It would overwrite the audit trail with whoever double-clicked last.
