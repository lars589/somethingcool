# ADR 0279 — An upgrade is proven by the served version, not by a health check

- **Status:** accepted
- **Date:** 2026-09-11
- **Task:** [task 1002884](https://cloudbongos.com/builders#/task/1002884) (BONGOS-V2, goal 1000090 — *Working area 4, Bongos Core distribution*), from idea 1000682
- **Extends** the mandatory post-restart health check of task 1002222 (audit H9, finding F5) and the auto-rollback of task 2149, whose unattended policy is [ADR 0136](0136-update-channel-subscription-policy.md) §3. The health check stays; this says why it was never sufficient on its own.

## Context

On 2026-08-11 the auto-upgrade sweep on cloudbongos.com printed `✓ upgrade complete — core 1.19.13 → 1.19.56`, wrote a success row to the `core_upgrades` ledger and exited 0. Live kept serving **1.19.13**. Every monitoring surface agreed the upgrade had landed. None of them had looked at the running process.

Three things had to line up, and all three were in the shipped code:

1. **The restart failed, and that was a warning.** The sweep ran `systemctl restart cloudbongos.service` as user `lars` with no TTY. The unit is a `User=` unit, so the restart needed authorization polkit could only get interactively — `Interactive authentication required`, exit 1. `upgrade.js` logged `! restart command failed` and **fell through to verification**.
2. **The version check read the wrong thing.** `readInstalledCoreVersion()` reads `node_modules/@bongos/core/package.json` — the version on **disk**. `npm install` had genuinely put 1.19.56 there. Disk was right; the process was not.
3. **The health check could not tell the difference.** `pollHealth()` asks whether *something* answers with a 2xx. The old process was up and perfectly healthy, so it answered. A health check confirms a port is being served; it cannot confirm *what* is serving it.

Each check was individually reasonable. Together they were a closed loop that could not observe the failure they existed to catch, which is the worst shape a check can have: it reports success it has not proven, and a lying tool is more expensive than a broken one, because nothing goes looking.

The damage outlived the incident. `.claude/scheduled-tasks/core-update-subscription/subscribe.js` routes around `bongos upgrade` in favour of `go-live.js` and says so in a comment — *"upgrade.js's own health check is documented to false-pass by polling the still-running OLD process"*. A known-lying tool had become something the rest of the system worked around instead of fixing.

## Decision

**A bump is confirmed by asking the running process what version it is. Anything less is unconfirmed, and unconfirmed is not success.**

Three changes in `scripts/gds/upgrade.js`:

1. **A failed restart fails the upgrade.** It enters the same auto-rollback path as a failed install, migrate or health check, and returns non-zero. Rolling back rather than merely erroring keeps disk and process consistent: the previous core goes back on disk, matching the one that is (still) running. Leaving disk ahead of the process is the state that made the original incident invisible.

2. **The served version is read back from `/version`.** That route reports the live process's `coreVersion` (`serve-internal.js`, since 1.17.2) and is exempt from the prelaunch gate, so it is readable wherever `/healthz` is. The URL defaults to `/version` on the health URL's origin and can be overridden with `--version-url`. Deriving rather than requiring a new flag is deliberate: every existing call site passes only `--health-url`, and a check that must be opted into is off exactly where it is needed.

3. **A mismatch fails; an unreadable endpoint warns.** These are different facts and are treated differently. *"It says 1.19.13 and I asked for 1.19.56"* is proof of failure — roll back. *"It would not tell me"* is absence of proof: an instance may not expose the endpoint, and refusing every such bump would be a worse regression than the false-pass we are removing. Passing `--version-url` explicitly asks for proof, so there an unreadable endpoint **is** a failure — which is what the unattended subscription lane now does, since its roster already carries the exact URL.

**On escalation: `sudo -n`, not a hand-placed polkit rule.** `restartService()` retries a failed `systemctl restart` through `sudo -n` when not root — the idiom `dev.js` and `dev-lib.js` already use, and consistent with `provision.js`, which prefixes its own `systemctl` calls with `sudo`. `upgrade.js` was the one place that restarted a service without escalating, which is why only it hit the wall. The live mitigation at the time was a hand-written `/etc/polkit-1/rules.d/<redacted>.rules` on one box; that rule is **superseded**, because a rebuilt box inherits code and does not inherit hand-placed `/etc` files. `-n` fails fast rather than hanging on a password prompt, so the retry costs nothing where it isn't permitted. The polkit route is documented in [`docs/recipes/instance-service-restart.md`](../recipes/instance-service-restart.md) for hosts that prefer it or that deliberately withhold sudo.

## Consequences

- An upgrade that cannot restart the service now **fails loudly and reverts**, where it used to warn and claim success. This is the point, but it means a host with neither passwordless sudo nor a polkit rule will start seeing upgrades fail that previously "passed" — correctly. The error names both fixes.
- `--no-health-check` remains the single documented escape hatch and now waives the served-version read-back too, rather than adding a second flag to reason about.
- `subscribe.js` no longer needs to describe the direct-upgrade lane as having "no independent read-back"; the comment and the log line were corrected with the fix, since a stale comment about a fixed bug is how the next session re-learns a lie.
- The rollback path calls `restartService()` too, so it also escalates — a rollback on a box that needs sudo can now actually restart onto the restored core instead of silently leaving the failure in place.

## Rejected

- **Comparing `startedAt` instead of `coreVersion`.** A restart that swaps nothing still moves `startedAt` if the unit bounced, and a process that never restarted keeps an old one — but `startedAt` cannot distinguish "restarted onto the same (old) core" from "restarted onto the new one". `coreVersion` answers the actual question.
- **Making an unreadable endpoint fatal by default.** Fails closed in the wrong direction: it would break upgrades on instances that never served `/version`, to catch a case that a fatal restart failure already catches.
- **Requiring `--version-url` everywhere.** The check would then be absent from every current call site — the same "off where it matters" failure in a new costume.
- **Keeping the polkit rule as the answer.** It works, but it lives in `/etc` on one machine. The task's own framing is that a rebuilt box must inherit the fix; only code does that.
