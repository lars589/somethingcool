# ADR 0274 — One kernel, three role packs: the always-loaded instructions stop being an engineer's

**Date:** 2026-09-10
**Context:** BONGOS-V2, goal [1000095](https://cloudbongos.com/builders#/goal/1000095) (Working area 6 — Governor / Builder / Artist / Ideator experience), criterion `wa6-kernel-and-packs`, task [1002990](https://cloudbongos.com/builders#/task/1002990). Builds on [ADR 0061](<redacted>.md) (the CLAUDE.md context budget), [ADR 0062](0062-medusa-instance-model-decoupling.md) §7 (the core ↔ host split), [ADR 0272](0272-a-craft-is-an-identity-not-a-toolchain.md) (a craft is an identity, not a toolchain) and [ADR 0271](0271-the-ideator-surface-is-two-halves.md) (which predicted this move: *"when declaration lands the contract MOVES into the Ideator pack"*). Its dependency, task 1002989, widened the module map to cover the methodology surfaces so this work had a wall to stand in.
**Status:** Accepted.

## Problem

The root `CLAUDE.md` loads **in full, every session, for every craft** — and it was an engineer's document. 250 lines and 32,422 characters of claim-before-working, worktree-per-claim, `DEPS_NOT_SHIPPED`, doc-comments, `touches[]`, generated-artifact hygiene, `/merge-mode`. An ideator who came to think about an idea, and an artist who came to look at something, each paid the full token cost of a build pipeline they were not going to run, and read it as instructions addressed to them.

That is a correctness problem before it is a budget one. The file said, as its hard rule, *"every change is backed by a claimed Bongos task, no exceptions"* — while the same goal's criterion `wa6-drift-stops-the-session` says an ideator is *"pointed at ideation (which needs no claim)."* The kernel and the criterion disagreed, and the kernel is what every session actually read.

Meanwhile the craft-specific material that *did* exist lived in three slash-command skills — `/dev`, `/ideate`, `/paint`. A skill is the wrong carrier for a role's operating playbook for two reasons. Its `description` is resident in every session's skill listing whatever craft is running (the listing measured 27,022 chars against a ~8,000 budget, and `dev`/`ideate`/`paint` were three of the twenty over-length entries). And it must be *invoked* — a session that never types the slash command works from the kernel alone, which is the engineer's document again.

## Decision

**One role-neutral kernel plus one pack per craft, bound by a registry that CI checks.**

1. **`CLAUDE.md` is the kernel.** What Cloud Bongos is, the lifecycle in plain terms, the money, the trust boundary, the identity split, the content charter, and the navigation index. The test for a line is now two-part: *would removing it cause a mistake?* **and** *is it true for every craft?* A line that is only true for engineers moves out. Result: 250 → 216 lines, 32,422 → 22,572 chars, which clears the `fitness.js` character target it had been over.

2. **Three packs under `docs/packs/`** — `engineer.md`, `artist.md`, `ideator.md`. **On the name:** task 1002990's own title says *"the Builder pack"*, and this ADR does not. The criterion it implements names the three crafts *Engineer, Artist, Ideator*; `CORE_DISCIPLINES` is `['engineer','artist','ideator']` (ADR 0272); and `tasks.discipline` stores `engineer`. "Builder" is the person who holds a claim in any craft — an artist is a builder too — so naming one craft's pack after it would collide with the word the rank ladder and the whole hall already use. The pack is keyed by the discipline it is bound to, because that key is what the registry looks up. The Engineer pack inherits today's methodology verbatim in substance (the loop, the working rules, the session protocol, the daily cadence, subagent routing) plus what `/dev` carried. The Ideator pack absorbs `/ideate` and writes down the two grades the criterion names: a quick idea stays **one line**, and after one is filed Claude **asks** whether to develop it into a Full Idea — five questions drawn out of the conversation, in the ideator's own words, scored on completeness. The Artist pack absorbs `/paint` and generalises it off the pixel-art pipeline (ADR 0272: the craft is core, the pipeline is an optional host module): show-first, **as little interpretation as possible** — take the brief literally, you are their hands and not their art director — and **arrive precalculated**, with the look already loaded and the options already rendered, because a session that opens with intake questions is a form.

3. **`/dev`, `/ideate` and `/paint` are deleted.** The skill listing drops to 25,624 chars and 17 over-length descriptions.

4. **`scripts/gds/discipline-modes.json` becomes the role registry.** A core craft names a `pack` (a file to *read*); a module-contributed discipline may still name a `skill` (a command to *invoke*), which is how `ui` → `/design` survives unchanged, as ADR 0272 requires. `claim.js` prints whichever the entry carries, with the right verb. *(Since task 1002992 the full pointer is injected by the Conductor from GET /me and `claim.js` prints only the one role line.)*

5. **`scripts/gds/role-pack-guard.js` hard-fails CI** when an entry names a pack that is not in the tree, when an entry names neither pointer, when fewer than three crafts carry a pack, or when a pack exceeds its character budget (16,000 hard / 13,000 target, ratcheted just above the packs as authored).

### Why the guard is hard when the runtime is fail-open

`claim.js` must never break a granted claim, so its registry read swallows everything. That means a pack path pointing at nothing degrades to **silence**: the builder is told their craft's label and nothing else, and the playbook that carries everything the kernel deliberately dropped never loads. The role is hollow and no error says so. CI is therefore the only place that failure can be caught — which is exactly what the criterion asks for when it says *"CI budgets each pack."*

### Why `docs/packs/` and not `.claude/packs/`

Three reasons, in order of weight. `docs/` is already owned by the `methodology` key in `module-scope-map.js`, so the packs sit inside a wall that exists; a new top-level path would resolve to **no** key, and the scope map's own comment records what that costs — a missing key is an empty wall, and `goal-scope-check` then denies every member-authored task (the 1002690 / 1002736 / 1003124 precedent). Second, a pack must not be a skill: skills are listed in every session regardless of craft, which is the cost this ADR is removing. Third, `docs/` resolves from the core package the same way `discipline-modes.json` does, so a scaffolded instance reads the registry and the pack it names from one place with no materialisation step.

`docs/` is default-deny in the publish manifest, so `docs/packs/` is registered explicitly. The registry line and the allowlist line are only ever added or removed together — a core that shipped the registry without the packs would print, on every claim on every instance, a path that resolves to nothing: precisely the silent failure the guard exists to make loud.

## Consequences

- **The ledger rule survives the split, and gets more honest.** The kernel keeps it in role-neutral form — *a change to project state is recorded in Bongos before it is made* — and each pack says what recording means for that craft. The engineer holds a claim; the ideator files the idea; the artist claims the work or records the review. The no-loopholes paragraph moves to the Engineer pack intact, where it is true.
- **The ship card had to move with the claim.** `modules/lifecycle/ship-card.js` routed a claimed task's "Open the work" button to `/dev`, `/paint` or `/ideate`. Left alone it would have shipped a button firing a command that no longer exists — the same divergence task 1003487 fixed in the other direction. It now points at the pack, and `tests/ship_card.mjs` asserts no core craft is routed to a slash command.
- **The ship card duplicates the registry, and a test is the shared source it cannot have.** `ship-card.js` is a module and may not require a core script across the boundary, which is why it and `claim.js` have always carried the map twice — and task 1003487 was exactly that duplication drifting. Rather than pretend the duplication away, `tests/fitness.mjs` now walks the registry entry for entry and asserts the card agrees, so a pack rename fails a test instead of shipping a hall button that opens nothing.
- **`tests/idea_ideate_full.mjs` moved with its subject.** Its thirteen assertions pinned the Full-Idea contract in `/ideate`'s prose — the same-route rule, the never-invent rule and its reason, the five-questions-are-not-restated rule. Repointing it at `docs/packs/ideator.md` is what stops the split from deleting a guard along with the file it guarded; all thirteen pass against the pack unchanged.
- **The line target is not yet met.** The kernel is 216 lines against a ~200 target — a `fitness.js` warning, not a failure, and the same warning it carried before at 250. The character target, which is the real per-session cost, is now cleared. Tightening the line count is the context-budget cluster's work (tasks 1003620, 1003687, 1003688), which the goal's audit sequenced explicitly behind this one.
- **Governor is deliberately absent.** Three packs, not four, until the owner decides. The guard's floor is `>= 3`, so adding a fourth is additive and removing a third is a failure.
- **What this unblocks.** Task 1002991 (serve composed session context from the server) and 1002992 (inject role context at start and claim) now have something to compose and inject: today the pointer is printed and read, and those tasks replace the reading with injection. Task 1003732 authors the three responsibility statements into the packs' reserved seams — the Artist pack names its own, unwritten, rather than inventing it.

## Rejected

- **Keeping the three skills and adding packs beside them.** Two homes for one craft's playbook is how they drift, and it keeps the skill-listing cost the split exists to remove.
- **Packs as skills under `.claude/skills/packs/`.** Every session pays for every pack's description — the exact failure being fixed.
- **A fourth Governor pack "while we're in here."** The criterion defers it by name, and inventing a role's operating playbook without its owner is how the un-owned areas in this goal's audit came about.
- **Duplicating the safety rules into all three packs.** The charter forbids duplication for a reason: three copies drift and the kernel becomes the one nobody trusts. Safety stays in the kernel; craft stays in the pack.
- **Leaving `checkRolePacks` advisory, like the doc-comment check.** That check is advisory because a blocking doc-comment gate buys filler prose. This one gates a *resolvable path*, which is a fact and not a judgement, and the runtime cannot report it.
