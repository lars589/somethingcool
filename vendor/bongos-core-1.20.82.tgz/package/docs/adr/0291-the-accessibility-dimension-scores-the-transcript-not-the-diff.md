# 0291 — The accessibility dimension scores the transcript, so it lives in the session evaluator, not the grader panel

**Status:** accepted · 2026-09-16 · [task 1002516](https://cloudbongos.com/builders#/task/1002516)

## Context

Clause 4 of criterion `accessibility-fluency-profile` asks that "the session evaluator (grader or the BFG 6D eval) gains an accessibility dimension scored from the transcript — unexplained-jargon density, <redacted>, outcome-vs-implementation — tracked per-builder and surfaced on the dashboard."

The task that carries the clause points at `modules/grading/`, and so does the sibling [task 1003937](https://cloudbongos.com/builders#/task/1003937), which wants a copy/voice lens added to the same rubric. Reading them together, the obvious move is one new worker in the v4 panel serving both.

That reading does not survive contact with the seam. The v4 panel's workers are handed `{ task, valueSummary, diff, changedFiles, diffStats, deterministicFindings, priorRound, contextBundle }` (`modules/grading/grader-workers/index.js`, `runWorker`). **There is no transcript anywhere in that argument list, and nothing upstream has one to give.** A grader worker judges the change a session produced; it cannot see how the builder was spoken to while producing it, which is the entire subject of this clause. A fifth worker would have had to re-read the session corpus from inside the ship path to say anything at all.

The transcript does exist — in `session_records`, uploaded by `scripts/gds/session-digest.js` on the SessionEnd seam and evaluated by `scripts/gds/session-eval.js` (ADR 0027, cluster 6D). The criterion's own wording offers that path first ("grader **or** the BFG 6D eval").

## Decision

**1. The dimension lives in `modules/sessions/accessibility.js`**, a pure scorer over the session digest's per-turn detail, and the grader panel is untouched. Three signals, exactly the three the criterion names: unexplained-jargon density, terminal-where-a-click-path-exists, and implementation framing carrying no cost/time/reader framing.

**2. It is scored server-side at upload**, in `POST /sessions`, for the same reason `drachmae_earned` is: a score the uploader could supply is a score nobody can read. The route is also the only place the builder's own interaction profile is available without another round trip — the SessionEnd hook runs under a 6-second watchdog, so making it fetch `/me` would trade a coaching metric for dropped uploads.

**3. It is profile-relative, and a sanctioned signal is not scored at all.** The criterion is explicit that "an expert's terse experience is never degraded to help a newcomer". A signal the builder's own profile sanctions is marked `waived` rather than given a generous threshold: `technical_level: engineer` waives jargon and implementation framing, `toolchain_familiarity: comfortable` waives terminal-first, and `mixed` widens the jargon allowance instead of waiving it. **A session whose every signal is waived scores `null`, not a number** — so a profile-sanctioned reply cannot produce a low score even in principle. This is the sibling of the rule that keeps `verbosity: concise` from dropping a render rung ([task 1002518](https://cloudbongos.com/builders#/task/1002518)), and `verbosity` is deliberately not an input here at all: every rate is per 1000 sampled characters, so brevity is arithmetically incapable of lowering the score.

**4. It is advisory and gates nothing.** [ADR 0241](0241-the-artist-gate-is-a-per-project-deploy-gate-that-reads-a-state.md) settled that a taste-shaped judgement may hold a deploy and never a builder's ship. A transcript-shaped judgement is the same kind, and it arrives after the session has ended in any case. It is recorded on the session row, shown on the Session Ledger, and raised as an `unplain_speech` finding by the BFG for per-builder coaching.

**5. The profile crosses the module boundary as DATA, not an import.** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) forbids a module requiring a sibling, so `accessibility.js` never requires `builder-settings`. The route resolves the `builder-settings` kernel port, asks it for the effective profile, and passes the plain object in; the scorer keys on the literal field values. `tests/session_accessibility.mjs` asserts those literals still exist in `interaction-prefs`, so a rename there fails a test rather than silently un-waiving an engineer's session.

## Consequences

**The sampling bound is real and is reported, not hidden.** The digest stores only the first 160 characters of each assistant turn (`snippetOf`), so this measures the opening of every reply rather than its whole body. Widening the snippet would inflate every `session_records` row against the SR-17 disk bounds, so the sample stays and `sampled_chars` + `confidence` travel with the score. A thin sample cannot raise a BFG finding.

**Every detector fails towards not penalising.** Jargon matching is word-bounded (a substring match made `ORM` fire on "format"), any nearby definition marker counts as explained, and a terminal command is only a finding when its subject appears in an explicit table of click-paths that actually exist. A metric that punishes correct work is what the task's own "watch out" calls actively harmful, so the undercount is deliberate.

**Task 1003937 is not answered by this.** A copy/voice lens judges the words in a *diff* — strings a user will read — which genuinely is the grader panel's shape, and that task's three open questions (cost, gate-or-advisory, and what written standard to judge against) still need the owner. This ADR settles only that the two are different seams and must not be built as one worker.

**Historical rows are re-scored, and say so.** `session-eval.js` prefers the stored score and falls back to re-deriving one at the default profile for a row that predates the dimension, marked `rescored` so a reader never mistakes it for the original.
