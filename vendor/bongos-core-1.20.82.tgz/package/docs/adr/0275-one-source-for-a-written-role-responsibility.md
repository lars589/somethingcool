# ADR 0275 — A role's written responsibility has one source, and the pack's copy is generated

**Date:** 2026-09-10
**Context:** BONGOS-V2, goal [1000095](https://cloudbongos.com/builders#/goal/1000095) (Working area 6), criterion `wa6-written-responsibilities`, task [1003732](https://cloudbongos.com/builders#/task/1003732). Depends on [ADR 0274](0274-one-kernel-three-role-packs.md) (the kernel/pack split, which reserved the seam this fills) and [ADR 0272](0272-a-craft-is-an-identity-not-a-toolchain.md) (`CORE_DISCIPLINES`). The three sentences were fixed by the area owner on 2026-09-08.
**Status:** Accepted.

## Problem

The criterion is one sentence: *"Each role's responsibilities are written down, and that text is what the pack teaches and the grader judges by. One source, shown on the profile, injected into the pack, referenced by grading."* Before this task the statements existed only inside the criterion record — nowhere in the tree.

The interesting half is **why one source, and not three good copies.** Three consumers need the same words: the hall profile shows a person what they are answerable for, the role pack instructs their session, and the grader judges the result. If each holds its own copy, the copies drift — and the drift has a specific, unfair shape. The project can show a builder one standard on their profile, teach a session a second, and grade the shipped work against a third. Someone is then judged by a rule they were never shown. That is the failure mode; a typo is not.

## Decision

**One source at `src/role-responsibilities.js`, three consumers, and the one copy that *can* drift is generated and CI-gated.**

1. **The source** is a frozen map of `discipline → the owner's sentence`, verbatim, with provenance. It imports nothing.

2. **The hall reads it through the projection that already exists.** `clientModules()` gains `responsibilities`, scoped to the disciplines the instance offers. That projection is already injected into every served page as `window.__MODULES__`, so the profile renders the statement with no new route, no fetch, and no second copy.

3. **The grader reads it through the doorway.** `module-api` exposes `responsibilityFor()`; `grader-prompt.js` states the craft's standard in the prompt and says plainly that it is the project's written standard, not the grader's preference.

4. **The packs carry a GENERATED block.** `scripts/gds/gen-role-responsibilities.js` writes it between markers; `role-pack-guard.js` fails CI when it drifts.

### Why the pack's copy is the one that needs a gate

The profile and the grader read the source at runtime and *cannot* drift — they have no copy to go stale. A markdown pack cannot require a JS module, so its copy is the only one that can. It is also the worst one to lose: the pack is what a session is actually instructed by. So the promise "one source" is enforced exactly where it is falsifiable, and asserted nowhere it is free.

The generator reads the **role registry** for its targets rather than hardcoding three filenames, so a renamed pack or a fourth craft (Governor, when the owner decides) is picked up with no edit to it.

### Why the statement is on the kernel roster

`src/modules.js` is a `KERNEL_FILES` file and may import only the kernel, so the source joins that roster. It earns the place: two separate modules consume the same sentences, modules never import each other, and the file imports nothing — so holding it to the kernel rule costs nothing.

## Consequences

- **`fitness.js` needed an exemption for the owner's own prose.** The ideator's statement opens *"Make good ideas"*, and `ideas` is a module key — so the no-module-keys-in-the-kernel scan flagged an English word as a module reference. Paraphrasing to satisfy a scanner is exactly what this task forbids, so the file is exempted with that reason written down. Its import *direction* is still guarded.
- **`fitness.js` was one line from its size budget, which changed the design for the better.** Registering the pack-block freshness inside `checkGeneratedArtifactsFresh` pushed the file past the 1,500-line ratchet. Rather than raise the baseline — which the check explicitly forbids — the assertion moved into `role-pack-guard.js`, which already owns the packs. One check now answers "are the packs correct": they resolve, they fit their budget, and they carry the current statement.
- **The generator matches each pack's own line ending.** The packs are `.md`: CRLF on a Windows checkout, LF in CI. A generator that always wrote `\n` would make the committed bytes platform-dependent and the freshness gate red on one checkout and green on the other, for a file nobody touched.
- **A craft with no statement renders nothing, everywhere.** `ui` is module-contributed (ADR 0272) and Governor is deferred (ADR 0274). Every consumer treats absence as a legitimate answer — no empty quote on the profile, no line in the grader prompt. A grader told "this role has no written standard" would supply its own, which is the invention this ADR exists to prevent.
- **The profile's avatar needed realigning.** The head grid is `align-items: center`, which read fine while the identity column was three short lines; the responsibility block made it tall enough that the avatar floated beside the middle of the prose instead of beside the name. Pinned to the top row. Verified in both themes in the hall preview.
- **A test enforces "no second copy" directly.** `tests/role_responsibilities.mjs` sweeps `src/`, `scripts/`, `modules/`, `tests/` and `docs/packs/` for any file repeating a statement outside the source, its generated blocks and the test's own fixture. That is the criterion's actual content, so it is asserted rather than described.

## Rejected

- **Three hand-written paragraphs, one per pack.** The thing the criterion forbids, and the drift would be invisible.
- **A new route (`GET /role-responsibilities`) for the hall.** A fetch, a loading state and a failure mode, for static text already riding a rail that reaches every page.
- **Storing the statements in the DB.** They are not live state — they are the project's own written standard, versioned with the code that teaches and enforces them. A DB row would put the text outside code review, which is the opposite of what "written down" is for here.
- **Letting the grader compose its own description of a craft from the discipline name.** That is the invented standard the whole task removes.
- **Raising `oversized_file_count` to let `fitness.js` grow.** The ratchet says never raise the baseline to pass, and the constraint produced a better home for the check.
