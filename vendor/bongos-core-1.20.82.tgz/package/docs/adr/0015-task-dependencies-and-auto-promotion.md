# ADR 0015 — Task dependencies + auto-promotion

**Date:** 2026-05-17
**Context:** GDS-V3, task [#309](https://example.com/builders#/task/309) (V3.R02 — Task dependencies + auto-promotion system).
**Status:** Accepted.

## Problem

The GDS has a `tasks` table with a `status` column and a `priority` column, plus a `V<ver>.R##` rank prefix encoded in the title. Planning Session `#1` (2026-05-12) used the rank prefix as the "order to ship things in." But the system had no machinery to enforce that order:

- Every new task lands in `status='backlog'`.
- A task can only be claimed when `status='ready'`.
- `backlog → ready` only flips via manual `POST /tasks/:id/promote`. There is no auto-promotion rule.
- So the rank prefix was decorative — execution order was whatever happened to be promoted, which in practice meant "whatever was already `ready` from a previous version."

Lars hit this on 2026-05-17: he wanted to claim the top-rank GDS-V3 task and the API offered him one option (V3.R18) — the only `ready` task — when the ranking implied he should be working on V3.R02.

We needed three things:

1. **A way to declare "task A must wait for task B."**
2. **A rule that promotes tasks automatically as their dependencies ship**, so the queue self-feeds.
3. **A claim-time guard** so a task can't be worked while its deps are still open, even if it ended up `ready` manually.

## Decision

Add a `task_dependencies` join table, a `tasks` UPDATE trigger that auto-promotes dependents on ship, a claim-time check that refuses `DEPS_NOT_SHIPPED`, and an API surface for managing deps.

### Schema

```sql
CREATE TABLE task_dependencies (
  task_id            bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  depends_on_task_id bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  created_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (task_id, depends_on_task_id),
  CONSTRAINT no_self_dep CHECK (task_id <> depends_on_task_id)
);
CREATE INDEX idx_task_deps_task         ON task_dependencies (task_id);
CREATE INDEX idx_task_deps_depends_on   ON task_dependencies (depends_on_task_id);
```

Many-to-many. Cascade on delete because a task being removed orphans its edges. Self-deps are constrained out at the DB layer; cycles are checked at the application layer (recursive CTE in `addTaskDependency` / `setTaskDependencies`).

### Trigger

```sql
CREATE TRIGGER trg_promote_dependents_on_ship
  AFTER UPDATE OF status ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION promote_dependents_on_ship();
```

The function fires when `NEW.status='shipped' AND OLD.status<>'shipped'`. It scans rows in `task_dependencies` where `depends_on_task_id = NEW.id`, and for each dependent task that is `backlog`, is NOT `kind='spike'`, and has zero remaining unshipped deps, flips it to `ready` and stamps `promoted_at`.

### Claim-time guard

`claimTask` in [src/bongos/db.js](../../src/bongos/db.js) checks `unshippedDependencies(taskId, client)` before inserting the claim row. If any dep is unshipped, throws `{ code: 'DEPS_NOT_SHIPPED', deps: [...] }`. The route handler maps that to HTTP 409, the CLI prints a clean error listing the blockers.

`claimTasksBatch` does the same check per-task but treats batch-internal deps as "OK" (the batch is worked serially).

**The batch caller owns the ordering (task 1004391).** "Worked serially" is a promise the caller makes, not one the system keeps. `claimTasksBatch` (now in [modules/lifecycle/db-claims.js](../../modules/lifecycle/db-claims.js), with its dry-run twin in the same file) only waives the claim-time check for a dependency that is claimed in the same batch; **nothing at ship time checks that the dependency shipped first**. Once both are claimed, a dependent can pass `completed`, `confirmed` and land on `main` before the task it depends on. Whoever claims a batch — a builder, `/builder-sequence`, the autonomous runner — must ship each in-batch dependency before its dependent. The owner chose to write this rule down rather than add a ship-time gate (which would change the protected ship pipeline); if dependents landing out of order ever causes real damage, the gate is the follow-up.

### A dependency added AFTER promotion: the row stays `ready`, the FEED hides it (task 1004390)

Everything above describes the forward path — `backlog → ready` as dependencies ship. The reverse direction had no written rule. Adding a dependency to a task that is already `ready` leaves it `ready`: the promotion trigger only fires on ship, and nothing anywhere demotes. The paths that produce such a row are a hand-promoted task (`POST /tasks/:id/promote`), an edge written after promotion, and a dependency target that leaves `shipped` later. For most of this ADR's life the consequence was that the task kept being advertised by `/builder-start` and was then refused at claim time with `DEPS_NOT_SHIPPED` — `db-claims.js` calls its own check "the second line of defence", and there was no first line.

**The ruling: fix the FEED, never the status.** Two fixes were on the table and only one of them is honest.

- **Rejected — demote the target to `backlog` in the dependency writers** (`addTaskDependencies` / `setTaskDependencies` / `addDependency` in [modules/lifecycle/db-deps-criteria.js](../../modules/lifecycle/db-deps-criteria.js)). It needs no migration, which is the whole of its appeal. Against it: `backlog → ready` is a human's deliberate act, and a planner adding an edge would silently reverse it with nothing in the record naming who undid whom. Auto-promotion is a **forward-only** signal (the cost bullet below); this would have made it bidirectional, and the ship trigger re-promoting the row later only hides how far the status drifted from what anyone decided. A status is an answer to "was this promoted?", not a cache of "is this workable right now?".
- **Chosen — hide a dep-blocked `ready` task from the claimable feed.** Shipped as `core_264` under task 1004190: `claimable_tasks`, and its two inlined copies (`CLAIMABLE_SQL` in [modules/lifecycle/db-tasks.js](../../modules/lifecycle/db-tasks.js) and the feed body in [src/bongos/optimizer.js](../../src/bongos/optimizer.js)), carry a dependency clause that mirrors `unsatisfiedDeps` — the predicate `POST /claims` actually runs — arm for arm, rather than the promotion trigger's `task_is_fully_unblocked`. The two disagree on an orphaned edge, and copying the promotion predicate would have hidden a row the claim gate still accepts. The feed must say exactly what the gate will do.

So a dep-blocked `ready` row is now **neither advertised nor claimable**, and its status still reads `ready` because that is the true answer to the question `status` asks. The dependency writers issue no status write at all, deliberately — `tests/dependency_writes_atomic.mjs` goes red if one ever appears, so re-adding the rejected branch cannot pass as a tidy-up.

### API surface

| Verb     | Path                                          | Body / returns                                           |
|----------|-----------------------------------------------|----------------------------------------------------------|
| `GET`    | `/api/gds/tasks/:id`                          | `task` now includes `dependencies[]` + `dependents[]` arrays |
| `GET`    | `/api/gds/tasks/:id/dependencies`             | `{ dependencies, dependents }`                            |
| `POST`   | `/api/gds/tasks/:id/dependencies`             | `{ depends_on_task_id }` or `{ depends_on_task_ids: [N,...] }` |
| `PUT`    | `/api/gds/tasks/:id/dependencies`             | `{ depends_on_task_ids: [N,...] }` — replaces full set    |
| `DELETE` | `/api/gds/tasks/:id/dependencies/:depId`      | removes one edge                                         |

Error codes: `self_dep` (400), `task_not_found` (404), `cycle` (409 — returns the path).

### Spike convention

Spikes (`kind='spike'`) NEVER auto-promote. They sit in backlog until a power-user manually calls `POST /tasks/:id/promote`. This is the "ambiguity gate" — spikes produce new task definitions or ADRs whose outputs reshape downstream work; auto-flowing them would skip the human review that justifies the spike's existence.

Non-spike tasks (`feature`, `bug`, `infra`, `cleanup`, `refactor`, `learning-capture`, `decision`, `blocker-resolution`, `unclassified`) auto-promote.

### Rank renumbering

The `V<ver>.R##` rank prefix is now a topological renumbering of the dep graph. For any A → deps → B, B's R## < A's R##. Tiebreaker: lower current R## (preserves planning intent), then alphabetical. The rank is decorative — `dependencies[]` is load-bearing — but a topologically-sorted rank makes the queue display read true.

Migration 021 did the initial pass for GDS-V3: 86 dep edges inserted, 72 of 87 non-shipped tasks renumbered.

## Alternatives considered

### One: `tasks.depends_on int[]` array column

Single column, no join table. Rejected because:
- Indexing both directions (forward + reverse) is harder with arrays.
- The cycle-detection CTE is uglier without a normalized edge list.
- The 1-row-per-edge model lets us add per-edge metadata later (e.g. `reason`) without schema churn.

### Two: `parent_task_id` for ordering

We already have a parent/child hierarchy column (PMS-V2 [#210](https://example.com/builders#/task/210)). Reuse it for ordering. Rejected because hierarchy is a *containment* relationship ("R17 is a sub-task of R15") and dependency is a *precedence* relationship ("R17 cannot start until R08 ships"). Two different things. Conflating them would make both unusable.

### Three: Cron-based promotion

A scheduled task walks the backlog every N minutes and promotes anything whose deps are clear. Rejected because:
- Latency: tasks could sit unpromoted for up to N minutes after a ship.
- More moving parts (one more scheduled task to monitor).
- The trigger is exactly correct here — it fires synchronously with the state change that matters.

### Four: No auto-promotion — keep manual `/promote`

Rejected because that's the system that was failing Lars in the first place. Manual promotion doesn't scale beyond one builder.

## Consequences

**Good:**
- A high-rank task that's stuck in backlog is now self-explanatory: look at its `dependencies[]`.
- A planning session's rank actually means something now — execution order can't drift from the spec.
- Parallel-safe: deps are evaluated per-claim, so two builders can independently claim tasks whose dep graphs don't overlap.
- The auto-promotion trigger is one place to read; it's the only thing that flips status from backlog → ready (other than `POST /promote` and the existing blocker-resolution trigger).

**Costs:**
- Migration 021 was hand-built for the GDS-V3 task set; future planning sessions will need their seed scripts to write the `task_dependencies` rows as part of the same atomic seed. The [planning-session SKILL](../../.claude/skills/planning-session/SKILL.md) Phase 4 now captures this.
- Cycle detection on every `addTaskDependency` is a recursive CTE walk. Cheap for V3-sized graphs (<100 nodes, <100 edges); will need an index review at 1000+ nodes if we ever get there.
- A planner who forgets to declare a dep will get the wrong execution order — but they'll see it immediately when the wrong task auto-promotes, and editing deps after the fact is cheap (`PUT /tasks/:id/dependencies` replaces the full set). The auto-promotion trigger doesn't retro-flip; if you add a dep to a task that's already `ready`, the task stays ready. That's intentional — auto-promotion is a forward-only signal, and *A dependency added AFTER promotion* above is what keeps that row out of the queue instead.

**Operationally:**
- `/builder-start` never shows a dep-blocked task. **The reason changed (tasks 1004190 / 1004390).** Filtering by `status='ready'` was never enough on its own — a dep added after promotion leaves the row `ready`, so for most of this ADR's life the menu offered work `POST /claims` would refuse. Since `core_264` the claimable feed filters on the dependency graph itself; the status filter is no longer load-bearing for this.
- `/builder-claim` returns `DEPS_NOT_SHIPPED` if a manually-promoted task is claimed before its deps land. CLI prints the blockers. Good UX.
- The `[ADR 0014](../adr/0014-families-canonical-over-vocabulary.md)` ADR number was taken by the families work; this one is **0015**.
