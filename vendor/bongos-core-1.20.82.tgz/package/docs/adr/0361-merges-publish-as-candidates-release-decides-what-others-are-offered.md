# ADR 0361 — Merges publish as candidates; Release on /deploy decides what other projects are offered

- **Status:** Accepted. Ships **inert**: candidates start only when the owner sets `PUBLISH_AS_CANDIDATE=1` (see *Arming*).
- **Date:** 2026-10-01
- **Task:** [task 1004298](https://cloudbongos.com/builders#/task/1004298) (goal 1000090 — BONGOS-V2), split out of [task 1002622](https://cloudbongos.com/builders#/task/1002622) §3.
- **Deciders:** the owner. Decisions of 2026-09-25/26: nothing reaches other projects until it is released, **patches included**; the button belongs to the `npm-release` module.
- **Amends:** [ADR 0161](0161-publish-on-merge.md) (publish on merge). Every merge still publishes; it no longer becomes what every project is offered.
- **Builds on:** [ADR 0360](0360-bongos-follows-every-candidate-every-other-project-follows-releases.md) (the per-instance follow), [ADR 0136](0136-update-channel-subscription-policy.md) (channels).

## Context

Under ADR 0161 every merge to core `main` publishes a new `@bongos/core` under npm's `latest` label, and every consumer read "newest on npm" as "what you may move to". So a merge was a release to every project, minutes after it landed, with no point at which the owner said yes.

ADR 0360 gave each instance a **follow**: `released` (at or below `latest`) or `candidates` (every version). Until now the two picked the same target, because `latest` was always the newest version.

## Decision

### D1 — Merges publish under `next`

`publish.yml` publishes with `--tag next` when the repository variable `PUBLISH_AS_CANDIDATE=1`. The version is on npm, installable by exact number, and `latest` does not move. Unset, the lane publishes under `latest` exactly as before. That is what lets this change land without changing anything.

### D2 — Release moves `latest`, in GitHub

Release is a second job in `publish.yml` (`release`, on `workflow_dispatch` with `release_version`). It asks `scripts/gds/release-core.js` whether the version may be released, then runs `npm dist-tag add @bongos/core@<v> latest`.

- **The version must be published, stable, and newer than the current release.** An older version would move every project's offer backwards. That is a rollback for everyone, and it stays a terminal act. Releasing the current release again is a no-op.
- **It lives in `publish.yml`, not a new file.** npm's trusted publisher for `@bongos/core` names `publish.yml`. Since 2026-09-30 the same OIDC identity can move dist-tags once "Allow npm dist-tag" is ticked on that entry. A separate file would need a second trusted-publisher entry or a long-lived token, and this lane was built to be rid of the token (task 1003202).
- **The version reaches the shell through `env`**, never `${{ }}` inside a script, and is refused unless it is `x.y.z`.

### D3 — The button starts the job; the server never holds an npm credential

`POST /api/bongos/npm-release/release` (`core.pin.move`, the deploy page's own atom) dispatches the release job through GitHub's API. The GitHub credential is the server's existing GitHub App; the call reaches it through a one-function port, `lifecycle.workflowDispatch`. The `npm-release` module can start a workflow and do nothing else with that credential. The route applies `releaseDecision` first, the same function the job applies again. So the button cannot promise what the job would refuse, and the job remains the gate.

### D4 — The button shows the evidence

The deploy page's **Release** section lists the versions this hall runs that are not released, newest first. Each shows how long it has run on this hall and whether a move to it was ever rolled back here, from the `core_upgrades` ledger. Release covers a whole version: everything merged up to it.

### D5 — Every consumer offers only what is released

- The update sweep (ADR 0360) already follows `released` by default.
- The "update available" banner (`src/bongos/core-update.js`) offers versions at or below `latest`, read from the same packument. With no readable label it has no answer.
- The platform's upgrade runner for hosted projects (`scripts/gds/provision-core-upgrade.js`) offers a project the versions its follow admits. The follow comes from its hosting shape: the `control-plane` row is the platform hall and takes candidates; every other shape takes releases (`followForShape`). It is derived, not a column, because there is exactly one platform hall. A column someone could set on a tenant would be one more way to hand a project an unreleased version.

## Arming (owner steps, in this order)

1. **Platform hall follows candidates.** On the control plane, set the platform's entry in `config/update-subscriptions.json` to `"follow": "candidates"` (ADR 0360). Otherwise, once D1 is on, cloudbongos.com stops updating itself.
2. **npm:** on npmjs.com → `@bongos/core` → Settings → Trusted publishing, tick **Allow npm dist-tag** on the `publish.yml` entry.
3. **GitHub App:** give the server's GitHub App **Actions: Read and write** on this repository, and accept the permission change on the installation.
4. **Switch on:** set the repository Actions variable `PUBLISH_AS_CANDIDATE=1`.

Until step 4, every version this hall runs is already `latest`, so the Release section reads "Nothing is waiting" and nothing else changes. A press made before steps 2–3 fails with the reason (no dist-tag permission, or the App lacks Actions: write) and moves nothing.

## Consequences

- Other projects stop receiving merges the moment step 4 is done. They receive the next version the owner releases, and everything merged before it.
- The deploy page's "Running here, not released" stage fills between merges and a Release, and empties after one.
- A version can be released only after this hall has run it, because the candidate list stops at the live version. The evidence is real, not inferred.
- **Rejected:** a long-lived npm token in a separate release workflow (the risk task 1003202 removed). Choosing "released" by a git tag or a file in the repo (every instance already reads npm, and a second source of truth would drift). A per-instance follow column (D5).
- **Proof:** `tests/release_core.mjs` (the rule and the workflow wiring), `tests/npm_release_release.mjs` (evidence, the press, the GitHub call, the route gate), `tests/core_update_banner.mjs` (only released versions offered), `tests/core_upgrade_runner.mjs` (the platform hall takes a candidate; a tenant is refused one), `tests/update_channel.mjs` (`followForShape`).
