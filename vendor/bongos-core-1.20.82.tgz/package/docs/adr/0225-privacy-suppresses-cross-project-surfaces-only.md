# 0225 — Privacy suppresses cross-project surfaces only: a private builder still appears on their own project's roster

- **Status:** Accepted
- **Date:** 2026-09-02
- **Tasks:** [#1003443](https://cloudbongos.com/builders#/task/1003443) (goal 1000075 — collaboration and the social hall; criterion `community-is-one-builders-page`)
- **Related:** [ADR 0171](0171-profile-rollup-join-and-consent.md) (owns `hide_stats` + `profile_state`, fail-closed consent in the READ path) · [`docs/specs/<redacted>.md`](../specs/<redacted>.md) (the spec this amends)

## 1. Why this ADR exists

The privacy spec is **accepted**, and for one case it defined its two flags
inconsistently. Found 2026-08-30 while scoping the Builders page:

- `hide_stats` suppresses *"everything derived from the **cross-project rollup**"* —
  qualified, so a project's own in-hall leaderboard is plainly out of scope.
- `account_visibility: private` said *"absent from search, **leaderboards**, sitemap"* —
  **not** qualified, so it read as covering the in-project leaderboard too.

Two readers could act on the same accepted spec and build opposite behaviour. Worse,
PV2 requires *"ONE shared predicate used by every public read: … leaderboards …"*,
while `modules/economy/credits.js`'s `leaderboard()` is a bare
`SELECT … FROM builders ORDER BY total_credits DESC` — no join to
`platform_identity_accounts`, no predicate at all. Read one way that is an unshipped
PV2 violation sitting in main; read the other way it is correct. Nothing in the
documents settled which.

## 2. The decision

**Privacy suppresses CROSS-PROJECT surfaces only.** Owner, 2026-08-30.

A builder marked `private` is absent from `/u/<handle>`, platform search, the sitemap,
Explore-adjacent surfaces and the recruiting reach — every surface that is *about the
platform*. They still appear on the roster and leaderboard of a project they actually
build on, because **a project's record of its own work is the project's business**. The
flag governs how far a builder's identity travels, not whether the work they did for
you is yours to show.

Two things follow, and they are the point of writing this down:

- **`credits.leaderboard()` is correct as written and needs no change.** Adding a
  visibility predicate there would be a regression, not a fix — which is exactly what
  a future session reading PV2 literally would have done.
- **PV2's "every public read … leaderboards" means the cross-project leaderboards.**
  The shared predicate still owns every surface it names; the in-project ledger was
  never one of them.

## 3. What changed

The spec was amended rather than left to be re-litigated — the ambiguity was in its
wording, so the wording is the fix (task 1003443):

- the D1 `account_visibility` row now says *cross-project* leaderboards, and says
  outright that the flag does not reach a project's own roster;
- the two `active · private` matrix rows no longer say **"absent everywhere"** — the
  single most misreadable phrase in the file — but "absent from every cross-project
  surface";
- the `active · public` rows qualify their "leaderboards" the same way, so the matrix
  cannot be read against the table;
- PV2's own ship-table row is qualified too;
- and the boundary is stated as the **third rule** under D2, beside "`hide_stats`
  beats everything", because that block is where a reader looks for the rules the
  matrix encodes.

## 4. Rejected

**Making `private` hide a builder from the projects they build on.** It reads as the
more privacy-protective option and is the reason the ambiguity was worth an owner
decision rather than a coin flip. Rejected because it breaks the ledger: a project
whose roster silently omits contributors cannot show who built it, credits and karma
would be awarded to someone invisible on the surface that explains them, and the
in-hall leaderboard would disagree with the task history any builder can already read.
Privacy about *the platform* does not imply anonymity *inside a project you joined*.

**Leaving it as a dated note in the spec.** The task offered this and it is the wrong
shape: the decision resolves a stated ambiguity in an accepted spec and pins a piece
of shipped code as deliberately predicate-free. That is an ADR's job — a note in a
spec is not what a future session greps when it wonders why one leaderboard query has
no visibility join.

## 5. What this does not decide

Whether an in-project roster may be made public to the world (a per-project
visibility question the platform owns — goal 1000058's `platformVisibility`), and
whether a builder can leave a project's roster entirely. Both are about the
*project's* surface, not the account flag this ADR scopes.
