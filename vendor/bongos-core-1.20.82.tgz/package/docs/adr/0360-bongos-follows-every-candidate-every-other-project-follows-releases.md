# ADR 0360 — Bongos follows every candidate; every other project follows releases

- **Status:** Accepted
- **Date:** 2026-09-26
- **Task:** [task 1004297](https://cloudbongos.com/builders#/task/1004297) (goal 1000090 — BONGOS-V2), split out of [task 1002622](https://cloudbongos.com/builders#/task/1002622) §4.
- **Deciders:** the owner, Lars. His decision, confirmed 2026-09-26: "Bongos takes every candidate automatically."
- **Amends:** [ADR 0136](0136-update-channel-subscription-policy.md) (the update-channel subscription policy). It adds a second axis and a retry hold. The channels, the opt-in roster, autonomy-gating and auto-rollback are unchanged.

## Context

Other projects will soon receive only the versions the owner presses Release on (task 1004298). Bongos must not wait on that button: it is the project every change is built in, and running each version first is what gives Release its evidence.

Today the machinery exists but is slow. The update sweep upgraded cloudbongos.com from 1.19.1030 to 1.19.1033 at 00:22 UTC on 2026-09-26, and nothing else moved it that day. Its timer on the control plane still fires daily, although task 1003674 declared a 15-minute cadence; installing that is [task 1003969](https://cloudbongos.com/builders#/task/1003969), an operator step on the host.

The site served 1.19.1033 all afternoon while 1.19.1034–1.19.1039 were published. The deploy page listed that work as "published, not running here" and did not say that the sweep was the reason.

## Decision

### D1 — A per-instance FOLLOW beside the channel

`config/update-subscriptions.json` entries carry `follow`:

- **`released`**, the default for every project. It takes only versions at or below the registry's `latest` label, which is what the owner has released to other projects.
- **`candidates`**, for the platform's own hall only. It takes every version as soon as it is published.

The channel still bounds how far a jump may go (patch, minor, never a major). The follow bounds which versions exist to jump to. An unknown value reads as `released`, the follow that takes fewer versions, the same way an unknown channel reads as `patch`.

### D2 — Released means the `latest` label, and an unreadable label moves nobody

`readReleaseTags` reads `npm view @bongos/core dist-tags`. It is a separate read, because `listAvailableVersions`' output shape is relied on by the deploy door and by `bongos upgrade`. An instance that follows releases and whose label cannot be read is **skipped** and logged. It is never upgraded on a guess.

Until task 1004298 publishes candidates under a label of their own, `latest` is the newest version and both follows pick the same target. The axis lands first so that the split changes nothing for Bongos.

### D3 — Cadence is the lag

The sweep's timer period is the delay between a merge and Bongos serving it; CI publishes within about two minutes. The declared cadence is 15 minutes, with a floor of about 5 minutes (ADR 0136, task 1003674). Nothing in the core can install a host timer, so the declaration and the recipe are the core's half. Task 1003969 installs it on the control plane.

### D4 — A version that failed here is held for a day

At a daily cadence a version that failed its health check was retried once a day. At 15 minutes the same version would be installed, fail, restart the service and roll back four times an hour until something newer was published. So when an upgrade fails and the version did not go in, the sweep records it for that instance in its own config home (`~/.config/<instance>/core-update-refused.json`, never inside an instance's tree, where it would wedge the lane).

For a day the sweep skips that version and says so. Any newer version is taken at once, because it is the fix. The hold expires, so a transient failure is retried rather than refused forever.

### D5 — The deploy page says whether it is happening

The npm-release section of the platform hall's `/deploy` gains **Upgrades on this hall**, read from the `core_upgrades` ledger, newest first:

- **Who moved it.** An Upgrade pressed on `/deploy`, the automatic update, or "on the server" when the ledger cannot tell a sweep from a shell.
- **Rolled-back moves**, flagged with their reason. A rollback as the last move is a warning.
- **A published version waiting more than 30 minutes**, twice the declared cadence. The page calls it "the automatic update may have stopped", which is what the afternoon of 2026-09-26 was.

## Rejected

- **A second, candidate-only runner.** One sweep over one roster, with the difference expressed as data on the entry, keeps one code path and one set of safety rules.
- **CI pushing the upgrade to the box.** It would move the act across the trust boundary ADR 0293 D1 keeps on the control plane.
- **Holding a failed version until a human clears it.** That trades an outage generator for a silently frozen lane. The day-long hold plus "a newer version is taken at once" covers the real case, where the fix is the next merge.

## Consequences

- **Owner or operator step before task 1004298 ships:** set the platform's roster entry to `"follow": "candidates"`. Otherwise, the day candidates stop carrying `latest`, the platform stops taking them.
- **Operator step (task 1003969):** install the timer at `OnCalendar=*:0/15`. Until then the lane still runs once a day, and the deploy page will say so.
- **The platform restarts on each new version**, roughly one every merge, with the existing health check and auto-rollback as the net.
- **Proof:**
  - `tests/update_channel.mjs`: follow normalisation, `versionsForFollow`, `readReleaseTags`, the roster field, and composition with the channel.
  - `tests/update_subscription_engine.mjs`: `followTarget` over the real channel math, the fail-closed skip, the old-core fallback, and the hold (skip, expiry, a newer version still taken, the record kept outside the instance tree).
  - `tests/npm_release_work.mjs` and `tests/npm_release_page.mjs`: the ledger reading, the rollback, the waiting alarm, and their rendering.
