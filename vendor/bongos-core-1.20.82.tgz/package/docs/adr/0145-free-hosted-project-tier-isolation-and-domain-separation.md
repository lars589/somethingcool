# 0145 — A free "own-repo" hosted project tier needs domain separation + per-project isolation (not a bare cloudbongos.com subdomain)

- **Status update 2026-09-29 — Finding 1 is FIXED by host-only hub cookies ([task 1004357](https://cloudbongos.com/builders#/task/1004357); build sequence step 1, the cookie half).** Option A was chosen over a separate registrable domain for halls: it needs no new domain, no DNS or TLS work and no change to any project's address, and it closes the hole for every hall already live. What changed, all in `src/bongos/routes/auth.js`:
  - **Nothing the hub sets carries a `Domain` attribute any more.** The session is `__Host-bongos_session` over https (a browser only accepts a `__Host-` cookie that is Secure, `Path=/` and host-only), plain `bongos_session` on local http. The OAuth and Discord handshake cookies are host-only too.
  - **`builders.` / `status.` / `www.` get the session through a one-time handoff.** A sign-in begun on one of them restarts on the canonical host (the only host the GitHub callback reaches). The canonical host then redirects back with a single-use, 60-second code bound to that one host, and `GET /auth/web/handoff` trades it for that host's own host-only copy of the same token. A builder already signed in on the apex who opens `builders.` skips GitHub entirely. A code is only ever minted for one of the hub's four hosts, never a hall.
  - **Existing browsers are moved over.** Every hub API request that carries a pre-fix session cookie and no `__Host-` one re-issues the same token host-only and expires the apex-scoped copy.
  - **Proof:** `tests/hub_cookie_host_only.mjs` runs the real router through an RFC 6265 cookie jar and asserts a hall at `<handle>.<apex>` receives no hub cookie after the full flow.
  - **Still open from step 1:** CSRF tokens on state-changing hub endpoints. `SameSite=Lax` does not separate a hall from the hub, because they are the same site. The legacy session names are still ACCEPTED on read (so nobody was signed out at deploy), which leaves a hall able to plant a cookie under an old name. Retiring those names (task 1003706's Part 4) closes that. A token copied by a hall BEFORE this shipped stays valid until it expires or its builder signs out.

- **Status update 2026-09-28 — Finding 1 is OPEN again, and permanently ([ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md) decision 6).** Project halls now stay hosted on our box, so ADR 0323's "closed by removing its precondition" below no longer holds. Measured: the hub still sets `Domain=.cloudbongos.com`, and a hall loads modules from its own repository, so a hall at one of our addresses can read a visiting hub builder's session. The sign-in hardening is a **blocking prerequisite again** for any new hall at one of our addresses, filed as [task 1004357](https://cloudbongos.com/builders#/task/1004357). A hall on the owner's own domain is not exposed.
- **Status:** **Superseded in part by [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md)** (2026-09-21). Three of this ADR's decisions are replaced: the free tier becomes a **capped trial**, not all-free; customer projects leave the shared box for a managed platform, so **container isolation on our own box is no longer the plan**; and **Finding 1 is closed by removing its precondition** — with no customer code on a `cloudbongos.com` subdomain there is no tenant to receive the hub session cookie, so the sign-in hardening in the build sequence below is no longer a blocking prerequisite (it remains worth doing on its own merits). The two security FINDINGS below stand as analysis and are the reason the new direction is safe.
- **Status:** Accepted — owner decided 2026-07-15: **keep `cloudbongos.com`** (no separate domain), **container** isolation, **all-free** for now. Choosing the literal same domain makes hardening core sign-in a required prerequisite (see "Decisions" + "Required build sequence"). Build unblocked ([task 1002251](https://cloudbongos.com/builders#/task/1002251)); blocker 1000080 resolved.
- **Date:** 2026-07-15
- **Deciders:** Lars (owner/Archon) chose the direction after a security review; Claude ran the review + designed.
- **Task:** [task 1002249](https://cloudbongos.com/builders#/task/1002249) · **Follow-up to** [ADR 0141](<redacted>.md) (federated hub IdP) and [ADR 0143](0143-onboarding-repo-picker-oauth-scope.md) (the `/create` wizard).

## Context

Owner design review of the `/create` wizard (`public-landing/create.html`, absorbed into `projects.html` `?view=new` by task 1002763) asked that a new project be reachable at a **free `<handle>.<platform>` address that works out of the box** (sign-in included), with **bring-your-own-domain** as the optional upgrade — i.e. the handle becomes a real subdomain, not just an internal name.

Today `/create` always provisions the **`standalone`** shape (the owner's own GitHub repo + a pinned `@bongos/core`, run **control-plane-local** on the hub box), and sign-in on a standalone requires the owner to hand-create their own GitHub OAuth app. The natural-looking implementation was: default the address to `<handle>.cloudbongos.com` and extend the hub federation ([ADR 0141](<redacted>.md)) — which already gives co-tenant instances zero-setup sign-in — to standalone instances on that subdomain. A pre-build security review found this **UNSAFE** on two independent counts.

### Finding 1 — the hub session cookie is shared across all `*.cloudbongos.com` (account takeover)

The hub's `gds_session` cookie is issued with `Domain=.cloudbongos.com` on the apex/`builders.`/`status.` hosts, by design, so one sign-in is shared across those subdomains ([src/bongos/auth.js](../../src/bongos/auth.js): `SESSION_COOKIE`, `configuredCookieApex`, `sessionCookieDomainOpts`, the `res.cookie(SESSION_COOKIE, …)` call). A cookie with `Domain=.cloudbongos.com` is sent by the browser to **every** `*.cloudbongos.com` host — including an owner's `mercury.cloudbongos.com`. `httpOnly` does not help (it blocks `document.cookie`, not a server reading its own `req.headers.cookie`); `sameSite:lax` does not help (apex and subdomain are the **same registrable domain** = same site). So a standalone instance running **the owner's code** on a cloudbongos.com subdomain would receive the live hub session token of any signed-in visitor and could replay it against the hub → full account takeover. The neutral core ships `cookieDomain: ""` (host-only, safe); the **live hub must** set `.cloudbongos.com` for its own cross-subdomain sign-in, so the risk is real in production.

The co-tenant instances that federate on cloudbongos.com subdomains today (e.g. `demo.cloudbongos.com`) are safe **only because they run platform-controlled code** ([modules/provisioning/provisioning.js](../../modules/provisioning/provisioning.js): `co-tenant` = a process on THIS control-plane checkout; `standalone` = the owner's OWN repo checkout). The precedent does **not** extend to owner code — it relies on exactly the first-party-code-on-every-subdomain property that owner code breaks. This is why [ADR 0141](<redacted>.md) §4 scoped federation to co-tenant.

### Finding 2 — control-plane-local standalone runs owner code on the hub box, sudo-capable (pre-existing)

A `standalone` runs **on the hub box** ([scripts/gds/provision.js](../../scripts/gds/provision.js): `standaloneBase`, control-plane-local IP) as the **same UID as the hub** (`serviceUnit` hardcodes `User=lars`), and its deploy runs `npm ci` (not `--ignore-scripts`) in a **passwordless-sudo-capable** runner context. A malicious owner could ship a `postinstall` and get code execution as `lars` with sudo on the hub box → the hub's signing key, every instance's secrets, the hub DB. This is a pre-existing property of running owner code on the hub box at all, independent of federation, but any free "run your code for you" tier would expose it at scale.

> **Amended 2026-09-12 ([ADR 0281](0281-an-instance-identity-is-its-own-unix-account-and-pg-role.md), task [1003369](https://cloudbongos.com/builders#/task/1003369)):** `serviceUnit` no longer hardcodes `User=lars` — each provisioned instance now runs as its own unix account with its own password-authed PG role, so the *running* instance is no longer the same UID as the hub. **Finding 2 stands regardless:** the exposure it names is the DEPLOY, not the steady state — `npm ci` still runs owner `postinstall` code in the passwordless-sudo-capable runner context, before the per-instance account is ever involved. The decision below is unchanged.

The federation protocol itself is sound: the hub binds the minted audience to the instance's exact origin (the `#1002108` fix; asymmetric Ed25519 so one instance can't forge for another). A leaked per-instance client secret is contained to its own origin. The weakness is **placement** (shared cookie domain) and **execution** (owner code on the hub box), not the protocol.

## Decision

**Do not** put an owner-code instance on a bare `cloudbongos.com` subdomain, and **do not** extend federation to `standalone` as it exists today. A free "your-own-repo, works-out-of-the-box" tier is delivered **only** once both conditions the review identified are met:

1. **Domain separation.** Free owner instances live under a **different registrable domain** than the hub (e.g. a dedicated `*.<apps-domain>`), so they are cross-site from cloudbongos.com and **never receive the `gds_session` cookie**. (Alternative: make the hub session cookie host-only on a dedicated auth host — but that breaks today's `builders.`/`status.` shared sign-in and is a larger redesign.)
2. **Per-project isolation.** Owner code must not run as a sudo-capable, same-UID-as-hub process on the hub box: isolate each instance (its own droplet — the existing `dedicated` shape — or a container with a distinct UID, `npm ci --ignore-scripts`, verified-pinned-core-only, and no passwordless sudo in the deploy path).

Only after (1)+(2) is the origin-bound, asymmetric federation ([ADR 0141](<redacted>.md) §4) safe to extend to these instances, giving the zero-setup sign-in.

Points 1 & 2 of the same design review (drop the redundant Home-step "create repo" button; collapse the repo picker on select) were **unrelated to this and already shipped** ([task 1002247](https://cloudbongos.com/builders#/task/1002247)).

## Decisions (owner — resolved 2026-07-15)

- **Domain: keep `cloudbongos.com`** (no separate domain). The owner accepts the "same-site" tradeoff: because tenants (`<handle>.cloudbongos.com`) share the registrable domain with the hub, the browser's same-site protections between them are off, so **Finding 1 is closed by hardening core sign-in** (below) rather than by domain separation. This is the fragile/expert path — it needs strict, permanent cookie/CSRF/CORS hygiene, and one lapse reopens the takeover hole. (Rejected: the separate cloudbongos-branded sibling domain, e.g. `cloudbongos.app`, which the browser would treat as a different site and isolate for free — the industry-standard approach, à la `github.io`.)
- **Isolation: containers.** Each tenant runs in its own container (distinct UID, `npm ci --ignore-scripts`, no passwordless sudo, not as `lars` on the hub box) — closes Finding 2.
- **Cost: all-free for now.** Containers make many-instances-per-box cheap; a spend cap is revisited at scale ([§4](../../CLAUDE.md)).

## Required build sequence (task 1002251)

Keeping `cloudbongos.com` makes the sign-in hardening a **hard, security-critical prerequisite** — it changes sign-in for *every* user of the hub, so it lands and is verified on its own before any tenant is placed on a subdomain:

1. **Harden core sign-in (FIRST).** Make `gds_session` a host-only `__Host-` cookie so tenant subdomains never receive it (Finding 1) and cannot toss a parent-domain cookie at the hub; **rework the `builders.`/`status.` shared sign-in** that currently depends on the `.cloudbongos.com`-scoped cookie ([src/bongos/auth.js](../../src/bongos/auth.js) `APEX_COOKIE_HOSTS`); add **CSRF tokens** across all state-changing hub endpoints (SameSite no longer defends against same-site tenants). Audit every hub cookie + CORS rule for `.cloudbongos.com` scope.
2. **Container isolation.** Provision tenant instances in per-instance containers (distinct UID, `--ignore-scripts`, no sudo in the deploy path) — closes Finding 2.
3. **Extend federation.** With 1+2 done, extend the origin-bound Ed25519 federation ([ADR 0141](<redacted>.md) §4) to these isolated same-domain instances for zero-setup sign-in.
4. **Frontend.** Rebuild the `/create` Address step (the stashed redesign is the starting point) + the summary + the federated done-panel.

## Consequences

- The `/create` "free `<handle>.cloudbongos.com`, out of the box" flow is **not built**; the frontend redesign that assumed it is stashed, not shipped. Until this tier exists, `/create` stays own-repo + bring-your-own-domain (safe today).
- Finding 2 (owner code as sudo-capable `lars` on the hub box) is a **standing risk for the current control-plane-local `standalone` shape** and should be hardened regardless of this tier.
- If the cost model lands as "platform-subsidized free," a hard spend cap + a cheaper fallback (container isolation, or the co-tenant tier below) is required per [§4](../../CLAUDE.md).

## Alternatives considered

- **(A) Free co-tenant tier (rejected by owner for this ask).** A free `<handle>.cloudbongos.com` running **platform** code on the shared box (like `demo.cloudbongos.com`) is safe + $0 + already federates — but gives the user no separate repo of their own. Closest safe match to "free + out of the box," at the cost of "your own repo."
- **(C) Keep today's model, honest copy (deferred).** Own repo + bring-your-own-domain, with the `/create` copy clarified (handle = platform name; domain = the real address, needed for sign-in). Safe and shippable now; delivers no free address.
- **(B) — chosen:** free address + own repo, made safe via domain separation + isolation, accepting the cost. This ADR records why B is required to be safe and what it depends on.
