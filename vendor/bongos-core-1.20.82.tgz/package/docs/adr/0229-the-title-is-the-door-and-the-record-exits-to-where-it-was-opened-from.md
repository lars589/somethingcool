# ADR 0229 — The title is the door into a task record, and the record exits to where it was opened from

**Status:** accepted · **Date:** 2026-09-02 · **Task:** [task 1003468](https://cloudbongos.com/builders#/task/1003468) · **Goal:** 1000081 (the builders' hall in the chrome world) · **Supersedes in part:** the "only way in" half of task 1869's card decision (task 1759's primary interaction stands)

## Context

The owner, working the live hall on 2026-09-01, reported two halves of one journey. Into a record: *"you cant click into tasks that are todo they just get selected, you can only click into completed tasks it seems like."* Out of it: *"when you click into a completed task from a goal the only option from the ui is to go back to the tasks page even if you came from the goal. It should route you to the page where you clicked into a task card."*

Both were shipped behaviour, not re-skin regressions. Tasks 1759 and 1869 made multi-select the primary interaction on a claimable card so a builder can bulk-claim, and added `.task__open`, a 26×26 button holding a 12px glyph in `--ink-faint`, as **the only way** from a claimable card into the record. A read-only card (active, backlog) opened on a body click; the Completed ledger's rows always opened. So the owner's read was exact: the completed ones open, the to-do ones select. The owner of the instance not finding the glyph is the strongest evidence an affordance can fail on.

On the way out, `task.js` hardcoded `Open the work board` in three renders (the record, not-found, and the failed read) and `task.html`'s crumb a fourth (`Back to tasks` → `/work`). No referrer, no origin parameter, no history: a builder who walked goal → task had only the browser's own Back, and the two failure renders sent them somewhere they had never been.

## Decision

**The title is the door.** `.task__title` carries a real link, `.task__link`, on both surfaces that render the card — the work board (`work.js`) and the goal detail To-do pane (`goals-render.js`). This is the convention the rest of the hall already uses (`.gr-title` on the goals list, the ledger rows), so it needs no teaching. The card body still toggles selection, the checkbox still does what it does, bulk claim is untouched: both click handlers `return` on the link and let the browser navigate (a middle-click opens a tab, which a button never gave). Once a control, the title owes the 24px floor on both axes; it is bought with the recipe `style.css` already uses for `.scroll__lede a` and `.gr-title` — inline-block, padding, and an equal negative margin that hands the room back so the card's line does not re-space. Ink at rest, accent underline on hover: sixty accent titles would take the board over.

**The ⤢ glyph goes.** The task allowed it to stay or go; with the title carrying the job it is a second door to the same room, one the owner never found, and a second control per card on a board whose point is scanning. Removed from both renderers, both handlers, and the sheet.

**The record learns where it came from.** The link a list writes carries the origin as a query parameter — `task-detail.js`'s new `OTBTaskDetail.href(id)` appends `?from=<pathname + search + hash>`, and `open(id)` (the backlog rows, the goal ledger rows, the read-only cards) navigates to the same URL. A query parameter, not in-memory state, because the origin must survive a reload and a copied link; and the hash rides inside it, because a goal lives at `#/goal/N` and `document.referrer` never carries a fragment. `task.js` resolves the exit in one place, in this order: `?from=` → a same-origin referrer → the work board. The crumb is pointed before the fetch, so the way back exists in every state; the actions row of all three renders uses the same target; the label is said the way the sidebar says it (*back to goal 1000081*, *back to the work board*, *back to sessions*).

**A value is honoured only as a path on this host.** One leading slash and not two (`//host` is another origin), no backslash (browsers read `/\host` as `//host`), no whitespace, never `/api/` or `/lib/` (the sign-in round trip's referrer is the auth callback), never this same record (a loop is not a way back), and at most 2048 characters. Anything else falls through to the next source. This is an `href`, not a redirect, so the blast radius of a bad value was a wrong link; the allowlist keeps it from ever being an off-host one.

## Consequences

- From the goal detail To-do pane, clicking a claimable task's title opens its record; the card body still toggles selection and bulk claim still works. The same on the work board.
- A record opened from a goal offers a way back to that goal; one opened from the board offers the board on the tab it was opened from; one opened from any other hall page offers that page via the referrer; one opened cold offers the work board.
- The four hardcoded work-board exits are gone; `/work` remains only as the fallback in `task.html`'s static crumb and in `task.js`'s last resort.
- `docs/copy-inventory.md` / `docs/copy-registry.json` regenerated: `Open the work board` (3×) left the inventory; `Back to tasks` stays as the static fallback label.
- Pinned by seven new tests in `tests/hall_record_world.mjs` §10 (the record run in a vm with a query and a referrer, including the hostile values above) and four in `tests/hall_board_world.mjs` §7 (the link on both renderers, both handlers letting it through, the floor recipe, and `task-detail.js` run in a vm to prove the link carries path + query + hash on both hosts). `task.states.json` gained a `from-goal` state so the longer crumb label is measured.

## Rejected

- **Making the card body open the record.** Deletes bulk claim, which is the reason the card behaves as it does; 1759/1869 remain right about the primary interaction.
- **Keeping the glyph beside the title link.** Two doors to one room, and a control per card that the person who owns the instance did not find.
- **In-memory origin (`sessionStorage`, a global).** Lost on reload and on a copied link, which is exactly when a builder needs the way back.
- **`document.referrer` as the primary source.** It drops the fragment, so a goal (`/goals#/goal/N`) would read as *goals*; it is the fallback for links written without `?from=`.
- **`history.back()`.** Not a link (no middle-click, no hover target), wrong after a reload, and it cannot be labelled with where it goes.
- **A `<base>`-style rewrite or server-side referrer handling.** The hall is static markup plus page scripts; the origin is known to the page that writes the link, and nowhere else.
