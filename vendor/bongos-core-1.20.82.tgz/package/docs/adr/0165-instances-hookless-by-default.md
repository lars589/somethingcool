# 0165 — Instances are hookless by default: no scaffolded `.husky/`; local hooks stay an instance-owned opt-in

- **Status:** Accepted
- **Date:** 2026-08-11
- **Deciders:** Claude (jaxri session), under the bug-wave mandate — flagged owner-adjacent; the ADR is the revisit point

**Track:** `internal` (provisioning / trust boundary). Task [1002641](https://cloudbongos.com/builders#/task/1002641), from idea 1000655. Relates to [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (Layer 1), [ADR 0055](0055-server-mediated-branch-publish.md) (server-mediated publish), [ADR 0162](0162-review-gates-retired-rank-consistent-ci-only.md) (CI-only gates).

---

## Context

Task 1002608 delivered `.husky/pre-push` — the ADR 0043 **Layer 1** local permission gate — for **this core repo**, and `scripts/gds/install-git-hooks.js` (run by `/builder-setup`) activates whatever hooks a clone's `.husky/` tracks by setting `core.hooksPath`.

But nothing delivers Layer 1 to a **scaffolded standalone instance**: `init.js` / `provision.js` / `onboard.js` materialize no `.husky/`, and `publish-manifest.js` excludes `.husky/` from the published core artifact **by design** (`PROTECTED_TOPOLOGY_EXCLUDE` — a core update must never silently rewrite an instance's local gate topology). So instances run with no pre-push permission gate and no pre-commit secrets hook. Task 1002641 asks: is that a gap to fill, or the accepted posture?

## Decision

**Hookless-by-default is the accepted posture for instances. Provisioning scaffolds no `.husky/`. Local hooks are an instance-owned opt-in: an instance that wants them commits its own `.husky/`, and the core's existing `install-git-hooks.js` activates them on every builder's machine.**

Four structural reasons:

1. **The population Layer 1 constrains holds no push credential on an instance.** Sub-Metic builders work dev boxes where the git origin is credential-less and landing goes through **server-mediated publish** (ADR 0053/0055): the box uploads a bundle, the *server* pushes and opens the PR. A client-side pre-push hook on the box guards a push that cannot happen. Metic+ builders with real push access are inside the trust boundary, and their pushes meet the server-side gates that actually enforce: branch protection, the required `unit` check (fitness, gate-review tests, the authorship gate — task 1002640), and the every-push `main-audit`.
2. **A client hook is not a security boundary** (ADR 0016: the DB and server enforce; local edits grant nothing). On the core repo, `.husky/pre-push` is defense-in-depth for contributors with direct push access — a materially different population than instance builders. Scaffolding it onto instances would *look* like a control while a hostile clone deletes it in one command.
3. **The core cannot maintain what it deliberately does not ship.** `.husky/` is `PROTECTED_TOPOLOGY_EXCLUDE`d from the artifact, so scaffolded hooks would be born orphans — no upgrade path, rotting silently until they misfire. A written control that no longer runs teaches builders to ignore controls (the audit-authorship lesson, task 1002640).
4. **ADR 0162 (owner directive): gates live in CI, rank-consistent and hands-free.** Instance-side client gates re-introduce the blocked-builder friction class that ADR retired — a broken hook strands a legitimate land until a human intervenes.

**Secrets hooks follow the same rule.** A pre-commit secrets guard needs per-machine tooling and gives false local confidence; the PR-time CI secret scan is the enforcing control on every land.

**The opt-in stays real, and stays instance-owned.** `install-git-hooks.js` ships in the core and already runs at `/builder-setup` on every instance; it activates whatever `.husky/` the *instance's own repo* tracks. Policy (which hooks, if any) is the instance's; the activation mechanism is the core's. That split mirrors the branding contract (ADR 0062 §7).

## Rejected

- **Scaffold `.husky/` wrappers at `init`/provision** — orphaned gate topology the core can't update (reason 3), guarding a push path instance builders don't have (reason 1).
- **An `init --with-hooks` flag** — speculative surface; no instance has asked. If one does, it composes trivially on the opt-in path above.
- **Treating hooklessness as a security regression to hotfix** — the enforcing controls on instances are server-side and already in place; Layer 1 was always the advisory outermost layer, not the wall.

## When to revisit

An instance model where builders routinely push directly with their own credentials (no server-mediated publish, no branch protection) would remove reasons 1–2; revisit then.
