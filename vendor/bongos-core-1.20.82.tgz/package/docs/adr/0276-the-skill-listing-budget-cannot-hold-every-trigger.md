# 0276 — The skill-listing budget cannot hold 64 skills and every trigger, so the number is ratcheted and the choice goes to the owner

**Status:** Accepted (the ratchet). The budget question itself is **open and owner-gated** — [blocker #1000139](https://cloudbongos.com/builders#/blocker/1000139), see §5.
**Task:** [#1003620](https://cloudbongos.com/builders#/task/1003620) · goal 1000095 — *Working area 6*, criterion `wa6-role-experience`
**Builds on:** [ADR 0274](0274-one-kernel-three-role-packs.md) (which measured the listing at 27,022 chars against a ~8,000 budget and sequenced this task behind it), tasks 1003548 and 1003587 (the two earlier trims)

## 1. The problem, and why trimming keeps not solving it

Every SKILL.md `description` is resident in **every session**, for every craft,
whether or not the skill is invoked. `skill-lint.js` budgets the whole listing —
each skill's name plus its description — at **8,000 chars** ("~2k tokens ≈ 1% of
a 200k window") and warns when it is over.

It has been over for a long time, and it has been trimmed twice:

| pass | skills | listing |
|---|---|---|
| task 1003548 — "shorten the 9 longest" | ~60 | — |
| task 1003587 — the 14 module ui-design descriptions | 65 | 26,385 |
| **task 1003620 — this one, 49 descriptions** | 64 | **25,624 → 19,316** |

Each pass shrank it and each time it grew back, because the per-description aim
(400 chars) was a **warning that accumulates**: nothing fails, so the number
drifts up until someone files another cleanup task.

## 2. What this task did

Rewrote 49 of the 50 `.claude/skills/` descriptions — cutting implementation
paths, ADR and task numbers, script names and second explanatory clauses.
`skill-lint` goes from 17 warnings to **0 errors, 0 warnings**, and the listing
from 25,624 to 19,316 chars (~6,400 → ~4,830 tokens): about **1,570 tokens
returned to every session**.

The 14 `modules/ui-design/` descriptions were deliberately not touched — task
1003587 rewrote them a week earlier and they sit at ~384 chars each.

**Every trigger phrase was preserved, and that was checked mechanically**, not
by eye. A checker extracted the quoted phrases from each description at HEAD and
asserted each still appears in the rewrite. It caught five genuine losses in the
first pass (builder-reauth's full error string, `read the latest session
export`, two session-handoff phrases, two status phrases) which were restored.
Four quoted strings were dropped on purpose because they were never triggers:
UI button labels (`Close box`, `Re-issue CLI token`, `CLI Access`, `key needed`)
and one gloss (`the thoughts`).

## 3. Why 8,000 was not reached, stated as arithmetic

This is the part that matters, because the task's DONE WHEN asked for it and
this record is where the shortfall is declared rather than buried.

With 64 skills:

```
names                                    880 chars
quoted trigger phrases (mandatory)     ~5,370 chars
                                       ------------
irreducible floor                      ~6,250 chars
budget                                  8,000 chars
                                       ------------
left for saying what each skill DOES   ~1,750 chars  ->  ~27 chars per skill
```

Twenty-seven characters. Reaching the budget therefore means **trigger-only
descriptions**: no statement of what the skill is for. That trades one routing
failure for another — truncation is avoided, and the semantic signal the router
leans on when the user's words do not literally match a trigger is deleted.
The scope note on the task forbids exactly this: *"a description is routing
text, and cutting a trigger silently stops a skill from being found."* The same
logic applies to the sentence that says what the thing does.

So the shortfall is not a trim left half-finished. **The budget and the roster
are in conflict**, and no amount of editing resolves it.

## 4. Decision: ratchet the number

`skill_listing_chars` becomes a ratcheted metric in
`scripts/gds/fitness-ratchets.js`, baselined at **19,316**. CI fails if the
listing grows; lowering it when a description genuinely tightens is the ordinary
path. The collector fails **open** if the linter cannot load — this must never
be the reason a build cannot run.

This answers the question the task raised (*"consider whether the 400-char aim
should become a hard error at some ratcheted ceiling rather than a warning that
accumulates"*) in the way the repo already answers it for size, duplication,
cycles, console calls and doc entropy.

**The baseline is deliberately above skill-lint's own 8,000 budget and is not a
claim the budget is met.** It records today's real number so it cannot get worse
while the question in §5 is open.

## 5. Open, and the owner's to decide

Three ways to actually reach 8,000, none of which a cleanup task should pick
unilaterally:

1. **Delist skills.** 64 is a lot to hold resident. Many are ops routines
   (`builder-backup`, `close-box`, `otb-figma-sync`) a session almost never
   needs. If the listing carried 30, the budget fits with room for real prose.
2. **Scale the budget with the roster** — a per-skill ceiling (say 250 chars)
   rather than a global 8,000, which was set when the roster was smaller and
   silently became stricter with every skill added.
3. **Accept trigger-only descriptions** and take the routing hit.

Recommendation: **(1) then (2)**. The listing is a menu, and a 64-item menu is a
context cost whatever the wording. Filed for the owner as **blocker [#1000139](https://cloudbongos.com/builders#/blocker/1000139)**
rather than left in this file, because a decision nobody is asked to make is not
a decision.

## 6. Consequences

- `fitness.js`'s `skill frontmatter parses` check **still warns** that the
  listing is over budget. That warning is now correct and load-bearing: it is
  the visible trace of the open question, and it should stay until §5 is
  answered.
- A new skill is no longer free. Adding one costs its name plus its description
  against a ratchet that fails the build — which is the intended pressure.
- Rejected: raising skill-lint's `LISTING_BUDGET_CHARS` to 19,316 so the warning
  goes away. That deletes the signal instead of the debt, and the file's own
  policy forbids moving a number to make a gate pass.
- Rejected: cutting the module ui-design descriptions again a week after task
  1003587 wrote them, to buy ~2,000 chars toward a target still 9,000 away.
