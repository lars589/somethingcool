# ADR 0357 — The update rule set on /deploy is the one the sweep follows

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1004468](https://cloudbongos.com/builders#/task/1004468) (goal 1000090, BONGOS-V2)
- **Amends:** [ADR 0136](0136-update-channel-subscription-policy.md), "Alternatives considered" (a `provisioning_instances` column for the channel) and its Consequences line naming `config/update-subscriptions.json` as the one place a channel is set
- **Builds on:** [task 1004445](https://cloudbongos.com/builders#/task/1004445) (migration provisioning_029, `POST /provisioning/instances/:id/update-channel`), [ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md) (the deploy door)
- **Decided with:** the owner, 2026-09-30. Asked "which one decides how far a project auto-updates, the site setting or the server file?", they chose the site setting.

## Context

ADR 0136 put each subscribed instance's update channel (`pinned` / `patch` / `minor`) in the roster file `config/update-subscriptions.json`, and it rejected a `provisioning_instances` column because the fleet registry was not yet designed. By the time of [ADR 0325](0325-the-managed-fleet-control-plane-is-the-hub-we-already-run.md), `provisioning_instances` *was* the registry. Task 1004445 then added `update_channel` to it, so the owner could set the rule on /deploy, and the deploy door's runner obeys it.

That left two rules for one project. On 2026-09-30 cloudbongos.com was set to `minor` on /deploy and still `patch` in the box roster. The button followed the first and the unattended sweep the second, so a step-up release (1.20 → 1.21) would never land unattended even though /deploy said it would. Task 1004451's proof was graded down for exactly this.

## Decision

**D1. The project row is the rule.** For a roster entry whose `slug` matches a `provisioning_instances` row, the sweep uses that row's `update_channel`. The match is by slug, the only stable key the table carries (it records no directory).

**D2. The roster's `channel` is a fallback, not a second vote.** It applies only when no row matches (an instance the control plane never provisioned) or when the sweep cannot read the database. The roster keeps everything else it holds — `dir`, service, health URL, topology, `env`, pin mode — because the registry doesn't record those.

**D3. Every fallback says so.** The sweep prints each entry's channel and where it came from ("set on /deploy", or "from the roster — <reason>"). When the row overrides a different roster value, the log names the ignored value too. A silent fallback is how two rules drifted apart in the first place.

**D4. It reads the control plane's database, over psql, from the sweep's own environment** — `DATABASE_URL`, else `PGDATABASE` (socket + peer auth). These are the two variables `upgrade.js` `recordLedger` reads. Unlike recordLedger, it hands a `DATABASE_URL` to `psql -d` rather than the pg driver, because the sweep is synchronous. An entry's `env` is never used, because it names *that instance's* database. A core too old to carry the reader keeps the roster behaviour unchanged. A failure is logged as a fixed class (unreachable, login refused, table missing…), never psql's own text, which can name a user or host.

**D4a. `UPDATE_CHANNEL_DB` comes first** (task 1004307, 2026-10-01). The sweep spawns every upgrade with its own env underneath the entry's, so a unit-level `PGDATABASE` would reach any tenant entry that names no database and point its migrate at the control plane's. A control-plane unit therefore sets `UPDATE_CHANNEL_DB`, which only this reader consults; `DATABASE_URL` / `PGDATABASE` remain the fallback.

**D1a. Why not slug *or* directory.** The task brief suggested matching by slug or dir. `provisioning_instances` stores no directory, so there is nothing to match a dir against, and a roster slug that differs from its row's slug falls back to the roster, visibly (D3).

**D5. Nothing is migrated or copied.** Every row already has a channel (the column defaults to `patch`, the old behaviour). So once this is live, an entry the roster listed as `minor` but whose row was never changed on /deploy is swept as `patch`. That is the ruling applied, not a regression, and D3 makes it visible in the log.

## Consequences

- One place to change how far a project auto-updates, on the site, with no SSH.
- ADR 0136's policy is otherwise unchanged: majors and prereleases are never automatic, every move is health-gated with auto-rollback, and the routine stays opt-in and autonomy-gated. Enrollment itself (which instances the sweep touches, and where they live) is still the roster.
- **Delivery depends on the sweep running current code.** On cloudbongos.com the sweep runs from a checkout frozen at 2026-08-25 ([task 1004307](https://cloudbongos.com/builders#/task/1004307)). Until that is fixed, or the checkout is updated, a release carrying this change does not reach the sweep.
- The rule is now testable in isolation: `tests/update_channel_db.mjs`.

## Alternatives considered

- **Keep the roster in charge (ADR 0136 as written).** Rejected by the owner: changing the unattended behaviour would stay an SSH edit, and /deploy would keep showing a setting the sweep ignores.
- **Take the stricter of the two.** Rejected: safe, but setting `minor` on the site would do nothing until someone also edited the file, which is the same confusion in a new form.
- **Copy the roster's channels into the rows first.** Rejected: the rows already hold the owner's deliberate choices (cloudbongos = `minor`), and a copy would overwrite a newer decision with an older file.
