# 0241 — The artist gate holds the DEPLOY, not the ship, and it reads a state rather than a judgement

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1003116](https://cloudbongos.com/builders#/task/1003116) (R05 of goal 1000074, the artist's loop) — the decision task the goal placed BEFORE [#1003115](https://cloudbongos.com/builders#/task/1003115) (R04, the review task), so that no code is wired to a gate whose authority is unsettled
- **Reconciles:** [ADR 0162](0162-review-gates-retired-rank-consistent-ci-only.md) — review gates retired on `main`, so no human approval sits in the land path
- **Rule relied on:** [ADR 0158](0158-choke-point-verdict-taxonomy.md) §2 — a verdict is advisory and never self-executing
- **Related:** 0178 (the copy desk flag + queue, which deliberately blocked nothing and named this decision as the one that would settle it), 0233 (a copy proposal is a task carrying a patch), 0016 (authority is resolved server-side, never from a local file), 0120 (pay on land), 0137 (land → release → deploy are three separate gates)

## Context

Goal 1000074 gives the artist real authority over what ships — the owner's ABI brief hands them
the project's text, its story and ideology, its purpose and gravitas. The goal also carries the
owner's constraint, verbatim: **blocking strictness is per project, not global.** A project whose
outputs must be closely monitored should be strict; a project where visuals and copy come
afterwards can run loose.

And it carries the collision that constraint creates. ADR 0162 retired review gates: after a
code-owner review requirement stranded two graded-PASS ships inside a day, review requirements on
`main` were removed permanently, and the principle recorded was that **no human click sits in the
land path**. An artist who can block a ship is a new human click in the land path. Two rules, one
of them about to contradict the other, which is exactly the condition R05 exists to end.

## What ADR 0162 actually forbids

This matters, because the shorthand it is usually cited by — "a verdict is advisory, never
self-executing" — is a paraphrase, and reading the paraphrase instead of the ADR would rule out
things 0162 explicitly keeps.

*Citation note (task 1003573):* the shorthand is not 0162's wording at all. It is, nearly
verbatim, the heading of [ADR 0158](0158-choke-point-verdict-taxonomy.md) §2 — a rule about what
an audit finding authorizes (nothing, until a human acts on it) — and 0162's text uses neither
"advisory" nor "self-executing". Cite 0158 §2 for that rule, and 0162 for what it retired.

0162's own table of what still guards the safety machinery lists four controls and marks three of
them **fails closed** — including the subagent grader panel, which runs on every GDS ship and parks
a failing task at `completed`. So 0162 plainly permits an automatic gate that stops work. What it
retired was something narrower and structural: a gate GitHub could only express as **accounts**.
Its reasoning is worth restating because it is the test this ADR applies:

1. **Identity-pinned, not rank-based.** GitHub has no concept of GDS ranks, so "code-owner review"
   degenerated into "one specific account must click." That collides with ADR 0016.
2. **It stranded work with no escape hatch.** A blocked PR had nowhere to go, including the PRs that
   fixed the strand.

So the rule 0162 leaves behind is not "nothing may ever block". It is:

> A gate is admissible when it is evaluated automatically, from state the system can read,
> consistently for every builder, with a named escape hatch. A gate is inadmissible when it
> requires a particular person to act before work can move, and stalls indefinitely when they
> do not.

The grader passes that test. A CODEOWNERS review does not. The artist gate has to be built to pass
it too, and everything below is that shape.

## Decision

### 1. The gate reads a STATE, never an opinion

The blocking condition is **"is there an unresolved artist review task attached to this work?"** —
not "did the artist approve it?".

That distinction is the whole reconciliation, so it is worth being exact about. An artist's verdict
never moves anything by itself: an artist saying the copy is bad does not stop a deploy, and an
artist saying it is fine does not release one. What the system reads is the review task's *status*,
which is ordinary GDS state that any rank can see and that moves by the ordinary means — the task
is resolved, dismissed, or shipped. The artist's judgement is what they write **into** that task;
it stays advisory in precisely ADR 0158 §2's sense.

This is not a technicality to route around the rule. It is what makes the gate rank-consistent and
machine-checkable rather than identity-pinned: a status is a fact, a judgement is a person.

### 2. Strictness is a per-project setting, and it holds the DEPLOY

Three ordered levels, a project setting like any other:

| Level | Artist review tasks | What is held |
|---|---|---|
| `off` | not generated | nothing |
| `advisory` | generated | nothing |
| `strict` | generated | **the deploy** — the instance's pin may not move while one is unresolved |

**`strict` holds the deploy, not the ship** (owner ruling, 2026-09-03). This is the load-bearing
choice, and it is what lets a real gate coexist with 0162 rather than merely arguing with it:

- **No builder is ever stranded.** Their work is graded, merged, credited and landed on `main` on
  CI alone, exactly as today. The wave-4 strand class that forced 0162 cannot recur, because
  nothing an artist does can hold a builder's ship at `completed` or their credits at unpaid.
- **It gates what the artist was actually given.** The ABI brief hands the artist what users see —
  no slop appearance, the project's text, whether story and gravitas land. Users see the deployed
  instance, not `main`. ADR 0137 already separates land, release and deploy into three gates; the
  artist's authority attaches to the third one, which is the one their mandate is about.
- **Nothing is ever un-shipped.** The gate can only delay a pin move, an action that is already
  deliberate, already owner-initiated, and already reversible by doing it later.

### 3. The escape hatch is the project owner, and it is never quiet

At `strict`, an unresolved review can be released past by the **project owner only** — not the
builder, not any Metic+, and not the artist (owner ruling, 2026-09-03). The owner's reason is
recorded because it constrains the implementation: *people can be both artist and builder, so they
could potentially pass their own work; they should care about passing the grade, or improving the
grader.*

Two things follow, and the second is a reading of that reason rather than a literal instruction —
flagged as such so it can be corrected:

- The right answer to being gated is to **fix the work or fix the grader**, not to wave it through.
  The release valve exists so a project never deadlocks, not as a routine step.
- A solo instance would deadlock under a strict self-approval bar — on this instance the owner is
  frequently also the builder and the artist. So a self-release is **permitted and recorded as
  such**: releasing past a gate on your own work is allowed, is written to the audit log as a
  self-override with a required rationale, and is visible in the ledger. It costs visibility rather
  than being impossible. If the owner meant the harder rule — that you may never release your own
  work, and a solo project must resolve the review properly or stay undeployed — that is a
  one-line change here and in R04's implementation.

The mechanism is the one that already exists for a failed grader verdict: the override-request
(`POST /tasks/:id/override-request`, rationale required, audit-logged). No new machinery, no second
authority path, and the escape hatch 0162's incident found missing is present from the first day.

### 4. The default is `strict`

Owner ruling, 2026-09-03, against the recommendation this ADR's author put forward (`advisory`, on
the grounds that a gate arriving by default is how 0162's incident happened).

The ruling is coherent with §2 and is recorded with its consequence stated plainly: because
`strict` holds only the deploy, a default-strict project cannot strand a builder — the worst case
is a project whose pin waits on a review nobody has done yet. That is a visible, owner-fixable
state, not a silent one, and the owner holds the release valve. **This instance is included**: once
R04 ships, moving cloudbongos.com's pin will require the artist reviews on that release's copy and
visual work to be resolved or released.

Two guards on that, which R04 must implement rather than assume:

- A project at `strict` with **no artist** must still be able to deploy. The review task exists, it
  is unresolved, and the owner releases it — a project with nobody in the role is the normal case
  for a new instance, and a default that bricks new instances is not a default.
- The gate must say **what** is holding the deploy and **which** control releases it, in one line
  at the point of refusal. 0162's incident was made worse by a blocked state that did not explain
  itself.

### 5. Tightening the setting is not retroactive

When a project raises its strictness, the new level applies to work that ships **after** the
change. Already-shipped work is not retroactively gated, and an already-moved pin is never rolled
back.

The alternative — re-gating history — would mean a single setting change could strand a project's
next deploy behind a backlog of review tasks for work nobody remembers, and would make the setting
frightening to raise. A project that genuinely wants its existing surface reviewed has a better
tool already: R02's flag queue, which is exactly the mechanism for "someone should look at this
copy that already shipped."

Loosening is symmetric and immediate: unresolved review tasks stay on the board as ordinary work,
they simply stop holding the pin.

## Consequences

- **R04 ([#1003115](https://cloudbongos.com/builders#/task/1003115)) is now buildable**, and its
  brief is narrowed by this ADR: it generates the review task and attaches it, and the gate it
  wires is a state check at the deploy step. It does not build an approval UI, and it must not
  make a verdict self-executing.
- **A new project setting** is added to the project settings vocabulary
  (`artist_gate ∈ off | advisory | strict`, default `strict`). It is a policy key the running
  instance obeys, the same shape as the join door (ADR 0238).
- **ADR 0162 is reconciled, not amended.** Nothing in it changes: `main` still carries required
  status checks only, no human click sits in the land path, and no CODEOWNERS file returns. This
  ADR adds a gate on a *different* boundary — the deploy — and adopts 0162's own admissibility
  test to do it.
- **The paraphrase is corrected.** Several surfaces cite 0162 as "verdicts are advisory, never
  self-executing" (this project's skills and ADRs 0178 and 0233 among them). That shorthand is
  true of *verdicts* and false as a blanket claim about gates — 0162's own table has three
  controls that fail closed. Cite the test in §1 above rather than the slogan. (Task 1003573
  corrected those citations: the slogan is ADR 0158 §2's rule about verdicts, and a surface that
  means 0162 now says what 0162 retired.)
- **Accepted trade:** an artist who never does the work can delay a project's deploys. That is the
  point of `strict`, it is per project, it is owner-releasable, and the owner chose it as the
  default with that consequence stated.

## Rejected

- **Blocking the ship instead of the deploy.** The strongest version of the artist's authority, and
  the one that recreates 0162's incident exactly: a builder's graded, merged work parked behind
  another person's queue, with their credits unpaid (ADR 0120 pays on land).
- **Advisory at every level.** Consistent with 0162 by doing nothing, but then "blocking strictness
  is per project" configures nothing and the owner's rule is unimplemented.
- **Any Metic+ as the escape hatch.** Lowest friction, and it makes `strict` indistinguishable from
  `advisory` in practice.
- **Making the artist's verdict itself the gate.** The direct reading of "artist blocking", and the
  one thing 0162 genuinely forbids: it pins the gate to a person, and stalls indefinitely when that
  person is unavailable.
- **Retroactive tightening.** See §5.
- **A global strictness constant.** The owner's constraint rules it out by name.
