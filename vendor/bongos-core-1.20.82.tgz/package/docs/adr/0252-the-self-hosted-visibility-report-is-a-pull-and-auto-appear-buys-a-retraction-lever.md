# ADR 0252 — The self-hosted visibility report is a PULL, and auto-appear buys a retraction lever

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1002321](https://cloudbongos.com/builders#/task/1002321) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-visibility-states` / C1), BV1.R02 — a spike whose output is this decision
- **Gates:** [task 1002327](https://cloudbongos.com/builders#/task/1002327) (BV1.R08 — the build)
- **Deciders:** the Archon (the two product calls in §3 and §5), Claude (the mechanism)
- **Depends on:** [ADR 0182](0182-project-visibility-two-axes.md) D3/D5 (the two axes, and the hand-off that named this ADR's scope) · [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) (the owner's door is a provisioning settings key; the hub column stays the cache) · [ADR 0246](0246-catalog-membership-is-a-projection-not-a-federation-side-effect.md) (the control-plane projection, and the line this ADR sits on)
- **Related:** [ADR 0144](0144-federated-single-logout-backchannel.md) (the tripwire this route avoids) · [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) (why `standalone` holds no credential) · [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) (what a self-report may and may not buy) · [ADR 0047](0047-discord-bugs-intake-anti-abuse.md) (the straight-through path and its abuse guard are one task) · [ADR 0199](0199-restart-an-unreachable-active-project.md) / [ADR 0226](0226-one-stale-timer-reporting-degrades-enforcement-refuses.md) (a degraded report is not a state change)

---

## 1. The problem, and a premise that turned out to be false

BV1.R02 was written to design "how a self-hosted instance reports its visibility to the hub, and how far the hub trusts it," and to settle the **auto-appear vs. Archon-curate** question the planning interview deferred.

Reading the tree first changed the question. **A self-hosted instance has no channel to the hub at all, and no credential with which to open one.** `registerClient` has exactly one caller in the repository — `scripts/gds/provision-net.js:84`, inside the operator's own control-plane `federateInstance` — and that call is gated:

```js
if (inst.hosting_shape !== 'co-tenant') return { federate: false, reason: … };
```

Every writer of `sso_clients` is control-plane; no route registers a client. So *federated* ⊆ *operator-provisioned co-tenant*, and *self-hosted* is a disjoint set holding nothing. That is deliberate on two counts: [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) says in as many words **do not** extend federation to `standalone` as it exists today, and [ADR 0144](0144-federated-single-logout-backchannel.md)'s Known Limitation rests on it — *"today every secret-holder is an operator-provisioned, trusted instance … the proper fix must land before federation opens to untrusted third-party clients."*

So the literal reading of R08 — "a self-hosted instance authenticates and pushes a report" — cannot be built without first minting credentials for untrusted third parties, which walks straight into that tripwire. [ADR 0182](0182-project-visibility-two-axes.md) D5's phrasing ("accepts a report from the authenticated `sso_client`") described a client that, for this population, does not exist.

## 2. The channel is a PULL of the instance's own public manifest

**Decision.** The hub does not receive a pushed report. It **reads the instance's already-public declaration**: `GET <origin>/api/gds/instance` → `branding.project.visibility`.

That value is already there and already public. The owner's pick lives at `provisioning_instances.settings.visibility`, is handed to the instance as `<PREFIX>_VISIBILITY`, and the instance re-serves it on a CORS-open route (`src/branding.js`, `src/bongos/routes/instance.js`). The comment that put it there already anticipated this consumer: *"which is what lets a later task enforce the door there and report the value to the hub catalog (R08)."*

Five things a pull gets for free, each of which a push would have had to build:

1. **No credential.** Nothing is minted for anyone, so ADR 0144's tripwire is untouched and ADR 0145's rule holds. This is the whole reason the decision goes this way.
2. **No replay surface.** ADR 0182 D5 handed R02 "replay, rate" as its scope. A pull reads *current state*, so there is no message to capture and resend — the `jti`-style machinery [ADR 0144](0144-federated-single-logout-backchannel.md) D6 needed for the push direction is moot here. Replay is answered by not having a message.
3. **No wire change on anyone else's upgrade clock.** [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) rejected adding a required body field precisely because "the callers are other instances on their own upgrade schedule," and [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) D2.2 solved the same problem with a header. Here the field already ships in every core; nothing has to be added at all.
4. **The hub still authorizes nothing.** It reads a declaration and caches it, which is exactly what [ADR 0182](0182-project-visibility-two-axes.md) D5 requires and what [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) rejected a `PATCH /projects/:id/visibility` for failing.
5. **The fetch is already written.** `modules/platform-identity/project-stats.js` fans out to project origins today behind a real SSRF guard — DNS-resolve-all with a public-address assertion, `redirect: 'error'` (a curated origin is trusted, a redirect target is not), per-request timeouts, a TTL cache, a negative cache and inflight collapsing. The visibility read rides that machinery rather than opening a second, weaker outbound path.

**The pull carries `visibility` and nothing else.** It is a three-value closed enum; an absent or off-vocabulary answer yields *no verdict* (§4), never a default. No free text, no name, no tagline, no art reaches the catalog through this channel — those stay curated fields, so the property the map has today (a project owner controls no free-text field that reaches the feed) is not spent here.

## 3. Auto-appear: no human stands between a public project and the map

**Decision (the Archon's).** A self-hosted project reporting `public` appears on the map with **no human act**. `featured` keeps the only job [ADR 0182](0182-project-visibility-two-axes.md) D3 left it — ranking among rows already there — and curation stays editorial.

The alternative (a one-time admission, or ongoing curation) was offered and declined. What was declined with it is the friction ADR 0182 D3 had already removed once: an owner setting their project public and seeing nothing happen until someone else acted.

**This decision is conditional, and the condition is §5.** Auto-appear is only defensible because retraction ships beside it; [ADR 0047](0047-discord-bugs-intake-anti-abuse.md) is explicit that the straight-through path and the abuse guard are the *same* task, and this ADR treats that as binding rather than advisory.

## 4. Trust follows provenance — the asymmetry is in the guards, not in a gate

**Decision (the Archon's).** Hosted and self-hosted projects are **not** held to the same bar. Both auto-appear; what differs is what each is trusted to *say*, because the evidence behind each differs:

| | control-plane / co-tenant | self-hosted |
|---|---|---|
| how `visibility` arrives | **assigned** by the bridge from `provisioning_instances.settings` | **pulled** from a manifest the hub does not control |
| evidence | an own-scoped, vocab-validated, audited route the operator's own plane ran | someone pointed a domain at the hub |
| status of the value | authoritative | a **cached claim, with a recency stamp** |
| may move | its own row | its own row, and only its own row |

Stated once, so it is not re-litigated: **an instance is authoritative about its own door and about nothing else.** That is [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) and [ADR 0141](<redacted>.md)'s line held in a new place — identity and self-description federate, authority does not.

### Absent is a third state, and it must not purge

[ADR 0182](0182-project-visibility-two-axes.md) D5 says the absent-report default is fail-closed: unreported ⇒ dark matter. That stands, **scoped to a self-hosted row that has never once answered** — such a project is off the map rather than exposed by omission.

It must never be evaluated against control-plane rows, and it must never be read as "answered before, silent now." [ADR 0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md) D4 found the live shape of this trap: at the time of writing, *every* catalog row carried `description: null`, so a naive fail-closed enforcement wired that day would have refused every join on the platform at once. The same hazard applies here.

So the tri-state is explicit — `null` (never read) ≠ `false` (read, and negative) ≠ `true`:

- **never successfully read** → dark matter (D5's rule, doing its job)
- **read before, unreachable now** → **keep the last known state, stamped with its recency.** A project does not leave the map because its server was down for a sweep. [ADR 0199](0199-restart-an-unreachable-active-project.md): liveness is an overlay, never a lifecycle state. [ADR 0226](0226-one-stale-timer-reporting-degrades-enforcement-refuses.md): reporting may degrade where enforcement must refuse — and this is reporting.
- **read, and narrower than before** → applied immediately and unconditionally. A report that *reduces* exposure needs no trust at all: the worst a lying instance achieves is hiding itself.

That last line is the shape of the whole trust model. **Narrowing is free; widening is what costs.**

## 5. Auto-appear buys a retraction lever — and `hidden` is sticky

`platform_identity_projects.status` is `('active','hidden')` and the public feed requires `active`. **No route writes it.** The only `status` write in the module is on `sso_clients`. Today, removing a project from the map is hand-written SQL on production.

Under control-plane provisioning that was survivable, because the set of rows was bounded by who the operator had provisioned. Auto-appear replaces that bound with *whoever points a domain at us*, and a one-way door onto a public surface is not a door. So R08 ships, in the same task:

1. **`PATCH /projects/:id/status`** — `active|hidden`, `project.curate` floor (metic, per [ADR 0157](0157-archon-is-rank-and-identity-only.md)), audited.
2. **`hidden` is STICKY against the pull.** A retracted project that keeps reporting `public` **stays hidden**. This is the single most important line in this ADR: without it the next sweep silently undoes every takedown, and the lever is decorative. Retraction is a hub decision about the hub's own surface, and the pull may not overwrite it — the pull moves `visibility`, never `status`. The two columns answer different questions and this is where that separation earns its keep.
3. **A per-IP read limit on the public feed** (the [ADR 0209](0209-one-budget-for-the-account-existence-oracle.md) precedent). `GET /projects/featured` is unauthenticated, CORS-open and currently unmetered, and each cold sweep can drive up to 500 rows × 4 outbound fetches.

### One gap this decision widens, named rather than left

`hall_origin` reaches the public feed from the remote instance's own discovery index, and the hub relays it into an `<a href>`. Its only check is that it *differs* from the project's site host — the opposite of a containment rule. Under curated provenance that was survivable; under auto-appear it is a phishing hop anyone can mint.

The corpus already has the right rule and applies it one field over: `shipUrlWithinClientOrigin` requires a pushed ship link to point **at or below** the reporting instance, and explains why the mirror rule is not symmetric (on a shared apex, `foo.github.io` must not publish links on bare `github.io`). **`hall_origin` gets the same downward-only containment**, filed as its own task against R08.

## 6. Consequences

- **A self-hosted project can put itself on the public map, and that is now a supported, un-gated path.** The hub will also, once the SEO work lands, serve it an indexable `cloudbongos.com/<slug>` page — so auto-appear is also auto-issue of a page on the hub's own domain. Accepted knowingly; §5 is the counterweight.
- **The hub reaches out to more origins.** The fan-out ceiling is unchanged (500 rows, TTL + negative caches), but the *population* is no longer bounded by provisioning. The feed read limit exists for this.
- **Two populations, one column, different provenance** — readers of `platform_identity_projects.visibility` cannot assume how it got there. The recency stamp is what tells them.
- **A self-hosted instance that never upgrades never appears.** It already serves `branding.project.visibility`, so in practice this is only the very old.
- **Nothing here federates a self-hosted instance.** It holds no credential, mints no assertion, writes no membership, and reports no analytics. The later analytics feed R02 was asked to anticipate is deliberately *not* decided here: it carries per-person data, which is exactly what [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) proved cannot ride an unwitnessed self-report. It needs the ADR 0144 credential work first, and it is a separate decision.

## 7. Rejected

- **A pushed report authenticated by a client credential.** The literal reading of R08. Rejected: self-hosted instances hold no credential, and minting them is the exact move [ADR 0144](0144-federated-single-logout-backchannel.md) and [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) say must not happen yet. It would also have owed replay protection, a rate budget and a wire-compatible field — three problems the pull does not have.
- **`PATCH /projects/:id/visibility` on the hub.** Already rejected by [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) for making the hub authorize a door change; restated here because a pull could be mistaken for a licence to add one.
- **A one-time admission, and ongoing curation.** Both offered to the Archon; both declined in favour of auto-appear (§3).
- **Trusting the pull to move `status`.** The retraction lever would be decorative (§5.2).
- **Enforcing "unreported ⇒ dark matter" across all rows.** [ADR 0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md) D4's live finding: it empties the map (§4).
- **Letting the pull carry name, tagline or art.** Today no project owner controls a free-text field that reaches the feed. That is a property worth keeping, and a visibility report is not the place to spend it.
