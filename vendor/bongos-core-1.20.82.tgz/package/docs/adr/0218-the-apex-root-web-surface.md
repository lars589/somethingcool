# ADR 0218 — The apex-root web surface: a module may own the front door, and says so with a flag, not an empty prefix

- **Status:** accepted
- **Date:** 2026-08-30
- **Task:** [task 1003322](https://cloudbongos.com/builders#/task/1003322) (goal 1000080 — the apex frontend pass; the last of the five tasks scoped with the owner on 2026-08-28, after 1003320 the kit, 1003321 the skills, 1003323 the style library and 1003324 the module)
- **Relates to:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the module system, the one-way rule, and §Decision #4 "the kernel names no module key"), [ADR 0093 §1](0093-tranche-2-core-carve-sequence.md) (the web-surface carves: status-UI BV1.R84, hall-UI BV1.R85), [ADR 0197 §8](0197-the-ui-design-module.md) ("the front door keeps its own key" — this carve was named there), [ADR 0062 §7](0062-medusa-instance-model-decoupling.md) (the core ↔ host split), [ADR 0108 §1](0108-instance-composition-configurable-root.md) (host content vs the core package), [ADR 0152](0152-landing-gate-served-by-the-core-app.md) (the landing is served by the core app), `modules/public-landing/CLAUDE.md`

## Context

Cloud Bongos's own front door — the landing page, the projects hub, the three legal doors and every asset behind them — lived at the repo root in `public-landing/` and was served by a **hardcoded block** in `src/platform-server.js`: `const LANDING_DIR = path.join(__dirname, '..', 'public-landing')`. It was the last first-party web surface not to be a module. The status dashboard graduated to `modules/status-ui/` in BV1.R84 and the builders' hall to `modules/hall-ui/` in BV1.R85; `src/bongos/module-scope-map.js` had carried the key `public-landing` since task 1002690 with a comment saying, honestly, "not yet a carved module, so the glob lists where the code lives TODAY".

The obstacle was the seam. `moduleWebSurfaces()` (`src/module-loader/loader.js`) resolves an enabled module's `contributes.webSurfaces` into serving descriptors, and its whole routing vocabulary is a **Host-header prefix**:

```js
if (!s || typeof s.host !== 'string' || typeof s.dir !== 'string') continue;
out.push({ key, host: s.host.toLowerCase(), dir: abs });
```

`serve-internal.js` then routes each descriptor with `host.startsWith(s.host)` — `"status."`, `"builders."`. That vocabulary can express "a surface that lives on a subdomain" and nothing else. The apex root is not a prefix of anything; it is **whatever is left** once the subdomains have been taken (`isApexHost` is literally `!isStatusHost && !isBuildersHost`). So the front door could not declare itself with the seam as it stood, and the carve could not happen without teaching the seam a second kind of surface.

The hall had already established the other half of the answer. A web-surface module's manifest declaration is the **discovery, scope-map and `window.__MODULES__` record**; it does not have to be what reads the bytes. The hall keeps a dedicated serving block because its serving is far richer than a static dir (the apex `/builders/*` shim, the canonical redirects, the page gates, the widget injection), and `serve-internal` partitions it out of the generic loop on a *host predicate* rather than on its key. The landing's serving is richer in the same way, for different reasons: the apex-only sentinel strip, the branding-token stamp, the `?v=` content stamp, five named routes, an asset handler and a fall-through to the game-less 404 tail.

## Decision

1. **`modules/public-landing/` is a default-on core-domain WEB-SURFACE module, and the key `public-landing` is kept.** The scope-map key does not change (only its glob does), so goal scopes, task affinity and every existing reference to the key keep resolving. It sits beside `hall-ui` and `status-ui` as the third web surface, and beside them in `publish-manifest.js` so a released core carries the front door it has always carried. Per ADR 0197 §8 it stays its **own** key rather than joining `ui-design`: a customer of a capability is not part of it, and a second instance must be able to use `ui-design` without inheriting Cloud Bongos's page.

2. **A web surface declares EITHER a `host` prefix OR `apexRoot: true` — never both, never neither.**

   ```json
   { "contributes": { "webSurfaces": [ { "apexRoot": true, "dir": "public" } ] } }
   ```

   `moduleWebSurfaces()` accepts a surface whose `dir` is a string and which carries exactly one of the two, and returns for an apex-root surface `{ key, apexRoot: true, dir }` — **with no `host` field at all**. Host descriptors are returned byte-identical to before (`{ key, host, dir }`), so every existing consumer and its tests are untouched.

3. **`host: ""` is rejected, and this is the reason the flag exists.** An empty prefix reads like the natural spelling of "the root", and it is a trap: the router's match is `host.startsWith(s.host)`, and **every string starts with `""`**. A surface declaring `host: ""` would answer on `builders.<apex>` and `status.<apex>` too, and — worse — `isModuleSurfaceHost()` would then return true for *every* request, which is the predicate the eleven `/builders` guards in `serve-internal.js` use to decide to step aside. The hall would stop serving itself. That failure is total, silent and produced by a declaration that looks correct. A boolean cannot be mistaken for a prefix, so the shape that cannot be written wrongly is the shape we take. The loader's guard is explicit: a surface with an empty-string `host` is skipped, exactly as a surface that declares a directory it does not ship is skipped.

4. **The generic static loop stays host-only.** `serve-internal.js` filters the resolved set to descriptors that carry a string `host` before it builds `webSurfaces`, so an apex-root surface is never in that list and therefore never in `isModuleSurfaceHost`. This is the same partition the hall gets, made on the declaration rather than on a host string — and it is what keeps the eleven `/builders` guards honest.

5. **The landing keeps its dedicated block, and only its root moves.** `src/platform-server.js` keeps every transform verbatim — `stripApexOnly` → `injectBrandingGlobal` → `stampAssets`, the memoised page cache, the `/`, `/create`, `/projects`, `/privacy`, `/terms`, `/contact` routes, the apex-only static asset handler, the 404 tail. The single change is that `LANDING_DIR` stops being a hardcoded path and becomes `landingDir()`, resolved once through `moduleWebSurfaces({ isEnabled: isModuleEnabled })`. The DONE WHEN is byte-identity, and the way to get byte-identity is to move the root and touch nothing else.

6. **Disabling the module removes the front door, and the apex answers the 404 tail.** With `public-landing` disabled the loader returns no apex-root surface, `landingDir()` is `null`, `landingPage()` returns `''`, each of the six routes calls `next()`, the asset handler is never mounted, and the request falls to the game-less tail — a JSON 404 for an API-shaped path, plain text otherwise. Nothing throws and nothing is hardcoded to be missed: this is the module contract's "can be disabled without breaking anything" in its most literal form, and it is why the resolution is a lookup rather than a fallback path.

7. **At most one apex-root surface; the first discovered wins and a second is logged.** The apex root is singular by definition — two modules cannot both be "everything that is not a subdomain". Rather than let a second declaration silently shadow or silently lose, `landingDir()` warns with both keys and serves the first. An instance that installs a second landing module gets a line in its log saying so, which is the whole of the error handling this deserves.

8. **The kernel still names no module key** (ADR 0083 §Decision #4). `platform-server.js` selects its surface with `surfaces.find((s) => s.apexRoot)` — a predicate over the *declaration*, exactly as `serve-internal.js` partitions the hall with a predicate over the *host*. Neither file's **code** names the key after this change — only comments say where the bytes happen to live today. A future instance that ships its own front door module gets the apex by declaring `apexRoot`, with no core edit.

9. **The nested `modules/public-landing/CLAUDE.md` is the newcomer's map of this instance's world** — `DESIGN.md`, the fifteen-token contract and why there are two sheets ([ADR 0196](0196-chrome-world-token-contract-and-the-landing-sheets.md)), the direction records and the mocks, which page is which, the test pins that bite, the traps, and a pointer to `modules/ui-design/`'s kit for the look-before-you-ship loop. The module ships the *world*; the method for building one stays in `ui-design`.

## Consequences

- **The front door is a module like any other.** `GET /modules` lists it, `window.__MODULES__` carries it, the scope map points at `modules/public-landing/`, and the fitness core↔host boundary check now covers it.
- **The `?v=` stamp and the asset resolution follow the dir automatically.** `assetStamp()` resolves a URL against the surface dir and refuses anything that escapes it; moving the dir moves the jail with it, and the stamp is a content hash, so the served bytes are unchanged.
- **The kit needed no functional change.** `resolveSurfaceDir()` (`modules/ui-design/kit/lib.js`) already resolved a surface argument as *either* a checkout directory *or* a module key whose manifest declares a `webSurfaces` dir. `--surface public-landing` therefore keeps working across the move, resolving through the manifest instead of the root directory — the seam ADR 0197's kit built for exactly this day.
- **Byte-identity is the evidence, not the claim — and it has exactly one deliberate exception.** The five apex pages and the two stylesheets were hashed as *served* (through the real `buildPlatformApp()` over an ephemeral listener, on the apex host) before and after the move. The stylesheets match outright. Each HTML page grew by **22 bytes, the same 22 on all five**: `"public-landing":true,` — the module's own entry in the injected `window.__MODULES__`, which is the front door becoming a module *observable in the page*, and the one change this ADR intends. Remove that single substring and all five digests equal their BEFORE values exactly. The 106 moved files hash identically on disk before and after.
- **What this does not do:** the surface still ships wholesale to every instance and is still stripped by the apex-only sentinels on a child (ADR 0152's arrangement is untouched). A child instance overriding the front door with its own module is now *expressible* — declare `apexRoot`, disable `public-landing` — but nothing in this ADR builds or tests that path.
