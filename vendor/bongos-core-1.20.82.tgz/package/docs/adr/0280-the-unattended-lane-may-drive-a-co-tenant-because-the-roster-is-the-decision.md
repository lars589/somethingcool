# ADR 0280 — The unattended lane may drive a co-tenant, because the roster entry *is* the per-instance decision

- **Status:** accepted
- **Date:** 2026-09-12
- **Task:** [1003843](https://cloudbongos.com/builders#/task/1003843) (goal 1000106) — from [task 1003521](https://cloudbongos.com/builders#/task/1003521), which built co-tenant mode into `go-live.js` and deliberately left this caller alone.
- **Adjacent:** [ADR 0279](0279-an-upgrade-is-proven-by-the-served-version-not-the-health-check.md) (why this lane prefers `go-live.js` at all) · [ADR 0136](0136-update-channel-subscription-policy.md) (the subscription policy core).

## Context

`go-live.js` grew **co-tenant mode** in task 1003521: `deployTimer` became optional (a provisioned instance under `/srv/<host>/<slug>` has no pull-deploy timer to stop), and `pinMode: local-commit | leave-dirty` stopped it pushing the pin into the **customer's own** GitHub repo.

The nightly auto-subscription lane (`.claude/scheduled-tasks/core-update-subscription/subscribe.js`) could not reach any of it, because it keeps a **second copy of go-live's target contract**:

1. `GO_LIVE_REQUIRED` still listed `deployTimer`, so `goLiveTargetFor()` returned `{ok: false, missing: ['deployTimer']}` for every co-tenant.
2. `rawTopologyFor()` reads a fixed field list off `config/update-subscriptions.json`, and `pinMode` was not in it — the same stale-normalizer trap that function's own comment was written to fix, one field later.

Task 1003521 deferred the fix on the grounds that widening it "would have meant changing the unattended lane's policy about which instances it may deploy, which is a judgement call." **That premise does not survive reading the fallback.** `mapped.ok === false` does not mean "skip this instance" — it means "deploy it the *weaker* way": a bare `bongos upgrade` with no backup and no deploy-timer guard, and, because the roster's `--commit-pin` support is independent of all this, a pin **committed and pushed** — into the co-tenant's own repo, which is precisely what `pinMode` exists to prevent.

So the lane was already auto-deploying co-tenants. The only question ever open was whether it did so well.

A third defect sat behind the other two, and would have turned the reported silent downgrade into a hard failure if only the first had been fixed: the normalizer yields `deployTimer: null` for an absent field, an explicit `null` **survives `JSON.stringify`** into `--target-json`, and go-live's `validateTarget` runs `isSafeToken(null)` on it and rejects the whole target. Dropping `deployTimer` from `GO_LIVE_REQUIRED` alone would have handed go-live a target it refuses.

**The remaining defects sat outside the go-live call entirely, and they are what made "reachable" different from "safe".** The lane writes the instance's pin in **three** places, and every one of them decided whether to push without asking what mode it was in:

1. **The durability net after the upgrade** — `commitPin()` commits the pin files and **pushes to `origin`**. Under `local-commit` go-live leaves the tree clean, so the net no-ops and is correct by luck. Under **`leave-dirty`** the pin is in the working tree *by design*, so the net committed it and pushed it into the customer's repo.
2. **The HEAL-FIRST step before the upgrade**, which is the worst of the three because it fires on the **happy path**. A `leave-dirty` co-tenant's steady state after a *successful* upgrade IS a dirty pin — so the next scheduled sweep read it as "a leftover from an earlier sweep", committed it and pushed it. Reliably, every sweep, not just after a crash. (Found by the grader; it shipped past a green suite on the first round because the decision was an inline `if` inside a 250-line loop that no test could reach.)
3. **The direct-upgrade fallback**, which passes `--commit-pin` to `upgrade.js` — and that flag commits *and pushes*. So a co-tenant on an older core had its pin pushed anyway, by the very path taken when go-live's co-tenant support was missing.

Reaching co-tenant mode without closing all three would have been worse than not reaching it at all: the lane would honour `pinMode` at the one site that names it and undo it at the two that do not.

## Decision

**The nightly lane may drive a co-tenant, and needs no new gate to do it — because enrolling an instance in `config/update-subscriptions.json` already IS the explicit, per-instance operator decision.** The roster ships empty, an instance is touched only after an operator lists it, and the whole routine is behind the autonomy flag (`requiresAutonomy: true`, default OFF). Adding a second consent gate in front of that would be asking the same person the same question twice.

The change therefore makes the *existing* behaviour correct rather than widening it. Concretely, in `subscribe.js`:

- `GO_LIVE_REQUIRED` now **mirrors** go-live's `REQUIRED_FIELDS` exactly, and a test reads **both source files** and fails on drift. The contract is someone else's; the copy is the liability.
- `deployTimer` moves into the optional-field loop, which drops falsy values, so a co-tenant **omits the key** rather than carrying a `null` that go-live would reject.
- `rawTopologyFor` carries `pinMode`, and `goLiveTargetFor` passes it through.
- The capability probe in `resolveGoLive` gains a **`needsCoTenant`** leg, checked **only when the target actually needs it** — a target with no `deployTimer`, or one naming `pinMode`. Both are rejected outright by a go-live.js predating 1003521 (the missing required field; the unknown-field check), so the fail-closed rule of task 1003212 applies: probe the capability, fall back if absent.
- `goLiveEngineFor()` makes that decision **once**, for both the dry run and the apply path. They previously re-derived it separately, and the co-tenant probe gave them a third thing to keep in step — a preview that promises an engine the real sweep will not use is its own quiet failure.
- **All three pin-writing sites obey one policy, read from the roster.** `pinModeOf()` reads the **roster entry** — the operator's declared intent — not the go-live target, because deriving it from the target would silently revert a co-tenant to `push` on exactly the runs that fall back to a direct upgrade. `commitPin()` takes `push` (default `true`, so the platform instance is unchanged); the fallback withholds `--commit-pin` unless the mode is `push`; and the "pin is not durable" advice no longer tells an operator to `git push` a repo we do not own.
- **The heal decision is a named function, `healDecision(pre, pinMode)`.** Under `leave-dirty` a dirty pin is `by-design`, not a leftover — go-live's dirty-checkout halt reads the **core** checkout, not the instance, so leaving it dirty wedges nothing. Extracting it is the point as much as the fix: all three bugs were a site deciding without asking, and an inline `if` in a long loop is exactly what no test can reach. Non-pin changes still `halt` in **every** mode — a human's uncommitted work stops the lane regardless of pin policy, and the test pins that ordering.
- **An unknown `pinMode` is refused, not defaulted.** Every unrecognised value would otherwise fall through to the push branch, so a typo in the roster degrades to the *most* dangerous behaviour. The instance is skipped with the expected values named. `PIN_MODES` mirrors go-live's enum, pinned by the same read-both-sources test as `GO_LIVE_REQUIRED`.

**Why the probe is conditional and not unconditional.** Probing for `pinMode` on every target would strip the go-live path from any instance sitting on a core between the `--target-json` release and 1003521's — a live regression traded for a hypothetical one. The capability is demanded only where it is used.

## Consequences

- A provisioned co-tenant listed in the roster now takes the **stronger** deploy path: pg_dump backup, the served-version read-back of ADR 0279, and a pin that is committed locally instead of pushed into a repo we do not own — end to end, including the lane's own net after go-live returns.
- A co-tenant on an older core **falls back and says so**, naming co-tenant support specifically, so an operator can tell it apart from a malformed roster entry.
- Ordinary instances are unchanged — including the mid-generation ones the conditional probe protects.
- `GO_LIVE_REQUIRED` and `PIN_MODES` drifting from go-live's contract are now **test failures**, not silent downgrades. This is the second time this copy has drifted; the next time it moves, CI says so.
- A source-level test asserts that **every** `commitPin` call site names `push`, and that the fallback gates `--commit-pin`. The recurring bug was never one site — it was the absence of anything that could see all of them at once.

## Rejected

- **A second consent gate** (an opt-in `allowCoTenant` roster flag, or an operator-only command): the roster entry already carries that consent, and the routine is autonomy-gated on top of it.
- **Deferring to the fleet control plane** ([task 1001948](https://cloudbongos.com/builders#/task/1001948)): that epic is unspecced, and leaving this until then does not leave co-tenants alone — it leaves them on the weaker path, pushing pins into customer repos.
- **Dropping `deployTimer` from `GO_LIVE_REQUIRED` and nothing else** (the fix as originally proposed): it trades a silent downgrade for a hard target rejection, because of the surviving `null`.
- **Probing for co-tenant support unconditionally:** regresses every instance on a mid-generation core.
- **Reaching co-tenant mode without teaching the durability net about it:** `leave-dirty` would have been committed and pushed to the customer's remote by the net running seconds after go-live deliberately did not — nominal support that breaks its own promise.
- **Teaching `loadSubscriptions()` about `pinMode`** instead of `rawTopologyFor`: that normalizer ships in the *control plane's* vendored core, which nobody bumps — trusting it is the exact trap `rawTopologyFor` was written to route around.
