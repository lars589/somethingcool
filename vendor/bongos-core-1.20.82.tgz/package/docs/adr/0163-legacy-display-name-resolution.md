# 0163 — Pre-197 display names: a transitional 'legacy' source, resolved at first sign-in

- **Status:** Accepted
- **Date:** 2026-08-11
- **Deciders:** Claude (jaxri session), under the bug-wave mandate

**Track:** `internal` (GDS / builder experience). Task [1002643](https://cloudbongos.com/builders#/task/1002643), from idea 1000659. Extends [ADR 0156](0156-user-set-display-name-wins.md).

---

## Context

ADR 0156 (migration `core_197`) made a builder's self-chosen display name durable by recording *who last set it* (`builders.display_name_source`: `'github' | 'user'`) and guarding the sign-in upsert. It claimed `'github'` was "the correct default for every pre-existing row: whatever is stored survived the last sign-in, so it *is* the GitHub-derived value."

That claim has a hole: a builder who renamed via `PATCH /me/display-name` **after their last sign-in but before 197 landed** still held their builder-set name in the row — 197 stamped it `'github'` anyway, so their next sign-in clobbers it. The fix shipped forward-only; the bug it fixed kept firing for exactly the people who had already hit it.

A precise backfill is impossible: the rename route writes no `audit_log` entry, and nothing stores what GitHub reported per row. "Was this stored name builder-set?" has no answer in the data.

## Decision

**A third, transitional `display_name_source` value — `'legacy'` — for every row that predates 197 on the instance, resolved definitively by the upsert at each row's first subsequent sign-in.**

- Migration `core_214` extends the CHECK constraint and marks `'legacy'` every row with `display_name_source = 'github'` created before `core_197`'s `applied_at` **on that instance** (read from `schema_migrations`, so the scoping is portable to self-hosted instances regardless of when they upgraded). A replay guard ensures resolved rows are never re-marked.
- `upsertBuilder`'s conflict branch resolves each `'legacy'` row exactly once, using the one comparison that is only available at sign-in time — the incoming GitHub-derived name:
  - stored name **equals** incoming → provably GitHub-derived → `'github'`; re-sync resumes as if 197's default had been right.
  - stored name **differs** → treated as builder-set → kept, stamped `'user'`; durable from then on.
- `'user'` and `'github'` remain terminal; post-197 rows are untouched.

### The accepted misclassification

A `'legacy'` row whose *GitHub-side* name changed between its last pre-214 sync and its first post-214 sign-in also "differs" — the stale GitHub name gets frozen as `'user'`. That trade is deliberate: the wrong outcome there is a stale *label*, visible and self-fixable in Settings; the wrong outcome under the status quo is the silent destruction of a deliberate rename — the reported bug. Preserve wins over sync when the evidence is ambiguous.

### Rejected alternatives

- **Backfill `'user'` where `display_name <> github_login`** — overwhelmingly wrong: most GitHub accounts have a profile name that differs from the login, so this would freeze GitHub-derived names for nearly everyone, silently reintroducing the frozen-name bug ADR 0156 rejected.
- **Backfill nothing, compare names for ALL `'github'` rows forever** — turns every future GitHub rename into a frozen name; `'legacy'` scopes the ambiguity to the rows that actually carry it and expires it one sign-in later.
- **Restore lost names from an audit trail** — there is no audit trail; rows already clobbered between 197 and 214 are unrecoverable, and this ADR does not pretend otherwise.

## Consequences

- `builders_display_name_source_check` now allows `'legacy'`; the value disappears from a row at its first post-214 sign-in and is never written by any other path.
- `tests/display_name.mjs` evaluates the real conflict-branch SQL for all three source states and pins the migration's contract (only-`'github'` rows marked, `applied_at` scoping, replay guard).
- Not surfaced in the API — same posture as ADR 0156; no UI copy branches on it.
- Builders whose names were already re-clobbered between 197 and 214 must re-save once in Settings — with 214 in place, it now sticks.
