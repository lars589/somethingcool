# ADR 0200 — A mistyped bring-your-own domain can be corrected, the address it leaves is released to a blackhole, and the attach leg stops regenerating web.env from the row

- **Status:** accepted
- **Date:** 2026-08-28
- **Task:** [task 1003237](https://cloudbongos.com/builders#/task/1003237) (goal 1000058 — the non-cloudbongos project lifecycle)
- **Relates to:** ADR 0111 (provisioning trust boundary), ADR 0190 (settings-apply in-place env patch — the hazard this ADR pays off), ADR 0181 (teardown state gate + address retention — the half this one does *not* touch), ADR 0133 (GitHub App Manifest cred placement), task 1002692 (the attach route), task 1002704 (the in-apex squat rule), task 1002897 (teardown never reclaims the address), task 1002720 (F16/F19 truthfulness), idea 1000842 (the `webEnvBody` hazard)

## Context

`POST /provisioning/instances/:id/domain` refused a second address with a deliberate `409 domain_already_set`, and its comment recorded the policy in as many words: *"A genuine BYO address stays un-re-pointable, as before."* The redesign direction §8 said the opposite — *"attach/change stays for custom domains."* The pre-UAT hub review (2026-08-24) filed the contradiction as a decision rather than a UI tweak, because rendering a field that always 409s would be worse than rendering none.

The founder-facing shape of the gap: a founder types their domain into the create wizard, mistypes one character, and the project stands up permanently addressed at a hostname they do not own — with no path back except tearing the project down and starting over.

Three things made this more than a route edit.

**The address is held in more than one place.** ADR 0181 §2 decided that a *torn-down* project keeps its `port` **and** its `domain`, because the two are one coupled decision: release the port while a stale Caddy block still answers, and a later instance handed that port begins serving under the torn-down project's hostname — one owner's project under another owner's name. A re-point is the opposite case (the owner has *asked* to leave the address), so it must release, and releasing means knowing what "release" consists of.

**The runner could not see what was left behind.** The web tier overwrites `domain` the instant it records the new one, and the runner — the only tier holding a DNS token (ADR 0111 §2) — reads the row. Without a carrier, an abandoned hostname's A record would sit pointed at platform infra with nothing left in the row to say so.

**`domainAttachInstance` re-wrote `web.env` from the template.** ADR 0190 §"Why the in-place patch is load-bearing" named this: `webEnvBody(inst, …)` regenerates the file **from the row**, and the row knows neither the OAuth client id/secret `placeManifestCreds` fetched (ADR 0133), nor the App private key, nor the federation block. Today it is masked by wizard order — the address is attached *before* the GitHub App exists, so there is nothing yet to blank. **A re-point is not masked.** It runs on a project the founder is already signed in to, so the same move would break sign-in on the exact project they had just corrected. This was the hazard that made the task's scope "fix it here or depend on the fix."

## Decision

### 1. A bring-your-own address may be re-pointed, under the guards the first attach already applied

The `409 domain_already_set` is gone. A re-point runs the same gauntlet a first attach runs, in the same order, with no clause added and none weakened:

- `normalizeHostname` must yield a real multi-label host (`400 bad_domain`);
- `isReservedHostname` refuses a platform-reserved name (`400 domain_reserved`);
- inside the platform apex, the only address an instance may hold is its own `<slug>.<apex>` — the task-1002704 squat rule (`400 domain_reserved`);
- `getInstanceByDomain` refuses an address another instance holds (`409 domain_taken`);
- `DOMAIN_ATTACH_FROM` still gates on state, and already admitted `active` (`409 domain_not_attachable`).

The platform-assigned `<slug>.<apex>` is **not** re-pointable in the sense that matters: it is the platform's own name for that slug, it cannot be pointed anywhere else, and the squat rule is what enforces that. What changes is only that a *founder-supplied* address is no longer permanent.

An `active` instance re-points through a `domain-attach` intent — the same intent, because the wiring is the same wiring, and `DOMAIN_ATTACH_FROM` already admitted `active`. A `requested`/`error` instance only records it; its next provision run wires the domain itself.

### 2. The address it leaves is released — parked at a blackhole, not deleted

`provisioning_012` adds `released_domains text[]`, written in the **same statement** as the new domain (`updateInstanceDomain`'s third argument). A re-point that recorded the new address but crashed before queueing the old one would leave a hostname aimed at platform infra with nothing in the row to say so; one statement makes that unrepresentable.

An **array**, not a scalar: a founder who mistypes once can mistype twice, and a scalar would silently drop the middle address. The runner drains the whole list and empties it (`clearReleasedDomains`).

Only a **BYO** address is ever queued, and only from a state that actually stood up (`DOMAIN_RELEASE_FROM = {error, active}`). Two exclusions, for two different reasons:

- The platform-assigned `<slug>.<apex>` — the upgrade path task 1002704 already allowed — queues nothing: that name is the platform's own, and the revive path re-uses it (ADR 0181 §2).
- A `requested` instance queues nothing either: it has never stood up, so nothing ever wrote an A record for the address it is leaving. Parking that name would **create** a junk record in the owner's zone rather than release one — the inverse of the leak this exists to close. An `error` row is frequently a *partial* standup that did write it (ADR 0181 §1), so it counts.

The web tier decides both, because it is the tier that knows the apex and the lifecycle state.

> **Amendment (owner, 2026-09-16, task 1002902): the first exclusion is withdrawn.** An upgrade off the platform-assigned `<slug>.<apex>` now queues that name for release like any other address a project moves off; only the `requested` exclusion remains. The revive argument did not hold for this path. A revive re-uses the row's *current* address, which after an upgrade is the BYO name, not the assigned one. Teardown already parks whatever address the row holds (task 1002897). A project that moves back onto its assigned name re-UPSERTs it in the same attach, and `releasableDomains` never releases the address a row is on. Keeping the name meant leaving a record aimed at platform infra with no vhost behind it, which is the leak §2 exists to close. The route releases the row's own `current` value and never derives one, so a mis-derived name cannot park another project's record, and the squat rule keeps `<slug>.<apex>` usable only by that slug's own project. The manage card's "lets `<host>` go" line now shows on the upgrade too.

**The queue is capped (`MAX_RELEASED_DOMAINS`), and the route that fills it is throttled.** The runner drains this list **synchronously, one <redacted> call per entry**, and every re-point is a write an authenticated owner can repeat — `normalizeHostname` checks a hostname's *shape*, never that it exists. So an uncapped array is a resource-exhaustion vector against a **platform-wide** resource (the control plane's DNS token and rate limit, and the drain loop itself), not merely against the owner's own project. Two bounds, at different layers:

- **The cap is enforced in `updateInstanceDomain`'s own SQL**, not trusted from the caller: past the bound the append is dropped, keeping the entries most likely to name a hostname the platform really wired. Dropping is the deliberate failure mode; growing without bound is not.
- **The route carries a per-builder limiter** (the task-1002898 slug-check shape — keyed on the builder, since per-IP starves co-located builders while an attacker rotates IPs). It had none before: until this task the route could only *record* an address, and recording had no downstream cost.

Release is **a repoint to `192.0.2.1`, not a delete.** This is the shape `scripts/gds/box-infra.js` already proved for a torn-down box (idea 309 → task 1234), adopted here for its two reasons:

- **No NXDOMAIN window.** Deleting a name opens a gap that resolvers negative-cache for the zone's SOA neg-TTL (~30 min on Cloudflare, not builder-editable), so a client that queried mid-gap stays broken long after. A name that always resolves — to a host RFC 5737 guarantees is never routable — has nothing to negative-cache.
- **No new hook contract.** `BOX_DNS_HOOK` is an operator-supplied script and the core cannot assume it implements a delete mode. A release expressed as an UPSERT needs only the contract every hook already implements.

Two halves of the address release themselves and need no separate step, which is worth writing down because it is why this leg is as small as it is: the Caddy snippet is per-**slug** and always carries the *current* domain, so the same write that wires the new host takes the old vhost away; and `/provisioning/tls-check` answers from the row, so on-demand TLS stops being minted for the old name the moment the row moves.

### 3. Both legs that wire a domain drain the queue

`domainAttachInstance` owns an `active` instance. It deliberately no-ops for anything else ("provision owns pre-active domains"), so a re-point on a `requested`/`error` project would queue a release nothing ever drained — and an `error` row is frequently a *partial standup* that already UPSERTed the address it is now leaving (ADR 0181 §1). `provisionInstance` therefore drains the same queue after its own DNS step, through the same `releaseAbandonedDomains` helper. One implementation, two callers.

### 4. The release is best-effort, and the queue is the retry

Every queued address is attempted — one host whose zone the token cannot reach must not strand the others behind it — and the queue is emptied only when all of them landed. Re-parking an address already at the sentinel is an idempotent UPSERT, so retrying the whole list costs nothing but the call. A hook that fails returns `ok: true` with `releaseFailed` naming the first host that did, and **does not** clear the queue — so the next attach retries it. A release that failed must never fail a re-point that has already landed; the founder's project is answering at its new address, and re-pending the intent would restart that work four more times and end by stamping an `error_note` over a correction that worked. With no hook configured at all, the outstanding manual step is **logged by name** rather than swallowed (the F16 rule).

### 5. `domainAttachInstance` patches `web.env` in place

The leg now reads the file and patches **only** the four `<PREFIX>_*_ORIGIN` lines through `upsertEnvVars` — the `settingsApplyInstance` shape (ADR 0190 §2), with the same refusals:

- a dry run **plans** the patch and writes nothing, rather than writing a synthetic body that would read as the exact overwrite this change exists to prevent;
- an unreadable or empty file is **refused** (`ok: false`), never patched — four origin lines written over a missing `PORT`/`PGDATABASE` would take down an instance that is *already serving*.

`originEnvVarsFor(inst)` (pure, in `provision-units.js`) is the domain-dependent half of `webEnvBody`, factored out so the two can never drift. `webEnvBody` remains the right thing for a **first** provision, where there is no file yet and nothing to preserve.

This closes idea 1000842 for the attach path. `placeManifestCreds` still writes a full `webEnvBody` — correctly, since it is the tier that *holds* the creds it is placing.

### 6. A changed address clears the liveness overlay

`last_verified_at`/`last_verified_up` are a verdict on an **address** (task 1002696). Carrying them across a re-point would let the card say *"Answering at `right.example.com` — last answered 2 minutes ago"* when only `typo.example.com` was ever probed. Both are set to NULL when — and only when — the domain actually changes, guarded in SQL so an idempotent re-record can never blank a good probe. NULL means "never probed", which is the truth for a name nothing has asked yet; the sweep re-probes within minutes.

### 7. The card gains a third door, and says what it costs

`canAttachDomain` no longer excludes an addressed project. The fold now reads its label from what the project is actually addressed as: **Give it an address** (none), **Use a domain I own** (on the platform-assigned name), **Use a different domain** (on a BYO name), and the F19 **Try the address again** door keeps its louder, self-opening shape. The correction door pre-fills the current address — a typo is corrected by editing one character, not by retyping the whole hostname — and carries one line under the button: *"Changing it lets `<host>` go — it stops answering for this project."* Letting the old address go is said where the decision is made, not discovered afterwards.

## Consequences

- **A mistyped domain is no longer a reason to tear a project down and start over** — the founder-facing point of the whole task.
- **The `webEnvBody` hazard is paid off on the attach path**, which also makes the *first* attach safer than it was: it was only ever masked by wizard order, and nothing enforced that order.
- **An abandoned address stops reaching platform infra.** It resolves to a dead end rather than 404ing off the platform's own edge, and it is immediately re-claimable by any instance, since the uniqueness check reads the row.
- **The parked record is left in the founder's zone.** A true `DELETE` is available to an operator through the hook's own `BOX_DNS_DELETE` mode; the platform does not reach for it, for the neg-TTL reason above. If a founder wants the name gone entirely, that is a change in their own DNS.
- **[Task 1002897](https://cloudbongos.com/builders#/task/1002897) (teardown never reclaims the address) can reuse this seam** — `dnsReleaseEnv` + `DNS_BLACKHOLE_IP` are exported and shape-agnostic. It still owns the questions this ADR does not answer: whether a torn-down address 404s or serves an honest "this project ended" page, and whether the port is released with it. **ADR 0181 §2's retention decision is untouched here**: a torn-down project still keeps its address, deliberately, because the revive path re-uses it.
- **A re-point costs a service restart**, like every other change that reaches a running instance's memoized branding pack (ADR 0190 §3).
- **The cap can, in principle, drop an address.** Only past `MAX_RELEASED_DOMAINS` queued releases on one instance — a state a founder correcting a typo cannot reach, and one the route's limiter makes slow to reach deliberately. The dropped hostname keeps its record until an operator removes it; that is strictly better than letting one owner queue unbounded work against the shared token.

## Alternatives considered

- **Amend direction §8 and make the card say the address is fixed once set.** The task's other branch. Rejected by the owner: a founder who mistypes a domain would have no path back but teardown, which loses the project's database and repo wiring for a one-character error.
- **Delete the old A record instead of parking it.** Cleaner in the founder's zone, but re-opens the NXDOMAIN negative-cache window the box lane already learned to avoid (idea 309), and assumes a hook mode the core cannot guarantee.
- **Sequence this task behind 1002897.** The owner's decision allowed either order. Carving the release leg here was chosen because the hazard in §4 is on *this* path and a re-point that leaked its old address would ship a known leak in the name of ordering.
- **A `previous_domain` scalar instead of an array.** One column less, but it silently drops the middle address when a founder corrects twice before the runner drains — the exact user this feature is for.
