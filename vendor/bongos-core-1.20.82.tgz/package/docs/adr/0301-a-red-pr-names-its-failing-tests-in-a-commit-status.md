# ADR 0301 — A red PR names its failing tests in a commit status, and says so when it cannot see

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003988](https://cloudbongos.com/builders#/task/1003988) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0055](0055-server-mediated-branch-publish.md) (a builder box holds no GitHub credential; the server answers for GitHub) · [ADR 0031](0031-cloud-dev-environments-for-builders.md) §6 (the box's clone token is one-shot) · [ADR 0162](0162-review-gates-retired-rank-consistent-ci-only.md) (shipping lands on CI checks alone) · [ADR 0082](0082-server-side-merge-conflict-auto-resolution.md) (the stale-generated-file heal)

## Context

On 2026-09-17 one task's pull request took **nine red CI runs in four hours**: the first eight
failed the same `security` test, the ninth a different one. The builder's session was not being
careless. It was blind:

- `GET /tasks/:id/publish-status` reported `rollup_state: FAILURE` with `checks: []`. The Cloud
  Bongos GitHub App has no `Checks: read`, so GitHub answers the rollup **state** and nulls every
  `CheckRun` node (blocker 1000151). The code already tolerated that — and then dropped the holes
  silently, so an empty list read as "nothing failed".
- `mergeBlockReason` then called the red PR `blocked_required_review_or_pending_check`, which is
  an instruction to *wait*.
- A box has no `gh`, no credential, and the repository is private, so there is no other door.

A task parked at `confirmed` also shuts that builder's claim gate, so one unreadable red check
stopped all of their work. A non-technical builder has no independent way to sanity-check the
agent's reading of any of this.

## Decision

1. **Say when the list is blind.** `getMergeState` counts the nulled nodes and returns
   `checks_unreadable`. A red rollup with no readable failing check is reported as
   `failing_check_unreadable`, never as a review/pending wait. A `PENDING` rollup keeps the old
   reading, because there a wait is the truth.
2. **Report the failing tests through a channel the App can already read.** A `StatusContext`
   survives the missing permission where a `CheckRun` does not (it is why `gate-author-trust` was
   the one entry that ever appeared). The `unit` workflow gains a `report` job that posts a
   `unit-report` commit status whose description is `N failed: <names>`; the server returns it as
   `failing_tests`.
3. **The write-scoped token never sits beside PR code.** `report` is a separate job: it holds
   `statuses: write`, checks out nothing, and receives the failure line as a job output through
   `env`. The `unit` job keeps `contents: read`.
4. **Treat the description as untrusted.** The PR controls the workflow that writes it, and the
   text is handed to an agent, so `failing_tests` is reduced to test-list vocabulary and the raw
   description never rides out on `checks[]`.

## Alternatives rejected

- **Only ask the owner for `Checks: read`.** Still the right grant, and blocker 1000151 stays
  open for it — but every new instance starts without it, and a fix that needs an owner action
  on each install is the interruption this work exists to remove. With the grant, `checks[]`
  fills in and (1) and (2) simply agree with it.
- **Post the status from the `unit` job.** One job fewer, but it puts a status-writing token in
  the job that runs PR-controlled tests. Gate contexts are commit statuses too.
- **A PR comment.** Readable without the permission, but it accumulates, notifies people, and is
  not part of the head commit's rollup the server already reads.
- **Make the poll bail on red.** The reconciler can still heal a stale generated file and turn the
  PR green, so `pollServerPublish` prints the reason once and keeps its window.

## Consequences

- `failing_check:unit-report` matches the reconciler's existing `^failing_check:` test, so the
  ADR 0082 stale-generated-file heal can now fire on an instance without `Checks: read`. It was
  designed to; it never could.
- `report` is not a required check and never fails — a status that could not be posted (a fork's
  read-only token) is a warning. While it runs, a green PR reads `UNSTABLE` for a few seconds;
  GitHub's own auto-merge ignores non-required contexts, and the server's `mergeIfGreen` catches
  it on the next sweep.
- The CI log still prints only a node:test file's summary counts, not its assertion. Naming the
  test is what makes a local reproduction possible; printing the assertion is separate work.
