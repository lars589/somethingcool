# ADR 0283 — The core publishes publicly, because access was never the thing protecting it

- **Status:** accepted
- **Date:** 2026-09-13
- **Task:** [1003872](https://cloudbongos.com/builders#/task/1003872) (goal 1000090, working area 4 — Bongos Core distribution). Gated on [1003869](https://cloudbongos.com/builders#/task/1003869) (sweep the literals), [1003870](https://cloudbongos.com/builders#/task/1003870) (fail-closed leak scan), [1003871](https://cloudbongos.com/builders#/task/1003871) (fixture confirmation). Records the owner decision behind [1003502](https://cloudbongos.com/builders#/task/1003502) ("public repo, public npm, or wait for the mirror" — **public npm**). That task is *not* closed by this ADR: its remaining work is repointing the gate's open-source link, which lives in a separate static site with no auto-deploy, and should follow once the registry flip is live.
- **Supersedes:** [ADR 0134](0134-private-first-npm-distribution.md)'s **core half** — the pre-launch private-by-default posture. (Its client half was already superseded by task 1003742.)
- **Adjacent:** [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) (the public CLI, which exists *because* the core was private) · [ADR 0136](0136-update-channel-subscription-policy.md) (the subscription lane this unblocks) · [ADR 0099](0099-delayed-redacted-mirror-export.md) (the mirror pipeline this path deliberately does not use) · [ADR 0161](0161-publish-on-merge.md) (the lane that performs the publish).

## Context

ADR 0134 chose **private-first**: `@bongos/core` publishes as a restricted scoped package on a paid npm org, with "public at launch" named as a later, deliberate step. That was the right call pre-launch. This ADR is that later step.

The posture had a cost that grew quietly, because every symptom looked like a different bug:

- **A tokenless `npm install` returns a flat E404** — indistinguishable from "no such package". Every co-tenant and downstream instance upgrade needs a credential to move at all.
- **The nightly auto-upgrade sweep died on 2026-08-25 and reported `failed=0`.** Its systemd unit passed no `NPM_TOKEN`, the instance's env-fed `.npmrc` expanded to empty, and the private read 404'd. A skip is not a failure in that script's accounting, so nothing anywhere complained while the instance stopped receiving core updates.
- **Any Anthropic-hosted cloud session** working on an instance repo cannot install the dependency at all.
- **A newly scaffolded instance's README step 1 is `npm install`** — which is also what installs the `bongos` command. Without a token the owner does not get a stale instance; they get no working instance.
- **[ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) exists only because of this.** `@cloudbongos/cli` was built, and its require-closure painstakingly delazified, so that a new builder could reach the board without a private-registry credential.

The decisive point is that **access control was never what protected this artifact.** Three gates decide what is *in* the tarball, and all three now hold:

1. The in-build **no-leak gate** (branding-derived literals + live credential shapes) — fail-closed, 2,624 files clean.
2. The **prior-instance leak scan** — fatal by default since task 1003870, with `--no-leak-scan` the only escape; a real build passes with `✓ no prior-instance literals in the built artifact`.
3. The **fixture confirmation** of task 1003871 — all 14 credential-shape files checked against each provider's real key format (11 too short to have ever been valid, 3 alphabet sequences or Amazon's own published documentation example).

`--access restricted` decides *who may fetch* the artifact. Those three decide *what is in it*. Conflating them is what made the private posture feel like a security control rather than a launch-timing choice.

## Decision

**`@bongos/core` publishes as a public scoped package.**

- `buildPackageJson` sets `publishConfig.access: "public"`, and `publishArgs` passes `--access public`. Both, deliberately: the belt-and-braces of the restricted era, pointed the other way, so neither drifting alone can silently take the package back to private.
- **`.github/workflows/publish.yml` passes `--access public` too.** This is the site that actually releases — `package-core --publish` is the manual owner path. Flipping only `package-core.js` would have left every real release restricted while the code claimed otherwise: precisely the failure shape of task 1003870, where the workflow did not arm the gate its own header comment advertised. A test now reads the workflow and fails if `restricted` reappears anywhere in the lane.
- **The one-time registry flip is a separate, deliberate owner step:** `npm access set status=public @bongos/core`. `--access` on publish governs what *that publish* declares, and has historically been a no-op when re-publishing an already-private package. The package read `private` on the registry when this ADR was written, so the flag alone cannot be assumed sufficient — the flip is verified by a tokenless install from a clean `HOME`, not by the flag's presence.
- **Provenance stays off.** The *package* is public; the *source repository* is not. npm refuses to generate provenance from a private repo, so `NPM_CONFIG_PROVENANCE: 'false'` remains required until the source repository itself goes public. Turning it on before then fails every publish.
- **The npm path does not run ADR 0099's mirror pipeline, by design.** `package-core` performs its own redaction (476 docs redacted, 24 agent-docs stubbed, `package.json` synthesized). That is why gates 1–3 carry the whole safety burden here, and why they had to land first.

## Consequences

- `npm install @bongos/core` works from any machine with no credential. Co-tenant upgrades, the nightly sweep, cloud sessions and fresh scaffolds all stop needing a token they were never given.
- The sweep's `NPM_TOKEN` dependency becomes vestigial for reads. It should be removed from that path rather than left as a trap that appears to work.
- **[ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) is largely redundant and should be revisited, not deleted reflexively.** `@cloudbongos/cli` is published, works, and has a deliberately narrow verb set; the question is whether a public core makes it a maintenance burden or a still-useful thin entry point.
- **This does not fix the 22 co-tenants.** Twenty of them pin `file:vendor/bongos-core-<v>.tgz` — a local path with no registry channel to follow. Public access is necessary but not sufficient; converting them is separate work.
- The source repository stays private. Public package ≠ public repo, and nothing here changes who can read the source repository.
- Going public is effectively **one-way**. A published tarball is mirrored and cached beyond our control; `npm unpublish` has a 72-hour window and does not reach mirrors. This is why the flip is an owner action and why gates 1–3 were non-negotiable prerequisites.

## Rejected

- **A rank-gated registry proxy** — the server holds the npm token, builders authenticate with their existing Bongos CLI session, and the server proxies to npmjs.org after a per-request rank check. This is the correct design *if the core must stay private*: nothing is handed out, revocation is instant and per-builder, and every fetch is auditable. It was rejected because it manages the problem that going public deletes, and because it would entrench the private posture the owner chose to leave.
- **Handing builders the npm read token, gated by rank.** Rank-gating the handout does not rank-gate the use: a token, once held, is held forever and can be passed on, and revocation means rotating it for everyone. It is access control in name only.
- **Keeping the vendored-tarball path as the answer.** It is what co-tenants do today, and it is exactly why twenty of them are frozen on the version current at their provisioning date.
- **Making the repository public in the same change.** A larger decision with its own review, and not required for any of the benefits above. Keeping them separate also keeps the provenance question honest.
