# ADR 0322 — The five states are derived once, and a remnant needs evidence

- **Status:** Accepted
- **Date:** 2026-09-20
- **Task:** [task 1004103](https://cloudbongos.com/builders#/task/1004103) (BV2.R17, goal 1000095 — BONGOS-V2)
- **Spec:** `docs/specs/<redacted>.md` decisions 4, 19 and 20; criterion `ideator-sky-tells-the-truth`
- **Design of record:** `docs/design/ideator-surface-direction.md` §"The five objects"
- **Under:** [ADR 0321](0321-brightness-is-a-weighted-share-and-the-targets-are-a-row.md), [ADR 0313](0313-a-removal-is-proposed-by-the-ship-and-confirmed-by-a-person.md), [ADR 0312](0312-provenance-is-a-second-ideas-owned-edge-table.md)

## Context

The ideator surface draws a thought as one of five objects: **star** (it caused work that
is still alive), **protostar** (filed, not yet ignited), **satellite** (folded into another
thought), **remnant** (it burned, then the project removed it) and **cold body** (declined
at triage, so it never ignited and has no size at all). Dim and dark are different states
and must be different objects, not one dot at two opacities.

Three surfaces are about to draw them — the room (BV2.R03), the descent (R10) and the sky
(R20) — and the spec's own phrasing is that every state must be *computed from the ledger,
and no surface has to infer one*.

The facts already exist. `idea_inbox.status` carries the triage verdict (`open`,
`promoted`, `discarded`, `merged`; `core_195`). ADR 0321 gave economy `ideaBrightnesses()`,
returning `hasWork`, `share` and `attributable` per idea. `tasks.goal_id` and `tasks.status`
say where a thought's work sits and whether it awaits a nod. Nothing was missing; what was
missing was one place that reads them.

## Decision

**One resolver, `modules/ideas/idea-state.js`, and no surface decides a state.** A state
inferred in three renderers is three states: the sky can say a thought went out while the
room beside it still calls it alive, with nothing erroring and no way to tell which is
right. The resolver is pure — facts in, object out — the way `routing.js` is pure about a
landing. `attachStateToTrail` is the one async wrapper, composed on the trail route after
`attachSizeToTrail`.

**Brightness goes on the `reward` port.** `ideas` may not reach `credit_log` any other way
(ADR 0083 rule 1), and it already declares `reward` in `consumes`, so no new dependency
edge. Shipping size without brightness had left the module able to draw how big a thought
was and unable to say whether it was still alive.

**The order of the tests is the decision**, and each step could have gone the other way:

1. **Merged wins over everything.** A folded thought is a satellite even when it earned
   money of its own — and it *keeps* that money; `trail-size.js` is emphatic that stream 1
   books against the idea whose lineage row named the shipping task. This changes what the
   thought **is**, not what it earned. Letting work win here draws a satellite as an
   independent star beside the thought that absorbed it: one idea, twice in the sky.
2. **Work beats a discard.** The design defines a cold body as one that *"never ignited, so
   it has no size at all"* — a stated property, and testing work before status is what
   makes it true by construction rather than by hope. It is reachable: triage can discard a
   duplicate whose twin already routed and paid, and `updateIdea` never touches the ledger.
3. **A remnant needs evidence, never the absence of an answer.** `share === 0` means the
   project confirmed every piece of the descent gone. `share === null` means the removal
   facts could not be read at all — ADR 0321 is explicit that those are different answers.
   An idea with work and no readable facts is a **star** carrying `attributable: false`, so
   a surface says "unknown" rather than "full". Reading a falsy share as death turns one
   unmounted module into a sky of hollow rings.
4. **A protostar is the absence of work, not the presence of a status.** Ignition is being
   *paid* for something, not being converted into a row, so a promoted-but-unshipped idea is
   still unignited — which is exactly the state the nod queue exists for.

**Position is a second axis**, because the design says the object alone cannot carry it: a
protostar **in a well** has a home and awaits a nod; one in **open space** has nothing
holding it. The resolver returns `position`, `wellGoalId` and `awaitingNod` for every state
(a star has a position too), and the nod is asked of *every* task rather than only the one
that named the well — an idea that became two tasks, one promoted and one still at
`backlog`, still has something waiting on a person.

**`suggested_goal_id` is deliberately not a well.** It sits on the row, it names a goal, and
it is the wrong fact: `projection.js` records it as strictly advisory — the routing hint on
a filing that did **not** convert, with `tasks.goal_id` as the binding home. Reading it here
would draw a protostar inside a well that never caught it and put it in a nod queue nobody
can act on, because no task exists to promote. The binding fact is now selected on both of
the trail's task joins (`trail.js`), which costs no extra round trip.

**The page reads the ledger once.** `attachSizeToTrail` leaves economy's own `byTask`
breakdown on each row and brightness takes its share of exactly that, so the state attach
hands it straight back. All of the sizes or none: a partial map reads a missing entry as
"no work", which would draw a paid star as a protostar.

**An absent `reward` port does not empty the sky.** The states still resolve on status
alone, carrying `attributable: false` — the same posture `trail-size.js` takes with
`size: null`.

## Consequences

- `GET /inbox/by-builder/:id` now returns `state` per idea beside `size` and
  `descent_tasks`. Additive; no existing consumer reads it yet, and R03/R10/R20 will.
- The five objects are spelled once (`IDEA_STATES`), so a renderer switching on hand-copied
  strings cannot drift by a hyphen and silently draw nothing.
- Nothing here writes, and no credit moves. ADR 0313 stands: `shipped` is terminal, and
  only the picture changes.
- `tests/idea_state.mjs` (31 cases, DB-free). The ordering, the zero-over-zero edge, the
  well and the trail SQL are each mutation-probed.

## Rejected

- **Resolving the state in each renderer.** The cheapest thing to write and the reason the
  done-when says "no surface has to infer one".
- **Deriving the state from `share` alone.** It merges a protostar with a remnant — the
  precise distinction the two channels exist to draw, and the one BV2.R19's proof checks.
- **Treating an unreadable `share` as zero.** "We could not look" is not "everything was
  removed"; ADR 0321 pays for that distinction upstream and discarding it here wastes it.
- **Status-first ordering** (a discarded idea is always a cold body). It contradicts the
  object's own stated property the moment triage discards something that already paid.
- **Reading `suggested_goal_id` as a well.** Advisory by construction; it would populate a
  nod queue with entries nothing can act on.
- **A sixth object for "unknown brightness".** The vocabulary is the owner's and is five;
  the uncertainty is carried as a flag on the answer, not as a new thing in the sky.
