# ADR 0349 — A version preview is a sandboxed child the web tier launches, reached by a cookie

- **Status:** accepted
- **Date:** 2026-09-29
- **Task:** [task 1004300](https://cloudbongos.com/builders#/task/1004300) (goal 1000090 — BONGOS-V2); split out of [task 1002622](https://cloudbongos.com/builders#/task/1002622)
- **Deciders:** Lars (owner, Archon) approved both decisions below on 2026-09-29, in chat with the orchestrator: "Yes to cookie routing and web tier, build 1004300." Claude wrote the record.
- **Amends:** [ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md) D1, for this one feature only.
- **Related:** [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (authority is resolved per request) · [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (the control plane is a separate privilege domain) · [ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) (`requirePermission`) · [`docs/modules-contract.md`](../modules-contract.md) (the `request.divert` seam)

## Context

The owner asked for the version history on `/deploy` to open the hall **as it was at that
version**, with a banner saying which version it is. A release-notes page was rejected: the
point is to see, and to run a version's migrations against real data before that version goes
live. So a preview is a second Bongos process, running an installed copy of that core against
a copy of the live database.

Two questions had no safe default.

**How does a browser reach it?** The hall's pages call absolute `/api/bongos/...` URLs about
133 times across `modules/*/public`, and the hall is routed on the Host header
(`src/bongos/serve-internal.js`, `isBuildersHost`). Serving a preview under a `/preview/<v>/`
path would break both. A second origin would need its own GitHub OAuth app, an owner step.

**Who launches it?** ADR 0293 D1 keeps the web tier shell-less: it asks, and the control-plane
runner acts. That fits a privileged act like moving a pin. A preview is unprivileged by
design, and routing every start and stop through the intent queue would add a timer's latency
to something a person is waiting on.

## Decision

### D1 — Route by cookie, through an optional `request.divert` seam (owner)

`GET /api/bongos/npm-release/preview/enter?v=X` sets `bongos_preview=X` (HttpOnly, SameSite=Lax,
Path=/). A kernel middleware, mounted before any surface, asks an **optional** provider of the
`request.divert` seam whether to take the request. With no provider it is one map lookup and
`next()`: an instance without the npm-release module is served exactly as before. A provider
that throws is treated as absent for that request.

The npm-release provider forwards a request to the preview only when **all** hold:

- the cookie names the version now running;
- the path is not sign-in (`/api/bongos/auth/*`) and not the module's own preview routes, so
  signing in and **leaving** a preview always reach the live hall;
- there is no `Authorization` header (a CLI or API call is never a preview);
- the caller is signed in and holds `core.pin.move`, resolved by the kernel's own
  `requireBuilder` and `requirePermission` gates on **every** forwarded request, uncached
  (ADR 0016). A refusal clears the cookie and serves the live hall.

The proxy keeps the Host header, passes server-sent-events streams through unbuffered, strips
the steering cookie from what the preview sees, and injects the banner after `<body>` on HTML
responses, so a version older than any banner code still shows it.

The session cookie is forwarded: the preview's database is a copy, so the same session rows
exist in it and no second sign-in is needed. Anything done there stays in the copy.

**Rejected:** a `/preview/<v>/` path (breaks 133 absolute URLs and Host routing); a second
origin (an OAuth app per preview host, and cookies that no longer carry).

### D2 — The web tier launches the preview, as a sandboxed child (owner; amends ADR 0293 D1)

The npm-release module's supervisor installs the version, copies the database, migrates the
copy and spawns the child itself. This is the exception ADR 0293 D1 refuses for the deploy
door, granted here because a preview is not the deploy door: it changes nothing live.

What keeps that exception narrow:

- **The child's environment is built from nothing.** An allow-list of `PATH`, `NODE_ENV`,
  `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, plus its own `PORT`/`HOST` on 127.0.0.1. `HOME`
  is an empty scratch directory, so the Discord webhook file is not found. Every `GITHUB_*`,
  `DISCORD_*` and AI key is absent because nothing carries it, not because it was removed.
  `CHAT_DRY_RUN=1`; nine pollers off (`PUBLISH_RECONCILER_DISABLED`, `ROUTINE_TIMERS_DISABLED`,
  `BOARD_EXPIRY_DISABLED`, `SEARCH_INDEX_SWEEP_DISABLED`, `SESSION_UPLOAD_HEALTH_DISABLED`,
  `SESSION_REWARD_RECONCILE_DISABLED`, `PROVISIONING_LIVENESS_DISABLED`,
  `PROVISIONING_CATALOG_BACKFILL_DISABLED`, `CONFLICT_RESOLVE_DISABLED`); modules `discord`,
  `agents`, `provisioning` and `npm-release` off.
- **The copy is a dump and a restore, never a template copy.** `pg_dump -Fc` then `pg_restore
  --no-owner` into `bongos_preview`. A template copy needs no other connection on the source,
  and the live pool holds some. `PGDATABASE` is pinned to the copy and `DATABASE_URL` blanked
  for the migration, so nothing can be applied to the live database.
- **Commands run without a shell.** A version is `^\d+\.\d+\.\d+$` before it reaches any
  command line.
- **One preview at a time; 20 minutes idle stops it** and drops the copy.
- **Only published versions**, no older than the running version minus 30 published versions.
- **Nothing here holds a control-plane credential.** The web tier already cannot read
  `/etc/cloudbongos/box.env` (ADR 0327 §5); the child gets less than the web tier has.

### D3 — Accepted residual risks, for now

- The child connects to Postgres as the same role as the live hall (`PGUSER`), so a hostile
  published core could open the live database. It is our own published package, built from
  this repository by CI, and a preview is limited to `core.pin.move` holders; a per-preview
  database role is the next step, not built here.
- **No egress firewall yet** (owner default). The env allow-list means the child holds no
  outward credentials; it can still make anonymous outbound requests. `systemd-run
  IPAddressDeny` is the follow-up and needs the droplet.
- A preview started by the live process is stopped when that process exits, but the copy is
  dropped only by the next start or stop. It is one fixed name, so it cannot pile up.
- **Correction, 2026-09-30 (task 1004466): the proxy strips every upstream `Set-Cookie`.** Same origin means a cookie the child set replaced the live hall's own (`cb_stealth`, the session) and locked the owner out of `/deploy`. The child's cookies now stay with the child; the steering cookie is the only one this module writes, and its clear repeats the set's Path, SameSite and Secure.
- **Correction, 2026-10-01 (task 1004486): the child is handed `PGUSER`.** The droplet's hall connects by socket peer auth with no `PGUSER`, so the driver names its login from `USER`, which an environment built from nothing does not have: every query in the copy failed. When no `PGUSER` is carried, the child gets the OS user it runs as (the identity peer auth checks anyway). And the dump file, a full copy of the live database, is now deleted as soon as the restore has read it; a service restart had left one in `/tmp` for eleven hours.

## Consequences

- One new optional seam, `request.divert`, listed in `docs/modules-contract.md`.
- No migration. No schema. The provider is registered only where npm-release is on.
- **Part B is unverified until run on the droplet:** the `lars` role has CREATEDB, the unit's
  `MemoryMax` fits a second Node process plus a restore, the dump time, one preview end to end,
  and live row counts before and after. Until then the code is implemented, not verified.
