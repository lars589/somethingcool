# ADR 0316 — The ignite floor is a scheduling dial, not the trusted tier

- **Status:** Accepted
- **Date:** 2026-09-20
- **Task:** 1004084 (BV2.R05) · goal 1000095 · spec `docs/specs/<redacted>.md` decisions 3 and 16
- **Supersedes nothing.** Narrows how spec decision 3 is to be read.

## Context

BV2 decision 3 makes the **ignite floor** — who may turn a quick idea directly into
claimable work — a per-instance setting: "a project of one wants every thought
claimable; a project of fifty wants a nod." Decision 16 adds a second dial, the
**descent decay rate**, and rules that the two should share one home rather than
growing separately.

Both the spec and the seeded task described the implementation the same way: the
ignite floor *is* the `METIC_PLUS` constant in `modules/ideas/routing.js`, so this
is "a setting, not a refactor."

Tracing the code before building showed that premise is false. `METIC_PLUS` is
spelled once but **read for four semantically different gates**:

1. `decideLanding`, the homeless-bug branch — land at `ready` or at `backlog`.
2. `decideLanding`, the goal-carrying bug branch — the same split.
3. `mayProposeCriterion` (and the 403 in `routes/inbox.js`) — who may file a
   `kind='criterion-proposal'`, a planning-scope write that reshapes a version's
   scope-truth.
4. The protected-scope wall in `authorizeRoutedLanding` — who may route work into
   the permission / ship-grade / deploy / migration core.

Only (1) and (2) are the ignite floor. Making the *constant* configurable, as
written, would mean an instance setting its floor to `xenos` — precisely the
"project of one" case the owner asked for — would **also** grant every Xenos the
right to file criterion-proposals and to put rows into the protected core's queue.

The codebase already said so, in three places, and none of them had been read into
the spec:

- `routing.js` at the constant's definition: "It grants nothing — the server-side
  rank floor and the goal's scope wall are separate, load-bearing gates."
- The protected-scope branch: "the two are layers, not alternatives."
- `tests/filing_abuse_matrix.mjs` models the widening as an **attack**, recording
  in its header that "METIC_PLUS widened to include xenos ... 4 of 23 fail", and
  pinning the literal.

## Decision

**The ignite floor is a separate dial from the trusted tier, and only the dial is
configurable.**

- A new per-instance config home, `modules/ideas/config.js` +
  `config/ideas.neutral.json`, carries both dials. Precedence mirrors
  `modules/government/config.js`: env override → `config/ideas.json` at the
  **instance** root → `config/ideas.neutral.json` at the **core** root. The
  dual-root split matters here for the reason ADR 0268 records.
- `igniteFloor` defaults to `metic`, which resolves to exactly the `METIC_PLUS`
  set, so the default is a true no-op. It is threaded into `decideLanding` as a
  ready-made `trustedRanks` Set by the callers, keeping `routing.js` pure and
  free of both config and DB.
- `descentDecayRate` defaults to `0.5`. R11 is its intended consumer and has not
  landed, so it ships as a contract with no production caller — the same
  deliberate slice boundary `modules/government/config.js` documents for itself,
  and what decision 16 asked for when it said the two dials should share one home.
- **`METIC_PLUS` stays a fixed constant** for gates (3) and (4). Neither takes a
  floor argument, and `tests/ideas_config.mjs` asserts structurally that
  `authorizeRoutedLanding`'s signature never grows one.

## Consequences

- An instance may open its ignite floor all the way to `xenos` without opening any
  authority surface. The worst a wide-open floor can do is put a row at `ready`
  that a human can move back to `backlog`.
- The `filing_abuse_matrix` pin on the `METIC_PLUS` literal stays green and is not
  to be relaxed. A future change that needs to relax it is almost certainly the
  widening this ADR exists to refuse.
- `modules/ideas/config.js` derives the rank ladder from `api.LIVE_RANK_LADDER`
  on the doorway. The first cut restated it as a literal, reasoning that the file
  must resolve at load with no port wired; `tests/rank_tier_single_source.mjs`
  rejected that — a ladder array literal in a tracked `src`/`modules`/`scripts`
  file fails CI unless allowlisted — and it was right to. The doorway value is a
  lazy getter over the kernel this module's callers already load, so deriving
  costs nothing and removes the drift risk instead of merely detecting it.
- Spec decision 3's phrase "spelled in one place, so this is a setting, not a
  refactor" should be read as describing the *intent*, not the mechanism. The
  spec was not edited; this ADR is the correction of record, and the task
  description was amended in-flight to match.

## Alternatives considered

- **Make `METIC_PLUS` itself configurable, as written.** Rejected: it is a
  security widening wearing a config file's clothes, and the repo's own tests
  already classify it as an attack.
- **Split `METIC_PLUS` into four named constants and configure one.** Rejected as
  more churn than the decision needs — the other three gates want the *same* fixed
  tier, and giving them separate names invites someone to configure them later.
- **Have `routing.js` read the config itself.** Rejected: it would make the
  landing matrix non-pure and file-system-dependent, and would remove the
  callers' ability to be tested at a different floor.
