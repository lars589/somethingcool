# ADR 0344 — A tester is a project that opts in once; an untested version reaches everyone after seven days

- **Status:** accepted
- **Date:** 2026-09-28
- **Task:** [task 1003801](https://cloudbongos.com/builders#/task/1003801) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Will (owner of working area 5) chose the opt-in shape and the no-volunteer rule, and accepted the defaults for updates and tester pricing; Claude wrote the record.
- **Related:** [ADR 0338](0338-modules-travel-through-a-bongos-hosted-store.md) (the hosted store and its channel check) · [ADR 0343](0343-a-module-score-is-a-security-gate-then-an-average-of-visible-parts.md) (the security gate and tester feedback as a score part) · [ADR 0264](0264-the-ten-working-areas.md)

## Context

Criterion `wa5-staged-rollout` says willing users test a version before everyone gets it.
"Willing" was undecided, and the build depends on it. The open questions: does a project opt in
once or per module; who can opt in; what happens when nobody volunteers; does this cover
updates; and do testers pay.

## Decision

### D1 — A project opts in once, and can skip individual modules (owner)

Being a tester is a **per-project** setting, switched on by that project's own admin. A tester
project gets tester-channel versions of **every module it has**, except any module it has
switched to "general only".

- It is the **project**, not an individual builder, that opts in, because the project is what
  runs the module. A builder cannot opt in someone else's project.
- The switch is visible and reversible. Turning it off puts the project back on general
  versions from its next update.
- "Willing" is load-bearing: a project is never a tester by default.

### D2 — Testing covers updates, not only first releases

Every new version, first release or update, goes to the tester channel first. An update to a
module people already rely on is where an untested version does the most damage.

### D3 — An untested version reaches everyone after seven days (owner)

A new version moves from the tester channel to general **after seven days**, if it still passes
the security gate and its tests (ADR 0343). This applies whether or not any tester picked it up,
so a module nobody volunteers for still gets updated.

The seven days is the baseline. The promotion gate (task 1003804) may also promote **earlier** on
evidence (for example, enough clean tester installs) or **hold** a version on evidence (tester
errors), but it never holds one forever for lack of testers.

### D4 — Testers pay the normal price

A tester gets an early version of a module it already has, on the same terms. Being a tester is
not a way to get a paid module for free. **A discount or free access for testers is area 8's
call** (credits and payments, goal 1000092). This ADR names the question rather than deciding it.

### D5 — What testers see feeds the score

A tester project's install success, errors and crashes on a tester version are the tester
feedback part of the module's score (ADR 0343 D1, task 1003806).

## Consequences

- **Task 1003802** (opt in) builds a per-project tester switch plus a per-module
  "general only" override, on the project's own admin surface.
- **Task 1003803** (tester channel first) applies to every published version, updates included.
- **Task 1003804** (promotion gate) builds to D3: seven days by default, may promote earlier or
  hold on evidence, and never waits forever.
- **Task 1003805** (install/update honour the channel) serves a tester project tester versions,
  except for its "general only" modules.
- **Removal is unchanged.** Under ADR 0338 D2, a version a tester already installed keeps
  working even if it is later withdrawn.

## Rejected

- **Opt in per module only.** More control, but few projects would bother, leaving too few
  testers.
- **One all-or-nothing switch.** There'd be no way to avoid early versions of a module a project
  depends on heavily.
- **Waiting for a tester before general release.** A module nobody volunteers for would never be
  updated.
- **Releasing to everyone at once.** Testing would only happen when volunteers happened to be
  there.
