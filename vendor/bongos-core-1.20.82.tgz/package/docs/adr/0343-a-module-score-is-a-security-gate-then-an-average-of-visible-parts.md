# ADR 0343 — A module's score is a security gate, then an average of parts every buyer can see

- **Status:** accepted
- **Date:** 2026-09-28
- **Task:** [task 1003790](https://cloudbongos.com/builders#/task/1003790) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Will (owner of working area 5) chose how the signals combine, and added that each part's score must be visible; Claude inventoried the measurable signals and wrote the record.
- **Related:** [ADR 0338](0338-modules-travel-through-a-bongos-hosted-store.md) (the hosted store) · [ADR 0342](0342-module-categories-are-eight-parents-with-approved-sub-categories.md) (the sub-category the ranking runs in) · [ADR 0027](0027-bfg-session-inefficiency-evaluator.md) (prior art: a multi-dimension evaluation) · [session log 2026-09-10](../session-logs/2026-09-10-goal-1000091-area-5-criteria.md)

## Context

Criterion `wa5-quality-assessed` says Bongos scores each module **from what the platform can
measure itself**, with a Metic+ override and delist, and free modules assessed identically. No
module score exists today. `bongos module check` is a pass/fail submit gate, not a grade. The
quality floor (task 1003807), the ranking (task 1003808) and the cap (task 1003809) all derive
from this score. That makes the formula the thing an author appeals against, so it has to be
explainable in a sentence.

## Decision

### D1 — The parts, and when each one arrives

| Part | What it measures | Available |
|---|---|---|
| **Security** | dependency and code scan (task 1003792) | day one |
| **Tests** | pass rate of the module's own tests, run by the platform (task 1003791) | day one |
| **Install** | share of installs that complete cleanly (task 1003793) | once real installs exist |
| **Reliability** | runtime error and crash rate from real installs (task 1003793) | once real installs exist |
| **Tester feedback** | what testers hit during staged rollout (task 1003806) | once staged rollout exists |

Each part is scored 0–100 per module **version**, because a new version can be better or worse
than the last.

> **Amended by [ADR 0347](0347-every-store-module-ships-a-how-to.md):** adds a **Docs** part (the how-to, scored day one), shown with the parts but not in the D3 average.

### D2 — Security is a gate, not an ingredient

A version that **fails the security check is not listed**, whatever else it scores. Security is
never averaged in, so a module can't make up for a vulnerability with good tests.

### D3 — The overall score is the plain average of the other parts that have data

Overall = the unweighted average of whichever of Tests, Install, Reliability and Tester
feedback have data for that version. A part with no data yet is left out, not counted as zero.

Unweighted on purpose: an author who asks "why did I score 71?" gets an answer they can check
themselves. Weights can be added later by a superseding ADR, if real data shows one part
predicts quality better than the others.

### D4 — Every part is visible, not just the overall number (owner)

The owner's addition: **each part's score is shown to buyers alongside the overall score**, so
someone comparing two modules can pick the one that is strongest where it matters to them. One
buyer might care most about reliability, another about test coverage. The overall number sorts
the listing; the parts explain it. This is the requirement tasks 1003798 (store per-part
scores) and 1003799 (show strengths and weaknesses in the API and hall) build to.

### D5 — A version without real-world data is labelled "New", not scored low

Until a version has Install or Reliability data, it shows as **New**, with its day-one parts
(Security passed, Tests score) visible. It isn't pushed below the floor for lacking data it
couldn't have yet. The floor and the ranking decide how New modules are placed (tasks 1003807,
1003808). This ADR only says a missing part is never a zero.

### D6 — Free and paid are scored identically; Metic+ can override with an audit entry

Price is never an input. The Metic+ override (task 1003796) and delist (task 1003797) sit on
top of the computed score and never replace how it is computed. Every override is recorded.

## Consequences

- **Day one, only Tests counts toward the overall score**, behind the Security gate. The number
  becomes more meaningful as installs and testers arrive. The "New" label (D5) makes that honest
  rather than hidden.
- **Re-assessment runs per version** (task 1003794) and whenever new install, reliability or
  tester data arrives.
- **A score an author can reproduce** is the appeal path: every part and the averaging rule are
  public.

## Rejected

- **A simple average including security.** A module with a known vulnerability could still
  score well.
- **A weighted average from day one.** The weights would be guesses, and harder to justify to an
  author asking why they scored low.
- **One overall number only.** Two modules with the same score can be good at different things,
  and the owner wants buyers to see that.
- **Counting a missing part as zero.** It would punish every new module for data it couldn't
  have yet.
