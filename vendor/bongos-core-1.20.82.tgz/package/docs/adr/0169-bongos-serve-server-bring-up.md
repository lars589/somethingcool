# 0169 — `bongos serve`: the `bongos dev` boot path, on a real host

- **Status:** Accepted
- **Date:** 2026-08-13
- **Task:** [#1002398](https://cloudbongos.com/builders#/task/1002398) (goal 1000052 — first-run onboarding), depends on [#1002397](https://cloudbongos.com/builders#/task/1002397).
- **Extends:** [ADR 0149](0149-bongos-dev-local-launcher.md) (`bongos dev`, the local launcher). Sibling of [ADR 0108 §4](0108-instance-composition-configurable-root.md) / [`instance-deploy.md`](../recipes/instance-deploy.md) (the *pinned-core consumer* deploy) and `provision.js` (the *control-plane* cloud path).

## Context

ADR 0149 shipped `bongos dev`: one idempotent command that stands an instance up **on the owner's laptop**. The obvious next question — "great, now put it on a server" — had no equally good answer:

| Path to a real host | Why it didn't close the gap |
|---|---|
| Docker ([`self-host.md`](../recipes/self-host.md)) | serves the **vanilla** brand on `:3000`; matching the repo's brand + port needs a compose override |
| `bongos onboard` → `provision.js` | provisions a **whole droplet** through the control plane — needs a public domain plus DigitalOcean/Cloudflare tokens |
| [`instance-deploy.md`](../recipes/instance-deploy.md) | describes the right shape, but the systemd unit is a **hand-written prose step** ("create a systemd unit for the instance…") — no script in the core writes one |

So an owner with a plain VPS — the most ordinary hosting story there is — was back to hand-assembly, and hand-assembly is where ADR 0149's three silent mismatches (port, DB name, socket) came from in the first place.

The boot path itself is *already right* for a server: deps → Postgres → createdb → migrate → env → server → health is exactly what a host needs. Only four **decisions inside it** are laptop-shaped.

## Decision

Ship **`bongos serve`** — the same script, the same six steps, with `--server` pinned on (`bongos dev --server` is the same thing). Not a second boot path: a **mode** on the existing one, so the two can't drift.

Four decisions change, each derived rather than asked:

1. **Supervision — a systemd unit, not a pid file.** The laptop's detached-with-a-pid-file process is right for a laptop and wrong for a host: it dies on reboot, has no restart policy, and logs to `/tmp`. Server mode writes `/etc/systemd/system/bongos-<db>.service` (`Restart=always`, `WantedBy=multi-user.target`), `daemon-reload`s, and `enable --now`s it — so the host's own supervisor owns the process. Where systemd is absent (a container, a BSD, an operator without root) it **falls back** to the pid-managed process with a loud warning rather than refusing.
2. **Bind address — derived from the origin.** `https://…` means something already terminates TLS in front of us, so bind `127.0.0.1`; plain `http://` on a public hostname means nothing is in front yet, so bind `0.0.0.0`. `--bind` (or `HOST`) still wins. An operator never has to reason about it, and the common misconfiguration — an app bound to `0.0.0.0` behind a proxy, publicly reachable on its raw port — can't happen by default.
3. **A fresh Postgres cluster gets bootstrapped.** `apt-get install postgresql` creates exactly one role — `postgres`, peer-auth only — so a deploy user's `createdb` fails with `role "deploy" does not exist`. That reads like a broken install and is really an unbootstrapped cluster. On that specific error we create the login role + its database as the postgres superuser (`sudo -u postgres`, or `su postgres -c` for root on a sudo-less image). This is the fresh-Debian wall, and it is the one step most likely to end a first server run.
4. **Health means the *public* origin, not loopback.** The loopback probe proves the app; on a host the interesting failures are DNS, the proxy, and TLS — all of which sit outside it. Server mode probes `publicOrigin/healthz` too and, when it can't be reached, says which layer is missing. It is **advisory**: DNS legitimately may not be wired yet, so this warns and still exits 0.

Plus: no auto-login (a host has no browser — it prints `bongos login <origin>` instead).

**Secrets go to an `EnvironmentFile`, never `Environment=`.** The unit carries only the eight keys the boot path resolves; `PGPASSWORD` and the GitHub OAuth creds go to a root-owned `0600` `/etc/bongos/<service>.env`, created once and never overwritten. Two reasons: `systemctl show` exposes `Environment=` to any user on the box, and the laptop path's `buildEnv()` spreads the *caller's whole environment* — baking a builder's shell (tokens included) into a root-owned file. `unitEnvironment()` is a deliberately separate, allowlisted function for exactly that reason.

As with ADR 0149, every decision above is a **pure, injectable function** in `dev-lib.js` (`deriveBindHost`, `systemdPlan`, `pgStartPlan`, `pgBootstrapPlan`, `renderSystemdUnit`, `unitEnvironment`, `parseSub`); `dev.js` only executes them. `tests/dev_lib.mjs` proves all of it with no host, no spawn, and no network.

## Alternatives considered

- **A separate `deploy.sh`** — would have duplicated the boot path, which is precisely how the laptop and server paths would drift. Rejected: the whole value is that it's the *same* six steps.
- **Docker on the host** — real, and still the right answer for a container platform, but it makes the instance's own brand/port a compose-override exercise and puts a container runtime between an owner and a $5 VPS. Kept as the parallel path.
- **Always bind `0.0.0.0`** — simpler to explain, but publishes the raw app port on every host that has a proxy in front. Rejected on that alone.
- **Refuse without systemd** — cleaner contract, but would fail on containers and BSDs where the pid-managed fallback works fine. Rejected in favour of a warning.

## Consequences

- A plain VPS goes from `git clone` to a supervised, reboot-surviving instance with `npm install` then `bongos serve` — the same two commands as the laptop.
- `bongos serve stop` **stops and disables** the unit, so "stopped" survives a reboot; `bongos serve` re-enables it. Asymmetric with `bongos dev stop` (which only kills a process) because on a host the two verbs mean different things.
- The unit is a *starting point*, not a hardened production profile — no `ProtectSystem`, no resource limits, no log shipping. An operator with opinions should edit it; a re-run rewrites it, so persistent customisation belongs in a systemd drop-in (`/etc/systemd/system/bongos-<db>.service.d/`).
- TLS/proxy/DNS stay **out of scope** — deliberately. Those are the host's business and vary per operator; `bongos serve` tells you when they're the missing piece and points at [`server-bring-up.md`](../recipes/server-bring-up.md).
- Windows is still not a native path (migrations need `bash`), unchanged from ADR 0149.
