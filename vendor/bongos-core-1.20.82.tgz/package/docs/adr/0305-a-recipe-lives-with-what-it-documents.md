# ADR 0305 — A recipe lives with what it documents

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1002156](https://cloudbongos.com/builders#/task/1002156) (goal 1000091 — BONGOS-V2)

**Related:** [ADR 0098](0098-public-mirror-publish-manifest.md) (`isPublishable()` — the default-deny publish boundary this ADR re-aims) · [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) (submit → review → accept; the lifecycle this ADR declines to duplicate) · [ADR 0135](0135-module-upstream-submission-interim-queue.md) (the submission queue) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the module loader and its one-way import boundary) · [ADR 0062](0062-medusa-instance-model-decoupling.md) §1 (the portable-core / host-instance / feature-module cut-line) · [ADR 0108](0108-instance-composition-configurable-root.md) §1 (the core is consumed as a versioned npm package)

## Context

This is part A of the 2026-07-10 architecture-review sweep — the redesign deliberately
deferred until direction and learnings solidified (idea 536 / idea 537; part B shipped as
task 2155). It was held on the owner's explicit instruction not to start the ADR until the
direction was confirmed. That confirmation came on 2026-09-17.

**The thesis.** `docs/recipes/`, `scripts/` and `docs/research/` are all relevant to
*building* Cloud Bongos, but a new project built *on* Cloud Bongos wants only a subset.
Today the split is binary per file: [`scripts/gds/publish-manifest.js`](../../scripts/gds/publish-manifest.js)'s
`isPublishable()` either ships a file to every instance or traps it in this repo. The thesis
asks whether some of these assets should instead be **shareable the way modules are** —
authored, reviewed, accepted, opt-in installed.

**The binary split has already collapsed to one side.** Measured on this commit: all **36**
files in `docs/recipes/` and all **4** in `docs/research/` pass `isPublishable()`. Every one
ships to every instance. The instance-local half is empty in practice — the denylist entries
that used to hold it (`cloudbongos-standup.md`, `example-decouple-r89.md`,
`staging-data.md`) name files that no longer exist. The gate itself is sound; there is simply
nothing on the other side of it any more. So a fresh instance today receives
`figma-design-loop.md`, `redteam-patrol.md` and `parallel-goal-waves.md` whether or not any
of it applies to that instance.

**And the split is actively producing wrong documentation.** Four published recipes document
the dev-box: `devbox-app-release.md`, `devbox-app-windows-test.md`,
`work-on-a-task-from-your-dev-box.md`, `builder-box-lifecycle.md`. Goal 1000091 is in the
middle of deleting that module. None of the nine remaining removal tasks covers these four —
only task 1003896 touches `docs/recipes/`, and only to strip devcontainer mentions. Filed as
[task 1004013](https://cloudbongos.com/builders#/task/1004013).

That is the finding this ADR turns on. The recipes did not go stale through neglect; they
went stale because **nothing structurally ties a recipe to the thing it documents**. The
module is deleted in `modules/`, the recipe sits in `docs/recipes/`, and no test, no fitness
check and no reviewer diff connects them. A published doc for a deleted feature is worse than
no doc: it is a confident wrong answer, and `search-ingest-md` ingests it into the very index
builders are told to consult.

## Decision

### 1. The rule: a recipe lives with what it documents.

Not "which recipes are portable" — that is the question the binary split already answers
badly, one file at a time, by hand, forever. The durable question is *ownership*. A recipe
belongs in the same deletable unit as its subject, so that removing the subject removes the
recipe as a matter of file layout rather than of anybody remembering.

This yields a three-way classification, applied per file:

| Class | Home | Lifecycle |
| --- | --- | --- |
| **Core methodology** — how to operate *any* instance | `docs/recipes/` (unchanged) | ships with the core, not optional |
| **Feature-coupled** — how to use one module | `modules/<key>/recipes/` | ships, installs and **is deleted** with its module |
| **Instance-operational** — this host's own ops | instance-local, denied by `isPublishable()` | never leaves the instance |

### 2. `scripts/` stays core-shipped, whole.

`scripts/` is not documentation with a portability question; it is the CLI. `bin/` dispatches
into it, the fitness checks, ship gates and publish boundary *are* files in it, and
`isPublishable()` already allowlists the subtree with deploy denied. Splitting it per file
would make the core's own tooling conditional on an install choice. No change.

### 3. `docs/research/` becomes instance-local.

The four items are this instance's competitive analysis, its grader-cost evaluation and its
own task-network map. They are situated artifacts: findings about *this* project at a moment
in time, not methodology another instance can run. They are also the surface most likely to
carry a brand-name leak, since nothing about them was written to be portable. Deny the
subtree; keep any genuinely portable finding by promoting it into an ADR, which is the
artifact class that already exists for durable conclusions.

### 4. A shared recipe is a module contribution, not a new registry.

This is the half of the thesis that is **rejected in its literal form**. The task asks whether
recipes should become "a NEW shareable/opt-in asset class parallel to modules". They should
not be parallel to modules. They should be *carried by* modules.

A module already has every mechanism a shareable recipe needs, all of it built and shipped:
a validated manifest with `author` / `origin` / `license` / `maintainer`
([`manifest-schema.js`](../../src/module-loader/manifest-schema.js) `ATTRIBUTION_KEYS`),
submit → review → accept with a security review as a hard accept-gate (ADR 0107 §1, §5),
a submissions table (`migrations/core_191_module_submissions.sql`), default-off enablement
plus the publish-allowlist *as* the accept action (ADR 0107 §6), and a maintenance/orphaning
policy that refuses a `maintained` status without a named maintainer (ADR 0166).

Building a second registry would mean a second manifest, a second review queue, a second
attribution model and a second orphaning policy — to distribute Markdown. The precedent is
already on disk and nobody designed it: `modules/ui-design/docs/design-contract.md` is a
module-owned document that ships and dies with its module, and it has never needed a registry.

So: **no new asset class, no new lifecycle, no new CLI verb.** A recipe pack is a directory
inside a module. `bongos module submit` already carries it; enabling the module installs it;
deleting the module deletes it.

### 5. The publish boundary follows the layout; it does not define it.

`isPublishable()` keeps its default-deny two-layer design unchanged (ADR 0098). What changes
is that it stops being the *only* thing standing between a stale recipe and every instance.
Once a feature-coupled recipe lives under `modules/<key>/`, the existing module allowlist
entries already govern it and no per-file denylist row is needed. Per-file rows remain only
for the instance-operational class — the one case where a file must stay behind for reasons
the directory structure cannot express.

### 6. Sequencing.

This ADR decides direction only. It changes no code and moves no file. The moves are follow-on
work, and the dev-box four ([task 1004013](https://cloudbongos.com/builders#/task/1004013))
are deliberately *not* folded into it: that module is being deleted this goal, so its recipes
should be deleted outright rather than relocated into a directory that is about to disappear.
They are the worked example of the problem, not the first migration.

## Alternatives considered (rejected)

**A new shareable asset class parallel to modules** (the thesis as literally written; the
Chef Supermarket / Ansible Galaxy / Terraform-registry shape). Rejected on cost against an
already-built alternative: it duplicates the manifest, review queue, attribution model and
orphaning policy that ADR 0107 and ADR 0135 already ship, and it would leave a recipe's
lifecycle *still* unconnected to its subject's — the actual defect. The prior art also does
not transfer cleanly: Supermarket and Galaxy distribute executable units with dependency
resolution, which is what a module already is here. A recipe has no dependencies to resolve.

**Keep the binary split and fix it by classification** (the cheaper option the owner was
offered). Rejected because it treats the symptom. Hand-classifying 36 files restores the
instance-local half for exactly as long as it takes the next module to ship a recipe, and it
does nothing to stop the next dev-box four — under this option those are found by a human
reading `ls docs/recipes/`, which is exactly how the ADR-numbering collision behind
[ADR 0300](0300-a-missing-protected-surface-registry-is-a-broken-install.md)'s sibling guard
was found, and the lesson there was to make the structure enforce the rule.

**Per-recipe front-matter declaring portability.** Rejected: it puts the ownership claim in a
place no build step reads and no deletion touches. A `portable: false` key in a file whose
module was deleted is still a file in `docs/recipes/`.

**Delete `docs/research/` rather than make it instance-local.** Rejected: the grader-cost
evaluation and the competitive analysis are live inputs to open goals. Instance-local is the
correct home for a situated artifact, not the bin.

## Consequences

- **The stale-recipe class of defect stops being possible for module-coupled docs.** Deleting
  `modules/<key>/` takes its recipes with it, in the same commit, visible in the same diff.
- **A fresh instance receives less.** Recipes for modules it has not enabled no longer arrive.
  That is the thesis's goal, and it is what makes the core's own documentation honest about
  what is installed.
- **Module authors gain a documentation surface with attribution already attached** — the
  `author` / `origin` credit ADR 0107 §2 defines now covers the recipe as well as the code.
- **Follow-on work is a sweep, not a build.** Classify the 36 recipes against §1, move the
  feature-coupled ones into their modules, deny `docs/research/`, and add a fitness check that
  fails when a recipe under `modules/<key>/recipes/` outlives its module. No new machinery.
- **Revisit if a recipe ever needs to ship without a module to carry it.** That is the one
  shape this decision cannot express, and it would be the real argument for §4's rejected
  alternative. Nothing in the current 36 has it.
