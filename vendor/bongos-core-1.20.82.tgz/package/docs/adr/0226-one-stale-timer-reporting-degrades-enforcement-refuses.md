# 0226 — One stale-claim timer; reporting degrades where enforcement refuses

- **Status:** Accepted
- **Date:** 2026-08-28
- **Tasks:** [#1003476](https://cloudbongos.com/builders#/task/1003476)
- **Goal:** [#1000072](https://cloudbongos.com/builders#/goal/1000072) — Human legibility, criterion `legibility-sort-and-staleness`.
- **Builds on:** [#1003278](https://cloudbongos.com/builders#/task/1003278), which gave both work boards a shared *task* staleness vocabulary and left this one — the *claim* timer — named in a comment as the thing still to wire.
- **Split out of:** [#1003279](https://cloudbongos.com/builders#/task/1003279) on 2026-09-02. This work was authored under that task’s claim, but it answers a different question than that task’s DONE WHEN: 1003279 is the needs-attention **inbox item** a stale *goal or task* raises (with the verbs prune / kill / prioritise / water), and §4 below records that the *task* staleness buckets and a settings knob were deliberately **rejected** as out of scope here. It ships under its own task so the ledger says what the diff does; 1003279 stays open for its inbox half.

## 1. The problem: one question, four answers, none of them the project's

"How long may a claim go silent before this project calls it abandoned" was
answered independently in four places:

| Surface | Number | Where it came from | What it does |
|---|---|---|---|
| `scripts/gds/pulse.js --release-stale` | **6h** | `GDS_STALE_CLAIM_HOURS`, else a literal `6` | **acts** — releases the claim, stamps the session log `[auto-released:stale]`, returns the task to `ready`, pings the builder |
| `GET /builders/roster` → `getBuildersRoster` | **24h** | a literal, twice (route and db helper) | **reports** — the `stale_claim` flag on the Archon roster |
| `GET /builders/:id/active-claims` → `<redacted>` | **24h** | a second, byte-identical literal | **reports** — which claim to target for release |
| `sweepStaleClaims` / `getStaleClaimsForBuilder` | **30 min** | a default parameter | whatever an argument-less caller wanted |

The 6-vs-24 pair is the one that hurt. The roster is the screen an Archon opens
to decide whether to intervene, and for **eighteen hours** after the sweeper had
already released a claim, tagged it and handed the task back to the queue, that
screen still showed it healthy. Neither file is wrong when read alone — the
roster's own comment even says it "mirrors the threshold the stale-claim-release
sweeper uses", which was true of the *definition* and false of the *number*. A
mirror that copies the shape and not the value is worse than no mirror: it reads
as a guarantee.

This is the shape goal 1000072 exists to close. A person steering an AI-run
project is steering by what the surfaces tell them, so a surface that reports a
different rule from the one the machine enforces is not a cosmetic defect.

## 2. Decision

**One resolver owns the timer, and every surface that reports or enforces
staleness reads it.** `src/stale-timer.js` — a KERNEL file, in the same category
as `instance-config.js` and `branding.js`: host configuration a module reads
rather than hardcodes. Exposed to modules through the doorway
(`api.resolveStaleClaimHours`), required directly by core routes and by the CLI.

Precedence, widest scope last:

1. **An explicit override** — `--threshold-hours`, `?stale_hours=N`. A *lens*, not
   a reconfiguration: an Archon asking "what would 48h show me?" must not change
   what the project does, and the response labels the answer `query` so the
   distinction survives into the payload.
2. **`<PREFIX>_STALE_CLAIM_HOURS`** — the project's configured timer, resolved
   through `instance-config.resolveEnv`, whose legacy prefix chain still honours
   the `GDS_STALE_CLAIM_HOURS` the live sweeper has always read. **Nothing in a
   running deployment has to change for this to resolve to what it resolves to
   today.** This is also the channel a platform-managed project already has: the
   provisioning runner patches `web.env` in place and restarts ([ADR 0190](0190-settings-apply-in-place-env-patch.md)).
3. **`6`** — the default. Deliberately the *sweeper's* historical number and not
   the roster's 24: the sweeper is the surface that acts, and adopting 24 would
   have quietly made every project three times more patient with a dead claim
   while looking like a tidy-up.

The bound is **1..720 hours** — not taste: `GET /builders/roster` has published
`1..720` as its `stale_hours` contract since V3.R14, and one timer means one
bound. (Sub-hour values were previously accepted by that route despite the
published range; they are now rejected, consistent with what it always claimed.)

**Every surface that prints the timer prints where it came from.** The sweep
header and the auto-release note carry the source; both roster reads return
`stale_hours_source`. A number with no provenance is precisely what let 6 and 24
sit side by side in the ops log for a year.

## 3. The part that is not obvious: the fail posture is asymmetric

A misconfigured timer must not silently become a different policy. But the two
kinds of caller cannot want the same thing from a bad value, so the resolver
**reports** rather than throws, and each caller states its own posture:

- **Reporting degrades.** A read-only surface takes the default and labels the
  source `default (invalid <VAR>="…": …)`. A 500 here would take down the roster
  an Archon opened *to find the problem*, and hide the typo behind an error page;
  answering with the default and naming the bad value puts it on the screen of
  the one person who can fix it.
- **Enforcement refuses.** The sweep declines to run at all. It releases other
  people's claims and stamps their session logs, and no reload undoes that — so
  "probably 6" is not an answer it is allowed to give. An explicit
  `--threshold-hours` that is unusable is likewise a usage error, as before.

Stated as a rule: **a surface that only reads may guess and say so; a surface
that acts may not guess.**

## 4. What was rejected

- **A new `config/stale.json` pair.** The env route already *is* the per-project
  channel (the runner writes `web.env`), and a config file would have added a
  fourth tier to a precedence whose whole point is that there is one place to
  look.
- **Making the roster's 24 the shared default.** It is the number nothing acted
  on. Unifying on it changes real behaviour under cover of a refactor.
- **Throwing from the resolver.** It would have forced the roster to either 500
  or re-implement the fallback, which is a second reader — the original bug.
- **Folding in the boards' 14/30/60-day task buckets.** A different question:
  those are *days*, about a *task* going untouched, and they are a browsing lens
  with no enforcement behind them. Two questions may have two vocabularies; only
  one of them may be a number typed twice.
- **A DB row + settings UI for the timer.** A reasonable next step, and out of
  scope here: the defect was four numbers, not the absence of a knob. Adding a
  row before the readers agreed would have produced a fifth.

## 5. Consequences

- `GET /builders/roster` and `GET /builders/:id/active-claims` gain
  `stale_hours_source`; their default `stale_hours` changes from `24` to the
  project timer (`6` unless configured). Additive to the payload; the default is
  a **deliberate** behaviour change — it is the fix.
- Both routes now share one `staleHoursFor(req, res)` helper. Two copies of a
  literal is how the drift happened twice in one file.
- `sweepStaleClaims` / `getStaleClaimsForBuilder` no longer have a number of
  their own; an argument-less call means the project's timer, resolved per call
  so an env change lands on the next sweep and not the next restart.
- Pinned by `tests/stale_timer.mjs` (the resolver executed, the sameness of every
  surface asserted, and both fail postures) plus the updated roster assertions in
  `tests/onboarding_observability.mjs` — whose old `stale_hours === 24` line *was*
  the eighteen-hour lie, written down as an expectation.
