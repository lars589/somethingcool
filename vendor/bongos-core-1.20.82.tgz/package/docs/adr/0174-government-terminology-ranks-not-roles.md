# 0174 — Governance is renamed government, its positions are ranks, and "role" is reserved for the three crafts

- **Status:** Accepted
- **Date:** 2026-08-16
- **Task:** [#1003002](https://cloudbongos.com/builders#/task/1003002) (R01 of goal 1000068 — government terminology)
- **Amends:** ADR 0151 and ADR 0172 (the editable-rank-roles one) — **vocabulary only**. Every decision either ADR made survives unchanged.
- **Related:** ADR 0016 (trust boundary — server-enforced, uncached, per request), 0043 (git/ssh trust boundary + the rank floor on protected paths), 0086 (goals + scope walls), 0157 (Archon is rank and identity only)

## Context

The word **role** currently names two unrelated things in this codebase, and a third thing is about to claim it.

1. **The permission system's positions.** `governance_roles` holds the four ladder tiers — Newcomer/`xenos`, Contributor/`thetes`, Trusted/`metic`, Owner/`archon` — plus any hand-composed permission bundles an Owner creates. Its key column is `role_key`. `governance_builder_roles` assigns them; `governance_role_permissions` grants to them. Throughout the module and its ADRs these are called *rank-roles*, which is itself a tell: the name needs a qualifier because the noun was already doing other work.

2. **The three crafts.** `tasks.discipline` and `builders.preferred_disciplines` carry `engineer` / `artist` / `ideator` (plus a `ui` value scoped for deletion, and `unclassified`) — migrations 014, 086, 176. Goal 1000066 is actively renaming these to **roles**: its criteria are literally `three-roles-only` and `users-hold-roles`, and its design treats Artist, Ideator, and Builder as the roles a session runs as.

3. **Discord's server roles.** `modules/discord/discord-role-sync.js` mirrors a builder's rank onto a Discord role badge. This is Discord's own noun for its own concept, reached through its API.

So goal 1000066 was on a collision course with the permission module: both would call their central entity a "role", in the same codebase, resolved on the same requests. The owner settled it by directive on 2026-08-16:

> *"Governance should be called government. Ranks are the positions in government. The name roles should be reserved for the three core roles of Cloud Bongos. Artist, Ideator, and Builder."*

Two facts made the rename cheap enough to do at full depth rather than as a label pass. The rank tiers' grants are ordinary `governance_role_permissions` rows (ADR 0172 established this when it made them editable), so nothing needs remodelling — only renaming. And the substantive authority work is already done and settled: ADR 0151 built the permission model, ADR 0157 fixed what Archon means, ADR 0172 made the tiers editable. There is no pending decision this rename would have to be sequenced around.

## Decision

**1. Governance becomes government, at full depth.** `modules/governance/` → `modules/government/`; the kernel module key `governance` → `government`; `config/governance.neutral.json` and `config/governance.json` → `config/government.neutral.json` and `config/government.json`; the API from `/api/bongos/governance/*` to `/api/bongos/government/*`; the permission keys `governance.manage` → `government.manage` (~50 call sites) and `page.view.governance` → `page.view.government`. Half-measures were considered and rejected: a labels-only pass leaves the UI and the code disagreeing, which is the exact condition that produced this collision.

**2. The positions in the government are ranks. The entity IS the rank — there is no second noun.** `governance_roles` → `government_ranks`, `governance_builder_roles` → `government_builder_ranks`, `governance_role_permissions` → `government_rank_permissions`, and the `role_key` column → `rank_key`. "Position" is the word for explaining what a rank *is* in prose; it is not a code term, because introducing it as one would recreate the qualifier problem that "rank-role" already demonstrates. `rank-roles.js` → `ranks.js`, and its exports `planRankRoleSync` / `isSeededRankRole` → `planRankSync` / `isSeededRank`.

**3. The kernel port `governance.roleSync` becomes `government.rankSync`.** This is a cross-module seam, not an internal name: it is declared in `modules/governance/module.json` under `provides`, and resolved through `seams.resolveOptional` by `modules/lifecycle/db.js` and `src/bongos/db.js` on the rank-write path. It is also a transaction participant — a failed rotation rolls the rank write back — so the rename must land atomically across the provider and both consumers, never as a partial sweep.

**4. Hand-composed permission bundles stay in the one table, as custom ranks.** They keep living in `government_ranks`, distinguished exactly as today by `seeded_rank` and `is_system`.

This was the closest call in the directive, and it was decided against the alternative deliberately. The objection is real: a custom bundle is *not* a position on the ladder, it is assigned by hand rather than derived from `builders.rank`, and ADR 0172 §4 already treats the two kinds as different enough that it widened one and refused to widen the other. Splitting them into a second concept — "appointments" was the candidate — would make that existing asymmetry structural instead of implicit. The owner chose the single table anyway, because it keeps this migration a pure rename with no restructuring of a store that every authenticated request reads. Recorded here so the next reader inherits the trade-off rather than rediscovering it: if the Government tab reads wrong once the labels land, splitting is a follow-up goal, not a defect in this one.

**5. "Role" means a craft — Artist, Ideator, or Builder — and nothing else.** Enforced, not merely documented: a rule in `scripts/gds/fitness.js` fails the CI `unit` check if "role" reappears on the government side, or if "governance" reappears outside the historical record. The rule ships with its allowlist and a one-line reason per entry, because a check that passes through blanket suppression reads as evidence while proving nothing.

**6. Discord's server roles keep the word.** `modules/discord/discord-role-sync.js` and everything it touches are out of scope. That noun belongs to Discord's API; renaming our side of the boundary would make our code describe their system incorrectly. The fitness rule from Decision 5 scopes to the government surface, not to `modules/discord/`.

**Explicitly unchanged.** The ladder slugs `xenos`/`thetes`/`metic`/`archon` and their labels Newcomer/Contributor/Trusted/Owner. `builders.rank`. `requireRank`. Every floor, grant, and assignment semantic. ADR 0043's out-of-band enforcement, which reads the rank ladder and never consults this database. This ADR moves no authority; it renames the things that hold it.

## Consequences

**The scope wall has to be widened before the folder moves, not after.** The kernel module key is load-bearing in a way a folder name usually is not: `MODULE_GLOBS` maps keys to file globs, and every goal's `scope_modules` array names those keys — including goal 1000068's own. Move the folder first and the goal's wall stops matching the files its remaining tasks need to touch, blocking the work mid-goal. Hence R02 adds `government` alongside `governance` and migrates the stored arrays before R04 moves anything.

**The database rename and the constant rename must land in the same deploy.** `government_rank_permissions.permission_key` stores `governance.manage` as text, and `catalog.js` holds the same string as a code constant. If the rows change while the old code is still serving, every `governance.manage` check fails closed — and because that key is what gates the Government tab, the failure mode is the Owner locked out of the surface they would use to investigate. R03 and R05 are sequenced accordingly, and R03 takes a backup first.

**Two ADRs currently claim the number 0172**, so "ADR 0172" no longer identifies a decision on its own. This ADR amends `0172-editable-rank-roles-substrate-axis.md`; the other is `0172-per-craft-compensation-ideator-credit-lane.md`. Filed as idea 1000753 with a proposed guard (fail CI on a duplicate ADR number); deliberately not fixed here, because renumbering an ADR mid-rename would put two independent reference churns in the same diff.

**ADR 0151 and ADR 0172 get amendment notes, not rewrites.** Their bodies stay in the old vocabulary. An ADR records what was decided and why at a point in time; editing the prose to match today's words would quietly erase the evidence that the words changed — which is the one thing a reader hitting "rank-role" in an old session log will need.

**Goal 1000066 can now proceed without ambiguity, and needs to.** This ADR frees the word; 1000066 spends it by renaming `tasks.discipline` and `builders.preferred_disciplines` to roles. Neither half is sufficient alone: until 1000066 lands, "role" is unclaimed rather than correctly claimed, and the fitness rule from Decision 5 only proves the government side is clean. The two goals are independent in their file sets and can run in parallel.

**Rejected: renaming the ladder slugs to match.** `xenos`/`thetes`/`metic`/`archon` are referenced by `builders.rank`, `requireRank`, the protected-path enforcers, the Discord role map, and years of session logs. The directive did not ask for it, and bundling it here would turn a bounded rename into a trust-boundary migration.

**Rejected: a compatibility shim kept indefinitely.** The old `/governance/*` route paths answer for exactly one release, logging each hit, and R05 records the removal release in this ADR's lineage. A permanent alias would mean both vocabularies stay correct forever, which is the state this ADR exists to end.

## Lineage — the compatibility alias, and when it actually went

The Decision above promised the old `/governance/*` route paths would answer for
**exactly one release**, and that R05 would record the removal release here. That
record was never written, and the alias outlived the promise by a wide margin.

| | |
|---|---|
| Alias shipped | task 1003006 (R05), with the rename |
| Promised life | one release |
| Actually removed | **task 1003084**, core 1.19.219+ — many releases later |

Two source comments (`src/bongos/module-scope-map.js`, and the `VOCAB_ALLOW`
entry in `scripts/gds/fitness.js`) asserted the route aliases had already gone
with the module-key alias in R05. They had not. A reader who trusted them —
and the goal 1000068 criterion review nearly did — would conclude the
compatibility surface no longer existed while production was still 308-ing on
it. The alias was found by curling live, the same way all three of its original
defects were.

**The lesson, recorded because it generalises past this ADR:** a removal that is
promised in prose and pinned by nothing does not happen. The shim had thorough
tests, but they asserted the shim WORKED — so deleting the shim would have
deleted its own evidence. Task 1003084 inverts them: `tests/government_routes.mjs`
now asserts the legacy paths **404**, with a companion assertion that the current
paths still route so the check cannot pass by everything being broken. A
time-boxed compatibility surface should ship with the test of its ABSENCE
written at the same time, disabled until the clock runs out — not with a
calendar note in a comment.
