# ADR 0215 — The pre-accept recruiter sliver is a CEILING, not a step: a whitelist keyed by consent-and-reach, on the recruiting surface's own door

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1002968](https://cloudbongos.com/builders#/task/1002968) (PV3, goal 1000045 — Public builder profiles, criteria C2/C5)
- **Relates to:** `docs/specs/<redacted>.md` **D3** (the owner-signed sliver, 2026-08-16) and D1/D2 (the two privacy axes), [ADR 0171](0171-profile-rollup-join-and-consent.md) D2/D4/D5 (rollup consent, no partial numbers, no-store), [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) D2/D4 (the recruiting door; reach composed but not folded down), [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) D3 (the `project.recruit` atom belongs to the console wave), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (cross-project numbers are descriptive, never authority), [ADR 0202](0202-connections-graph-and-bounded-degree.md) D4 (one shared effective-visibility predicate)

> 0213 and 0214 are held by sessions in flight; this ADR takes 0215 rather than race them (the ADR 0199 / 0202 / 0207 / 0210 precedent).

## Context

Privacy spec D2 has a row that nothing could serve: **private · discoverable**. A builder who wants no public profile page but does want to be found for work sets `account_visibility = 'private'` and `recruiter_discoverable = true`, and until now that combination bought them exactly nothing — [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) D4 says so in as many words: *"a private account is absent from the directory on purpose: the full rollup is never its disclosure — the D3 sliver is."* The sliver was the unbuilt half.

Two consequences had accumulated around that gap. The Settings toggle's copy was deliberately **narrowed** by task 1002290 to "the People directory", because the sliver was unbuilt and no guard could hold a wider promise. And [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) had to ship the cross-project application queue showing a private applicant's *name, handle and note only*, deferring the richer record to "the sliver half, sequenced behind the recruiter port".

The design question is not what to show. The owner signed that on 2026-08-16 and it is short: **handle, display name, avatar, the disciplines union, and a coarse "active in the last 30 days" boolean — nothing else**; name-only under `hide_stats`; never for a provisional account; never a profile-page link. The question is what *kind of thing* the sliver is, and everything below follows from one answer: **it is a ceiling, not a step.** Nothing a recruiter holds after reading it gets them closer to the record it withholds.

## Decision

### D1 — The sliver's audience predicate is CONSENT **and** REACH, and it deliberately omits the EXISTENCE axis

`recruiterSliverVisibleSql` / `isRecruiterSliverVisible` join `modules/platform-identity/account-visibility.js`, the sole owner of every effective-visibility answer (ADR 0202 D4). Like `rollupVisibleSql` and `scoutingListableSql` it is **composed**, never restated:

```
recruiterSliverVisibleSql = accountActiveSql  AND  recruiterReachSql
```

It is the one composed answer in that file that does **not** contain `accountVisibleSql`, and that omission is the decision. Every other public read floors on `account_visibility = 'public'`; ANDing it here would empty the sliver of precisely the account it exists to serve, leaving a poorer, redundant copy of the directory.

**Dropping the existence axis is safe only because the reach half is an explicit opt-IN for a private account.** `recruiterReachSql` is `COALESCE(recruiter_discoverable, account_visibility = 'public')`: for a private account the `NULL` default resolves to **false**, so a private account reaches this surface only when its owner set the flag by hand. The widening is therefore not the platform's; it is the account's. Consent, not a relaxed floor.

`profile_state = 'active'` still floors it — a provisional account is never recruiter-visible, exactly as spec D3 says out loud — and `hide_stats` appears nowhere in the predicate, because hiding changes the **shape** of the sliver, never who appears in it.

**And the opt-in has to be the one they MEANT — which needed a write-path change, not only a predicate.** That safety argument holds only if an explicit `recruiter_discoverable = true` on a private account was given *as* a private account, and it need not have been. Toggle discoverability off and on again while **public** and the column stops being `NULL`: it becomes an explicit `true` meaning *"recruiters may see my public profile"*. Set the profile to Private later — reading a row that promises the page answers "not found" to every visitor — and that stale `true` used to be **inert**, because every recruiting surface floored on the existence axis. This ADR's own predicate is what would have activated it: silently, with no re-consent and no notice. So `setAccountPrivacy` now resets `recruiter_discoverable` to `NULL` — back to "follow visibility" — whenever a PATCH turns an account private **without naming reach**; naming it in the same PATCH *is* the re-consent and stands. The D2 "private · discoverable" row still exists; it now takes two deliberate moves instead of one forgotten one. (Found in adversarial review. The write's D2 matrix is resolved from the statement's own `CASE` in `tests/account_privacy_flags.mjs`, so deleting the arm reds it.)

Because that predicate is the only shared answer missing the existence axis, `tests/effective_visibility_predicate.mjs` **pins it to its one reader**. Naming it in that guard's `ADOPTS` list is what lets the sliver's own query pass the adoption rule, and that would otherwise be a hole: a future public read joining it would look adopted while quietly serving private accounts.

### D2 — The projection is a literal whitelist, `hide_stats` decides its SHAPE, and the hidden case never fetches what it will not show

`modules/platform-identity/recruiter-sliver.js` builds the object key by key. No row is ever spread, so a column added to either query cannot ride along. Two shapes, and only two:

| | keys |
|---|---|
| full | `handle`, `display_name`, `avatar_url`, `disciplines`, `active_recently` |
| `hide_stats` | `handle`, `display_name`, `avatar_url` |

The two rollup-derived keys are **absent, not null** — the sliver does not carry an empty box where a number used to be — and for a hidden account **the activity query is never issued at all**. Dropping the fields after fetching them would be equivalent today and strictly worse tomorrow: the cheapest way for a later edit to leak a number is for the number to already be in hand.

Four absences are load-bearing rather than incidental:

- **credits / works shipped / karma / project names / project count** — the post-accept record. "The aggregate is not the leak, the name is" (ADR 0171 D6), and a count beside a hidden total is a leak by subtraction, so there is no count either.
- **`last_active` as a timestamp.** The comparison to the 30-day window happens **in SQL** and only the boolean returns, so the date never enters the process and no later refactor can serialize it. A date is a behavioural trace; a boolean is a yes/no.
- **`github_id` and `github_login` as FIELDS.** Neither is a key of the sliver, and D3 names the *handle*, not the login. **The limit, stated rather than glossed:** the avatar D3 grants is GitHub's own URL — `https://avatars.githubusercontent.com/u/<github_id>?v=4` — so granting the avatar grants the account id inside it, and that id resolves through GitHub's public API to a login. Granting the avatar is the owner's decision, already made; pretending the id does not ride along was this ADR's. The proof now pins *where* it may appear (inside that URL and nowhere else) instead of asserting an absence the code does not deliver — an earlier draft claimed "the join key stays internal" while its fixture used an invented avatar host, so the sentinel could not have caught it.
- **any profile-page URL**, which spec D3 forbids outright.

### D3 — The handle is an ADDRESS, not a door — which is what "pre-accept" means operationally

The sliver hands a recruiter a handle, and the handle opens nothing: `GET /profiles/:handle` joins `accountVisibleSql` and answers **404** for exactly the private account whose sliver the recruiter just read. That is the whole claim of this ADR reduced to one assertion, and it is asserted — with a control proving the same page renders 200 for a publicly-visible builder, so the 404 cannot pass by the route simply being broken.

A **previous** handle resolves to nothing here either, deliberately unlike `resolveHandle`'s 301. The public page redirects so a *shared link* survives a rename; a recruiting read has no shared links to keep working, and resolving one would confirm to a recruiter that the account renamed — a disclosure the sliver never grants. (This was the one mutation the first draft of the proof did not catch; the rule was documented in the source and unheld by a test.)

### D4 — The sliver holds spec D3's **archon floor**; the directory's wider door is not reused, and the audience goes to the owner

`GET /scouting/:handle` sits in `modules/platform-identity/routes/scouting.js` beside `GET /scouting`, and the two do **not** share a gate. The sliver is `requireBuilder` → `api.requireRank('archon')` (behind its own read budget since [task 1003540](https://cloudbongos.com/builders#/task/1003540) — see the last honest limit); the directory keeps `requireScoutingReader({ curateGate: requirePermission('project.curate') })`. Each gate is spelled in its own route's middleware list, so `route-rank-check.js` and `gen-api-docs.js` classify each from its real floor rather than recording a privileged route as `any-builder`.

Spec D3 says the sliver is "gated at the route by `project.recruit`" — and that atom **does not exist**. ADR 0201 D3 and ADR 0210 both refuse to mint it, on the same grounds: it belongs to the project-admin-console wave ([spike 1002786](https://cloudbongos.com/builders#/task/1002786) R3), which defines it, and minting it in a third place would fork its definition across three waves before any had shipped. **So which door does it use meanwhile?** The first draft reused the directory's, and that was wrong in the dangerous direction. Spec D1 declares the missing atom's shape — **floor archon**, widenable per instance through the governance tab — while the directory admits `project.curate` at the **metic** floor (ADR 0157) **OR any project owner**, who is typically a bare `xenos` on the hub (ADR 0210 D2). That door is *wider* than the signed floor on both halves. Reusing it would have widened an owner-signed privacy decision by implementation convenience, on the first surface that discloses a private account — and narrowing after people have been disclosed is not a recoverable move, while widening later is. So the sliver holds D3's declared floor, by rank, until the atom exists.

**The audience is the owner's call, and it is filed rather than taken.** [Blocker 1000126](https://cloudbongos.com/builders#/blocker/1000126) asks whether the wider recruiting audience is authorized here, with the evidence and a recommendation (hold the floor; let `project.recruit` — grantable per instance — settle it, which is exactly the knob the question wants). Answering it moves **one line**, and the tests that pin the floor flip with it. Goal 1000045 C5 (*"project owners, not only Archons, browse builder profiles to recruit"*) pulls the other way, and that tension is what the blocker carries: C5 was written about the DIRECTORY, which shows public builders; this surface shows private ones.

**Answered 2026-08-29 — the floor stands.** The owner kept the archon floor, and [ADR 0217](0217-rank-gates-inviting-not-viewing.md) D2 records why it is now the *consistent* answer rather than the merely safe one: the owner's rule from the same review is that **rank gates inviting, not viewing**, and the per-project invite floor they asked for also defaults to archon. The sliver is a recruiting disclosure of an account that asked not to be publicly visible, so it sits on the inviting side of that line. The C5 tension recorded above is resolved rather than deferred — C5 is about *browsing*, which ADR 0217 D1 makes ungated, and was never about disclosing private accounts. No code moved; the one-line swap remains available if the console wave's `project.recruit` atom later says otherwise.

The refusal for an unreachable *builder* is **404, never 403**: a 403 would confirm the handle exists, which is precisely the disclosure the opt-out removes. (A refusal of the *caller* is an ordinary rank 403 naming the floor it wanted, so the hall can render why.) And `Cache-Control: no-store`, the `/profiles/:handle` posture, because the rollup half is live-derived and hide must beat any cache (ADR 0171 D5) — the directory route gained the same header here, having been the last rollup read without it.

### D5 — The sliver grants nothing (ADR 0016), and that is enforced structurally

Being visible to a recruiter confers no rank, no permission, no claim right, and nothing consults the sliver to decide anything: the module is required by **exactly one** first-party server file, the route that serializes it, enumerated from source so a second reader fails the build. The response carries no rank, role, permission or membership under any name. The reverse holds too and is the point of the reach axis: a builder's recruiting opt-out changes who can *see* them and grants or denies them nothing.

### D6 — The Settings copy widens back to name **both** recruiting surfaces, held by a guard rather than by good intentions

Task 1002290 narrowed the discoverable toggle from "every recruiting view" to "the People directory" on the copy rule that *a toggle may promise exactly what is enforced* — the sliver was unbuilt, so no guard could hold the wider claim. It is built and gated now, so the row names both: *"removes you from both recruiting surfaces — the People directory, and a recruiter's look-up of one builder — straight away."*

"Both" rather than "every", and that word choice is the decision. `tests/account_privacy_flags.mjs` asserts that `routes/scouting.js` mounts **exactly two** routes and that `scoutingListableSql` and `recruiterSliverVisibleSql` each compose `recruiterReachSql`. A third recruiting read in that file, or either reader dropping the reach axis, reds it. "Every recruiting view" would be an open-ended promise no guard can hold, and it stays banned.

**The half that was actually wrong, though, was the GRANT.** Spec D3 makes stating it a MUST — *"the discoverable toggle's settings copy must state exactly this grant"* — and the shipped copy was false: it told a hidden account it would show *"your name and nothing else"* while `SLIVER_KEYS_HIDDEN` also ships the **avatar**, and the shown branch never mentioned the picture at all. Neither branch told a *private* account that this is the one thing a recruiter sees while their page answers "not found". All three are fixed, and the guard no longer checks transcribed phrases: it iterates `SLIVER_KEYS` / `SLIVER_KEYS_HIDDEN` from the module itself, so a sixth granted field cannot ship without the copy being made to name it.

### D7 — No migration, and no new file in `platform-identity.js`

Both columns exist (migration `platform_identity_012_account_privacy.sql`); the activity table's `(github_id)` index already serves both reads. Spec D3 asks for the port "beside `getPublicProfileExtras`" and it is beside it *in the module*, not in the file: `platform-identity.js` sits on the 1500-line ratchet with no headroom — the `account-visibility.js` / `scouting-authz.js` / `application-echo.js` precedent, now five sessions deep.

## Consequences

- Privacy spec **D2's "private · discoverable" row is finally served**, and [task 1002972](https://cloudbongos.com/builders#/task/1002972) — the application queue rendering a private applicant's record — has the port it was sequenced behind. Its own half of the problem is unchanged and still real: ADR 0201 notes the hub cannot check an *instance* permission from a cross-origin browser read, so how the reviewer's browser reaches this route is that task's decision, not this one's.
- The recruiting surface now has two reads and one door. When `project.recruit` lands, it replaces `project.curate` in one expression and both routes move together.
- **The directory is unchanged.** A private account — discoverable or not — is still absent from `GET /scouting`, and a public leaderboard must still join `rollupVisibleSql`, never `scoutingListableSql` (ADR 0210 D4). Reach still governs the recruiting surface only.

⚠ **Honest limits, recorded rather than fixed:**

- **No UI consumes the sliver yet.** This ships the port, the route and the proof; the recruiting *view* is the console wave's (spec D6, `<redacted>.md` CT6) and the application queue's (task 1002972). The route is reachable and gated today; nothing in the hall calls it.
- **The audience was unresolved when this shipped; it is settled now, and the floor did not move** ([blocker 1000126](https://cloudbongos.com/builders#/blocker/1000126), answered 2026-08-29 — see the D4 addendum above and [ADR 0217](0217-rank-gates-inviting-not-viewing.md) D2). The archon floor was the conservative reading of an owner-signed spec rather than a call this ADR was entitled to make; the owner has since made it, and kept the floor. **What is still true:** the gate is *narrower* than goal C5 describes, so project owners cannot use the sliver today — ADR 0217 D1 resolves that tension by making C5's subject (browsing) ungated rather than by widening this surface, and `project.recruit` remains the eventual home. An earlier draft of this section called the shipped gate "narrower than the spec's atom" and "not a widening in any direction"; both were wrong, and wrong in the dangerous direction, because the SUBJECT set strictly grows: private accounts were on no recruiter surface at all before this.
- **The rank gate is a documented HOLDOUT against the module-gate migration rule** (BV1.R105/R107, ADR 0151): `modules/*/routes` gates are supposed to be permission atoms, and `tests/government_require_permission.mjs` enforces it from source. This route is listed in that test's `RETAINED` set with its full argument — the atom it wants is specified and owned by another wave, minting it forks the definition, borrowing a different archon atom would name the wrong authority on a privacy surface, and the sibling's door is wider than the signed floor. It is temporary by construction: spike 1002786 R3 removes the entry.
- **The two gates are spelled twice, on purpose.** An earlier draft called them "one gate expression … a one-line change reaching both"; they never were one, and now they are deliberately different.
- **A recruiting read added in another FILE would not trip the two-route guard.** D6's count is over `routes/scouting.js` alone, so the "both recruiting surfaces" copy could become false without reddening. Sweeping every route file for reach-joining reads is a structural guard of its own and belongs with the shared-predicate work, not here.
- **`getRecruiterSliver` (the by-id port spec D3 names) has no production caller yet** — [task 1002972](https://cloudbongos.com/builders#/task/1002972) is its consumer. The route uses the by-handle sibling; the proof exercises both.
- **`active_recently` is coarse by design and coarse in practice.** It is derived from `max(last_active)` across the rollup, which is refreshed on federated sign-in and on ship — so a builder active only on a project that never reports will read as inactive. That understates rather than overstates, which is the safe direction for a privacy surface.
- **~~This route is not rate-limited~~ — closed by [task 1003540](https://cloudbongos.com/builders#/task/1003540); what was open, and why the fix took the shape it did.** `GET /profiles/:handle` carries a per-IP read limiter so the handle→identity mapping cannot be scripted at line rate (task 1002798), and `GET /scouting/:handle` shipped with none: a reader could probe guessed handles and learn *which private accounts opted into recruiting*, a set no other surface publishes — bounded by needing to guess a private handle, so a widening of degree, not of kind. It now spends its **own** per-IP budget, `recruiter-sliver-read`, at the `/public/*` posture (120 reads / 60s), mounted **ahead of** `requireBuilder`: the tag takes the route off core's default read ceiling (`rate-limit.js` #6), so a limiter behind the gate would have left every refused probe unmetered. It is **not** `accountExistenceReadRateLimit` — ADR 0209 is one budget per oracle, and sharing would hand an enumerator the sum of two. This note used to name a **doorway-exported factory** as the fix. That was wrong on ADR 0209's own terms, which rejects a limiter factory on the doorway as *"more general and more wrong"* (two call sites with matching config get two budgets), and it was overtaken: the module has had its own single limiter factory since task 1002978 (`modules/platform-identity/read-rate-limit.js`, mounted by the community and guild reads). The sliver's budget is one instance from that factory, built at module scope so every router the file builds spends from the same bucket — no new copy, and no change to the doorway. `tests/recruiter_sliver_boundary.mjs` §6b pins the budget, its position ahead of the gate, and that it is none of core's shared instances.

**Rejected:**

- **Flooring the sliver on `accountVisibleSql`** — it would empty the surface of the exact account D3 exists to serve.
- **Folding reach into `rollupVisibleSql`** so the sliver could reuse it — ADR 0210 D4's reason stands: it would silently empty a future public leaderboard of every opted-out builder.
- **Minting `project.recruit` here** — ADR 0201 D3 and ADR 0210 both refuse it; it belongs to the console wave that defines it.
- **A second route file** for one route — the two recruiting reads live in one file (they share consent machinery and a reader's mental model); what they deliberately do NOT share is a gate.
- **Reusing the directory's door for the sliver** — wider than the owner-signed floor on both halves, on the one surface that discloses a private account.
- **Leaving a stale `recruiter_discoverable = true` to be read as consent** after the account went private.
- **Returning the rollup-derived keys as `null` under `hide_stats`** — an empty box is still a box, and it means the numbers were fetched.
- **Returning a profile URL, `github_login`, a project count, or `last_active`** — each forbidden by spec D3 or by ADR 0171 D4's leak-by-subtraction rule.
- **301-ing a previous handle**, the way the public page does — a recruiting read has no shared links to preserve, and the redirect would confirm a rename.
- **403 for a non-discoverable builder** — it confirms the handle exists.
