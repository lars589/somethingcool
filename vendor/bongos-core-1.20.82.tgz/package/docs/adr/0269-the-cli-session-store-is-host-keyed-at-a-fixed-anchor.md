# ADR 0269 — The CLI's session store is host-keyed at a fixed anchor; the per-brand file stays the active pointer

- **Status:** accepted
- **Date:** 2026-09-09
- **Task:** [task 1003741](https://cloudbongos.com/builders#/task/1003741) (BONGOS-V2, goal 1000090 — *Working area 4, Bongos Core distribution*)
- **Deciders:** Claude, under the Archon's standing scope
- **Related:** [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) (the public CLI, which is where this bites) · [ADR 0108](0108-instance-composition-configurable-root.md) (each instance its own checkout) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (why the store directory may not be called `sessions`)

---

## Context

The CLI resolved its session path from the **branding pack**, which is read out of whatever
checkout the process happens to be standing in. That gave it exactly **one session slot**, and the
slot moved depending on where you ran from:

- **Standalone** — the public `@cloudbongos/cli`'s entire situation — no checkout means no brand,
  so every instance shared `~/.config/cloudbongos/gds-session.json`. Signing into a second
  instance **destroyed** the first. Measured on the published 0.1.1: `configHome()` resolved to
  `<HOME>/.config/cloudbongos` whichever instance was named.
- **In-repo** the brand resolved and the session landed in `~/.config/<slug>/`, where the
  standalone CLI could never find it. `npx @cloudbongos/cli api GET /api/gds/me` from a bare
  directory returned the cloudbongos.com builder while a valid hermeslines session sat on the same
  machine.

This was not theoretical. The owner's own config dir carries a hand-made
`gds-session.<redacted>.bak.json`, alongside four more rescues of the same
shape. For a newcomer with one project it is invisible; it bites precisely the people running more
than one, which is the direction the platform is going.

## Decision

**Keep one session file per instance, keyed by the instance's host, under a FIXED anchor —
`~/.config/<FALLBACK_DIR>/instances/<host>.json` — and leave the per-brand `gds-session.json`
exactly where it is, as the ACTIVE pointer.**

Four parts are load-bearing.

### 1. The anchor is fixed, never brand-derived

A brand-derived anchor is the bug. `sessionStoreDir()` is built from `FALLBACK_DIR` and must not
read `configHome()`, `configDirName()` or the pack — so the same instance resolves to the same file
whether you run from a checkout or from `npx`. A test asserts the function body names none of them,
because "helpfully" routing it back through the brand would silently reinstate the split.

It lives in `scripts/gds/cli-lib.js`, **not** `src/instance-config.js`. That module is generic
config-path machinery shared with the server, and a CLI session store is not its concern; cli-lib
already owns `SESSION_PATH` and `SESSION_READ_PATHS`, so one file now describes where a session
lives. (The first cut put it in instance-config and the knip dead-code ratchet caught it: knip
cannot trace that module's `require()` consumers, so every export it gains counts as dead — three
new ones broke the gate. The right answer was better placement, not a bigger baseline.)

### 2. The active pointer does not move

Every existing reader — in-repo skills, the card hook, the dev box, `readSessionToken` — looks at
`gds-session.json` in the configured dir. The store is **additive**: `saveSession` still writes that
file last and unchanged. Moving it would have been the tidier design and would have broken every one
of those readers at once, for no gain a builder can see.

### 3. The OUTGOING session is archived before the incoming one lands

Order matters, and this step is the one that is easy to omit. A session written *before* the store
existed is not in it; without archiving the session being replaced, the very first login after
upgrading would still lose it — the exact bug, surviving its own fix. Archiving is best-effort and
never blocks a real sign-in.

### 4. A stored token is verified before it is trusted

`bongos login <url>` now switches back to an instance you are already signed into with no browser
flow — but it calls `/api/gds/me` with the stored token first. Reinstating an expired or revoked
token unchecked would leave a builder "signed in" to a session every later command then fails on.
An unverified token falls straight through to the real device flow; `--force` signs in as somebody
else.

Because sessions are now kept rather than overwritten, `login` also names the other instances this
machine knows and how to move between them — silence would leave them unfindable.

## Consequences

- Signing into a second instance is non-destructive, and moving between two projects costs no
  browser round-trip.
- Session files are `0600` in a `0700` directory: they hold bearer tokens.
- An `api_base` that names no host is **not stored** rather than stored under a guessed name, so a
  malformed or hostile base cannot write outside the store directory.
- **The directory is `instances/`, not `sessions/`.** `sessions` is a live module key, and
  ADR 0083 §Decision #4 forbids kernel machinery from naming one — `src/instance-config.js` is a
  kernel file and the fitness gate caught it. `instances/` is also the truer name: one file per
  instance is exactly what it holds.
- A corrupt entry in the store is skipped, never fatal.
- Still open: the store is per-machine and holds no notion of which instance a *directory* belongs
  to, so running in an instance repo does not automatically select that instance — the active
  pointer is whatever you last signed into. That is a smaller, separable question.

## Rejected

- **Moving the active pointer into the store** — breaks every existing reader at once for no
  visible gain.
- **One file holding a map of instances** — changes the on-disk format that in-repo readers,
  hooks and the dev box all parse today.
- **Keying the store under `configHome()`** — brand-derived, which is the bug being fixed.
- **Restoring a stored session without verifying it** — hands the builder a dead session that
  looks live.
- **A new `bongos switch` verb** — `login <url>` is the command a builder already reaches for, and
  the public CLI's verb surface is deliberately small (ADR 0258).
