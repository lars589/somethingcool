# 0167 — The /create gate trust link defaults to the AGPL license text, not the npm package page

- **Status:** Accepted — built in task 1002705.
- **Date:** 2026-08-12
- **Deciders:** jaxri (Archon) — autonomous session; the residual choice is the owner's (idea 1000700).
- **Task:** task 1002705 · **Goal:** 1000059 (projects surface revamp) · gap 1 of [`docs/audits/project-creation-gap-list.md`](../audits/project-creation-gap-list.md).

## Context

The /create gate's "open source" trust link pointed at `github.com/example-owner/Claude-OTB` — a 404 even authenticated (the real core repo is private). Task 1002705's brief said to "default to the npm link so the 404 dies now," on the premise that `@cloudbongos/core` is public on the registry.

That premise is false, verified 2026-08-12 against `registry.npmjs.org`: **both `@cloudbongos/core` and `@bongos/core` 404 anonymously** — they are private scoped packages (ADR 0134 publishes the core privately; npm shows private packages as 404 to signed-out visitors). The [ADR 0099](0099-delayed-redacted-mirror-export.md) public mirror is deliberately dormant until history clears the 180-day redaction window (~2026-11). So today there is **no browsable public code artifact at all** — following the brief literally would swap one dead link for another.

## Decision

Point the gate's "open source" link at the **AGPL-3.0 license text** (`https://www.gnu.org/licenses/agpl-3.0.html`) and tighten the copy to "open source (AGPL-3.0)". The license is the one live, instance-neutral artifact behind the claim today ([ADR 0065](0065-agpl-nonprofit-ai-first-governance.md) — AGPL is the governance keystone), and the link carries no instance identity into the portable core.

The upgrade to a *browsable-code* link is the owner's call, filed as **idea 1000700** with three options: flip the repo public now (forfeits the redaction window — weigh ADR 0065 §4), publish a public npm package, or wait for the ADR 0099 mirror (~2026-11, zero extra work). When one lands, repoint the `finePrint` link in `public-landing/create.html`; the pin is `tests/onboard.mjs` "the /create gate trust link points at a live artifact".

## Alternatives considered

- **The npm package page (the brief's default)** — rejected: verified 404 for anonymous visitors; the gate's audience is exactly the signed-out visitor.
- **Make the repo public now** — not a builder's call; forfeits the deliberate 6-month redaction window (ADR 0065/0099). Surfaced to the owner instead (idea 1000700).
- **Drop the link, keep plain text** — dies the 404 but weakens the claim; the license link is strictly more information at the same cost.
