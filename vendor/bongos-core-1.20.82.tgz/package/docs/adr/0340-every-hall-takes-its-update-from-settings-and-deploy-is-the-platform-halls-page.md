# ADR 0340 — Every hall takes its update from Settings, and /deploy is the platform hall's page

- **Status:** Accepted
- **Date:** 2026-09-26
- **Task:** [task 1004296](https://cloudbongos.com/builders#/task/1004296) (goal 1000090 — BONGOS-V2), split out of [task 1002622](https://cloudbongos.com/builders#/task/1002622) §1.
- **Deciders:** the owner, Lars. On 2026-09-25 he asked that each builders hall's Settings carry "a version description where they can pull the latest release. Just like iOS does", and ruled that `/deploy` is "only for bongos builders hall itself not for all production ones".
- **Amends:** [ADR 0339](0339-a-projects-owner-upgrades-it-and-a-hosted-project-hands-off-to-the-hub-door.md) D3 (where a hosted hall uses the hub address) and the reach of [ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md)'s door page. Nothing about who may move a pin, or how the move runs, changes.

## Context

Before this change a project learned about a newer core in one place, the banner (task 1004045), and only a holder of `core.pin.move` ever saw it. The banner named two version numbers and nothing that had landed between them. The only per-version record of work is the `release-notes.json` each package carries (task 1004218); the changelog's CI lines name none.

Every hall also served `/deploy`. The page's data and both of its acts are provisioning-module routes, so in a hall without that module (a hosted project, a self-hosted instance) it was a page with nothing behind it.

## Decision

### D1 — Settings → Software update, in the core, in every hall

A sixth Settings group. It shows the running core, then either "up to date" or the newest release the update channel lets this project take, then what each version in between brings, read from the newest package's own release notes.

- **Every signed-in builder reads it** (`GET /api/bongos/software-update`, `requireBuilder` only). It discloses nothing the public `GET /version` and npm do not already publish, so ADR 0043's vulnerability-window reason, which keeps the banner's reads on `core.pin.move`, does not apply here.
- **The channel rule is the runner's own** (`resolveChannelTarget`), with no channel passed, exactly as the banner. The panel never offers a version the runner would refuse.
- **"Up to date" is said only from an answer.** A failed registry read, a running version that cannot be named, and release notes that could not be read each render as what they are.

### D2 — The Update button leads to the door; it is not the door

The server names where this project's door is:

- `local` — `/deploy`, where the hall runs the provisioning module.
- `hub` — ADR 0339 D3's `<hub>/deploy?project=<slug>`, on a federated hosted project.
- `cli` — neither, as on a self-hosted instance. The panel says `bongos upgrade` on the server takes the version, with the same health check and rollback.

The button is drawn only when the viewer holds `core.pin.move`. That check is cosmetic; the door re-checks every request.

### D3 — `/deploy` exists only where the door does

In a hall that does not run the provisioning module, `GET /deploy` answers `302` to `/settings#software-update`. The redirect carries no gate, because it discloses nothing and Settings' own wall applies once it is followed. The platform's hall keeps `/deploy` behind its unchanged page gate. It remains the door for its own pin and, through `?project=`, for every hosted project's (ADR 0339).

### D4 — The banner and the rail stop linking off-site

On every hall but the platform's, the banner's Upgrade link opens Settings → Software update. On that panel itself the banner points rather than linking to the page it is on, the rule task 1004145 set for `/deploy`. The rail's Deploy item is no longer re-pointed at the hub, and it stays hidden wherever the module is off. `GET /core-update` no longer answers `deploy_url`. The hub address now lives only in `GET /software-update`'s `door`, which is ADR 0339 D3's hand-off moved from two places to one.

### D5 — The registry reader is the core's

`src/bongos/package-registry.js` holds the packument read, the in-process tarball stream and the small tar reader. It moved out of the npm-release module (task 1002622), because the one reader every hall needs cannot live inside a module that only one hall runs. Modules reach it through the doorway's `readPackageRegistry`, and both readers share one process-local cache.

## Rejected

- **A copy of the two-step door inside Settings.** It would put the confirmation, the busy states and the rollback display in two places for one act. Those are the rules ADR 0293 D4 exists to keep exact.
- **Gating the panel on `core.pin.move`, as the banner is.** The owner asked for the version in every builder's Settings, and the panel offers no act of its own.
- **Keeping `/deploy` on other halls with a "moved" notice.** A page that exists only to say it does not belong there is the dead end this replaces.

## Consequences

- **A hosted project gets the panel when it runs a core carrying this ADR**, like every in-hall change. Until then its banner still hands off as ADR 0339 D3 described.
- **The first open of the panel after a new release downloads that package once per server process** (about 24 MB for 1.19.1040, under a second from a droplet), then serves it from memory. It is read only when the group opens, never with the page.
- **What's new links each entry to its task only in the platform's hall**, whose ledger the ids belong to. Elsewhere the entries are plain text.
- **Proof:** `tests/software_update.mjs`:
  - the reading, over a real gzipped tar and packument;
  - the route, over real requests;
  - the panel, executed in a DOM stub against a live reading;
  - `/deploy`, answered by two real servers, one with the module and one without.

  `tests/core_upgrade_owner_door.mjs` covers the banner's new link. Each guard was deleted in turn and a test went red.
