# 0172 — The sub-Archon rank roles are owner-editable; the Archon role is not; the substrate keys are non-grantable to everything

- **Status:** Accepted
- **Date:** 2026-08-16
- **Task:** [#1002961](https://cloudbongos.com/builders#/task/1002961) (goal 1000030 — configurable roles & permissions)
- **Amends:** ADR 0151 §2 (the "four seeded rank-roles are immutable through this API" wall — the GRANT half only)
- **Related:** ADR 0016 (trust boundary — server-enforced, uncached, per request), 0043 (git/ssh trust boundary + the rank floor on protected paths), 0157 (the archon→metic delegation of nineteen operational keys)


> **⚠ VOCABULARY AMENDED by [ADR 0174](0174-government-terminology-ranks-not-roles.md) (owner directive, 2026-08-16) — the DECISIONS below are unchanged.**
> What this ADR calls *governance* is now the **government**; what it calls *seeded roles* / *rank-roles* are now simply **ranks**. The word *role* is reserved for the three Cloud Bongos crafts — Artist, Ideator, Builder — and appears nowhere on the government side.
> Concretely: `governance_roles` → `government_ranks`, `governance_builder_roles` → `government_builder_ranks`, `governance_role_permissions` → `government_rank_permissions`, `role_key` → `rank_key`, `governance.manage` → `government.manage`, `page.view.governance` → `page.view.government`, `/governance/roles/*` → `/government/ranks/*`, and `modules/governance/` → `modules/government/`.
> **The body below is deliberately left in the old vocabulary.** An ADR records what was decided and why at a point in time; rewriting it to match today's words would erase the evidence that the words changed — which is the one thing a reader who hits "rank-role" in an old session log actually needs. Every decision it makes still holds; only the nouns moved. A `fitness.js` check now enforces the new vocabulary, and excludes this file by construction.


## Context

The governance tab (BV1.R110/R111) let an Archon build custom roles and toggle their operational permissions, but rendered all four **rank roles** — Newcomer/`xenos`, Contributor/`thetes`, Trusted/`metic`, Owner/`archon` — read-only. The owner asked why, and then asked for them to be editable.

Three facts made this cheaper and narrower than the read-only rendering suggested:

1. **The rank roles' grants were already ordinary rows.** `governance_002_seed_and_backfill.sql` writes them into `governance_role_permissions` exactly like a custom role's. The immutability was a route-level refusal (`loadMutableRole` → `seeded_role_immutable`) plus a disabled toggle — policy, not structure. Nothing had to be remodelled to make them editable.
2. **The `system` flag was carrying two different meanings.** ADR 0151 used one boolean for "trust-boundary power," but the twelve `system:true` keys split cleanly in two. Seven are **in-app**: a real route reads them through `requirePermission`, so a grant row genuinely confers them (`builder.rank.set`, `version.close`, `task.confirm.grade_bypass`, `dependency.cross_tier.manage`, `goal.scope.manage`, `governance.manage`, `gate_approval.decide`). Three are **substrate**: `deploy.push_main`, `path.protected.modify`, `infra.ssh` are enforced entirely outside the app by the pre-push hook, `main-audit.js`, the grader pre-pass and credential placement (ADR 0043) — `tests/government_abuse_matrix.mjs` V10 asserts *no route consumes them* at all. Two are **principal** keys, held by an exact `builders.system_role` identity and by no role ever.
3. **A grant row for a substrate key is inert.** It resolves honestly and admits nothing (abuse matrix V8/V10/V11). So the interesting question was never "is it dangerous to allow" but "would allowing it be *true*" — and it would not be.

The owner was presented with the choice and chose to delegate the in-app Archon powers as well as the operational ones, having been told the escalation consequence explicitly.

## Decision

**1. The three sub-Archon rank roles are grant-editable; the Archon rank role is not.** `loadMutableRole` splits into `loadGrantEditableRole` (refuses only `seeded_rank === 'archon'`, as `archon_role_immutable`) and `loadAssignableRole` (unchanged). Keeping the Archon role frozen is not symmetry for its own sake — it is the **lockout guard**. `governance.manage` floors at archon, so the Archon rank role is the only role holding it by seed; if that role were editable, a sequence of clicks in this tab could revoke the permission needed to reach this tab. Frozen, no such sequence exists, and the escape hatch (Decision 4) never needs to be reachable without one.

**2. `substrate` becomes a declared axis in the catalog, and substrate keys are non-grantable to every role, forever.** `modules/governance/catalog.js` marks the three keys `substrate: true`, asserted at load to imply `system: true`, `floor: 'archon'`, and not-a-principal. This makes the class **data** rather than the hardcoded `SUBSTRATE_KEYS` array the abuse matrix used to carry, so a fourth substrate key is covered by every abuse vector the day it lands. The wall itself is the honesty rule: offering a toggle that writes a row conferring nothing would make the tab lie about the system's shape, which is a worse failure than the missing capability.

**3. Grantability becomes per-role: `catalog.isGrantableTo(key, role)`.** Four answers — never (substrate, principal); nothing (the Archon role); everything-but-those (a sub-Archon rank role); operational only (a custom role). `isGrantable(key)` survives unchanged as the narrow custom-role question, which is what `config.js` strips against and what the R96 config vector asserts.

**4. Custom roles are NOT widened.** A custom role keeps the operational-only wall. The asymmetry is deliberate and is the reason this delegation is bounded: a rank role is the owner's own coarse ladder, moved only by a rank write (`PATCH /builders/:id/rank`, itself `builder.rank.set`), while a custom role is ad-hoc and assignable to any builder by anyone holding `governance.manage`. Widening both would hand the second group the first group's lever in one step.

**5. Rank-role ASSIGNMENT stays rank-derived — unchanged.** `seeded_role_assignment_forbidden` still refuses assigning any seeded rank role, because assignment comes from `builders.rank` via the R95b `syncRankRole`. A second writer here would fork authority truth and be silently undone on the next rank write.

**6. A reset escape hatch: `POST /governance/roles/:roleKey/reset`.** Restores a rank role to `catalog.seedForRank(seeded_rank)` — the same floor derivation `governance_002` seeded from, so it cannot drift from the catalog even after later floor edits. It exists because a rank's grant set is ~60 rows: without it, a drifted rank has no practical way back, and "what does Trusted mean by default" becomes a question only a migration can answer. Written in one transaction (a crash between the delete and the insert would leave every builder at that rank holding nothing), filtered through `isGrantableTo` so reset can never write what the toggle refuses, and refused on a custom role (`role_has_no_default`) — a custom role's "default" is the empty set it was created with, and clearing grants under the name *restore* would be a destructive verb in a restorative costume.

## Consequences

**The escalation chain is now open by owner decision, and that is the point.** A rank role granted `governance.manage` can grant its own rank `builder.rank.set`, and thereby reach every in-app Archon power. The owner was shown this consequence in the words "anyone you give role-editing to can then grant themselves the rest" and chose it. It is Archon-set policy, not an oversight — and it stops at the substrate: no amount of in-app escalation produces a `git push origin main`, a protected-path edit below the Metic floor, or an ssh session, because ADR 0043's enforcers read the rank ladder and never consult this database.

**ADR 0151's parity guarantee now describes the seed, not the live system.** R103's "role(rank) reproduces `requireRank(rank)` exactly" remains true of `RANK_ROLE_SEED` and is still asserted (`tests/governance_seed.mjs`, `governance_require_permission.mjs` — both read the derived constant). It is no longer true of a *live* instance whose owner has edited a rank, and it was never meant to be after that point: making the ladder configurable is the goal, and `requireRank` is the legacy gate the R104–R109 migration is retiring anyway.

**One-boolean grantability is gone from the tab's rendering.** `GET /governance/permissions` now returns `substrate` alongside `system` and `grantable`, and the hall tab groups rows into Operational / Owner powers / <redacted>, computing the lock per selected role. A client that reads only `grantable` would under-render the rank-role case; nothing else consumes that endpoint today.

**A drifted rank role is invisible to the catalog.** Nothing warns that `metic`'s live grants differ from `seedForRank('metic')` — the tab shows what is, not what the ladder shipped. If that becomes confusing, the follow-up is a "differs from default" badge on the role list, cheap to add on top of the same two arrays; it was left out here because reset (Decision 6) already answers the operational need.

**Rejected: allowing the substrate keys on a rank role behind a warning.** It would produce a toggle that succeeds, persists, and delegates nothing — the failure mode of a permissions UI that is worst for exactly the reader who trusts it. Rejected: making the Archon role editable with a "you may lock yourself out" confirm — a confirm is not a guard, and the recovery for a real lockout is a hand-written SQL statement on the droplet.
