# 0168 — The scaffold vendors the hub's running core (npm pack of the installed package); registry-default deferred to the go-public step

- **Status:** Accepted — built in task 1002706.
- **Date:** 2026-08-12
- **Deciders:** jaxri (Archon) — autonomous session; the go-public trigger stays the owner's (idea 1000700, ADR 0134).
- **Task:** task 1002706 · **Goal:** 1000059 · gap 13 of [`docs/audits/project-creation-gap-list.md`](../audits/project-creation-gap-list.md) · ties: task 1002621, task 1002275, idea 1000671.

## Context

Two facts collided at the scaffold's core-install step:

1. **New projects were born frozen-stale.** A fresh scaffold pinned `file:vendor/bongos-core-1.19.2.tgz` — ~60 patches behind — because `installedCoreTarball()` (task 1002275) reuses whatever tarball the control plane's own `file:` pin names, and the mothership's pin had sat at 1.19.2. ADR 0136 channels can't move a `file:` pin, so children had no upgrade path.
2. **The registry cutover quietly broke the fallback.** Task 1002621 moved cloudbongos.com's own pin to the registry (`"@bongos/core": "1.19.56"` — verified on the box 2026-08-12). With no `file:` pin, `installedCoreTarball()` returns null and the scaffold falls into the `package-core.js` source rebuild — which **aborts on a consumer instance** (REPO_ROOT inside gitignored `node_modules` → empty core set → the child repo is left empty, the exact task-1002275 failure resurrected). The next greenfield scaffold on the box would have failed outright.

The task brief proposed "make registry the scaffold default now that `@cloudbongos/core` is public (verify unauthenticated `npm view` works)". **That verification fails**: both `@cloudbongos/core` and `@bongos/core` 404 anonymously on `registry.npmjs.org` (2026-08-12) — they are private scoped packages (ADR 0134), public only at the launch go-public step. A registry-default scaffold today would hand every new owner a caret pin + env-fed `.npmrc` they cannot resolve without a paid-org token — a project **born uninstallable**, strictly worse than born-stale.

## Decision

**Three-rung core-resolution ladder** in the standalone scaffold (freshest-correct first), replacing the two-rung one:

1. `file:`-pinned control plane → reuse its pinned tarball (task 1002275, unchanged).
2. **NEW — registry-pinned consumer control plane → `npm pack` the core it has installed** (`installedCorePackDir()` finds `node_modules/@bongos/core`, the scaffold packs it to a temp dir and `--vendor-core`s the result). The child pins the **same, current core the hub runs** — 1.19.56 today, not 1.19.2 — and stays `file:`-pinned, so its owner needs no npm token.
3. Genuine source checkout → `package-core.js` rebuild (unchanged).

The opt-in registry path (`PROVISION_CORE_FROM_REGISTRY=1` + `NPM_TOKEN`, fail-soft) is untouched. **Registry as the scaffold default is deferred to the ADR 0134 go-public step** — the same owner decision idea 1000700 tracks (public repo / public npm / wait for the ADR 0099 mirror). When the package goes public, flipping the default becomes a small follow-up: drop the token gate, keep fail-soft.

**Ops leg (gap 13's "flip the box env"):** nothing to flip now — setting `PROVISION_CORE_FROM_REGISTRY=1` on the box today would birth token-locked children (the private-pin trap above). Child freshness rides two things instead: this ladder (children inherit the hub's core at birth) and the hub's own pin staying current (task 1002708 — the upgrade lane must commit + push the pin).

## Consequences

- Born-stale collapses from "frozen at 1.19.2 forever" to "as fresh as the hub" — and the hub's freshness is an explicitly tracked lane (task 1002708).
- The post-cutover empty-repo regression is closed before it fired in production.
- `npm pack` naming (`<scope>-<name>-<version>.tgz`) is derived from the installed package's own `name`, so both scope aliases work.
- Rejected: registry-default now (verified-dead premise; uninstallable children), dropping `NPM_TOKEN` (the package is private — tokenless `npm ci` fails closed by design, ADR 0134), vendoring from the npm cacache (undocumented layout; `npm pack` is the supported path).
