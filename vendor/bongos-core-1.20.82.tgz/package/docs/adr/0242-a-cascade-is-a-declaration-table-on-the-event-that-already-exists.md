# 0242 — A cross-role cascade is a declaration table on the event that already exists

- **Status:** Accepted
- **Date:** 2026-09-04
- **Tasks:** [#1003549](https://cloudbongos.com/builders#/task/1003549) (goal 1000074, the artist's loop) — the split [#1003115](https://cloudbongos.com/builders#/task/1003115) (R04) invited in its own brief: *"if that generalisation is bigger than this task, split it — a cascade mechanism is its own task and possibly its own goal."* Encoded as a real dependency edge by [#1003264](https://cloudbongos.com/builders#/task/1003264).
- **Related:** 0241 (the artist gate — why a cascade may never fail a ship), 0083 (the module system's one-way rule and the kernel seams), 0233 (a proposal is a task carrying a patch — the same `(source, source_ref)` idempotency), 0086 (goals), 0120 (pay on land)

## Context

R04 needs "every ship with copy or visuals generates one [review task]" — automatic on ship, never
hand-filed. Its brief said plainly that the infrastructure for that **did not exist**, and named the
spark queue as the prototype to extend. Reading both surfaces closely shows the prototype is the
wrong half of the problem:

- The **spark queue** (goal 1000062 / [task 1002921](https://cloudbongos.com/builders#/task/1002921))
  returns open Big Idea Sparks not yet developed.
- The **copy-desk flag queue** (R02 / [task 1003113](https://cloudbongos.com/builders#/task/1003113))
  returns surfaces anyone flagged as needing touch-up.

Both are **PULL**: a filtered listing of rows another role had already created. They are how one role
*finds* work another role left. Nothing anywhere **generated** work on a state transition, which is
the **PUSH** R04 actually asks for. (`cascade-dispatch.js` is model-cost routing and unrelated —
named here only because its name has sent more than one reader down the wrong path.)

## Decision

### 1. No new bus — `task.shipped` already exists

The kernel seam registry's own header uses this exact scenario as its worked example: *"the lifecycle
emits `task.shipped` and the discord module may want to react."* The event is emitted post-commit by
both ship paths (the publish reconciler and the ship routes), and already has two consumers —
discord's ship broadcast and sessions' deferred reward.

So a cascade is **one more listener on the event that already says a ship happened**, registered in
`routes/lifecycle.js` beside the kernel port, for the reason that file already documents: the route
mount is the one boot hook that runs both in the live server and whenever a test rebuilds the router.
Building a second notification path would have been a parallel spine to keep in sync with this one.

### 2. A declaration table, not a rules engine

A cascade is one frozen entry: `{ key, discipline, when(task), title(task), body(task) }`. There is
no condition language, no stored rules, no per-project configuration, no UI, and no priority
ordering. Adding a cascade means appending an entry; the runner does not change.

This is the [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
/ [ADR 0239](0239-a-recommendation-is-a-table-that-carries-its-own-reason.md) shape applied to a
different problem, and for the same reason: the generalisations worth building are the ones two or
three real entries have shown they share. With one consumer in existence, a rules engine would be
inventing the requirements it then satisfied.

### 3. `CASCADES` ships EMPTY, and R04 writes the first rule

The mechanism lands with no production cascade. Its four properties are proved against the tests'
own declarations rather than against one example — which is the stronger proof, because a mechanism
pinned to its first consumer's shape tends to fit only that shape.

This is deliberate and is asserted, so the emptiness is a decision on the record rather than
something nobody noticed. The artist review cascade is R04's content: this task built the thing R04
said was missing, and stopped there.

### 4. Four properties, all of them load-bearing

- **It can never fail the ship it reacts to.** The event fires post-commit, both emitters already
  wrap it, listener errors are isolated by the seam, and `runCascadesForShip` catches everything and
  returns a report. Every failure shape — a predicate that throws, a malformed rule, a database that
  is down, a junk payload — is a logged report and nothing else. This is not defensive habit: ADR
  0241 settled that an artist's review may hold a **deploy** and never a builder's **ship**, and a
  generator that could fail a ship would smuggle that gate back in through the back door. Verified
  against a real failure, not a stub: with no database reachable, emitting `task.shipped` logs one
  error line and resolves.
- **It is idempotent, on machinery that already exists.** Generated tasks carry `source: 'cascade'`
  and `source_ref: cascade-<key>-<taskId>`, so `createTask`'s `(source, source_ref)` read — the same
  one a copy proposal uses (ADR 0233) — makes a reconciler re-sweep, a re-ship, or both emitters
  firing a no-op. The runner checks first, so the ordinary case is a read.
- **It says where it came from.** Every generated task inherits the source task's `goal_id` and
  `version_id`, carries the originating id in its ref, and opens with the source task and the rule
  key. NOT `parent_task_id`: that column models a **subtask**, and cascaded work is not part of the
  ship that triggered it — it is separate work, for a different role, that outlives its trigger.
- **It files at `backlog`, never `ready`.** Generated work is a request and goes through ordinary
  triage, like a copy proposal or a capture. Auto-filing claimable work would let a rule nobody
  re-read mint claims.

## Consequences

- **R04 is unblocked**, and narrowed: it appends one entry to `CASCADES` and writes the review task's
  content and the ADR 0241 gate. It does not build a generation mechanism.
- **A rule key is permanent.** It is half the `source_ref`, so renaming one re-files every task that
  rule ever generated. Stated in the file and pinned by the duplicate-key check.
- **The mechanism is discipline-agnostic.** Nothing about it is artist-specific; an ideator or
  engineer cascade is the same entry with a different `discipline`. That is the generalisation the
  brief asked for, and the reason this is not simply part of R04.
- **Accepted limit:** cascades are declared in code, not configured per project. A project that
  wants a cascade the platform does not declare cannot have one. That is the right trade while the
  count is zero, and the point at which it stops being right is when the second and third entries
  disagree about what they need.

## Rejected

- **Extending the spark queue.** The brief's own suggestion, and the wrong half: the queue is a
  read-side filter over rows that already exist. Nothing in it generates anything.
- **A new event or a poller.** `task.shipped` exists, is post-commit, and has two consumers already.
- **A rules engine, or per-project cascade configuration.** See §2 — both are generalisations ahead
  of their evidence.
- **Filing generated work at `ready`.** See §4.
- **`parent_task_id` as the link.** See §4 — it would claim a subtask relationship that is not true.
- **Running the cascade inside the ship transaction.** It would make a generation failure a ship
  failure, which is exactly the coupling ADR 0241 rules out.
