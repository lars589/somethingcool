# 0177 — A goal membership is a `membership_kind`, and the rename ships expand-then-contract

- **Status:** Accepted
- **Date:** 2026-08-18
- **Tasks:** [#1003013](https://cloudbongos.com/builders#/task/1003013) (goal 1000068 — government terminology; unlinked from the goal's criteria on 2026-08-18 because it is a live-column migration, not a naming pass)
- **Extends:** [ADR 0174](0174-government-terminology-ranks-not-roles.md) — the reserved-word rule, applied to the fourth use it did not cover
- **Related:** ADR 0016 (authority resolved server-side, per request, uncached), 0086 (goals + scope walls), 0154 (goal owner/manager authors criteria), 0137/0161 (land → release → deploy are three gates)

## Context

ADR 0174 reserved the word **role** for the three crafts — Artist, Ideator, Builder — and renamed the
government's use of it to **rank**. Its fitness rule (goal 1000068 R07) enforces the reservation on the
**government surface only**, and that scoping is deliberate: `builders.system_role` is a core
machine-identity column, and Discord's API owns its own "role" noun. A repo-wide ban would be wrong.

Sweeping the docs for R08 turned up a **fourth, independent use** that nobody had catalogued:
**goal membership**. `goal_members.role` holds `'lead' | 'member'` — created by `160_goal_tier.sql`,
read as `actorMembership.role === 'lead'` in `modules/lifecycle/goal-authz.js` and in the PATCH
`/goals/:id/members/:builderId` gate, rendered by the hall's Goals page as "Manager"/"Member". It sits
outside R07's surface, so the rule is silent on it — the rule working as designed, and also the reason
this use would have sat there indefinitely.

Four meanings, for the record: (1) government ranks — renamed by ADR 0174; (2) the three crafts — the
reserved meaning; (3) Discord server roles — out of scope, Discord's word; (4) goal membership — this.
A **fifth** turned up while doing the work and is deliberately NOT in scope here:
`project_memberships.role` (`'owner' | 'builder' | 'visitor' | 'pending'` — whose `builder` value
collides with a craft name as well). It is filed as its own task; this ADR is the worked example for it.

Two things make this small change need a decision record. The value is on the **authorization** path
(the MANAGER predicate), and the column is **live**.

## Decision

**1. The noun is `membership_kind`; the values are unchanged.** `goal_members.membership_kind` holds
`'lead' | 'member'`. The values were never the problem — the noun was. `rank` would be wrong (a
membership is not a position on the ladder), and `position` would be worse: ADR 0174 uses "position"
as the *prose* word for what a rank is, so borrowing it here recreates exactly the qualifier collision
("rank-role") that ADR 0174 diagnosed.

**A boolean `is_lead` was seriously considered and rejected.** It removes the word rather than trading
it, and there are exactly two values with one default — the task itself argued for it. Two things
decided against: a text rename preserves the copied `CHECK` and stays a *reversible* schema change on a
live authz column, whereas `ADD boolean; UPDATE; DROP text` is data-destructive; and the values are how
every consumer already reads (`'lead'` renders "Manager"), so the boolean would have changed the shape
of every call site instead of one identifier. The extensibility argument is secondary but real: a third
membership (reviewer, observer) is a row-value under this shape and a migration under a boolean.

**2. The migration is EXPAND-THEN-CONTRACT, not `RENAME COLUMN`.** `bongos upgrade` auto-rollback
reverts the **code pin** and not the DB. A bare rename plus a rolled-back deploy would leave the
previous release querying a column that no longer exists — every goal-membership check erroring, on the
authz path. `tests/migrations_forward_safe.mjs` exists to catch precisely this, and it would have caught
it here. So:

- **Step 1 (`core_220_goal_members_membership_kind.sql`, this task)** — ADD `membership_kind`, backfill
  it from `role`, copy the `CHECK`, and keep the two columns in lockstep with a **BEFORE INSERT OR
  UPDATE trigger** whose direction is decided by which side changed. Both names therefore work for one
  release: new code writes `membership_kind`; the historical `lifecycle_001` seed and any older release
  (including the one a rollback restores) write `role` and the new column follows. Forward-safe, no
  pragma, nothing to remember in application code.
- **No `SET NOT NULL` in step 1.** The trigger fills the column on every write (a BEFORE ROW trigger
  runs ahead of constraint checks), but a static NOT NULL on a column the previous release has never
  heard of is the shape the forward-safety gate flags, and it would flag it rightly. NOT NULL arrives
  with step 2.
- **Step 2 (its own task)** — DROP `role` and the trigger, once the release carrying step 1 is behind
  the live pin. That step IS forward-unsafe, ships with the `-- forward-unsafe:` pragma, a fresh
  backup, and its own deploy window — the `government_001` precedent.

**3. The API field renames with the column, with NO alias.** `POST /goals/:id/members` and `PATCH
/goals/:id/members/:builderId` take `membership_kind`; the refusals become `bad_membership_kind`,
`owner_membership_fixed`, `membership_change_conflict`, `membership_change_failed`. ADR 0174's own
Lineage records the lesson that a time-boxed shim outlives its release, so there is no `role` alias to
outlive: the rename is a contract change, and `tests/goal_member_kinds.mjs` pins that the old field name
buys nothing. Every known consumer (the hall's Goals page, the generated typed client) ships in the same
release; the generated API docs regenerate with it.

**4. The reservation gets a SECOND narrow wall, not a widened first one.**
`<redacted>` (`scripts/gds/fitness.js`) scans the goal-membership surface — the
routes and pure gate that decide it, the hall page that renders it — plus, line-scoped, the lines of
`modules/lifecycle/db.js` that name `goal_members`. The line scoping is the point: that file is 5k+
lines and legitimately says "role" about ranks and `builders.system_role`, so scanning it whole would
need an allowlist longer than the rule, while scanning the lines that name the table catches the only
regression available — a membership query reaching for the old column — with no false positives. The
only exemption is a line that CITES the rule (ADR 0174 / ADR 0177 / task 1003013); naming a ban has to
be legal or the code cannot explain itself. R07 stays scoped to the government surface, unchanged.

## Amendment, same day — the FIFTH use: project membership (task [#1003090](https://cloudbongos.com/builders#/task/1003090))

The sweep for the fourth use turned up a fifth, and it is worse: the hub's
`<redacted>.role` (`'owner' | 'builder' | 'visitor' |
'pending'`, ADR 0141 §3) collides with the reserved word **twice** — the column is named
`role`, and one of its VALUES is `'builder'`, a craft name pressed into meaning "a
non-owner member of this project". The migration's own comment ("a COARSE role ONLY …
the role is owner|builder|visitor, NEVER a rank") is the same qualifier tell ADR 0174
diagnosed in "rank-role".

Decisions 1, 2 and 4 above carry over unchanged: the column becomes `membership_kind`,
the value becomes `'member'` (`owner` / `visitor` / `pending` untouched), the migration
is expand-then-contract with a lockstep trigger (`<redacted>`), and the
fitness wall's file list grows rather than the rule widening. **Decision 3 is the one
that does NOT carry over.**

**Decision 3′ — this rename keeps a compatibility window, and the sender writes BOTH
spellings.** This is a deliberate, named divergence from decision 3 above *and* from the
sequence task [#1003090](/builders#/task/1003090) itself prescribed ("the API field renamed with no alias"); the
task wrote that sequence before anyone had looked at who calls the endpoint. Decision 3
holds wherever every caller ships in one release, which is why it stays the default — and
it does not hold here. The goal-membership rename could ship without an alias because every
caller lived in the same release. This table's writer is `POST
/sso/membership/check-in` — a **server-to-server call from other instances**, each on
its own upgrade schedule (ADR 0137/0161: land, release and deploy are three separate
gates *per instance*). So:

- the **hub accepts both** fields, `membership_kind` winning when both arrive, and maps
  a legacy `'builder'` to `'member'` on the way in;
- the **sender sends both** (`src/bongos/auth.js`). This is the part worth writing down:
  sending only the new field would make an un-upgraded hub silently default every
  membership to non-owner — *dropping the owner flag* — while sending only the legacy
  field would make an upgraded hub translate forever. Sending both is what makes the two
  ends independent;
- the trigger therefore maps **values as well as columns**, in both directions, which
  `core_220`'s did not have to.

**And a trap both triggers share, found by the grader on [#1003090](/builders#/task/1003090).** The INSERT branch has
to tell "the caller wrote the new column" from "the column's DEFAULT filled it" — and it
cannot, if the new column has a DEFAULT: **Postgres materializes a column default into
`NEW` before any BEFORE ROW trigger fires.** With a default in place, an old-release
`INSERT … (client_id, github_id, role) VALUES (…, 'pending')` — `inviteToProject`'s exact
statement — took the "new code wrote it" branch and overwrote `role`, turning a pending
INVITE into an active membership. So the new column stays **DEFAULT-less** while the legacy
one is still written (NULL then means exactly "not written"), and `DEFAULT` + `NOT NULL`
arrive together in step 2. `core_220` shipped with the defective form and was corrected
the same day under task [#1003093](https://cloudbongos.com/builders#/task/1003093) — there
the same statement demoted a goal's first lead to `member` on a fresh install
(`lifecycle_001_goal_first_leads.sql` runs after the core migrations), and no production
row was ever affected because the pin still served 1.19.218; the invariant is
pinned statically by `tests/membership_kind_lockstep.mjs`, since the trigger only
misbehaves against a live Postgres and CI has none.

The window's removal was a filed task, and its condition was explicit: every federated
instance past the window, not merely "one release later". A time-boxed shim still ships
with the test of its absence (ADR 0174's Lineage lesson) — that test lands with the
removal, because until then the legacy field is load-bearing, not vestigial.

### The window closed — 2026-09-16, task [1003092](https://cloudbongos.com/builders#/task/1003092)

`<redacted>` is the contract phase: the lockstep trigger and its function
are dropped, `<redacted>.role` is dropped, and
`membership_kind` gains `NOT NULL` + `DEFAULT 'member'` — the two guarantees 010
deferred. The check-in route's schema no longer names `role` (strict validation
refuses a legacy-only body with 400 and writes nothing), the sender writes one
spelling, and the translator functions are deleted.

**How the condition was satisfied, since it was a condition and not a date.** The
hub holds no record of a caller's core version, so the audit probed `/version` on
every origin in the hub's project catalogue. The release carrying the expand phase is
core 1.19.241 (2026-08-18). The hub served 1.19.766; every hosted instance served
1.19.312 or later. Two catalogued instances — the original standalone Example
(core 1.17.3) and Emersonian Circles (no `coreVersion` at all) — sat *below* the
window, and that turned out not to matter: federation itself (the hub SSO, the client
registry, the idp client config and the check-in sender) landed on 2026-07-13, after
the 1.18.0 re-seed, so a 1.17.x core has no idp config, registers as no sso_client and
has never sent a check-in of either spelling. They are catalogue-only rows. One hosted
box (walk-lantern) was unreachable; if it wakes below 1.19.241 it must be upgraded
before anyone signs in to it. The general lesson for the next cross-version window:
"behind the release" and "a live legacy sender" are different sets, and the second is
the gating one.

## Consequences

- The word `role` no longer names a goal membership in the API, the hall, or the docs, and in the DB it
  survives only as the step-1 compatibility column, on a trigger, for one release.
- **The two halves must ship in one release** — they do: the column, the trigger, and every reader land
  in one commit, so no deploy sees new code against an old schema.
- A rollback of that deploy is safe by construction, which is the whole reason for the trigger. It is
  the only new moving part on the write path, and it is the thing step 2 removes.
- `docs/canonical-permissions.md` (the goal-management wall) now names `membership_kind`; the
  `authorizeGoalManagement` behaviour is untouched — this ADR changes no authority, floor, or grant.
- The fifth use (`project_memberships.role`) shipped the same day under the amendment above — same shape, plus a cross-version window because its writer is another instance. That window closed under task 1003092 (`<redacted>`); both renames are now complete and one-spelling.
- **No sixth use is known.** The remaining `role` spellings in the repo are the three legitimate ones ADR 0174 named: the crafts, `builders.system_role` (machine identity), and Discord's own noun — plus HTML's ARIA attribute, which every wall strips before matching.
