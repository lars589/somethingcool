# ADR 0259 — A project's departure from the public list is public, and the copy says so

- **Status:** accepted
- **Date:** 2026-09-07
- **Task:** [task 1003672](https://cloudbongos.com/builders#/task/1003672) (BONGOS-V1, goal 1000046 — *Project creation*)
- **Deciders:** the owner (choosing between accept / delay / decoys), Claude
- **Related:** [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) §6.2 (which filed this leak rather than implying it fixed) · [ADR 0182](0182-project-visibility-two-axes.md) D2a (the stealth redaction and its `STEALTH_ANONYMOUS_KEEPS` allow-list) · [ADR 0253](0253-the-takedown-lever-has-two-writers-and-provenance-is-a-column.md) (the `visibility_source` provenance this feed joins)

---

## 1. The channel

The public projects feed publishes a named list plus a count of anonymous rows. When a
project flips to stealth, its named row **leaves the identified block** and the anonymous
count **rises by one**. An observer who keeps yesterday's feed and diffs it against today's
reads that off directly:

> *Mercury is gone, and there is one more black hole.*

That names the project that went stealth, and the moment it happened, with no reference to
ordering at all.

**Everything ADR 0182 D2a does is defeated by it.** That ADR takes real trouble to keep any
stable per-project key off an anonymous row — `STEALTH_ANONYMOUS_KEEPS = ['state', 'orb']`
is an allow-list precisely so a column added next year is anonymous without anyone
remembering to come back to it. But the identity was never carried *on* the anonymous row.
It is carried by the **absence** of the named row that used to sit beside it.

**It is larger than the leak [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md)
closed.** The ordering channel needed repeated sampling and correlation to be useful. This
one is a single diff of two snapshots and it is exact.

## 2. Why no ordering fix reaches it

It is not an ordering property, so no `ORDER BY` change touches it. It is inherent in
publishing a named list at all: any list that names its members leaks a member's departure
to anyone who read it twice. The three ways out are all product decisions with visible
costs, which is why 0255 filed this rather than fixing it:

| Option | Cost |
|---|---|
| **Accept it, and say so** | An observer archiving the list learns who went stealth, and when. |
| **Delay** — keep the named row for a window | A privacy control that takes days to take effect, which is the wrong direction for a privacy control. |
| **Decoys** — pad the anonymous block | The count stops being truthful. It is truthful today. |

## 3. Decision

**Accept it, and make the copy say so.**

The promise stealth actually keeps is about the project's *contents*, not about the
*transition*. An anonymous row stays anonymous: no name, no tagline, no art, no origin, no
stable key, nothing that survives to the next snapshot. What is not private is the act of
stepping off the named list, because the named list is published and readers may keep
copies of it.

Two reasons this is the right end of the trade, and not merely the cheapest:

1. **It is already the honest reading of the existing promise.** ADR 0182 D2a made existence
   and count public *by design* — the map shows that hidden projects are there. A count that
   is public and truthful is a count whose changes are public. Delay and decoys both work by
   making a currently-honest number less honest.

2. **The alternatives damage the control they defend.** A delay means an owner clicks the
   privacy setting and is not private yet, which is a worse failure than the one it fixes —
   the owner believes they are hidden while they are not. Decoys spend the count's
   truthfulness on a guarantee that is still only probabilistic.

### 3.1 What "say so" means concretely

The owner-facing copy for Stealth previously read:

> The map shows only that something is there. Its name, and everything else about it, stay
> yours — and nobody can ask to join.

Every clause is true and the paragraph as a whole still oversells, because a reader takes
"its name stays yours" to cover the switch itself. The copy now names the boundary in both
places an owner meets this setting — the choice's blurb and the explanatory fold — in the
plain register [ADR 0182](0182-project-visibility-two-axes.md)'s interview fixed for this
card (the space metaphor belongs to the drawn orb, never to the words).

**A privacy control that oversells is worse than one that admits a limit**, which is the
same standard 0255 §6 set for itself.

## 4. What a future fix must not do

Recorded so a later attempt does not undo the two guarantees that *are* held:

- **No stable per-project key on an anonymous row** — the `STEALTH_ANONYMOUS_KEEPS`
  allow-list ([ADR 0182](0182-project-visibility-two-axes.md) D2a). A decoy scheme that
  needs to tell its own padding apart from real rows is the classic way this gets
  reintroduced.
- **No anonymous ordering an observer can predict or correlate**
  ([ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) §3) — the trailing
  block's keyed, rotating permutation.

## 5. The residual this does not address either

Within one 24h epoch the anonymous block's permutation is stable, so two snapshots taken the
same day can tell black holes apart — though not name them. Bounded by the rotation, and
carried here from [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) §6.3 so
both residuals live in one place. Accepted on the same reasoning: the fix is a per-request
permutation, which breaks pagination exactly the way `ORDER BY random()` was rejected for in
0255.

## 6. Consequences

- No behaviour changes in `modules/platform-identity/projects-feed.js`. The feed, the
  redaction allow-list and the permutation are all untouched — this ADR decides that they
  are *finished*, not that they need more.
- The Stealth copy carries the boundary in both surfaces, and
  `tests/projects_hub.mjs` pins that it does, so the sentence cannot quietly drop out of a
  future copy edit and leave the page overselling again.
- [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) §6.2's "filed
  separately" is now resolved, and points here.

## Alternatives rejected

- **A delay window before the named row is dropped.** Rejected: the setting would not take
  effect when the owner sets it, and the owner would not know that. It converts an
  information leak into a false belief, which is worse.
- **Decoy rows padding the anonymous block.** Rejected: it spends the count's honesty, and a
  decoy scheme needs some way to distinguish padding from real rows — the exact stable key
  D2a forbids.
- **Dropping the named list.** Rejected: the map's whole purpose is showing what is being
  built here; a list nobody can read protects a privacy nobody asked for at the cost of the
  feature.
- **Saying nothing and leaving the copy as it was.** Rejected: the copy would keep implying a
  guarantee the system does not make. That is the failure mode this ADR exists to close.
