# 0187 — Collab's four carried-forward questions, answered

- **Status:** Accepted
- **Date:** 2026-08-24
- **Tasks:** [#1003170](https://cloudbongos.com/builders#/task/1003170) (goal 1000075 — collaboration and the social hall). Settles the questions criteria `collab-pass-a-task`, `collab-closeness-consented` and `collab-mingle-two-switches` were each carrying.
- **Related:** [ADR 0171](0171-profile-rollup-join-and-consent.md) (fail-closed consent in the READ path), ADR 0032 / 0033 (Discord as a one-way mirror, outside the trust boundary), [ADR 0120](0120-pay-on-land-and-builder-owned-rebase-gate.md) (pay on land)

## 1. Why this ADR exists at all

Goal 1000075 was written with four questions left open **on purpose**, under the
owner's instruction to *"answer them in the goal, do not let them be decided by
accident"*. That phrasing is the point: each one is the kind of question an
implementation answers silently if nobody answers it first — by picking whichever
branch was easier to code, and then the choice is load-bearing and undocumented.

The answers were given on 2026-08-23. This ADR records them, and the criteria
they settle were rewritten from *"the goal states explicitly whether X or Y"* into
the decision itself, so they are testable rather than a note to decide something.

## 2. Closeness is a WEIGHTED BLEND, and it must be able to explain itself

Closeness is computed from several signals — co-claims, co-build sessions,
goals shipped together, and (see §4) comms and mentions once chat is mirrored in.
Not a single signal.

Two consequences that are part of the decision, not follow-ups:

- **The weights are data, not a magic constant.** A blend whose coefficients are
  buried in a function is a model nobody can revise without reading code.
- **"Why am I close to them" must be answerable on the surface that shows it.**
  This score describes real people to each other. A number that ranks colleagues
  and cannot say what it is made of is the kind of thing that quietly becomes
  unfair, and nobody can argue with it because there is nothing to point at.

`collab-closeness-consented` already required the graph to resolve through
ADR 0171's fail-closed consent, with the hide flag enforced in the READ path. That
stands: a builder who has hidden their profile is not a node in anyone's graph.

## 3. Passing a task RECOMMENDS; it never transfers the claim

The recipient still claims it themselves. Nobody acquires work without opting in,
`claim`/`release` remains the single path to holding a task, and declining costs
nothing.

The ledger records **who recommended it and why** — which was already the
criterion's own point: an untraced recommendation is indistinguishable from a task
quietly changing hands.

**Rejected:** transfer-on-pass. It would make the claim ledger stop meaning "this
person chose this work", which is the property the whole lifecycle rests on.

## 4. Co-build is a GOAL-level fact, not a shared claim — and the reward question was wrong-premised

The original question asked how to split a reward between co-builders. The owner's
answer rejects the premise. Verbatim: co-building *"is more about performing the
different ABI tasks together, no one is ever going to co run the task on their
claims. Likewise co building is more about goals etc. where people are working
together."*

So:

- the unit of collaboration is the **goal**, not the task;
- each builder holds and is paid for their **own** task exactly as today;
- **there is no split and no double award to design.** What co-build needs is
  presence and visibility of people working the same goal — not a new payment rule.

This is worth recording precisely because it is a *deletion*: a reward-splitting
mechanism would otherwise have been designed, reviewed and shipped for a situation
that does not occur.

### 4a. The same answer ADDS scope: Discord mirrors INWARD

Verbatim: *"big part will be to mirror chats from discord into the social features
like the agora etc. into bongos that way we can actually also see comms and
mentions."*

Discord is **outbound-only** today and sits outside the trust boundary (ADR 0032 /
0033). Mirroring conversation *inward* is therefore not a plumbing change — it
puts attacker-authorable text on an in-hall surface, and this goal must answer the
trust-boundary posture for mirrored content rather than assume it.

**It is in scope for this goal and it is BLOCKED**, on [task #1002946](https://cloudbongos.com/builders#/task/1002946)
(BV1.R166, the Agora surface in goal 1000064), which is deliberately unstarted
pending team buy-in. Two things follow: the mirror cannot land before that goal
opens, and **this goal must not quietly reimplement the Agora to get around it.**

**No criterion was added for it, deliberately.** A criterion blocked on another
goal's unstarted work would make 1000075 unachievable for reasons that have
nothing to do with collaboration. It is recorded here as scope with a named
dependency; it earns its criterion when goal 1000064 opens.

## 5. Mingle pairs CROSS-CRAFT

An engineer with an artist or an ideator. This matches the goal's founding
premise — the person you need is often not another one of you — and keeps mingle
doing something the craft-matched Collab request path does not already do.

**Rejected:** same-craft pairing "to go deep". It is a reasonable feature and it
duplicates what `collab-page-matches-my-craft` already delivers.

The two-switch consent rule is unchanged: project-level enable **plus** per-builder
opt-in, pairing declinable without penalty. Auto-pairing a person with a stranger
is a real-world social commitment, and one switch is not consent.

## 6. What this ADR does not decide

The closeness **weights** themselves, the mirrored-content trust posture (§4a),
and whether mingle ever gains a same-craft mode. Each belongs to the task that
implements the surface, and each now has a decision above it to be consistent
with.
