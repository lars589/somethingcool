# 0337 — The hub account is the person, a hall account is their seat in one project, so anything that spans projects lives on the hub

- **Status:** Accepted
- **Date:** 2026-09-25
- **Deciders:** the owner (direction given 2026-09-24 while reviewing goal 1000110 Wave 1; the D4 calls answered 2026-09-25), Claude.
- **Task:** [task 1004255](https://cloudbongos.com/builders#/task/1004255) (goal 1000110, Working area 2: account creation, management & community)
- **Amended:** 2026-09-25 evening, D5 — the owner's four placement calls from the Wave 2 review sheet, recorded by [task 1003444](https://cloudbongos.com/builders#/task/1003444).
- **Amends:** [ADR 0336](0336-a-guilds-record-is-the-sum-of-what-its-members-already-show.md) D5 (superseded by D4.4 below) and D8 (the map ranks by the rounded total); `docs/specs/<redacted>.md` D8 (D4.1); the privacy spec's "`hide_stats` beats everything" rule, for guild totals only, and only for a member who was told and left counting on (D4.4). ADR 0336 D4 (a guild's size is its public roster length) is **unchanged**.
- **Relates to:** [ADR 0141](<redacted>.md) (the hub is the identity provider; authority stays local), [ADR 0217](0217-rank-gates-inviting-not-viewing.md) (rank gates inviting, not viewing), [ADR 0334](0334-the-recruiting-directory-lists-a-hidden-builder-by-name.md) (the name-only recruiting tier), [ADR 0335](0335-an-invite-is-a-pre-approved-row-on-the-projects-own-instance.md) (an invite is the project's own row), [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) (a public list is ordered only by what it publishes)

## Context

ADR 0141 made cloudbongos.com (the hub) the identity provider. One platform account signs in to every hosted project, and each project still decides rank, credits and admission for itself. That settled *who you are*. It did not settle *where a page goes*, so each task's text decided that for itself.

Goal 1000110 Wave 1 (2026-09-24) showed what that costs. R15 ([task 1002291](https://cloudbongos.com/builders#/task/1002291), ADR 0334) built a cross-project recruiting directory into the hall's `/people` because its task text said to. An owner call of 2026-08-30 had already moved cross-project discovery to the hub ([task 1003363](https://cloudbongos.com/builders#/task/1003363), [task 1003444](https://cloudbongos.com/builders#/task/1003444)). A placement audit of the goal's 66 open tasks found more of the same: recruiting, guild-map and settings tasks that placed a cross-project surface in the hall, or said nothing and would default there. Reviewing the wave, the owner said the people directory "shouldn't exist within the builder hall but instead the hub itself… the builders hall account is essentially a sub account that is specific to its project's domain", and that guilds "and many of these tasks also likely belong on the hub."

## Decision

**The hub account is the platform identity. A hall account is a sub-account: the same person's seat in one project, scoped to that project's domain. A surface is placed by the scope of what it shows.**

### D1 — The placement rule

| A surface goes on… | when what it shows is… | e.g. |
|---|---|---|
| **the HUB** (`modules/public-landing/`, `modules/platform-identity/`) | the person across projects, or more than one project | the people directory, community (leaderboards, search, builder of the week), guilds, connections (primary home, D5.4), recruiting and scouting, the public profile (with "Projects you build on" in its own view, D5.3), platform-account settings (D4.3), project invitations and the "join a project" field on their own page (D5.2) |
| **the HALL** (the project's own instance, `modules/hall-ui/`) | this project's people and work | `/roster` (Builders), the project console (invites, admission, ranks), tasks, goals, in-project activity and achievements |
| **both** | a person-centred view that has a useful in-project cut | "Builders you may know" (D4.2); connections, where the hall's tab shows only your connections who also build on that project (D5.4) |

`modules/status-ui/` is neither: it is the public status dashboard at `status.<apex>`, not the hall. A hall page may *link* to the hub for the cross-project view, but it does not rebuild it. When a task's text places a cross-project surface in the hall, the task is re-scoped before anyone claims it, never built as written.

### D2 — Authority does not move

D1 decides where pages go. It moves no authority. ADR 0141's line stands: the hub carries identity, and each project computes rank, credits and admission locally. A hub surface that acts on a project, such as an invite or an application, still lands as a row on that project (ADR 0335, ADR 0201). Hub pages read hub tables and the rollups projects already report. They never become a second authority over a project.

### D3 — The hall's `/people` retires, and `/roster` is the in-project directory

The hall's `/people` retires ([task 1003444](https://cloudbongos.com/builders#/task/1003444)). Its cross-project job, including ADR 0334's two-tier recruiting directory, moves to the one hub community page ([task 1003363](https://cloudbongos.com/builders#/task/1003363)). ADR 0334's predicates move unchanged; only the page that renders them changes. `/roster` ("Builders") stays as the in-project directory and stops linking out to `/people`.

**Amended by D5.1:** `/people` is deleted now, without waiting for [task 1003363](https://cloudbongos.com/builders#/task/1003363). Until that page ships, `/people` (and its legacy door `/scouting`) redirects to `/roster`.

### D4 — The owner's calls from the re-scope

1. **Hidden builders open to recruiters: the recruiter panel is recruiter-only, and public search is unchanged.** A builder who hides their numbers but stays open to recruiters appears in ADR 0334's name-only panel (login, display name, avatar) on the hub community page. The panel is shown only to a signed-in viewer that the recruiting door admits, which ADR 0334 defines as a project owner or a holder of `project.curate`. The public builder search (`GET /community/search`, [task 1002979](https://cloudbongos.com/builders#/task/1002979)) keeps listing such a builder by name with no numbers, the same as their public profile page already does. Private accounts stay out of both, and the private-and-discoverable sliver keeps its archon floor (ADR 0217 D2). This amends community-tab spec D8's "to every viewer identically": the public view stays the same for every viewer, and a signed-in recruiter also sees the panel. It adds no new disclosure class.
2. **"Builders you may know" is on both sides.** The hall profile panel ([task 1002297](https://cloudbongos.com/builders#/task/1002297)) stays. The hub community page gets a signed-in panel with the same suggestions across projects, over the existing own-scoped endpoint (`connection-suggestions.js`), with no new scoring. Every candidate keeps clearing `accountVisibleSql` there, so no private or provisional account can appear. The panel adds no read of `platform_identity_accounts` of its own (`tests/effective_visibility_predicate.mjs` holds that line).
3. **Platform-account settings live on a new hub account page.** Public/private, open to recruiters, hide my numbers, and handle/bio/links are properties of the platform account, so they are edited on cloudbongos.com. Each hall's Settings keeps per-project options only and links to the hub page. [Task 1002784](https://cloudbongos.com/builders#/task/1002784) (the settings inventory) and [task 1002800](https://cloudbongos.com/builders#/task/1002800) build to this.
4. **Guild totals count hidden and private members by default, with a notice and a per-guild switch (supersedes ADR 0336 D5).** The owner rejected D5's "count only members whose own record is public", because guilds of privacy-minded builders would look smaller than they are. A guild's totals should include its hidden and private members, while their own numbers stay unreadable. The rule for [task 1002302](https://cloudbongos.com/builders#/task/1002302) (R26):
   - **Terms.** A *non-public member* is one whose numbers are not public on the guild's page: a private account, hidden numbers, or not agreeing to be shown (`shown_publicly = false`).
   - **Notice and switch, which are the consent.** Every member is counted in the totals unless they switched it off for that guild. That is a per-membership flag, `counted_in_totals boolean NOT NULL DEFAULT true`, carried by R24's migration ([task 1002300](https://cloudbongos.com/builders#/task/1002300)). The invite, request and accept cards tell a non-public member, before they accept, that "your numbers count toward this guild's rounded totals", and they offer the switch there. The hide-my-numbers and private-account settings say the same and link to each guild's switch. A member who switches it off drops out at the next refresh.
   - **Rounded, never exact.** Totals are published on a 1–2–5 band scale (10, 20, 50, 100, 200, 500, …), shown as the band floor ("100+"). The scale is a named constant in R26.
   - **A minimum of 3.** Non-public members' numbers enter the totals only while the guild has at least 3 counted non-public members (a named constant, `k = 3`). Below that, the totals add up only its public members.
   - **A weekly refresh.** Totals are a snapshot recomputed at most once a week, never on a read. Each before/after comparison then costs an observer a week.
   - **Size is unchanged.** A guild's size stays the length of its public roster (ADR 0336 D4, ADR 0202 D4). Non-public members are never in it, so size minus roster reveals nothing, and a non-public member joining or leaving never moves it.
   - ADR 0336 D8's map ranks by the rounded published total, never the exact sum (ADR 0255). Private members' projects never enter a project count (ADR 0336 D5's union rule stands).

   **The honest limit, accepted by the owner (2026-09-25).** Rounding, the minimum and the weekly refresh stop a casual reader. They do not stop a determined guild owner, who can:
   - add members whose numbers they already know, such as two fake private accounts, so that a real non-public member becomes the third and enters the total;
   - then compare totals across refreshes, or pad with known members until the total sits on a band edge, and so learn a range for that member's numbers.

   The notice and the switch exist for this reason. A non-public member is told that their numbers count, and can turn it off for any guild they don't trust. This relaxes the owner-signed privacy rule "`hide_stats` beats everything" (privacy spec D2) for **guild totals only**, and only for a member who was told and left counting on. Every other surface keeps the rule.

### D5 — The owner's calls of 2026-09-25 evening (Wave 2 review)

Reviewing the Wave 2 sheet, the owner made four placement calls. They amend the D1 table above.

1. **Delete the hall's People page now.** The hall already has a Builders page (`/roster`), so `/people` goes without waiting for the hub community page ([task 1003363](https://cloudbongos.com/builders#/task/1003363)). The owner accepted that cross-project search and the recruiter name-only panel (D4.1) are absent until that page ships. [Task 1003444](https://cloudbongos.com/builders#/task/1003444) deleted the page, its nav entry and its page gate; `/people` and `/scouting` redirect to `/roster`. The recruiting API (`GET /scouting`, its own route gate and ADR 0334's predicates) is unchanged and waits for the hub page to render it.
2. **A builder's project invitations get their own hub page.** The invitations a builder has received (today a section of the hub's `/projects` page) move to a standalone hub page, and the "join a project" field (a project address and an optional note) moves there with them.
3. **"Projects you build on" moves to the builder's own profile, own view only.** Today a section of the hub's `/projects` page; a builder will see it on their own profile, and a visitor will not.
4. **Connections live on the hub first.** The hub is the primary home for connections. A project hall's connections tab becomes project-specific: it shows only your connections who also build on that project.

## Consequences

- Goal 1000110 is re-scoped against D1 before its Wave 2, in one owner-run script. Retargeted tasks carry a description append citing this ADR. Duplicates of the hub community page merge into task 1003363. Dependency edges are re-pointed before any merge or abandon, so no dependent is left on a dead edge. The goal's module scope widens to `public-landing` and `hall-ui`.
- Hub work grows. `modules/platform-identity/` and `modules/public-landing/` carry most of the remaining community work, so they reach their line ratchets sooner. ADR 0336 D1 already split guilds into their own files for this reason.
- A self-hosted instance that does not federate (ADR 0141 §4) has no hub, and so no cross-project surfaces. Its hall keeps `/roster` and the console, which is all a single project needs.
- Guild totals become a weekly stored snapshot instead of ADR 0336 D5's read-time sum, and R24 gains the `counted_in_totals` column. The guild cards and privacy settings gain the notice copy (R25, R27, and the hub account settings page of D4.3).

## Alternatives considered

- **Keep cross-project surfaces in each hall.** Rejected. Every hall would render the same platform-wide data, each copy would need the hub's privacy predicates, and a builder would meet a different "community" in each project.
- **Decide placement task by task.** Rejected, because that is what produced R15's hall directory. With a written rule, a task author can place a surface without asking.
- **Guild totals per ADR 0336 D5 (public records only).** This leaks nothing, even over time. The owner turned it down because guilds of privacy-minded builders would look smaller than they are (D4.4).
- **Count non-public members only if they opt in.** This is the safest for them, but totals understate until people tick the box. The owner chose counting by default with a notice and an off switch.
- **Count every member silently, protected only by rounding and the minimum of 3.** This was the first version of D4.4. It was withdrawn before landing, because the fake-account padding above defeats it for a member who was never told.
