# ADR 0323 — Hosting is three shapes, and we are not the landlord

- **Status:** accepted, **§2 superseded by [ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md)** (2026-09-28): project halls stay on the shared box, hosted by us, and only the owner's app goes to a platform of their choosing. Also **superseded in part by [ADR 0327](0327-a-cloud-host-runs-on-the-owners-account-and-the-key-is-borrowed.md)** (2026-09-22) — the platform choice, the not-the-landlord posture and decisions 2, 4, 5 and 6 STAND. Changed: §1 drops `dedicated-cloud-host` (two shapes, not three); §3's ~$14/project is the **owner's** cost, not ours, because a `cloud-host` now runs on the owner's own account; §7's capped free tier is retired with its premise — we no longer pay for customer compute.
- **Date:** 2026-09-21
- **Task:** [task 1004140](https://cloudbongos.com/builders#/task/1004140) (goal 1000106 — working area 1, Project creation)
- **Deciders:** Lars (Archon) — every numbered decision below is the owner's; Claude ran the audit and the platform comparison.
- **Gates:** [task 1004141](https://cloudbongos.com/builders#/task/1004141) (the rename) · [task 1004142](https://cloudbongos.com/builders#/task/1004142) (the migration) · [task 1004062](https://cloudbongos.com/builders#/task/1004062) (the env manifest)
- **Supersedes in part:** [ADR 0111](0111-instance-hosting-provisioning-module.md) · [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) · [ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md)
- **Related:** [ADR 0002](0002-digitalocean-over-hetzner.md) (why DigitalOcean) · [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) (the pull this ADR makes load-bearing for `byo-host`) · [ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md) (the seam whose second implementation this makes unnecessary)

## Context

Five active projects run as `hosting_shape='standalone'` on one `s-1vcpu-2gb` DigitalOcean droplet, beside the control plane itself. Each is a Node process and a Postgres database, about 80 MB warm; the box holds fifteen ([ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md)) at roughly $0.80 per project per month. It is the cheapest arrangement available, and standing it up cost us `scripts/gds/provision*.js` — about 4,600 lines that write systemd units, create unix accounts, render Caddy snippets, run `createdb`, install per-instance backup timers, and count memory against a ceiling.

That is the cost nobody priced: we are a landlord. Every one of those legs is infrastructure we maintain so that someone else's code can run on our machine.

Three further facts made the arrangement worse than its price suggested:

- **Customer code sits on our hub's registrable domain.** [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) Finding 1 established that the hub's session cookie, scoped `.cloudbongos.com`, is sent by the browser to every `*.cloudbongos.com` host — including a tenant's. It required the sign-in hardening to land *before* any tenant went on a subdomain. Two tenants are on subdomains today, one of them not the platform owner's, and the hardening has not shipped.
- **`dedicated` was written and never used.** A per-project droplet is 15–20× the shared cost, and no project has ever run on one.
- **The self-host container path kept finding new floors.** [ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md) made supervision a seam and named three remaining blockers; two shipped, and each existed only because we were building a container host of our own.

The owner's direction, settled over 2026-09-20/21, reframed the question. The platform should not host other people's applications at all: it should build on what others maintain, and let the owner keep the deployment platform they already use.

## Decision

### 1. Three owner-facing shapes

| Shape | Meaning |
|---|---|
| `byo-host` | The owner runs the instance: their machine, their VPS, their own platform account. **New.** |
| `cloud-host` | We stand it up for them on a managed platform. Rename of `standalone`. |
| `dedicated-cloud-host` | The same path on a larger plan. Rename of `dedicated`. |

`control-plane` is unchanged and stays unrequestable — it is the hub, not a product option.

**`co-tenant` is retired, not renamed.** It means *a process on our box, from our checkout* — the most platform-owned shape there is, and the exact opposite of bring-your-own-host. Reusing the name would make every existing comment and ADR reference lie. One row carries it and it is `torn_down`.

`dedicated-cloud-host` is a **plan size, not a second code path**. The DigitalOcean droplet and cloud-init implementation that sat behind `dedicated` becomes dead code.

### 2. DigitalOcean hosts hubs only

No customer project is deployed to it. The control plane stays where it is; the projects leave.

This closes [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md) Finding 1 by removing its precondition rather than by hardening the cookie: with no customer code on a `cloudbongos.com` subdomain, there is no tenant to receive the hub session. The cookie hardening remains worth doing on its own merits and is no longer load-bearing.

### 3. Render is the default platform for a `cloud-host`

Render's Postgres carries point-in-time recovery and automated backups on every paid tier. Roughly $14 per project per month (web service plus database).

Rejected: **Fly.io**, whose managed Postgres starts around $38/mo — the compute is cheaper and the database is not. **Railway**, whose Postgres templates are explicitly unmanaged: you tune and back them up, which is precisely the responsibility this decision exists to shed.

### 4. Cloudflare is the front door, not the compute

DNS, TLS, and — when `byo-host` needs to reach a machine behind a router — Tunnels, for which a working client already exists at `scripts/gds/cf-tunnel.js`.

**Not the hall's runtime.** Cloudflare Workers is a V8-isolate runtime, not Node; Express and `pg` would have to be rewritten. Cloudflare Containers is built for bursty workloads that sleep between requests, and the hall runs background sweeps and a live event stream that do not survive sleeping. Its Postgres would be external in either case.

### 5. Bongos does not integrate with the customer's deployment platform

Their application already deploys itself: Vercel and Netlify watch the repository. Bongos writes code and pushes it. There is no adapter layer, and an adapter layer would solve a problem that does not exist.

This is what makes "bring your preferred platform" nearly free to support. The platform we do not talk to is the platform we do not have to add.

### 6. The deployment platform is the system of record for secrets; Bongos stores names, never values

A project declares its environment variables to Bongos as a **manifest** — name, purpose, environment, required or optional — so a builder writing code knows what the surface is. The values live where the running application reads them, in a store that already encrypts, audits and rotates them.

Bongos holds no application secret, no platform API token, and runs no "is it set?" probe. Adding any of those makes the platform the custodian of other companies' credentials, which is the responsibility this ADR is spending its whole budget to avoid. See [task 1004062](https://cloudbongos.com/builders#/task/1004062).

For `byo-host` there is no platform to ask, and the manifest is simply marked unverifiable. That keeps *Bongos holds no values* true everywhere, with no exception to reason about later.

### 7. The free tier is a capped trial

At ~$14 per project, an indefinite subsidised free tier is not viable. This replaces [ADR 0145](0145-free-hosted-project-tier-isolation-and-domain-separation.md)'s "all-free for now". Implementing the cap is its own task; it cannot be metered before the migration.

## Consequences

- **This wave is mostly a deletion.** Systemd units, per-instance unix accounts, Caddy snippets, `createdb`, backup timers and the capacity ceiling are things Render provides. Not all of `provision*.js` goes — the repository scaffold, the GitHub App manifest handshake and the core-upgrade path serve the hub and the `byo-host` scaffold too. The migration task removes what is genuinely orphaned, after the projects have moved, and not before.

- **Per-project cost rises about 17×, from $0.80 to ~$14.** That is the price of not being a landlord, and it is why decision 7 exists. It also makes metering ([task 1001949](https://cloudbongos.com/builders#/task/1001949)) and the spend rollup ([task 1001621](https://cloudbongos.com/builders#/task/1001621)) real work rather than deferred work.

- **[ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md) stays true and stops being load-bearing.** Its measurements were correct and its ceiling still describes the box; the box just stops holding projects. The queued resize to 2 vCPU / 4 GB is therefore **not** to be spent ([task 1003923](https://cloudbongos.com/builders#/task/1003923), held).

- **[ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md)'s seam is not extended.** It correctly said it was "two implementations wide, not N". Render supervises its own processes, so the seam neither grows a third backend nor needs one.

- **The hub becomes the single point of failure it always was, now visibly.** With projects elsewhere, everything that can be lost with the droplet is the control plane's own database — which makes offsite backups ([task 1002214](https://cloudbongos.com/builders#/task/1002214)) the highest-consequence open item in the goal.

- **`byo-host` starts cheap and stays honest.** It reuses the pull that already exists ([ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md)): the owner supplies an origin and the hub reads the instance's own public manifest. Nothing is pushed to it, so it is excluded from the settings-apply and restart paths for the same reason `dedicated` was.

## Alternatives considered

- **Move to AWS or GCP.** Rejected. Their pricing is earned by consuming their managed services; a bare Linux instance from either is 2–3× DigitalOcean for the same memory, plus a console, an IAM model and a billing surface to learn. It adds maintenance where the goal is to remove it.
- **Keep the shared box and fix the cookie instead.** Cheaper, and it closes the security finding. Rejected because it leaves the 4,600-line landlord runner in place and answers none of the other three questions.
- **Build a deployment-platform adapter layer (Vercel/Netlify/Render).** Rejected as speculative pluggability, the thing [ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md) explicitly warned against. Their applications already deploy themselves.
- **Bongos as the secrets store, pushing values to each platform via its API.** Rejected: it makes us the custodian of other companies' credentials for convenience that the manifest already delivers.
