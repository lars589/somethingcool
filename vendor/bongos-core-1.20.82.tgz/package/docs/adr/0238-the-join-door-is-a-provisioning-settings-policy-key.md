# ADR 0238 — The join door is a provisioning SETTINGS key, and the hub column stays the cache

- **Status:** Accepted
- **Date:** 2026-09-03
- **Task:** [task 1002324](https://cloudbongos.com/builders#/task/1002324) (BONGOS-V1, goal 1000046 — *Project creation — visibility and customization*, criterion `proj-visibility-states`)
- **Deciders:** jaxri (Archon), Claude
- **Related:** [ADR 0182](0182-project-visibility-two-axes.md) (the two axes — this ADR only says *where* R05's half lives) · [ADR 0141](<redacted>.md) §3 (authority stays local) · [ADR 0190](0190-settings-apply-in-place-env-patch.md) (a pushed setting takes effect by a restart) · [ADR 0192](0192-platform-visibility-member-door.md) (`platform_visibility`, the neighbouring axis)

---

## Context

ADR 0182 D5 says R05 "**moves host** — an instance surface, not a hub one … The setting lives in the project's own hall settings, gated by the project's own ranks." It does not say through which channel, and on the tree as R05 was claimed those two sentences pointed at nothing that existed:

- **The hub catalog column that R04 shipped** — `platform_identity_projects.visibility` — is written by **no route at all**. Every write on `routes/projects.js` is `requirePermission('project.curate')`, an Archon/Metic *curation* gate with no ownership check, and `upsertProject` deliberately omits `visibility` from its column list (ADR 0182 D5: a client re-registration must not reset an owner's door). `owner_github_id` on that table is commented "advisory attribution (not an authority)". So the hub has, by design, no way to authorise an owner's visibility change.
- **"The project's own hall settings"** is a page that does not exist. `modules/hall-ui/public/settings.html` is per-**builder** (account / access / dev box / preferences); the hall's `my-projects.html` was deleted in task 1003308 ("the hub owns it"). Building a new project-settings page on the instance, plus the hub sync (R08, unshipped), to carry one radio group would ship a control that changes nothing anyone can see.

Meanwhile the surface where an owner **already manages a project** — `/projects?view=manage` on the hub — carries two adjacent settings that are the same shape as this one, on a channel built for exactly this: `provisioning_instances.settings`, a jsonb "dumb store" whose migration header names the keys the manage-page wave adds "one task at a time — *platform visibility, joinability, repo visibility, …*".

## Decision

**The owner's join door is a key in `provisioning.SETTINGS_VOCAB`** — `visibility ∈ (public, private, stealth)`, default `public` — set through the existing `PATCH /api/gds/provisioning/instances/:id/settings`, and rendered as one more section on the manage view.

That one line buys the whole of R05 from machinery already in place and already proven:

| What R05 needs | What the channel already does |
|---|---|
| only the owner may set it | `instanceAccessDenied` — own-scoped, Archon override, **404** (never 403) so there is no existence leak |
| the enum is enforced by the server | the route's schema **is** the vocabulary (`vocabSchema(SETTINGS_VOCAB)`), so a value off the list is a 400 and a key added to the vocabulary can never drift out of the validator |
| an audit trail | a `provisioning_events` row with the actor, `api:archon:<id>` on an override |
| the value reaches the instance | `settingsEnvVars` derives `<PREFIX>_VISIBILITY` from the vocabulary automatically; the runner patches `web.env` in place and restarts |
| the instance can read it | `src/branding.js` maps that env onto `project.visibility` and publishes it in the public manifest, beside its two neighbours |

### It is a POLICY key, not a platform-drawn one

The same store holds `PLANET_VOCAB` — keys the platform *draws* with, which have no default, ride no env and restart nothing. The door could have gone there (today only the map reads it, and the restart currently applies an env nothing consumes yet). It does not, for two reasons that outlive today:

1. **ADR 0182 D6 makes the door the ceiling `joinability` may only narrow**, and D1/D5 put admission authority on the instance. The instance is the thing that must refuse a self-join on `private` and refuse an application *at the door* on `stealth` (R11/R12). A door the instance cannot read cannot be a ceiling.
2. **A key with a default belongs in the defaulted vocabulary.** `effectiveSettings` gives `SETTINGS_VOCAB` keys today's behaviour for rows that predate them, which is exactly what ADR 0182's migration default (`'public'`, "existing rows keep today's behaviour") asks for. `PLANET_VOCAB` keys are nullable — null means *the platform picks* — and there is no such thing as "the platform picks your join door".

### The hub column is unchanged, and stays the cache

Nothing here writes `platform_identity_projects.visibility`. ADR 0182 D5 already calls that row a cache fed by the instance's report, and **R08 is that report** — this ADR only fixes where the truth it will carry is written. Until R08 ships, the map still reads the old `featured + active` predicate (R06's job), so an owner's pick is stored, validated, audited and delivered to their instance, and does not yet move the orb. That gap is R06/R08's, named here so the next builder does not go looking for a bug.

## Consequences

- Adding one key to `SETTINGS_VOCAB` propagates through every derived surface at once — the GET's `options`, the PATCH's validator, the env transport, the push receipt. The lockstep tests that had hardcoded the two-key world (`provisioning_settings*.mjs`, `provision_settings_apply.mjs`, the module's own unit file, the kit stub) all had to be told about the third key; that they broke is the guard working.
- The manage section deliberately has **no "what your project runs" read-back line**, unlike its two siblings. An already-deployed project reports no door until it takes a release carrying `project.visibility`, and a line that could only ever say *"this project's server doesn't report this setting yet"* is worse than no line. It arrives with the enforcement.
- `config/branding.neutral.json` gains `project.visibility: "public"`, so a self-hosted instance that never receives a push behaves exactly as it does now.
- The three settings on that page now answer three different questions and are easy to confuse. The mitigation is copy, not naming: each section's fold says what it is *not* ("separate from 'Who can see it' above — that one is the door on the project's own pages"), and the vocabulary comment in `provisioning.js` lays the three side by side.

## Alternatives rejected

- **A new owner-scoped write route on the hub catalog** (`PATCH /projects/:id/visibility`). Rejected: it would make the hub authorise a visibility change, which ADR 0182 D5 forbids in as many words, and it would have to invent per-project ownership authority on a table whose owner column is documented as advisory.
- **A new project-settings page on the instance's hall.** Rejected as the literal reading of D5: it is the right *long-run* home once a project has instance-side settings worth a page, but on its own today it is a control with no consumer — the map is fed by the hub, and the sync that would connect them (R08) is unshipped. The manage view is where an owner already goes, and the same value reaches the instance anyway through the push.
- **A `visibility` column on `provisioning_instances`, beside `description`.** Rejected: `description` earned a column because it is half the publish gate and is read by SQL; the door is a closed-vocabulary knob, which is exactly what the jsonb store plus a code-side vocabulary exists for (migration `provisioning_009`'s own reasoning: "a new key must not cost a migration each time").
- **Putting it in `PLANET_VOCAB` to avoid the restart.** Rejected above — it would buy a quieter save today and cost the ceiling rule tomorrow.
