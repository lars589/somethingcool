# 0331 — The sky is the ideator's home, and the project sky takes the goal map's page

- **Status:** Accepted
- **Date:** 2026-09-24
- **Tasks:** [#1004229](https://cloudbongos.com/builders#/task/1004229) (this ADR and the design of record), [#1004230](https://cloudbongos.com/builders#/task/1004230)–[#1004233](https://cloudbongos.com/builders#/task/1004233) (the build)
- **Goal:** [#1000095](https://cloudbongos.com/builders#/goal/1000095) — criterion `ideator-sky-tells-the-truth`, whose text this ADR rewrites.
- **Design of record:** [`docs/design/mocks/sky/`](../design/mocks/sky/) — the adopted prototype, and the pixel contract for the build.
- **Amends:** [ADR 0227](0227-a-task-network-map-is-refused-the-goal-graph-is-the-map.md) (§11 there), decision 11 of [`docs/specs/<redacted>.md`](../specs/<redacted>.md).

## 1. What happened

The owner reviewed an interactive prototype of the **ideator sky** and the **project sky** over
five rounds on 2026-09-24 and adopted it **as is** — copy, layout, colours, tour text, toggles,
interactions. That adoption contradicts two things already written down, so this ADR rewrites
them rather than leaving the build to be graded against a contract nobody meant any more.

## 2. The decision

**The sky is the ideator's home surface, not a decoration that arrives last.** It replaces
*Your thinking* for the ideator and it replaces the goal map page for the project.

**The rule that survives is the accessibility half, and it is unchanged in force:** the sky is
never the **only** path to anything it shows. The list drawer — the room — is one key away
(`L`), and every drawn thing is a row in it. What is dropped is "never load-bearing" and
"arrives last": those were a sequencing hedge from before there was a design to look at, and
holding the build to them now would mean shipping the owner's adopted surface as an optional
extra that nothing routes to.

**The five states and the two channels are untouched.** Criterion
`ideator-sky-tells-the-truth` names a *model* — star, protostar, satellite, remnant, cold body;
size is what a thought caused and never falls, brightness is how much of that work is still
alive — and it names it deliberately so the picture may change without the criterion becoming
unsatisfiable. This amendment changes the picture's standing, not the model.

## 3. Why amend ADR 0227 rather than reverse it

ADR 0227 refused a **whole-corpus task map** on measured evidence: ~1,357 tasks at 30.2px pitch
is confetti, and drawing it denser draws forty goals badly while claiming to show a thousand
tasks. **That refusal stands, and the project sky does not violate it** — it is 0227 §1's own
prescription, not its refusal:

- The entry point is the **goal graph**, as §1 requires.
- **Tasks are drawn only inside one goal, past a zoom threshold** — the per-goal drill-down §1
  and §10.5 measured as readable (worst case 127 tasks at 85.2px pitch; median 9). Below that
  threshold tasks are **dust density on a goal's rings, with no identities** — a texture that
  says "this goal is full", never a thousand discs nobody can name.
- The goal map's **table survives as the sky's ledger drawer**, which is 0227 §6's table
  equivalent, kept rather than dropped.

The one thing 0227 is genuinely amended on is **placement**: the goal map deliberately took no
nav slot, and a test asserts that. The owner grants the slot to the project sky, under Goals
(owner, 2026-09-24). Part 4 changes the page and that test together, with this ADR as the
licence.

Also noted: [ADR 0264](0264-the-ten-working-areas.md) deleted the goal **Living project sky**
([#1000044](https://cloudbongos.com/builders#/goal/1000044)) in the ten-working-areas cut. That
deletion is **superseded** — the work is alive again, under Working area 3, as tasks
[#1004229](https://cloudbongos.com/builders#/task/1004229)–[#1004233](https://cloudbongos.com/builders#/task/1004233).

## 4. The two heuristics that must not ship

The adopted prototype reads the live ledger for almost everything it draws, but **two things in
it are guesses**, and the built pages must not present a guess as a ledger fact:

1. **An idea's origin** — whether a person or a session filed it — is guessed from the idea's
   text (the `claude layer` toggle).
2. **"Born of a thought"** — a goal or criterion that came out of an idea — is found by scanning
   text for idea ids.

Parts 3 and 4 **hide** both layers. Part 5 replaces them with ledger facts: a `filed_via` column
and a real born-of-a-thought read. A heuristic drawn in the sky would be indistinguishable from
the facts beside it, which is the exact failure the criterion exists to prevent.

**Part 5 landed on 2026-09-24 (task 1004233) and both are ledger facts now.** `idea_inbox.filed_via`
(`hall | cli | discord | planning | api`; core migration `core_253_idea_filed_via`) is read off the session that
filed — a web cookie is the hall, a device-flow token is the CLI, anything else the API; the body
may add only `'planning'`, the Discord bot names `'discord'` on the port — and rows older than the
column stay NULL, shown by default and spoken as "filed before the ledger recorded where", never
backfilled from text. `GET /sky` returns `born: { goals, criteria }` from the two ratify tables
through the `ideas.bornOf` port, and both pages draw the nucleus ring, the notch and the thought's
place from it. The "claude layer" hides `cli`, `api` and `discord`.

## 5. Consequences

- The build (parts 2–5) is graded against `docs/design/mocks/sky/sky.template.html` as a **pixel
  contract**. Any deviation a gate or the file ratchet forces is listed in that part's ship
  notes, so a forced change is a recorded one rather than a quiet drift. **Part 3 landed on
  2026-09-24 (task 1004231):** the page at `/thinking`, its eighteen forced deviations listed
  one line each in
  [`docs/session-logs/<redacted>.md`](../session-logs/<redacted>.md)
  — the two §4 layers hidden, the bands derived from `GET /versions` rather than named, and
  `/me` resolving `idea.triage` for the nod. **Part 4 landed on 2026-09-24 (task 1004232):**
  the project sky at `/goal-map` — the SAME page opened in its "the whole project" lens
  (the body's `data-sky-lens` names the home lens; the switcher leaves for the other page),
  replacing the goal map (task 1003479) and taking the nav slot under Goals that ADR 0227 §11
  granted; its forced deviations are listed in
  [`docs/session-logs/<redacted>.md`](../session-logs/<redacted>.md).
  **Part 5 landed on 2026-09-24 (task 1004233):** the two §4 heuristics became facts —
  `filed_via` and the `born` read — and the pages draw them; see §4 and
  [`docs/session-logs/<redacted>.md`](../session-logs/<redacted>.md).
- The template ships with **no snapshot**: the snapshot script dumps real task, idea and goal
  titles, and this repo is public. `docs/design/mocks/sky/.gitignore` refuses both the snapshot
  and the built page.
- Criterion 1000384 is already `satisfied` and stays so; its text is rewritten, not its state.
  **This was done on 2026-09-24 under task 1004229, not left for later.** A satisfied
  criterion's prose is frozen (`409 criterion_satisfied`), so the route's own prescription was
  followed: `POST /done-when/1000384/unsatisfy` → `PATCH /done-when/1000384` with the new
  `criterion_md` → `POST /done-when/1000384/satisfy`. The read-back is `satisfied: true`, slug
  `ideator-sky-tells-the-truth`, and the last bullet now reads *"The sky is the ideator's home,
  and it is never the ONLY path to anything it shows. The list drawer — the room — is one key
  away, and every drawn thing is a row in it."* with a dated amendment paragraph after the
  drafting note. The five states / two channels text is byte-for-byte what it was. The full
  before/after is in the session log
  [`docs/session-logs/<redacted>.md`](../session-logs/<redacted>.md).

## 6. Alternatives rejected

- **Ship the sky as an extra and keep "never load-bearing".** Rejected: it makes the owner's
  adopted home surface unroutable and leaves *Your thinking* and the goal map as the real pages,
  which is the opposite of what was adopted.
- **Reverse ADR 0227.** Rejected: its refusal is measured and still correct. The project sky
  needs 0227's drill-down shape, not its repeal.
- **Ship the two heuristics behind a disclaimer.** Rejected: the criterion's whole claim is that
  each state maps to a ledger fact rather than a UI guess. A labelled guess is still a guess in a
  picture whose promise is that it cannot be faked.
