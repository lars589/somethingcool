# ADR 0284 — The control plane carries no metrics stack

- **Status:** accepted
- **Date:** 2026-09-15
- **Task:** [1003876](https://cloudbongos.com/builders#/task/1003876) (goal 1000106). Makes [1002068](https://cloudbongos.com/builders#/task/1002068) (rotate the metrics credentials) moot; it was abandoned and its blocker resolved.
- **Supersedes:** [ADR 0127](0127-cross-box-fleet-observability.md) — Grafana + Prometheus on the control-plane droplet.

## Context

ADR 0127 put Grafana and Prometheus on the control-plane droplet behind `metrics.cloudbongos.com`. Since then every provisioned project has landed on that same `s-1vcpu-2gb` box (control-plane-local `standalone` shape), and it ran out of headroom (task 1003875 added the swap it never had).

Measured on 2026-09-15:

- **Cost on the shared box:** Grafana 187 MB RSS (the largest process there) plus Prometheus 110 MB, about 15% of RAM, plus 2.5 GB of Prometheus data on disk.
- **Coverage:** Prometheus scraped four targets: `cloudbongos`, the two instances on the old co-hosting box, and itself. **None of the provisioned customer projects were scraped.** The dashboards watched the platform's past, not the fleet it now hosts.
- **Consumers:** nothing in the core reads Prometheus or Grafana. The dashboard was the only consumer, and the Grafana journal (kept since 2026-07-15) shows no login events.
- **Trust boundary:** an internal tool shared a kernel, a unix box and a Postgres install with tenant projects, so a Grafana CVE would have become a customer-data question. Its credentials had already been exposed in a session (task 1002068).

## Decision

**Remove it outright rather than moving it** (the owner's call, choosing between "drop it" and "move it to its own ~$6/mo droplet"). On the control plane:

- the `metrics.cloudbongos.com` Caddy site block is gone (validated and reloaded; a backup is at `/etc/caddy/Caddyfile.bak-task-1003876`);
- `grafana-server` and `prometheus` are stopped, disabled and purged, with their data and config dirs, the Grafana systemd drop-in that held its `GF_*` secrets, and the Grafana apt source.

The in-app exporter stays. Every instance still serves `/metrics` ([`src/bongos/metrics.js`](../../src/bongos/metrics.js), loopback or `METRICS_TOKEN` Bearer), so observability can come back **off** the control plane without touching any instance.

## Consequences

- **+** Memory available on the shared box rose from 554 MB to 1158 MB with no customer-visible change and no downtime. 2.5 GB of disk freed.
- **+** One less internet-facing, credentialed surface on the most-trusted host in the fleet.
- **−** No dashboards and no metrics history. If fleet metrics are wanted again, run the scraper on a separate box and point it at instances with `METRICS_TOKEN`, never on the control plane.
- **−** Leftovers outside the control plane's own config, filed as [task 1003924](https://cloudbongos.com/builders#/task/1003924): the `metrics.cloudbongos.com` DNS record (an unmatched host now gets Caddy's empty 200), the `metrics-fwd-*` socat forwarders and ufw rules on the co-hosting box (they expose whole app ports over the VPC to a scraper that no longer exists), and the instance-owned `infra/grafana`, `infra/prometheus` and `infra/Caddyfile` metrics block (ADR 0150 — not in this repo).
