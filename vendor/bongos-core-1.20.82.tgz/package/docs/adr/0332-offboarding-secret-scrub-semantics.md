# 0332 — Offboarding scrubs stored secrets: an event, not a direct write, and reactivation restores neither

- **Status:** Accepted
- **Date:** 2026-09-24
- **Deciders:** spike task [1003338](https://cloudbongos.com/builders#/task/1003338), goal 1000110

## Context

`deactivateBuilder` (`src/bongos/db.js`, the transaction behind `/builder-exit`) is the graceful-offboarding path: it releases active claims, drops rank to `xenos`, and — since the `#871` fix (security report task 1000004) — revokes every live `builder_sessions` row in the same transaction. It is explicitly designed to be **lossless**: credits, `credit_log`, shipped tasks, and session history all survive untouched.

It does not, however, touch two third-party credentials the platform holds **on the builder's behalf**:

1. **The GitHub OAuth repo token** (`github_oauth_tokens`, one row per builder, written by `upsertGithubToken` at sign-in for the onboarding wizard's repo picker). `deleteGithubToken` already exists (`src/bongos/db.js`) and is called from `routes/github.js` on a 401/invalidation — a *separate* inline `DELETE` inside `getGithubToken` lazily sweeps an expired row on read — but `deleteGithubToken` itself is never called from offboarding. The table's own migration comment (`migrations/core_192_github_oauth_tokens.sql`) calls this "the auth system's OWN handshake token," i.e. core-owned. Its `ON DELETE CASCADE` never fires because offboarding never deletes the `builders` row — it only flips `status`.
2. **The per-builder Gemini BYOK key** (`builders.gemini_key_enc` / `gemini_key_last4` / `gemini_key_set_at`, AES-256-GCM via `src/bongos/secret-box.js`, migration `122`). Both secrets are encrypted at rest with a server-env-only master key, so a DB dump alone cannot read either — the gap is **latent** for takeover, but a real data-retention/data-minimization defect: an offboarded person's third-party credential is retained indefinitely with no purge path.

The Gemini key is a special case: **its CRUD moved out of core into the `art-pipeline` module under ADR 0102**, specifically to stop core importing domain logic (`setBuilderGeminiKey`/`clearBuilderGeminiKey`/`getBuilderGeminiKeyRow` were three of the seven kernel→domain leaks that ADR closed). Core resolves the read side today through the `art.getBuilderGeminiKeyRow` port (`routes/me.js`), degrading to `{ enc: null, last4: null, set_at: null }` when the module isn't installed — which it isn't in this checkout (`config/modules.neutral.json` ships `art-pipeline: false` by default, and `modules/art-pipeline/` does not exist in this repo). The column lives in core's `builders` table (core-owned schema), but the module owns the logic that writes it — the exact split ADR 0102 chose.

Two decisions the task description left open, and the deliverable of this spike:

1. **Does a module own the key store, and if so, how does core reach across the boundary to scrub it?**
2. **What does reactivation restore?**

## Decision

**1. The GitHub token is deleted synchronously, in-transaction — the Gemini key is scrubbed via a new best-effort event, not a direct write.**

- In `deactivateBuilder`'s existing `withTx` block, call `deleteGithubToken({ builderId, p: client })` alongside the existing claim-release and session-revocation steps. `github_oauth_tokens` is core's own table; this is no different from the writes already there.
- Post-commit, alongside the existing `seams.emitAsync('builder.box-reconcile-needed', …)` call, emit a new event: **`builder.secrets-scrub-needed`**, payload `{ builderId, actor }`. This is the teardown port for any module that stores a builder-keyed secret against a core column or its own table — today, that's `art-pipeline`'s Gemini key. `art-pipeline` (when installed) registers `api.on('builder.secrets-scrub-needed', …)` and nulls `gemini_key_enc`/`gemini_key_last4`/`gemini_key_set_at` itself, mirroring exactly how `dev-box` already listens for `builder.box-reconcile-needed` (`modules/dev-box/routes/box.js`).
- Core must **not** `UPDATE builders SET gemini_key_enc = NULL, …` directly. That column is schema-owned by core but logic-owned by the module by deliberate design (ADR 0102) — reaching in to null it from `db.js` re-opens the exact kernel→domain leak that ADR closed, and it hard-codes one module's column names into core, which breaks the moment a different or additional module owns a different builder-keyed secret.
- On a vanilla instance (the default: every optional module off), the event has no listener and is a no-op — matching the graceful-degradation posture the `art.getBuilderGeminiKeyRow` port already uses. The GitHub-token delete still runs unconditionally, since it is core's own table regardless of which modules are installed.

**2. Reactivation restores neither secret.**

`reactivateBuilder` flips `status` back to `active` and explicitly leaves `rank` at `xenos` — "an Archon re-promotes deliberately." The same posture applies to both stored secrets: a returning builder is **not** silently handed back their old GitHub token or Gemini key. They re-enter their own BYOK key from Settings exactly as a first-time builder would, and the GitHub token is re-obtained the next time they run the sign-in flow that requests it. `reactivateBuilder` already never touched either store, so there is no functional change here — this decision adds an explicit comment there (`src/bongos/db.js`) so a future edit doesn't "helpfully" restore a stored credential.

Rationale for the deny-by-default reactivation stance:

- Secrets held on a builder's behalf are not "work" — the lossless guarantee (credits, shipped tasks, session history) is about *earned* state. A third-party credential is closer to a session token than to a credit ledger, and sessions are already revoked (not preserved) on exit.
- A gap between deactivation and reactivation is an elevated-risk window by definition (unknown reason for departure; possible compromise). Silently reviving a dormant credential on reactivation reopens exactly the exposure the scrub exists to close, with no signal to the returning builder that anything was restored.
- Matches `secret-box.js`'s own fail-closed ethos ("a malformed secret fails CLOSED — set/decrypt is disabled, never weak").

## Alternatives considered

- **Null the Gemini-key columns directly with raw SQL inside `deactivateBuilder`'s transaction.** Rejected: re-opens the kernel→domain leak ADR 0102 deliberately closed, and hard-codes `art-pipeline`'s column names into core. Also stops working the moment any *other* module wants to store a builder-keyed secret — the event scales, a hard-coded `UPDATE` does not.
- **Do nothing until the server-side memory store (criterion `#54`) lands.** Rejected: unrelated scope — #54 is about the server holding another builder's session/memory corpus, not third-party credential hygiene — and the gap is real today, independent of whether #54 ever ships.
- **Delete the `builders` row on offboarding (let `ON DELETE CASCADE` clear `github_oauth_tokens` for free).** Rejected: directly contradicts the explicit lossless design of graceful exit (`/builder-exit`'s own doc: "nothing the builder earned or shipped is ever deleted") — credits, `credit_log`, and attribution on shipped tasks all depend on the row surviving.
- **A cron/offline sweep that scrubs secrets for builders who have been inactive N days.** Rejected: introduces a whole new mechanism (a scheduled sweep) where a synchronous delete + an event mirroring the already-idiomatic `builder.box-reconcile-needed` pattern does the job with no new moving parts, and it closes the window immediately at offboarding time rather than leaving one open until the next sweep.
- **Auto-restore the Gemini key on reactivation** (treat it like credits — lossless). Rejected per the rationale above: a stored third-party credential is not earned state, and silently reviving it on reactivation defeats the point of scrubbing it in the first place.

## Consequences

- `deactivateBuilder` grows one direct call (`deleteGithubToken`) and one new best-effort `emitAsync`, both inside the pattern already established by the box-reconcile teardown — no new mechanism, no new dependency. This decision lands that change directly in this task (task 1003338): the in-transaction GitHub-token delete, the new event emission, a `docs/modules-contract.md` row for `builder.secrets-scrub-needed`, and tests (`tests/offboarding_secret_scrub.mjs`) covering the delete, the event payload, a no-listener instance, and that reactivation triggers neither.
- On this checkout, `art-pipeline` isn't vendored (`modules/art-pipeline/` doesn't exist here), so the module-side listener that would actually clear `gemini_key_enc`/`last4`/`set_at` cannot be implemented in this repo. Follow-up task 1004239 is narrowed to that listener, for whichever repo/host carries `modules/art-pipeline/`.
- **The Gemini-key scrub is single-shot and best-effort, honestly.** A crash between commit and the `emitAsync` call, an absent listener, or a listener error leaves `gemini_key_enc` in place with no automatic repair — and `deactivateBuilder` throws `ALREADY_INACTIVE` on a second run, so `/builder-exit` cannot be re-invoked to retry it. This is the same reliability profile the existing `builder.box-reconcile-needed` event already has in this codebase (its own repair path, `box-dormant-reclaim`, is cadence-less — "run by hand" per `scripts/gds/fitness.js`'s cron-cadence check), so this decision does not regress the bar, but it does not raise it either. Task 1004239 additionally scopes a periodic reconcile check (any `status='inactive'` builder whose module-owned secret is still set gets it cleared) as the durable backstop — which doubles as the one-time backfill for builders already offboarded before this change ships, so no separate backfill script is needed.
- Reactivation semantics for secrets are now explicit and symmetric with rank: neither is auto-restored. This is a (minor, and correct) behavior narrowing for any builder who reactivates within the GitHub token's 1h TTL — before this decision that token might have still been live if reactivation raced the TTL; after, it is always gone.

## Follow-up

Task [1004239](https://cloudbongos.com/builders#/task/1004239) — narrowed to the `art-pipeline` module-side listener for `builder.secrets-scrub-needed` (clearing `gemini_key_enc`/`last4`/`set_at`) plus the periodic reconcile backstop described above. The core-side change (GitHub-token delete, event emission, contract doc, tests) shipped with this task.
