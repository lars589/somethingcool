# 0188 — The weekly patrol runs on CI, and a declared cadence must have something that fires it

- **Status:** Accepted
- **Date:** 2026-08-24
- **Tasks:** [#1003209](https://cloudbongos.com/builders#/task/1003209) (goal 1000079 — pay down the frozen debt and make enforcement durable; criterion C4 `reduction-durable`)
- **Builds on:** [ADR 0078](0078-deterministic-first-cron.md) (deterministic-first routines + the `run-routine.js` dispatcher), [ADR 0180](0180-dependency-intake-and-drift-policy.md) §3 (the patrol's dependency checks), [ADR 0022](0022-secrets-policy.md) (the prevent → gate → patrol layering)
- **Related:** [ADR 0158](0158-choke-point-verdict-taxonomy.md) §2 (patrol findings are advisory — a verdict never self-executes), [ADR 0093](0093-tranche-2-core-carve-sequence.md) §1 (where `routine-timers.js` landed — the in-process poller seam this deliberately does *not* use)

## 1. Context

Goal 1000076 shipped a weekly red-team patrol: `scripts/gds/redteam-patrol.js`
(full-git-history secret scan, dependency-drift review, workflow action-pin
check), the `.claude/scheduled-tasks/redteam-weekly` routine that describes how
to run it, a recipe, and a row in `control-manifest.js` asserting the control
still exists.

Nothing ever ran it. The follow-up audit
([`docs/audits/ai-dev-redteam-followup.md`](../audits/ai-dev-redteam-followup.md) §7)
put the failure in three parts:

1. **No committed scheduler** for `.claude/scheduled-tasks/` at all. ADR 0078
   built the external dispatcher an operator was meant to wire into cron; the
   wiring never happened, which `routine-timers.js`'s own header already admits
   in so many words — *"nothing was ever durably scheduled."*
2. **No cadence to read.** The SKILL.md declared `mode:` and `steps:` — *how* to
   run — but never *how often*. There was nothing for a scheduler to honour even
   if one had looked.
3. **A manifest that was green anyway.** `control-manifest.js` proved the patrol
   "wired" by finding the substring `redteam-patrol.js` inside the SKILL.md —
   i.e. the routine mentioning its own scanner. The control read as connected
   for months while it ran zero times.

This is the same shape the ADR 0022 audit found in the first place: a control
that can quietly stop existing (or, here, quietly never start) is not a control.
It is also the fifth instance in this goal of a more specific pattern — **an
enforcement surface that names a file goes VACUOUS, not red, when the thing it
names moves or stops.**

## 2. Decision

### 2.1 The runner is CI, not the always-on server

The obvious symmetry was to add the patrol beside `peer-vote-tally` in
`modules/autonomy/pollers/routine-timers.js` — the in-process timer built (as an
ADR 0078 amendment) for exactly the "deterministic routine nobody scheduled"
problem, whose header even reasons through why an in-process timer beat external
cron *there*.

**That reasoning does not transfer, and applying it here would have produced a
patrol that reports clean while scanning nothing.** All three checks read things
only the *repository* has:

| check | needs |
|---|---|
| history-secrets | the full git history |
| action-pins | `.github/workflows/` |
| dependency-review | a `package.json` + `package-lock.json` npm can audit |

A deployed instance runs a **vendored** core out of `node_modules/@bongos/core`.
That directory is not a git repo, carries no workflows, and ships no lockfile.
The timer would have found no history to scan, no workflows to check, and
nothing to audit — and every one of those degrades to *"nothing found"*. Worse
than unscheduled: confidently, weekly, wrong.

So the scheduler is `.github/workflows/redteam-patrol.yml` — a weekly GitHub
Actions lane with `fetch-depth: 0` and a pinned, checksum-verified gitleaks
binary (the missing dependency the audit listed as its own gap). It invokes
`run-routine.js redteam-weekly` rather than the patrol script directly, so the
SKILL.md's `steps:` remain the single source of truth for what a run does.

### 2.2 `cadence:` is a real frontmatter field

`parseRoutineFrontmatter` now reads `cadence: hourly|daily|weekly|monthly`. It
is **declarative only** — `run-routine.js` still runs a routine exactly once per
invocation. The cadence is the contract a committed scheduler must honour.

### 2.3 A cadence nothing fires is a red build

`scripts/gds/routine-schedule.js` (fitness Check 25) is the part that keeps
§7 from recurring. Its predicate is **relational, not existential**: it reads
the cadence each routine declares, reads the cron each scheduler carries,
classifies that cron into the period it actually realizes, and fails when the
two disagree in either direction —

- a routine declares a cadence and no scheduler fires it → red
- a scheduler dispatches a routine that no longer exists → red (rename rot)
- the cron's real period differs from the declared cadence → red

The third is the one that matters most, because **no existence or substring
predicate can ever see it.** Edit the cron from weekly to monthly and the file
still exists, the workflow still names the routine, and every "is it wired?"
check in the repo stays green.

The manifest row was re-pointed to match: "wired" for a scheduled control now
means the *scheduler* names the routine, not that the routine names itself.

### 2.4 Red means "a finding was lost", not "a finding exists"

A CI runner has no GDS session, so `--file` would have hit `cli-lib`'s
interactive 401 path — printing *"run /builder-reauth"* and calling
`process.exit(2)` into a cron log, indistinguishable from a crash, before the
findings were ever shown. `--file` now preflights the session and follows the
`main-audit.js --require-roster` doctrine: report loudly rather than
green-and-vacuous.

The exit code is a small table (`disposition()`), and the choice inside it is
deliberate. Findings are **advisory** (ADR 0158 §2) — they are filed for
adjudication, not acted on — so a run that finds three things and files them is
a **success**:

| state | exit |
|---|---|
| ran, nothing to file | 0 |
| ran, dry run | 0 |
| ran, findings **filed** | 0 |
| ran, findings it **cannot** file | **2** |

Red is reserved for the single state where evidence evaporates. The alternative
— failing whenever findings exist — would have gone red on the very first run
and stayed red: the staging credential in commit `092e473` is still in history,
unrotated, so the history scan has a standing hit. A weekly job that is always
red is a weekly job nobody reads, which is the failure this whole goal is about.

Filing itself is optional and credential-gated: with no `GDS_PATROL_SESSION`
secret the patrol still runs every week and writes findings to the job summary.
That default matters because this same goal's C1 is about *removing* long-lived
tokens — the patrol must not require a new one to be useful.

## 3. Consequences

- The patrol runs unattended for the first time. The first scheduled runs are
  expected to file a `history-secrets` report until commit `092e473` is scrubbed.
- Adding a routine to `.claude/scheduled-tasks/` now forces a choice: declare a
  cadence and schedule it, or declare none and accept a warning that it is
  manual-only. Silence is no longer an option.
- The check is tolerant of the two-repo split: `.claude/scheduled-tasks/` is
  materialized into every instance, `.github/workflows/` is the core repo's and
  does not travel — so in a checkout with no workflows directory, unscheduled
  routines are warnings, not violations.
- `cronCadence()` refuses step values, lists and ranges rather than guessing.
  An exotic schedule cannot be described by a cadence word and must be reworked
  or left manual — the safe direction, since a clever cron silently counting as
  `weekly` would reopen the drift this exists to catch.

## 4. Alternatives rejected

- **An in-process timer in `routine-timers.js`.** §2.1 — the server cannot see
  the evidence. Rejected on correctness, not cost.
- **Teaching `routine-timers.js` to discover `.claude/scheduled-tasks/` and
  honour `cadence:` generically.** The task offered this first and it is the more
  general mechanism, but its only candidate user cannot run there, so it would
  have been a scheduler built for nobody. The `cadence:` field is deliberately
  *scheduler-agnostic*, so an instance that later wants an in-process lane for a
  server-side routine can read the same declaration.
- **Failing the job whenever findings exist.** Permanent red, then ignored. §2.4.
- **Requiring a GDS session secret.** Would have made the whole lane inert until
  a credential was provisioned, and adds a long-lived token to a goal whose C1 is
  about eliminating one.
- **A deeper `control-manifest.js` predicate instead of a new check.** The
  manifest's shallowness is deliberate and documented (existence + one wiring
  substring); the cadence↔cron agreement is relational and does not fit that
  shape. Re-pointing the row *and* adding the check keeps each honest.
