# ADR 0205 — A federated check-in may not speak for a person the hub never saw sign in: the membership carries the hub's own witness, and identity is never re-synced from client credentials

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1003340](https://cloudbongos.com/builders#/task/1003340) (goal 1000045 — public builder profiles + account security)
- **Closes:** security report 1000027 (high, LIVE on the hub)
- **Relates to:** ADR 0141 §1/§3/§4 (identity federated, authority local — the check-in and rollup wire contracts), ADR 0171 D7 (the rollup impersonation hardening this completes), ADR 0016 (the trust boundary), ADR 0083 §5 (module-owned, namespaced migrations), ADR 0156 / ADR 0177 (the `display_name` source guard and the `membership_kind` cross-version window this must not break)

## Context

`POST /sso/membership/check-in` is how a federated instance tells the hub "this builder builds on my project". It authenticates with `client_id` + `client_secret` — the same constant-time check as `/sso/token` — and takes the **subject** (`github_id`, `github_login`, `avatar_url`) from the request body.

That is the whole defect, stated plainly: **client credentials say WHICH PROJECT is calling. They say nothing about WHO the `github_id` in the body is.** Any owner of any registered SSO client, holding only their own legitimate secret, could:

1. **Rewrite a real person's public identity.** `upsertAccount`'s `ON CONFLICT (github_id) DO UPDATE` set `github_login = EXCLUDED.github_login` and `avatar_url = EXCLUDED.avatar_url` unconditionally on the victim's existing row. Both are what `<redacted>` and core `GET /builders/:id/profile` render, and `avatar_url` was stored with no scheme check at all. (`display_name` was already source-guarded by the ADR 0156 mirror; these two were not, deliberately — "neither is user-editable", which was true and beside the point once a *third party* could write them.)
2. **Mint the row that unlocks a forged portfolio.** ADR 0171 D7 added a `membership_required` precheck to `POST /sso/activity/rollup` precisely to stop a client publishing credits/karma/rank for someone who does not build on its project. But the membership it demands was created by the *other* endpoint, on the caller's unproven say-so — so the gate was satisfiable by the very call it was meant to gate. Check in as the victim, then push arbitrary totals onto their public cross-project record. The same row also made the attacker's project appear in the victim's "My Projects".

D7 hardened the read side of a door whose key was being handed out at the other window.

The fact that makes a fix possible: **the hub is the identity provider.** Every federated sign-in passes through the hub itself, at one of exactly two places, and in both the pairing of *person* to *project* is the hub's own finding rather than a caller's claim:

- `POST /sso/token` — redeeming a single-use code that `/sso/authorize` minted under a **live hub session**, bound at mint time to `(client_id, github_id, redirect_uri)`;
- `POST /sso/device/poll` — a GitHub device approval, with the audience **bound at start from the typed origin** so the CLI never names the client (the ADR 0141 §1 confused-deputy fix).

And the instance sequences its calls: `src/bongos/auth-idp.js` runs the token exchange or assertion verification, *then* the check-in, *then* the rollup. A legitimate check-in is therefore always preceded, within the same sign-in, by a hub-authenticated moment.

## Decision

### D1 — The membership row carries `signin_verified_at`, and only the hub can stamp it

`platform_identity_014_membership_signin_proof.sql` adds one nullable `timestamptz` to `<redacted>`. It is written by exactly one domain function, `recordFederatedSignin({ clientId, githubId })`, called from exactly the two hub routes above. **No request-body field reaches the statement** — the `client_id` is the authenticated client and the `github_id` comes from the redeemed code or GitHub's own device answer.

That is what makes it evidence rather than another self-report: it is a column the caller structurally cannot write.

### D2 — A check-in may only UPDATE a witnessed row; it can no longer create one

`upsertMembership` is replaced by `touchMembership`, an `UPDATE … WHERE client_id = $1 AND github_id = $2 AND signin_verified_at IS NOT NULL`. No match → the route answers `409 signin_required` and writes nothing at all. `recordFederatedSignin` is now the only birth path for a membership row, so a project cannot claim a person the hub never saw arrive.

Signing in also **accepts a standing invitation**: a `pending` row (pre-seeded by `POST /projects/invite`) becomes `member` when its invitee actually signs in, and any other stored `membership_kind` is left alone — the coarse kind stays the reporting instance's to say, through `touchMembership`, exactly as ADR 0141 §3 intends.

The check-in also gains the numeric-`github_id` guard the rollup already had, so a `system:*`-shaped principal is refused before it can hit the `bigint` column.

### D3 — A federated client gets an insert-only account writer

`ensureAccount` inserts the identity shell `ON CONFLICT (github_id) DO NOTHING` and returns the stored row. `upsertAccount` — whose conflict branch re-syncs identity — is now documented as belonging to hub-authenticated callers only (`/sso/authorize`, `/sso/device/poll`, the own-scoped profile route).

**Nothing is lost by removing the re-sync from check-in.** Both hub-authenticated paths already call `upsertAccount` on every single sign-in, from GitHub's own answer or the live hub session — so a renamed GitHub login and a changed avatar still land, on the pass where the hub actually knows whose they are. The check-in's identity write was pure redundancy that happened to be the attack surface.

### D4 — The rollup gate reads the witness, not the row's existence

One predicate, `membershipBacksRollup(membership)`: non-`pending` **and** `signin_verified_at` present. The gate ADR 0171 D7 describes finally means what it says.

### D5 — `avatar_url` is https-only, validated at the write boundary

`safeAvatarUrl` returns the value only when it parses as an absolute `https:` URL, and `null` otherwise — `http:`, `data:`, `javascript:`, `file:`, relative paths and malformed strings all collapse to null. It is applied inside **both** account writers rather than at each render, because the avatar is echoed into a public page and an `<img src>` from several surfaces and a per-render check is a rule someone eventually forgets. Every real GitHub avatar is already https, so nothing legitimate is refused.

### D6 — No backfill, and that is the deliberate part

Existing membership rows carry no witness, and there is **no predicate that separates a legitimate 2026 check-in row from a forged one** — grandfathering them would preserve precisely the rows the report is about. So the column ships NULL for every existing row and the gates fail closed on them.

The cost is bounded to near-zero because of D1's own sequencing: the first federated sign-in after this deploys stamps the witness *before* the check-in and rollup that follow it, so a real builder heals on their next login with no operator step. Already-published activity rows are untouched, so a public profile goes **stale until that login, never blank**.

`listMembershipsForAccount` ("My Projects", and the single-logout fan-out) is deliberately **not** retro-filtered on the witness. Once D2 makes new forgery impossible, filtering historical rows would empty every builder's project list for a marginal security gain against rows that were, in all likelihood, legitimate check-ins. The gates belong on the write and publish paths; this is a read of the past.

## Consequences

- The three attack steps in report 1000027 now stop at step 3: a client with valid credentials and no witnessed sign-in gets `409 signin_required`, having written nothing.
- `POST /sso/token` gains a write. It is inside the existing `try`, so a failure to store the witness fails the exchange rather than proceeding into a state where the client's own check-in would be the only evidence the sign-in happened. The code is single-use and already consumed at that point, so the user restarts sign-in — the fail-closed trade the report's severity justifies.
- **No wire-format change.** The check-in and rollup request schemas are byte-identical, `membership_kind`/`role` and the ADR 0177 cross-version window are untouched, and no federated instance needs to upgrade. The proof moved *inside* the hub, which is the only place it could live without asking every instance on its own schedule to carry a new field.
- New refusal codes: `signin_required` (409) and `invalid_github_id` (400) on check-in.
- Proof: `tests/sso_checkin_identity_spoof.mjs` — DB-free, in the default unit gate (a real-Postgres proof would self-skip in CI, which is where this one has to run). Ten of its fourteen assertions fail against the pre-fix code; the two "still works" rows are the control that the gate is a gate and not a wall.

## Rejected

- **Carrying the hub assertion in the check-in body.** The strongest-looking fix, and unshippable: `validateOrRespond` is strict, the callers are other instances on their own upgrade schedule (ADR 0141 §3), and requiring a new field would 400 every check-in from every un-upgraded instance. The same reasoning ADR 0201 D2 used to put its assertion in a header applies here — except here the hub already holds the evidence and needs no field at all.
- **Source-guarding `github_login`/`avatar_url` the way `display_name` is guarded (ADR 0156).** That guard answers "did the user set this themselves", which is the wrong question: neither field is user-editable, and the attacker is a third party, not the user. It would have left the membership half of the report wide open.
- **Backfilling `signin_verified_at = joined_at`.** Preserves exactly the rows that may be forged. See D6.
- **Refusing the check-in silently (200 with no write).** The caller swallows errors either way, but a silent success makes the hub's logs lie about what it did; `409 signin_required` says what happened, and matches the shape the rollup gate already uses.
- **Retro-filtering `listMembershipsForAccount`.** See D6.
