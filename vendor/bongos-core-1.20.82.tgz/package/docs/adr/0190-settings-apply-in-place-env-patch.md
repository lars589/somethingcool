# ADR 0190 — A changed project setting reaches a running instance by an in-place env patch and a restart, never a template re-write

- **Status:** accepted
- **Date:** 2026-08-25
- **Task:** [task 1003140](https://cloudbongos.com/builders#/task/1003140) (goal 1000058 — the non-cloudbongos project lifecycle)
- **Relates to:** ADR 0111 (provisioning trust boundary), ADR 0128 (runner privilege model), ADR 0133 (GitHub App Manifest cred placement), task 1003139 (the standup leg), task 1002692 (domain-attach), task 1002691 (the open-intent slot), task 1002720 (F16/F19/F23 truthfulness)

## Context

Task 1003139 built the *standup* half of the platform→instance settings channel: a newly-provisioned instance reads `platform_visibility` / `joinability` from the `/etc/<slug>/web.env` the control-plane runner writes, through `src/branding.js` `ENV_OVERRIDES` onto `project.*`. That closed the "write-only state" gap for new instances only. A **running** instance loads its branding pack once — `branding()` is memoized and deep-frozen for the process lifetime — so a value changed on the platform afterwards could not reach it by any path. `PATCH /provisioning/instances/:id/settings` wrote the jsonb and pushed nothing.

The owner decided on 2026-08-19 that a restart is an acceptable cost of applying a change, and that the surface must **say so** rather than restart silently; and that a PATCH is a *request* until the intent settles, so no surface may claim the new state on PATCH return.

The natural implementation is the `domain-attach` shape (task 1002692) minus the DNS legs: re-write web.env, restart the service, verify healthz. That shape has a hazard that only shows on an instance the owner has actually used.

## Decision

1. **A `settings-apply` intent** (migration `provisioning_010`, `INTENT_ACTIONS` in lockstep). `PATCH /settings` writes the platform row **first**, then — for an instance in `SETTINGS_APPLY_FROM = {active}` on a shape in `SETTINGS_APPLY_SHAPES = {co-tenant, standalone}` — enqueues the intent via `enqueueSettingsApply`. The web tier still only enqueues; the runner remains the sole token-holder (ADR 0111 §2).

2. **The runner patches the file in place, and every expected failure returns `ok:false`.** `settingsApplyInstance` reads the instance's web.env as it stands (`sudo cat` under the privileged model, ADR 0128), upserts **only** the two settings lines with the pure `upsertEnvVars` (replace where present, append where absent), writes it back through the same temp-file + `sudo install -m 600` path every `/etc` write uses, and restarts the unit. The write and the restart are guarded: a refused install or a non-zero `systemctl restart` returns `{ ok:false, error }` so the drain loop re-pends the intent (retrying up to the attempt cap) and leaves the instance's status alone — it **never** throws, because the drain loop's catch flips an instance to `error`, and a healthy active project marked broken over a settings push would stop being probed, fall off the push path, and need a re-provision to recover. Dry-run *plans* the patch ("would patch `<keys>` in `<path>` in place") rather than writing a synthetic two-line body that would read as the exact overwrite this leg exists to avoid.

3. **The verify asks the instance whether it *read* the values, and records only what it earned.** After the restart the runner polls `/healthz` with the manifest probe's patience (`MANIFEST_VERIFY_TRIES × MANIFEST_VERIFY_INTERVAL_MS`, the F23 lesson — a false "down" here is not cosmetic, it arms the owner's re-kick paths), then fetches the instance's own public `GET /api/gds/instance` and compares `brand.project` against the pushed values (`settingsConsumed`): **true** → "restarted and reads the new values"; **false** → "restarted, but still reports the OLD values — its core may predate the settings channel"; **null** → "its core does not publish its settings yet, so whether it reads them is unknown". Answering `/healthz` proves the process, not that the setting took; an instance whose pinned core predates task 1003139 restarts fine and ignores the lines, and the event must not call that "applied".

4. **The state gate is `{active}` only.** A pre-active instance gets the same values at standup from the same `effectiveSettings()` row; a torn-down one has nothing to restart. The provision intent cannot stand in for the push — `PROVISION_ENQUEUE_FROM` deliberately excludes `active` (task 1002691).

5. **A dedicated droplet is refused honestly, at both ends.** It is stood up by cloud-init and the runner has no post-hoc exec path to it (the `placeManifestCreds` precedent). The route stores the value and answers `push.reachable:false` — *"This project runs on a machine the platform doesn't manage, so it can't be restarted from here — whoever runs that machine has to apply it there."* (not "its own server", which is also the hub's label for a *standalone* project, which **is** pushable); the runner, should such an intent ever arrive, returns `ok:false` with the exact lines to set — never a reported push that did not land.

6. **A save that changes nothing neither writes nor restarts.** The route compares the request against `effectiveSettings(inst)`; an unchanged save answers *"No change — this project already has these settings."* with no row write, no event and no intent, so a whole-form save or a retried request cannot bounce a live project. The one exception is the owner re-kick (the domain route's F19 shape): the same values re-sent while a retired push left its `error_note` re-queue the push.

7. **The response is a receipt, not a claim.** `{ ok, saved, push }` — `saved` is what the platform now stores (deliberately not `settings`, the field a form would render as the live value), and `push: { queued, restart, reachable, message }` is one shape on every branch: `restart` = a restart is what applies this, `reachable` = the platform can perform that restart. Sentences are state-only, with no wall-clock **or duration** promises ("briefly" is a claim about downtime; the runner's own failure branch contradicts it). An open slot held by other work (or by a push already *running*, which may have read the row before this write) answers `409 intent_conflict` with `details.recorded:true`; an identical *pending* push is idempotent because the runner reads the row's current values when it runs; an enqueue that throws still answers `200` *"Saved, but the restart could not be queued just now — send it again to apply it."* — a `500` would deny a durable write. A snagged (`error`) project is told its standup stopped partway and the change takes effect the next time it is stood up, not that it "finishes standing up". The archon override stamps `api:archon:<id>` on the event and the intent (the force-teardown convention).

8. **A pending push yields to a teardown.** `enqueueTeardown` now supersedes a *pending* `settings-apply` exactly as it supersedes a pending `provision` (task 1002691): a push into a project about to be torn down is dead work, and the single open-intent slot must not hold the delete hostage across retry ticks. Running intents are never yanked.

9. **The read-back is the instance's own manifest.** `clientBranding` now projects `project: { platformVisibility, joinability }` — what the instance *resolved* from its environment, env override included — so `GET /api/gds/instance` `brand.project` is where a manage page learns what the instance runs. Resolved, not enforced: enforcement lands with tasks 1003043 (visibility) and 1003044 (joinability). The allow-list ledger in `tests/currency_label.mjs` was widened deliberately; the policy is public by nature (a gated project's gate says "sign in"; an invite-only door says so).

10. **The secret never reaches the journal.** A remote (ADR 0130) file placement embeds the base64 body in the ssh command; `makeExec` now takes a `shown` label so the runner logs "write `<path>` (N bytes)" and never the payload — this leg is the first to feed a *credentialed* file back through that path, but the fix covers every remote web.env write. The locally staged temp file is created `0600`.

## Why the in-place patch is load-bearing

`domainAttachInstance` re-writes web.env by re-running `webEnvBody(inst, { federation: null })`. That regenerates the file **from the row** — and the row does not know the OAuth client id/secret that `placeManifestCreds` fetched from GitHub and placed later, nor the App private key (the ADR 0055 publish credential), nor the federation block. A template re-write therefore writes those lines back **blank**. On the domain-attach path this is masked by wizard order (address first, GitHub App second) — except on the owner re-kick (task 1002720 F19), which can run after the creds are placed; a settings push always happens on an instance the owner is signed in to, so the same move would break sign-in on the exact project they just touched. The fix is not to teach `webEnvBody` the secrets (the row must never hold them) but to change **only the lines this leg owns**. An unreadable or empty file is refused rather than "patched" — writing two lines over a missing `PORT`/`PGDATABASE` would take the instance down.

The domain-attach hazard itself is pre-existing and out of this task's scope; it is captured as idea 1000842 for its own task, with this leg's in-place shape as the fix.

## Consequences

- Flipping a setting on a live co-tenant or standalone project restarts it within one runner tick; the owner is told so on every surface that carries the receipt, and told "no change" when nothing changed.
- The hub's card strip and the done panel label the intent by state — *"A settings change is queued — this card updates when it starts."* while pending, *"Applying a settings change — the project restarts to pick it up."* while running — instead of the generic "a settings-apply run is queued".
- An instance whose pinned core predates task 1003139 receives the env lines and the restart but does not *consume* them until its own core is upgraded; the runner's event says so ("does not publish its settings yet" / "still reports the OLD values") rather than "applied". The live test project (Spike Harbor) ran core 1.19.2 when this landed, so its manifest read-back waits on its own core pin. The live leg is witnessed only once this code is the control plane's pinned core (the runner executes the pinned package), so the 2026-08-25 session log records the baseline and the post-pin procedure, and the result lands as a learning on the task. Surfacing "not consumed" on the owner's card is follow-up work.
- `provision.js` grew by ~110 lines and stays well under the 1,500-line ratchet (the prerequisite shrink landed in task 1003206).

## Rejected

- **The template re-write** (`webEnvBody`) — blanks placed creds; see above.
- **Re-provisioning as the push** — `provisionInstance` is a no-op on an active instance by design, and a full standup is the wrong tool for two lines.
- **Skipping the restart** (hot-reload the pack) — the pack is memoized and deep-frozen on purpose; per-request re-reads would reopen the config-drift class of bug the freeze exists to prevent.
- **Claiming the new state on PATCH return** — contradicts the owner's honesty rule and `last_verified_up`'s whole discipline.
- **Queueing for a dedicated droplet anyway** — a push that cannot land, reported as queued, is exactly the F16 lie.
- **Treating `/healthz` as proof the setting took** — proves the process only; the manifest read-back is the witness.
- **Restarting on every save** — the owner accepted a restart as the cost of *applying a change*, not per Save click.
