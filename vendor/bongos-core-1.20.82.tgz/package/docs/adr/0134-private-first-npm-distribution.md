# 0134 — Private-first npm distribution for the core + client (paid scoped, then public at launch)

- **Status:** **Superseded.** The **core half** — the private-by-default posture — is superseded by [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md) ([task 1003872](https://cloudbongos.com/builders#/task/1003872), 2026-09-13): `@bongos/core` now publishes **public**. This ADR's own "public at launch" step is the thing that happened; what remains accurate here is the *reasoning* for the pre-launch posture and the scoped-package mechanics. The **client half** was already superseded by [task 1003742](https://cloudbongos.com/builders#/task/1003742) (2026-09-09) — see the note under Decision. Publish path built in task 2089. The **vendored-is-the-default** clause — *"until this registry path is proven end-to-end on a real greenfield standup"* — is superseded by [ADR 0292](0292-both-install-paths-stay-and-vendoring-is-the-production-one.md) ([task 1003879](https://cloudbongos.com/builders#/task/1003879), 2026-09-16): the condition is met, and vendoring stays the default anyway because it is the production provisioning path, not a fallback awaiting proof.
- **Date:** 2026-07-07
- **Deciders:** example-owner (owner/Archon), Claude. Owner asked to have the npm/CLI onboarding commands ready but kept private pre-launch, choosing paid private npm over the free GitHub Packages option.
- **Task:** [#2089](https://example.com/builders#/task/2089) (publish path + private config) · [#2092](https://example.com/builders#/task/2092) (the `@cloudbongos` → `@bongos` scope rename + first real publish) · **Goal:** 35 (project-creation flow), criterion 165.
- **Refines:** [#2025](https://example.com/builders#/task/2025) (the 2026-07-04 *public* unscoped `cloudbongos` decision — now the launch-time go-public step, not superseded) · **Builds on:** [ADR 0108](0108-instance-composition-configurable-root.md) (core-as-npm-dep), [#2053](https://example.com/builders#/task/2053) (vendored-tarball install).

## Context

A new owner stands up a standalone instance that depends on `@bongos/core` (ADR 0108), and external programs call the API through `@bongos/client` (ADR 0118). Today neither is on a registry: `package-core.js` produces a real, installable `.tgz`, and provisioning **vendors that tarball** into each instance repo (a `file:` pin `npm ci` resolves — task 2053). That works, but the onboarding experience isn't the clean `npm install @bongos/core` an owner expects, and the client's on-ramp doc referenced a nonexistent "internal registry."

The owner wants the npm/CLI commands **ready and usable pre-launch, but not public** — Cloud Bongos shouldn't be installable by the general public before launch. Two prior decisions bear on this: the *public* install name was set to the unscoped **`cloudbongos`** (task 2025, deferred), and the `bongos` + ~10 defensive npm orgs were reserved under the owner's login.

One npm rule forces the shape: **unscoped packages are always public — only *scoped* packages can be private, and only on a paid plan.** So the unscoped `cloudbongos` name *cannot* be the private form; the private artifact must stay scoped.

## Decision

Publish **`@bongos/core`** and **`@bongos/client`** as **scoped, private** npm packages during pre-launch, on the owner's **paid** `bongos` npm org — the **canonical** brand org.

> **SUPERSEDED for the client (2026-09-09, [task 1003742](https://cloudbongos.com/builders#/task/1003742)).** `@bongos/client`
> is no longer an npm package at all, and the reason is worth keeping so it does not come back.
>
> It was published **once** — 2026-07-07, version 0.0.2 — and never updated, while the API it is
> *generated from* moved 500+ core versions. In that time it had **zero consumers**: a sweep of every
> `package.json` across the core and every instance repo (hermeslines-marketing, cloudbongos-instance,
> mercury, charter, demo) found no dependency on it; the only matches were its own manifest. Everyone
> who needs the generated client **vendors a copy** — `modules/dev-box/app/src/vendor/bongos-client.cjs`,
> and `build-cli-package.js` into `@cloudbongos/cli`, which as a *public* package could not have
> depended on a private one anyway ([ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md)).
> A stale generated client that nobody installs is worse than none: the only thing it could do is
> mislead someone into pinning a client 500 versions behind the routes.
>
> The owner removed it from the registry. The **generated artifact stays** and still regenerates
> ([ADR 0118](0118-api-contract-source-of-truth-code-first.md)) — `clients/bongos-client/` and
> `gen-api-client.js` earn their place. What is retired is only the claim that it is a package: the
> generator no longer emits a `publishConfig`, and its README now documents vendoring instead of
> `npm install`. **This ADR's core half is unaffected.**

> **Scope correction (task 2092).** The publish path first shipped (task 2089) under the `@cloudbongos` scope, matching the name the repo already used. But when publishing, the paid org turned out to be **`bongos`** (the canonical brand the owner put on Teams), while `cloudbongos` — one of the ~10 defensive orgs — was left on the free tier. Since a private scoped publish requires the scope to match a *paid* org, and `@bongos` is the intended canonical brand anyway, we **renamed the core + client package identity `@cloudbongos/*` → `@bongos/*`** (a consistent rename across the build + vendored-install flow, verified by the test suite) rather than pay for a second org. Existing vendored consumers keep their pinned `@cloudbongos/core` tarball; only new scaffolds use `@bongos`.

- **Private by default in code, not just by flag.** The synthesized core `package.json` (`buildPackageJson`) and the generated client `package.json` (`gen-api-client.js`) both carry `publishConfig: { access: "restricted" }`. `package-core.js --publish` additionally passes `--access restricted` on the CLI — belt-and-suspenders so a stray config edit can't silently make the pre-launch artifact public.
- **The publish is a gated owner step; the tooling holds no token.** `package-core.js --publish` **dry-runs** by default; the real, permanent publish needs `--publish --live` plus the owner's `npm login` and the org on a paid plan. npm owns auth — this repo never stores a token.
- **Consumers authenticate with an env-fed `.npmrc`:** `//registry.npmjs.org/:_authToken=<redacted> The token expands from the environment, so it never lands in a committed file. Only members of the paid org can install.
- **The vendored-tarball path stays as the working default/fallback.** Rewiring provision/init to auto-pull the pinned core from the registry (env-fed token on the control plane) is a follow-up — it touches a proven, protected control-plane flow and isn't required for "commands ready + private." Publishing privately + documented auth already delivers a real `npm install`.
- **Going public at launch is one step**, chosen then: either `npm access public @bongos/core` (keeps the scoped name), or execute task 2025 to *also* publish the unscoped vanity `cloudbongos` for `npm install -g cloudbongos`. Task 2025 is therefore the launch-time go-public leg, not replaced by this.

The daily command stays `bongos` regardless of package name (the `bin` mapping in the synthesized package.json is name-independent), so `npm install -g @bongos/core` → `bongos init` works today, and the eventual public `cloudbongos` name changes nothing for users.

## Why paid private npm over the free GitHub Packages alternative

The owner chose it deliberately, knowing the trade-off. GitHub Packages is free but ties every consumer to a GitHub token + org membership and a non-default registry; npm private packages give the canonical `npm install` on the default registry with a clean one-flag flip to public — the same registry, name, and command the public launch will use. The recurring per-seat cost (~$7/member/month) is small at pre-launch scale (a handful of trusted early instances) and disappears at launch when the packages go public (public installs need no seat).

## Consequences

- Cost: a paid `bongos` npm org seat per person who needs to install during pre-launch. Gone at launch.
- Owner-only steps (out of the build session; capture as a blocker if they gate verification): put the org on a paid plan; generate an npm access token (automation — read-write to publish, read for CI/provision installs); run `package-core.js --publish --live` (permanent; login + 2FA).
- Follow-up: wire provision/init to install the pinned core from the private registry (env-fed `NPM_TOKEN`), keeping the vendored tarball as fallback.
- Full operator runbook — org, plan, token, publish, consumer `.npmrc`, and the go-public flip — is [`docs/recipes/private-npm-distribution.md`](../recipes/private-npm-distribution.md).

## Update — the provision/init registry path is wired (task 2090)

The follow-up above shipped. The wiring is **opt-in and fail-soft**, so the proven vendored-tarball path stays the default until the registry path is proven end-to-end on a real greenfield standup:

- **One source of truth**: `scripts/gds/npmrc.js` owns the env-fed `.npmrc` body (`@bongos:registry=…` + `_authToken=<redacted> and the gates (`hasNpmToken`, `registryCoreRequested`). The token expands from the environment at install time, so nothing secret is committed.
- **init** (`--registry-core`): keeps the caret pin and writes the `.npmrc`; with `NPM_TOKEN` set it also generates `package-lock.json` from the registry. Mutually exclusive with `--vendor-core`.
- **provision** (standalone scaffold): opt-in via `PROVISION_CORE_FROM_REGISTRY=1`; when a token is present it scaffolds via `init --registry-core` (no tarball build), and when the flag is set but no token is present it **falls back to the vendored tarball** — a tokenless standup still works.
- **upgrade** (`--to <v> --registry`): pins the exact registry version + ensures the `.npmrc` instead of vendoring; mutually exclusive with `--from`.
- **Verified — both legs green (task 2118, 2026-07-08).**
  - *Tokenless:* a scaffolded instance with the caret pin + env-fed `.npmrc` and **no** `NPM_TOKEN` 404s cleanly on `npm install` (`E404 … @bongos/core … could not be found or you do not have permission to access it`) — it fails closed.
  - *With token (the leg blocker 71 tracked):* a real `bongos init --registry-core` scaffold with a valid **read-only** token (paid `bongos` org) resolved `@bongos/core@1.17.0` from `registry.npmjs.org` and generated a reproducible `package-lock.json` (`resolved: https://registry.npmjs.org/@bongos/core/-/core-1.17.0.tgz`). The registry pull works with a token and fails closed without one — so the opt-in registry path is proven end-to-end, and blocker 71 is resolved. The vendored tarball remains the default until an owner chooses to flip a live provisioner to `PROVISION_CORE_FROM_REGISTRY=1`.
