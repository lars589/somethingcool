# ADR 0224 — Module-owned skills reach the core checkout as untracked, self-ignored copies with a manifest: the self-copy guard stays, the dev path is a flag, and the file map skips what the module documents

- **Status:** Accepted (2026-09-02)
- **Task:** [task 1003330](https://cloudbongos.com/builders#/task/1003330) (goal 1000083 — the ui-design module as a platform capability; from idea 1000864, filed by task 1003321)
- **Context:** [ADR 0198](0198-third-party-skill-vendoring-policy.md) landed module-owned skills for INSTANCES (`claude-materialize.js` step 1b, on `bongos init` / `upgrade`); [ADR 0220](0220-an-in-house-rebuilt-skill-is-a-first-party-skill.md) and its successors noted each time that "the core checkout itself still does not see module-owned skills".

## Context

`materializeClaude`'s self-copy guard is a deliberate no-op when the instance dir is the core root: a core copying itself onto itself would be a no-op at best and corrupting at worst. Claude Code discovers only `.claude/skills/` at the project root. So a builder working in the core checkout, where all nine `ui-design` skills were written, cannot invoke a single one of them; the only copies on this machine were the upstream ones under the builder's home directory, by the same names, which is the collision ADR 0220 called "by design". Two constraints shaped the fix: nothing under `.claude/skills/` may be committed twice (the module's `skills/<name>/` is the source and the file-map generator lists every dir there and demands a note for each), and `bongos init` from a checkout that carries the copies must still land them through the module path.

## Decision

1. **The dev path is a flag on the library, not a change to the guard.** `node scripts/gds/claude-materialize.js --module-skills-only [--dry-run] [--clean]` calls `materializeModuleSkillsIntoCore`, which walks the same roster and passes the same `vendoredSkillGate` and `SKILL_NAME_RE` as step 1b, copies every ENABLED module's skill tree **verbatim** into `.claude/skills/<name>/` (no `bongosify`: the checkout runs `node scripts/gds/…`), leaves a name the core's own tracked skills carry to the core, and excludes a disabled module's. The self-copy guard in `materializeClaude` is untouched; init and upgrade are unchanged.
2. **Untracked, self-ignored, manifest-named.** The run writes `.claude/skills/.module-skills.json` (each materialised name with its module, source dir, vendored flag and file count, sorted) and `.claude/skills/.gitignore` (ignoring itself, the manifest and every materialised dir), so `git status` shows nothing new and nothing can be committed by accident. Every run first removes what the last manifest named, then lands the current set, so a skill a module stopped declaring does not linger and a second run is byte-identical; `--clean` stops after the removal.
3. **The file map skips what the module documents.** `gen-file-map.js` reads the manifest beside `.claude/skills/` and excludes those names from its listing and from its notes contract (a module skill is documented by its module's README, not by `docs/file-map.notes.json`), and `tests/file_map.mjs` filters its own exhaustiveness walk the same way through the exported `materializedNames`. `--check` stays green with the copies present and without them.
4. **Init from a checkout that carries the copies still lands them through the module path.** `materializeClaude` reads the same manifest: step 1 skips the materialised names and the two dotfiles, and step 1b's "also exists under the core" note ignores a materialised copy, so an instance receives the module skills transformed (`bongos …`) as before and never the checkout's dotfiles.
5. **The pins** (`tests/claude_materialize.mjs`): an enabled module's skills land verbatim with the manifest and the `.gitignore` lines, a disabled module's are excluded, a core-owned name is kept; a second run is byte-identical, a dropped declaration is removed, `--clean` removes exactly what was made and nothing of the core's; an instance materialised from such a core gets the skill through step 1b, transformed, and never the dotfiles; the bare CLI refuses with usage; `gen-file-map`'s `materializedNames` reads the manifest.

## Consequences

- **A builder in the core checkout sees all nine `ui-design` skills** after one command; the roster ADRs' standing consequence is closed. The command is not run automatically: a checkout is a workbench, and a builder who wants the module's skills in front of them runs it (or `--clean` to take them away).
- **The upstream copies under the home directory are now shadowed by the project-level ones**, which is the collision ADR 0220 described, now resolved in the module's favour on this machine too.
- **`docs/file-map.md` does not list materialised skills.** It never should have: they are the module's, and the module's README is their roster.

## Rejected

- **Dropping the self-copy guard** so `materializeClaude` writes into the core: it would `bongosify` the checkout's own core skills onto themselves and copy hooks and settings onto their sources.
- **Committing the module skills under `.claude/skills/` as well:** two sources of truth for every skill, and the file-map notes contract doubled.
- **A symlink or junction per skill:** Windows junctions into a tracked tree are the trap `worktree.js` exists to avoid, and a symlink is a tracked file the moment it lands in the index.
- **Adding every materialised name to `docs/file-map.notes.json`:** a note for a dir that is not in the repository is a ghost by the file map's own definition.
