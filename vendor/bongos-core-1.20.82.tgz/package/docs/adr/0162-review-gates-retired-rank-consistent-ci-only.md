# ADR 0162 — Review gates retired: rank-consistent CI checks only on `main`

**Date:** 2026-08-10
**Context:** Owner directive (jaxri, Archon), recorded live 2026-08-08–10; idea 1000657 → task 1002635. Amends ADR 0159 (which introduced CODEOWNERS) and the gating posture of ADR 0058/0042.
**Status:** Accepted. The live half (dropping `require_code_owner_reviews` from branch protection) was applied by the repo-admin account on 2026-08-10 and verified behaviorally (a probe PR touching a formerly-owned path read `mergeStateStatus: CLEAN` on a green `unit` check — PR 32, closed unmerged). This ADR lands the repo half so no re-arm path resurrects the gate.

## The incident that forced the decision

Wave 3 of the rank choke-point remediation built the merge gates inert (required `unit`
check, `gating.js`, a CODEOWNERS file scoped to the gate-review HARD_FLOOR_GLOBS); task
1002619 armed them. Within a day, the code-owner review requirement had stranded two
graded-PASS wave-4 ships (PR 28 sat `BLOCKED` behind a review only the `example-owner` account
could give) and then blocked the fix for the strand it caused (the ship.js ci-land fix,
task 1002629, and the release-cascade fix, task 1002636, both touch owned paths).

The mechanics are structural, not incidental. GitHub can only express the gate as
**accounts** — it has no concept of GDS ranks; PR authors cannot approve their own PRs;
and on this instance nearly every PR is authored by agent sessions running under the
owner-archon's daily login. So "code-owner review" degenerates into "one specific
GitHub account must click on every gate-surface PR," which is:

1. **Identity-pinned, not rank-based** — against the instance's governance principle
   (ADR 0016; the no-hardcoded-Archon-identity rule).
2. **The opposite of the remediation's goal.** The owner's words: builders should have
   *fewer* rank-related shipping problems, not more; a code-owners layer "can only
   create shipping problems for builders."

## Decision

Review requirements on `main` are **retired permanently**:

- Branch protection carries **required status checks only** (today: `unit`; the
  `secret-scan` / `gate-review` contexts join when their workflows ship — ADR 0058).
- `gating.js` `DEFAULT_PROTECTION` sets `required_pull_request_reviews: null`, and
  `cmdOn` **normalizes both restore paths** (snapshot and default) to null — a snapshot
  taken while the review gate was live must not resurrect it on an off/on cycle.
- The `CODEOWNERS` file is **deleted**. The `CODEOWNERS` *glob* stays in
  `gate-review.js` `HARD_FLOOR_GLOBS`, `protected-surfaces.json`, and the publish
  denylist — so reintroducing the file is itself a flagged gate-surface change, and the
  hard-floor path list keeps protecting the same surfaces where it actually enforces
  (the sandbox gate).

## What now guards the safety machinery

The compensating controls are all rank-consistent and automatic:

| Control | When it bites | Fails |
|---|---|---|
| required `unit` check (suite + fitness) | before every merge | closed |
| gate-review sandbox (task 1002607) | agent ship flow on hard-floor paths | closed |
| subagent grader panel | every GDS ship | closed |
| post-merge main-audit (task 1002612, every push) | after any merge, incl. a bypass | audit + revert |

## Consequences

- **Positive:** no human click anywhere in the land path; a graded-PASS ship lands on
  CI alone; the wave-4/-5 strand class cannot recur; the gate posture matches the
  rank-first governance principle.
- **Negative / accepted trade:** there is **no pre-merge human approval on
  safety-machinery changes**. A compromised or prompt-injected session whose work
  passes the unit check reaches `main`, and is caught *after* merge by the main-audit
  rather than before. The owner chose this trade explicitly (2026-08-08, reaffirmed
  2026-08-10) with the mitigations above in place.
- **Reversal path:** re-add a CODEOWNERS file, restore a `required_pull_request_reviews`
  block in `gating.js`, remove the `cmdOn` normalization, and re-apply protection from
  an admin account. All four are deliberate steps — the gate cannot come back by
  accident, which is the point of the normalization.
