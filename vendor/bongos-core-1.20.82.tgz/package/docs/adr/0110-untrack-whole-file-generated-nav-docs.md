# ADR 0110 — Move whole-file generated navigation docs off the git graph; regenerate as deploy/box outputs

- **Status:** Accepted
- **Date:** 2026-07-03
- **Track:** internal
- **Builds on:** [ADR 0094](0094-repo-atlas-self-drawing-codebase-map.md) (the `gen-atlas.js` precedent — a gitignored artifact rebuilt on every deploy), [ADR 0063](0063-generated-repo-map-symbol-skeleton.md) (`gen-repo-map.js`), [ADR 0062](0062-medusa-instance-model-decoupling.md) §8 (`gen-session-index.js`), [ADR 0082](0082-server-side-merge-conflict-auto-resolution.md) (the reactive `otb-regen` heal — kept, not replaced), [ADR 0055](0055-server-mediated-branch-publish.md) (server-mediated publish — untouched)
- **Task:** [#1926](https://example.com/builders#/task/1926)
- **Supersedes (in part):** the "regenerated + committed at ship" contract for `docs/repo-map.md` and `docs/session-log-index.md` (ADR 0063 / ADR 0062 §8). The nested-block half of that contract stands.

## Context

Every `/builder-ship` regenerated and **committed** up to four generated artifacts onto the shipping builder's feature branch — `docs/repo-map.md`, `docs/session-log-index.md`, the OpenAPI docs, and (render-capable ships) the diagrams — plus the file-map. Because these are rebuilt deterministically from the whole tree, two builders working in parallel produce *different* copies and their branches **collide on nearly every merge**. ADR 0082 built a reactive heal (the `otb-regen` merge driver + a server-side resolver) that untangles these collisions after the fact — but it treats the *symptom*. As the platform pushes toward multi-builder parallelism (BONGOS-V1), the healing cost grows with the number of concurrent branches, and a confirmed PR can still stall waiting on the ~5-minute reconciler.

The owner asked to remove the **dependency at the source**, not keep patching the collision. A design workflow (2026-07-03, 11 agents, adversarially reviewed) mapped the artifacts and found they split cleanly into two kinds:

- **Whole-file generated** — every byte is machine-owned (`docs/repo-map.md`, `docs/session-log-index.md`, the OpenAPI spec + reference, the diagram renders). A file like this need not live in git at all.
- **Hybrid** — hand-written prose with a generator-owned block between markers (the three nested `CLAUDE.md` symbol blocks; the `CLAUDE.md` §13 "recent sessions" snippet; `docs/file-map.md`'s two sections). These **cannot** leave git without deleting the human prose.

The `gen-atlas.js` precedent (ADR 0094) already proved the pattern for the whole-file kind: gitignore the artifact and regenerate it server-side on every deploy into the served directory — untracked, so `git reset --hard` never wipes it and no branch can ever diff it. The deploy-prod.sh atlas comment even names this as "the model the doc generators migrate onto."

## Decision

Apply the atlas pattern to the two **whole-file navigation** artifacts — `docs/repo-map.md` and `docs/session-log-index.md` — in this pass. (The OpenAPI spec and the diagram renders are deferred to follow-up tasks: the spec has external consumers and wants a bounded freshness bot; the diagrams need verified headless-Chromium handling. `docs/file-map.md` is hybrid and stays as-is.)

1. **Untrack + gitignore** `docs/repo-map.md` and `docs/session-log-index.md` (`git rm --cached` + `.gitignore`). They can no longer appear in a branch diff, so the collision class is gone at the source.
2. **Regenerate at deploy** — `scripts/deploy/deploy-prod.sh` runs both pure-JS generators beside `gen-atlas.js`, best-effort, and **LOUD on failure** (`::ERROR::` → journald) so a broken generator surfaces instead of silently serving a stale/absent map (this advances goal 24 / criterion `gcarry-pipe-loud`).
3. **Regenerate at box-source-fetch** — `infra/box-source-fetch.sh` regenerates them after the credential scrub so a fresh dev-box clone has them for the `/dev` skill and the §13 links (additive, best-effort, never touches the security path).
4. **Split the CI freshness gate.** Both generators are **dual-duty** — each also refreshes a *tracked* block (the nested `CLAUDE.md` symbol blocks; the `CLAUDE.md` §13 snippet). The old `--check` bundled the whole file and the block into one exit code, so naively relaxing it would silently drop the block gate too (the adversarial review's fatal flaw). Instead each generator now exposes `--check-block` (tracked block only) and `--check-whole` (the gitignored whole file); `fitness.js` gates the **block bucket HARD** via `--check-block`. The whole-file freshness moves from a merge-time invariant to a deploy-time one.
5. **Ship-time regen keeps only the tracked blocks.** `ship.js`'s `regenerateRepoMap`/`regenerateSessionIndex` still run the generator (which writes the gitignored whole file harmlessly) but drop the gitignored paths from their `git add`/`git status` lists — an explicit `git add <ignored path>` **aborts the whole command** (exit 1), which would have dropped the nested-block commit.

## Why this is safe — and never worse than today

- **No bot ever commits to `main`; the trust boundary is untouched.** The whole files are written as untracked files on the droplet after `git reset --hard`, exactly like `atlas.json` — no push credential, no branch-protection bypass, zero change to ADR 0016/0043/0055. No `.github/workflows/` file is added (the server App token can't land those).
- **The reactive heal is retained, not deleted.** `git-merge-regen.js`, its `REGENERABLE` set, the `.gitattributes` drivers, and the ADR 0082 server resolver are **unchanged**. Once the two files are gitignored they simply never appear in a diff, so the driver is a harmless never-triggered backstop for them — and it still actively heals the hybrid docs (`file-map.md`, nested `CLAUDE.md`) that remain tracked. During the transition it also still covers any in-flight branch that already committed the old files.
- **The block gate stays hard.** A code change that didn't regenerate its nested block, or a session change that didn't regenerate the §13 snippet, still fails its PR via `--check-block`. Only *whole-file* drift is no longer gated (there's nothing committed to gate).

## Consequences

- The `repo-map.md` / `session-log-index.md` collision class — a recurring multi-builder merge cost (the PR #167 lineage) — is eliminated at the source. Ship drops up to two bookkeeping commits per session.
- **Accepted staleness:** the *served/on-disk* whole files are fresh only *after deploy* (or a box-fetch tick), not at merge. For navigation indexes this is tolerant by nature — worst case an agent's symbol map is a few minutes stale. A generator that breaks at deploy leaves a stale/absent file with no *blocking* backstop; the LOUD `::ERROR::` line is the alarm (mandatory, not optional).
- **Transition wrinkle:** a branch that already committed either file before this lands will hit a one-time modify/delete conflict on its next merge with `main` (resolve = keep deleted). New branches never touch the files.
- **Fresh pristine checkout:** a bare `git clone` that never runs a generator lacks the two files, so a markdown link to them (e.g. the CLAUDE.md nav row, the §13 snippet's "full history" link) points at an absent path *there only*. Nothing hard-checks links in that state; every real environment (box, deploy) regenerates them. `docs-entropy` (a scheduled scanner, not a CI gate) runs where they exist.
- The generated-artifact set is now defined per-bucket; adding a future gitignored generated file means: `.gitignore` + a deploy-prod.sh regen line + a box-source-fetch line + a `--check-block`/`--check-whole` split if it is dual-duty.

## Alternatives considered

- **Post-main regen bot / cron that re-commits the files** (the owner's two original ideas) — rejected as the *primary* mechanism: both keep the files in git, weaken the freshness gate for every content PR, burn CI on regen PRs, and (there is no GitHub webhook in this codebase) can only poll anyway. "Don't commit the file" is strictly simpler than "automate re-committing it." The bounded bot survives only for the API spec (a follow-up task), which has external consumers.
- **Strengthen the reactive heal only** (ADR 0082++) — rejected: makes conflicts invisible, not absent; the per-branch bookkeeping commits and the heal latency remain, and the cost grows with parallelism.
- **Trim `docs/repo-map.md` from `REGENERABLE`/`.gitattributes`** — deferred: it would force a rewrite of `tests/git_merge_regen.mjs` (which uses repo-map as its canonical whole-file heal fixture) for no real gain, since a gitignored file never reaches the driver anyway. Leaving the entries in place is the lower-risk transition posture.

## Amendment — 2026-09-25 (task 1001929): `docs/file-map.md` stays tracked; the reactive heal is enough

**The open question (pt.4).** `docs/file-map.md` is hybrid — hand-written prose plus two generated blocks (`.claude/skills/`, `.claude/scheduled-tasks/`, [ADR 0066](0066-generated-file-map-sections.md)) — so it cannot be gitignored like the two whole files above. What was left to decide: does its generated churn cause enough parallel-branch conflicts to justify the repo-map treatment (move the blocks into a gitignored companion file and split the gate into `--check-block`/`--check-whole`), or does the `otb-regen` heal it already has (`.gitattributes` + `REGENERABLE`, [ADR 0082](0082-server-side-merge-conflict-auto-resolution.md)) cope?

**Measured, not estimated.** Every merge commit reachable from `origin/main` at `331569b4` (2026-09-25) — the whole history since the 2026-07-03 core extraction, PR landings and the branch-side "merge origin/main into task-N" freshness merges alike — was replayed with `git merge-tree --write-tree --name-only <parent1> <parent2>` in a mirror clone (`git clone --mirror --shared`) that has **no** `merge.otb-regen.driver` registered. Git then falls back to its plain 3-way text merge, so the replay shows what each merge would have hit with no heal at all. For each `file-map.md` conflict, the conflict markers in the written tree were located against the `BEGIN`/`END GENERATED FILE-MAP` markers.

| Replay result | Count |
|---|---|
| Merges replayed | 2,287 |
| Merges that would have conflicted on any file | 248 |
| … on `docs/file-map.md` | **3** — all in hand-written prose, **0** inside a generated block |
| … on `docs/file-map.notes.json` (the hand-written notes sidecar) | 0 |
| Non-merge commits touching `docs/file-map.md` | 129 — 89 prose only, 30 generated block only, 9 both |

For scale, the same replay counted 78 conflicts on `docs/copy-inventory.md`, 77 on `CLAUDE.md`, 70 on `docs/copy-registry.json`, and 21 each on `docs/api/openapi.json` and `docs/api-reference.md`.

The three `file-map.md` conflicts all fell on 2026-08-29 (the freshness merges for tasks 1002968, 1002290 and 1002967), and all have one shape: two sessions each hand-appended a line for a new test file at the same end of the `tests/` listing. There have been none since. The generated blocks do churn (39 commits changed one) but never conflicted, even with the driver switched off: each block lists one directory per line in sorted order, so two branches adding different skills usually edit different lines. If they ever do meet, the driver already re-renders both blocks from the merged tree.

**Decision: no split.**

1. The split targets the one part of the file that has never conflicted. Moving the blocks out would have prevented none of the three conflicts on record — all were prose, and the prose stays in git whatever happens to the blocks.
2. It would cost real machinery for no measured gain: a new gitignored file with its own regeneration on every refresh path (the recipe in Consequences above, plus the standalone path, [ADR 0147](0147-standalone-live-docs-regen.md)), a gate split, and relinking the map to the companion file.
3. The file-map gate is unchanged: plain `gen-file-map.js --check`, hard, in `fitness.js`. It also enforces the note-per-skill contract and module coverage (task 1004066), both of which assume the file is tracked.

**Revisit if** a re-run of the same replay shows conflicts *inside* a generated block, or prose conflicts become routine. The prose case would need a different fix (for example, a per-area file for the hand-written tree); the split considered here cannot reach it.
