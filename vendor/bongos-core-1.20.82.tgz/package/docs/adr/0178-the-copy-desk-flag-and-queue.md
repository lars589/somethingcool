# 0178 — The copy desk: a flag carries a judgement, and no column here could ever hold copy

- **Status:** Accepted
- **Date:** 2026-08-19
- **Tasks:** [#1003113](https://cloudbongos.com/builders#/task/1003113) (R02 of goal 1000074, the artist's loop) — builds on [#1003112](https://cloudbongos.com/builders#/task/1003112) (R01, the copy registry)
- **Extends:** [ADR 0081](0081-tool-agnostic-design-layer.md) — the repo is the source of truth for design, with swappable tool adapters. This is the same claim for TEXT.
- **Related:** ADR 0083 (module system, module-owned migrations), 0086 (goals + scope walls), 0016 (authority resolved server-side), 0158 §2 (a verdict is advisory, never self-executing), 0162 (review gates retired — no human approval in the land path), 0175 (an objection requires a reason)

## Context

Goal 1000074 gives the artist real authority over what ships, and the owner's ABI brief gives them the
project's **text**: no slop, story and ideology communicated, purpose and gravitas, re-text-writing.
None of that was exercisable. Copy was scattered across 57 hall files, the status dashboard and a
server-rendered landing template, and nothing routed work to an artist.

R01 built the inventory: `scripts/gds/copy-inventory.js` emits `docs/copy-registry.json` — every
user-facing string with a stable id and the render path that shows it. An inventory answers *what does
the product say*. It cannot answer *what is wrong with what the product says*, which is a judgement a
person has to make and record. R02 is that record, plus the queue an artist reads it from.

Two constraints came from the goal itself, and they pull against each other. **Blocking strictness is
per project, not global** (R05's problem, not this one). And **NO LIVE CMS** — every copy change is a
claimed, graded, shipped task, because the GDS is the complete ledger of what happened to this project.
The tension: the goal also asks for "an editing affordance". An affordance that edits, and a ledger
that must record every edit, are one bad column apart from being incompatible.

## Decision

### 1. Copy is its own module — `copy-desk`, not `copy`

The domain has no home today. `ideas` owns intake queues and would have been the cheap answer, but its
module-owned migrations must be `ideas_`-prefixed, so the table would have been `ideas_copy_flags` — a
name that lies about the domain. `hall-ui` contributes no routes. `lifecycle` is the build state
machine. So: a new default-on core-domain module, which the loader discovers with no core edits.

**The key is `copy-desk` and not `copy` for a concrete reason, not a stylistic one.** The branding
contract already owns a `copy` block (`branding.copy.tagline` / `hallName` / `notFound`). The
`core carries no module code` fitness check greps kernel files for every discovered module key, so a
module keyed `copy` reds the build on the English word appearing in `src/branding.js`. `copy-desk` is
also the more accurate name: the copy desk is the editorial station copy passes over before it is
published, which is exactly the job. SQL namespace `copy_desk_`, table `copy_desk_flags`.

The generator stays at `scripts/gds/copy-inventory.js` and is listed in the module's scope-map globs —
a command travels with its domain (the `memory`/`ideas` precedent), it does not move.

### 2. A flag carries a JUDGEMENT, and the floor is in the schema

A flag with no reason hands an artist a pointer and no judgement. That is strictly **worse** than not
flagging, because it still costs them a look. So `reason` is required in the route (a named
`reason_too_thin` whose payload explains why, since the person hitting it is trying to help) **and** in
a CHECK constraint (`length(btrim(reason)) >= 10`).

Both, deliberately. The route gives a person a usable error; the constraint means no future write path
— a backfill, a CLI, a later module — can quietly create the reasonless flag the queue exists to not
contain. Closing a flag requires a note for the same reason, and **the symmetry is the point**: an
unexplained close is indistinguishable from a queue being cleared to make a number go down. ADR 0175
made the same call for a board objection.

### 3. NO LIVE CMS is enforced by the schema's SHAPE, and made testable

This is the load-bearing decision. A non-goal that lives only in prose erodes — and it does not erode
by someone committing "add a CMS". It erodes by one plausible column ("just store the suggested wording
so the artist doesn't lose it"), then one plausible read of that column, and the ledger rule is dead
with nobody having decided to kill it.

So **`copy_desk_flags` has no column that could hold replacement text, and must never gain one.** A
flag carries a judgement (`reason`, `kind`) and a pointer (`surface`, `string_id`). The editing
affordance R03 builds produces a **task with a diff attached**, not a row here; `resolved_task_id` is
the seam it lands on.

`modules/copy-desk/tests/copy_no_cms.mjs` pins the shape: the write surface is exactly the two verbs
R02 defines, no `new_text`-shaped column exists, this module performs no filesystem write, and the
manifest provides no port another module could write copy through. When R03 adds its proposal path the
expected route list changes **in a diff a reviewer can see**, rather than drifting.

### 4. Filing is open to every rank; closing is Metic+ or the author

Asymmetric on purpose. **"Sourced by everyone else" is the task's own framing** — the engineer who just
wrote a toast, the newcomer who could not understand a button, and the ideator reading the landing page
are the three people most likely to notice bad copy, and none of them is the artist. A rank floor on
filing leaves the queue empty and the goal unmet. The reason floor is the quality gate; rank is not.

Closing someone else's flag is a triage act at the same floor as idea triage and blocker resolution
(Metic+). An author withdrawing their own flag is a correction, not triage, and should not require a
promotion. **An artist is a craft, not a rank** (`builders.preferred_disciplines`), so nothing here
gates on craft — that would hide the artist's own queue from a Xenos artist.

### 5. Duplicates are the only automatic signal, and the count subtracts settled work

The task asked the queue to surface copy that is **stale, duplicated or off-voice**. Only duplication
needs no judgement layer, and R01 already computes it deterministically. This module does not recompute
it — it **subtracts what has already been flagged or dismissed**, because a count that never moves
however much work an artist does teaches them the queue is decorative. Stale and off-voice need either
a person (the flag) or a judge, which is not built.

### 6. A vanished target is reported, never auto-closed

The registry id is a content hash over (surface, text, render path): stable across a file **move**, not
across an **edit**. So a flag routinely outlives the sentence it names, and `annotateFlag` reports
`target_state: 'gone'`.

That is a **hint for a person**, not a verdict. Auto-closing on it would be the system deciding a human
judgement is finished because a hash moved — the same family of error ADR 0158 §2 rules out for audit
verdicts (a finding is addressed to a human; it is never itself the action). Every flag also stores a snapshot (text, file, line at flag time), taken server-side from the
registry and never from the request body: a caller-supplied snapshot is a caller-supplied claim, and
the snapshot's entire value is that it can be trusted later.

## Consequences

- **A new default-on module ships to every instance.** Justified: every instance shows a person words.
- **The queue describes the committed registry** — the deployed tree, not a working copy. It therefore
  names what it read and hands over `--check`, and **deliberately reports no `generated_at`**: R01 is in
  the `gen-*` family and its contract is determinism, so a clock is the one field it cannot carry. The
  file's mtime is the checkout's, and showing it as "generated" would be a plausible lie.
- **The inventory is partial and says so.** R01's documented blind spots — server-side messages, skill
  prose, runtime-composed strings — travel with the queue payload and render on the page, so "1332
  strings" is never read as "every word the project says".
- **Adding a hall page adds copy**, so `docs/copy-registry.json` must be regenerated when a surface file
  changes. `tests/copy_inventory.mjs` already enforces this; this task tripped it, which is the system
  working.
- **Goal 1000074's `scope_modules` must gain `copy-desk`**, or R03–R06 cannot declare `touches[]` in the
  module their work lives in. The mechanism is `POST /goals/:id/scope` with `{"add":["copy-desk"]}` —
  the ADR 0086 §4 "ask to widen" route, Metic+ and member-or-Archon, Archon-only for a protected module.
  **It cannot run until this change is deployed.** The route validates the key against `isModuleKey()`,
  which reads the *running server's* `module-scope-map.js`; until the instance pin moves, the live
  roster has no `copy-desk` and the call answers `400 unknown_module`. So this is an ordering
  dependency, not a missing capability, and it is the one follow-up that must happen after the pin
  moves rather than before.
- **R05 still owns the hard question.** Nothing here blocks a ship. Whether an artist's flag can ever
  gate a ship, and how that coexists with ADR 0162, is R05's to decide — this ADR deliberately does not
  pre-empt it, and the flag is advisory by construction until it does.
