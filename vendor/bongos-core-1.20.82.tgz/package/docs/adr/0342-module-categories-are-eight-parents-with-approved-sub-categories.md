# ADR 0342 — Module categories are eight fixed parents, with narrow sub-categories an author proposes and Metic+ approves

- **Status:** accepted
- **Date:** 2026-09-28
- **Task:** [task 1003783](https://cloudbongos.com/builders#/task/1003783) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Will (owner of working area 5) approved the parent list and chose who creates sub-categories; Claude derived the candidates from the live module roster and wrote the record.
- **Related:** [ADR 0338](0338-modules-travel-through-a-bongos-hosted-store.md) (the hosted store) · [ADR 0264](0264-the-ten-working-areas.md) (area 5) · [session log 2026-09-10](../session-logs/2026-09-10-goal-1000091-area-5-criteria.md) (the owner's cap-of-ten and nested-category rulings)

## Context

The owner's listing rule is a quality floor, then ranking, then **at most ten listed per
comparable category** — "fifteen Stripe modules all over 94% still show only the top ten". A
cap needs a set to count within, and nothing in the module contract carries a category today.
The owner has already ruled that categories are **nested**: a module sits in a sub-category
inside a parent.

The comparable set is the narrow one a buyer actually chooses between ("Stripe payments"), not
a broad department. If it's too broad, the cap hides good modules that don't compete with each
other. If it's too narrow, every module is top-ten in a category of one and the cap does nothing.

## Decision

### D1 — Eight parent categories, fixed

Derived from the modules that exist today (the roster under `modules/`):

| Parent | Key | Today's modules that would sit in it |
|---|---|---|
| Work & planning | `work` | lifecycle, ideas, agents, autonomy |
| Team & people | `people` | onboarding, government, platform-identity, builder-settings, specialities |
| Quality & review | `quality` | grading, security, copy-desk |
| Money | `money` | economy |
| Communication | `communication` | discord |
| Pages & design | `pages` | hall-ui, public-landing, status-ui, ui-design |
| Hosting & deploy | `hosting` | provisioning, npm-release, dev-box |
| Knowledge | `knowledge` | memory, sessions |

A parent is for browsing only. **The cap is never applied at the parent level.** Changing the
parent list needs a new ADR.

### D2 — The sub-category is the comparable set, and the cap applies there

Every listed module has exactly one sub-category under exactly one parent. The cap of ten, the
ranking and the per-category comparison (task 1003800) all run within a sub-category.

### D3 — The author proposes a sub-category; Metic+ approves it

When publishing, an author picks a parent and either picks an existing sub-category or proposes
a new one. A proposed sub-category is **not live** until a Metic+ builder approves it, renames
it, or merges it into an existing one. Until then the module is listed under its parent with no
sub-category, and it counts toward no cap.

This is the owner's choice, and the reason is the cap itself. If authors named sub-categories
freely, "Stripe", "Stripe payments" and "Payments (Stripe)" would become three categories with
five modules each, and the cap would never bite. An approver merging near-duplicates is what
keeps the comparable set real.

### D4 — One sub-category per module

A module that does two unrelated jobs picks the one it competes on. Multiple sub-categories
would let one module take a top-ten slot in several places, and the cap is meant to make slots
scarce.

## Consequences

- **Task 1003784** (nested category in the manifest and both catalog surfaces) builds to this:
  `category: { parent, sub }`. `parent` is one of the eight keys, and `sub` is the key of an
  approved sub-category or absent while a proposal is pending.
- **An approval queue** for proposed sub-categories is new work, not yet filed. It needs a
  Metic+ permission key and follows the same pattern as the score override (task 1003796).
- **Core modules get categories too**, so the catalog is consistent. The table in D1 is their
  starting assignment.
- **The cap (task 1003809)** counts listed modules per approved sub-category, never per parent.

## Rejected

- **Authors name sub-categories freely.** Near-duplicate names defeat the cap.
- **Only Metic+ creates sub-categories.** An author with a genuinely new kind of module would
  have to wait for someone else to make the category first.
- **A flat list of categories.** The owner specified nested. A flat list forces a choice
  between browsable-but-broad and comparable-but-endless.
- **Capping at the parent level.** Ten modules across all of "Money" would hide good modules
  that don't compete with each other.
