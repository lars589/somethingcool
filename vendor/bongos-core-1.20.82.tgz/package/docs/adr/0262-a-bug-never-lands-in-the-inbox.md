# ADR 0262 — A bug never lands in the inbox: the system names the home the reporter didn't

**Status:** Accepted · 2026-09-07 · task 1003691
**Supersedes nothing. Amends nothing.** It makes the explicit decision [ADR 0235](0235-a-fix-category-is-kindbug-under-a-goal-no-column-required.md) §6 said would be needed, and it keeps [ADR 0234](0234-idea-routing-capture-time-promotion-landing-matrix-homeless-inbox.md)'s `#ideas` interview decision and [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) D4's invariant both intact.

## Context

A reported defect could still end up parked in `idea_inbox`, waiting for a human triage pass — the exact tax criterion C1 of goal 1000071 was opened to remove.

The cause is one line. `modules/ideas/routing.js` `decideLanding()` opened with:

```js
if (goalId == null || goalId === '') return { route: false, reason: 'no_goal' };
```

The `kind === 'bug'` hard-land branch sat **nine lines below** it and was therefore **unreachable without a goal**. `kind` only ever chose the routed task's *status* (`ready` for a trusted filer, `backlog` otherwise); it never chose whether the filing routed at all. So "bugs are urgent-true" was true only for a reporter who already knew which goal the defect belonged to — which is precisely the knowledge criterion C5 promises a filer never needs.

### The conflict this task was filed over does not exist

The task was opened on the premise that two accepted ADRs contradict each other, and that one had to lose:

- **ADR 0250 D4** — "Every task belongs to a real, open goal. `goal_id` becomes required at creation." Enforced: `modules/lifecycle/db-tasks.js` throws, `POST /tasks` 400s `goal_id_required`.
- **ADR 0235** — read as exempting `kind='bug'` from needing a goal at all, on the strength of the phrase *"a fix needs no home to be filed correctly."*

**That reading of 0235 is wrong, and checking it was the first thing this task did.** ADR 0235's headline decision is the opposite:

> **A fix category is `kind='bug'` on a task that carries a real `goal_id`** — no schema change, no new column, no new goal type.

The quoted phrase describes `adviseGoal()` in `modules/lifecycle/goal-advisory.js:64`, which returns `null` — stays silent — for a `kind='bug'` task on its `no_goal`, `catch_all` and `no_criterion_link` branches. It is an **advisory suppression**: it stops the system nagging a bug about its goal. It grants nothing, and it changes no schema.

So both ADRs already require a real goal, nothing loses, and no amendment is owed. What ADR 0235 *did* anticipate is this task — §6 Consequences:

> giving `kind='bug'` more weight than an advisory exemption "is a new, explicit decision needing its own ADR."

This is that ADR.

## Decision

**A `kind='bug'` filed from a trusted vector with no goal becomes a task in the version's maintenance goal, at the status the existing rank split already assigns.** Two halves, and both are load-bearing.

### D1 — The home is the per-version MAINTENANCE goal, find-or-created

The reporter does not name a home; the system does. `modules/ideas/homeless-home.js` resolves the current building version (`lifecycle.currentBuildingVersionId`), then find-or-creates `"<version> — maintenance"` (`lifecycle.ensureMaintenanceGoal`).

**Not the `"<version> — general"` catch-all**, which is the obvious-looking choice and the wrong one. BV1.R11 (task 1003598) began *deleting* that fallback after 53 open tasks accumulated unread in two of them, and `db-tasks.js` warns against adding a third caller to the `allowCatchAll` opt-out it left behind. The maintenance goal is the home task 1003605 (BV1.R18) already designs for exactly this — *"where a defect against already-shipped work lands"* — so routing points at the destination the roadmap was already heading for rather than repopulating the bucket being drained. **This vector adds no `allowCatchAll` caller**, pinned by `tests/task_goal_required.mjs`.

ADR 0250 D4's invariant therefore holds exactly: the task carries a real, open `goal_id`. What changes is only *who names it*.

Three mechanics that are decisions, not implementation detail:

- **The version tiebreak is not new.** More than one version may sit at `building` — ADR 0250 D5 closes the *planning* slot only, and refusing a second building version is still unshipped (task 1003606, BV1.R19). The rule reused is `pickDefaultVersion` from `scripts/gds/version-select.js`, expressed in SQL: building only, `started_at DESC`, nulls last, `id` breaking a remaining tie.
- **Find-or-create takes a `pg_advisory_xact_lock`.** `goals` has no unique constraint on `(version_id, title)` — migration 160 used a `NOT EXISTS` guard, safe for a one-shot backfill and unsafe for a concurrent path, where two bugs reported in the same second would both insert and leave the title lookup permanently ambiguous.
- **It runs inside the caller's transaction.** A goal created on its own connection would outlive a rolled-back route as an empty goal nobody asked for.

**It fails closed.** No building version (`NO_BUILDING_VERSION`), or a version whose maintenance goal cannot be made (`NO_MAINTENANCE_GOAL`), refuses the filing and rolls back. Inventing a version is idea 1000771's exact failure — every Discord report entombed in a shipped version's catch-all — and this path exists to end that, not to repeat it.

### D2 — The gate is the VECTOR, not the kind alone

Routing keys on an allowlist, `routing.HOMELESS_ROUTING_VECTORS = {'api', 'discord-bugs'}`, and **absent or unrecognised is untrusted**.

This is the half that keeps ADR 0234 whole. Its owner-interview decision — *"Discord `#ideas` files with HINTS only, never routes"* — is not an incidental detail: `#ideas` passes **no kind at all**, so `inbox.classify()` guesses one from keywords, and its bug pattern fires on `fix|broken|bug|regression|crash|error` anywhere in the text. *"We should fix the copy on the landing page"* classifies as a bug. Gating on kind alone would let a keyword guess mint work and would have killed an explicit owner decision as a side effect.

The two trusted members each carry a human or a channel that means *this is broken*:

| Vector | Why it is trusted |
|---|---|
| `api` | `POST /inbox`, authenticated builder, explicit `kind`. `scripts/gds/capture.js` posts to this route, so the CLI inherits it and needs no member of its own. |
| `discord-bugs` | The **channel is the classification** (`discord-bugs.js` forces `kind='bug'`), and it already carries an unlinked-author guard, a per-builder hourly rate cap, and a body screen. |

`discord-ideas` is named explicitly at its call site so its exclusion is a written fact rather than an absence someone has to notice. The vector is **server-set at every call site and never read from a request body**, which is what makes forging it a non-move.

#### A vector is claimed by a call site, so the call site must still check identity

`#bugs` sets `vector: builder ? 'discord-bugs' : null` — **conditional, not the bare string.** The first cut of this ADR set it unconditionally and that was a trust-boundary regression caught as a grader blocker, worth recording because the shape will recur.

The channel earns its place on the allowlist through two guards that are both **identity-bound**: the rank-aware landing needs a rank, and the rolling rate cap is counted per builder id. An unlinked Discord author has neither — `filerRank` is null and the goal is only sought `if (builder)` — so an unconditional vector meant they took the homeless-bug branch and minted a real `backlog` task, with the per-builder rate limiter not running at all for them. That is unattributed task creation at no cost, and it contradicts the promise at the top of `discord-bugs.js` that ADR 0047 bought: *"an unlinked author cannot inject claimable work… it no longer mints anything."*

The general rule: **being on the allowlist is a property of the DOOR, not of everyone who walks through it.** A vector attests "filings from here carry a human who means *this is broken*"; where a door admits both identified and anonymous traffic, it may only claim the vector for the identified half. With no vector the filing falls back to the inbox exactly as before — the report is kept, its images re-hosted, a human still sees it in triage. Pinned as F16, mutation-verified against the unconditional form.

Everything else the matrix already decided is unchanged and still applies to this path: the Metic+ rank split (`ready` vs `backlog`), the Full Idea refusal, and the judgment kinds. **Only bugs get a free home** — a homeless feature or cleanup is exactly the work the inbox is *for*, and fabricating homes for it would empty the inbox by lying.

## Consequences

- **The inbox's stated identity becomes true.** `.claude/skills/idea-triage/SKILL.md` claimed bugs "never appear here" and credited task 1003071 — which only touched the triage/promote path (commit `dab7e314`); capture-time routing was task 1003065. The claim was false when written and is corrected alongside this ADR; it is now true for the `api` and `discord-bugs` vectors.
- **A bug reported in Discord `#ideas` still lands in the inbox.** That is deliberate, and it is not a gap: bug reports from Discord have their own channel, `#bugs`, which routes.
- **`#bugs`' bad-guess fallback got better.** It re-files with `goalId: null` when a suggested goal refuses the landing; that path now reaches the maintenance goal instead of the inbox, so dropping a wrong guess costs a triage pass rather than the whole report.
- **Task 1003605 (BV1.R18) is partly delivered and still owed.** This ships the maintenance goal's title, find-or-create and routing. R18 still owns auto-creating it with every version, the close-exempt flag R16 reads, and carrying open bugs forward to the successor version on close.
- **A new file on the create path** — `modules/ideas/homeless-home.js`, added to the `tests/task_goal_required.mjs` roster so the anti-drift pin covers it.

## Alternatives rejected

- **Let a goal-less bug create a goal-less task** (an `allowCatchAll`-style escape hatch for bugs). Breaks ADR 0250 D4 one day after it was accepted, and every consumer assuming `goal_id` is non-null would need auditing. The invariant is worth more than the shortcut.
- **Reject a bug with no goal, listing open goals to pick from.** One rule, no exceptions — but a rejected report does not land *at all*, and Discord's bot fires and forgets, so every inbound bug from a channel that cannot retry would be silently lost. It also directly contradicts the thing being asked for.
- **Route into the `"<version> — general"` catch-all.** Smallest diff, reuses shipped machinery, and repopulates the exact buckets BV1.R11 was filed to drain. R18 would then have to undo it.
- **Build R18 whole first, then route.** The cleanest end state, and substantially more scope than the defect being fixed; the close-exempt flag and version-close carry-forward are independent of whether a reported bug finds a home today.
- **Gate on `kind` alone.** Cheapest fix, and it silently overturns ADR 0234's owner-interview decision by letting a keyword classifier mint tasks from an ideation channel.
