# ADR 0300 — A missing protected-surface registry is a broken install, not a module opt-out

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003662](https://cloudbongos.com/builders#/task/1003662) (goal 1000091 — BONGOS-V2)

**Related:** [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (the protected-surface boundary this registry enforces) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (core never depends on a module's behavior) · [ADR 0108](0108-instance-composition-configurable-root.md) §1 (the core is consumed as a versioned npm package, and `modules/` ships inside it)

## Context

[task 1003662](https://cloudbongos.com/builders#/task/1003662) was filed as a bug with a
concrete remedy attached:

> `require('./module-scope-map')` throws on any checkout where
> `modules/government/protected-surfaces.json` is absent … This breaks any checkout that has
> disabled or not yet materialized the government module … Make `module-scope-map.js` degrade
> gracefully (empty protected set + a loud warning) when the government module isn't present,
> matching the `resolveOptional` pattern used elsewhere for optional module capabilities.

The throw is real and reproduces exactly as described. Moving the registry aside and requiring
the kernel file gives:

```
protected-surface registry unreadable at <root>/modules/government/protected-surfaces.json:
ENOENT: no such file or directory. Refusing to run with an empty protected set (ADR 0043).
```

Everything after that first sentence is wrong, in four separate ways — and the remedy it
proposes would disable the ADR 0043 boundary on exactly the installs least able to notice.

**1. The throw is not in the file the task names.** `module-scope-map.js` contains no `throw`
and no file read. It does `require('./permission-path-check')` at line 39, and
`permission-path-check.js`'s `loadRegistry()` throws at module scope. Any "fix" applied to the
file in the title would be applied to the wrong file; the behavior is owned by its sibling.

**2. The throw is a written contract, not an oversight.** `permission-path-check.js` states it
in its own header, in capitals, above the code:

> FAIL-CLOSED: a missing/empty/malformed registry THROWS. It never degrades to "nothing is
> protected" — an unreadable registry is a broken install, not an opted-out module.

The remedy asks for the one behavior the header names and refuses. That header also pre-answers
the architectural worry the title gestures at (a kernel file reaching into `modules/`): the read
is `fs`, never `require`, because ADR 0083's one-way rule forbids core from requiring a module's
*code* — and this is not code, it is a static declarative data file. The sibling trust primitive
`route-rank-check.js` reads `modules/*/routes/*.js` off disk the same way. Code still flows one
way; nothing in core requires the module.

**3. Disabling the government module cannot produce the ENOENT.** Module enablement is a
runtime flag, not a file deletion — disabling a module leaves its files on disk untouched. The
registry read never consults enablement, deliberately: per the same header, a module's
enable/disable state must never be something the kernel depends on. So the "disabled" half of
the premise describes a state that cannot occur.

**4. The "not yet materialized" half does not occur either, because the file ships with the
core.** `package.json` declares no `files[]` allowlist, so the whole directory ships.
`npm pack --dry-run` on this commit puts `modules/government/protected-surfaces.json` in the
tarball at 13,274 bytes, one of 3,419 files. Per [ADR 0108](0108-instance-composition-configurable-root.md)
§1 the core is consumed as a versioned npm dependency and `resolveCoreRoot()` resolves the core
package's own `modules/` inside `node_modules`. You cannot have `@bongos/core` without this
file. If it is absent, the install is damaged — a partial extract, a lossy copy, a `.gitignore`
that ate a JSON file — and that is a fact worth surfacing loudly, not smoothing over.

**The `resolveOptional` precedent does not transfer.** `resolveOptional` is real and used in
roughly a dozen places, but it is the module **seam/port resolver**: `api.resolveOptional('grade')`
lets one module degrade when another module's *runtime capability* is absent, which is exactly
right for an optional capability. A protected-surface registry is not a capability being
resolved at a seam. It is the static data the trust boundary is made of, read synchronously from
disk by enforcers that run where there is no server and no database — a git hook on a laptop, a
CI job. Borrowing the seam pattern here reads as consistency, but it silently converts "the
boundary is unreadable" into "there is no boundary".

## Decision

**Fail-closed stays. The registry is not optional, and a missing registry is a broken install.**

Concretely:

1. **No behavior change to `permission-path-check.js` or `module-scope-map.js`.** The throw is
   correct, its placement is correct, and the header already documents why.
2. **The task's described remedy is rejected**, on the grounds above — chiefly that an empty
   protected set is not a degraded mode of a trust boundary, it is the absence of one.
3. **The error message gains a remediation line.** This is the one genuine defect the report
   surfaced: the message states the refusal and cites ADR 0043, but never tells the reader what
   to *do*, which is precisely how a reader concludes the module must be optional and files this
   task. It now names the likely cause and the fix.

The asymmetry is the whole point. A false "nothing is protected" is silent, permanent, and
grants authority; a false "this install is broken" is loud, immediate, and grants nothing. Only
one of those is safe to be wrong about.

## Consequences

**A damaged install fails loudly at require time, and now says what to do about it.** That was
already true of the first half; the second half is new. The reader who hits this next gets
pointed at reinstalling the core rather than at weakening the check.

**The report will recur in some form, and that is acceptable.** Anyone meeting this ENOENT
cold sees a kernel file reaching into `modules/` and reasonably suspects a layering bug. This
ADR is the durable answer to that suspicion, which is why it exists rather than a won't-fix
note: the next agent to wonder can be pointed at a number.

**If a legitimate need for a core-only checkout without `modules/` ever appears, this decision
is the thing to revisit** — and the revisit is "where should the registry live", not "should it
be optional". Relocating the canonical data into `src/` and having the government module
contribute to it would preserve fail-closed while removing the cross-directory read. Nothing
today needs that, and doing it speculatively would move a trust primitive for no gain.

**What this does not decide:** whether other `modules/` reads from core (`route-rank-check.js`
reading `modules/*/routes/*.js`) should follow the same rule. They share the mechanism and the
justification, but each is its own trust surface and none is currently in question.
