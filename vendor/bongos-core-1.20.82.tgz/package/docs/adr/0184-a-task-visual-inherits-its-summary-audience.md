# ADR 0184 — A task's visual is its value summary in another medium, and inherits that audience

- **Status:** accepted
- **Date:** 2026-08-25
- **Task:** 1003109 (from owner idea 1000400, filed in Discord `#ideas` 2026-06-24)
- **Goal:** 1000072 — Human legibility

## Context

`value_summary` — the plain-language "what this means for a reader" line collected at ship time — already answers *what changed* for someone who does not read code. What it cannot answer is *what it looks like*. The owner's ask was explicit: a builder should be able to show "what they have built in the task … for the whole city to understand the impacts."

Everything else in that idea already shipped (the note itself, and the spend half via `/cost`). What was missing was a picture. The only visual path a builder had was a Discord post — outside the ledger, and on a CDN whose links expire.

Adding an image to a work-tracking record raises one question that is easy to answer badly: **who may see it?** A screenshot is not a sentence. It carries whatever was on the screen — an unshipped surface, another builder's name, a token in a terminal pane. The tempting move is to give visuals their own visibility control.

## Decision

**A visual has no audience of its own. It is the same claim as the task's `value_summary`, in another medium, and inherits that summary's audience exactly.**

Consequences, in the order they bite:

1. **One predicate, stated once.** `task-visuals.isPubliclyViewable(task)` — public means `status ∈ {shipped, confirmed}`, byte-for-byte the test `routes/public.js:projectPublicTask` already applies to a title and a summary. Anything else is served to any authenticated builder, which is the ordinary GDS posture: **not-public means un-published, never hidden**.
2. **The gate lives inside the serve handler, not in the mounted middleware.** The audience is a property of the *row*, and Express middleware cannot express that. The stored filename therefore carries the task id (`task-<id>-<16hex>.<ext>`), so one lookup resolves it. Every step fails closed — unparseable name → absent task → not-public → `auth.requireBuilder`, never past it.
3. **The public shipped feed mirrors the predicate in SQL** (`db.recentShippedTasks` nulls the URL for a `security_sensitive` row) so the unauthenticated status dashboard never advertises an image the serve route would refuse. Nulling the URL, rather than selecting the flag and filtering in JS, also keeps `security_sensitive` itself off the public wire. **Change one, change the other** — the two are noted in each other's comments.
4. **One deliberate narrowing vs `value_summary`:** a `security_sensitive` task's image stays builders-only even once shipped. A summary is a sentence its author chose; a screenshot is whatever was on the screen, and on a security task that is the wrong default to publish.

### The optionality is load-bearing

"Where relevant" was the owner's own wording, so *optional* is a contract, not a default:

- Nothing on the ship path calls the upload. `ship.js --visual` screens the file **before** the claim resolves (bad input costs a retyped command, never a claim) and uploads it **after** (a failed picture prints a warning and the re-attach command; it never fails a ship that already landed).
- A task with no visual renders **nothing at all** — no placeholder, no empty frame, no "no visual" line. A task without one must never read as unfinished.
- It is removable. `DELETE /tasks/:id/visual` exists because an image is not prose: the write-once rule of task 1003102 guards a written *claim*, not the picture beside it.

### Not an arbitrary-file host

Uploads are screened by an extension allowlist, a magic-byte sniff (a mislabeled content-type cannot smuggle a non-image onto disk), a 4 MB cap, and a server-minted filename. **SVG is deliberately absent** from the allowlist: it is an executable document, and these are served from our own origin. The serve route adds `nosniff`, `Content-Disposition: inline`, and a `default-src 'none'; sandbox` CSP. Files live under `var/task-visuals/` — outside the git tree, like the `#bugs` re-hosts (task 936), so a deploy's `git reset --hard` never wipes them.

## Alternatives considered

- **A per-visual visibility flag.** Rejected: it invents a second privacy axis over the same fact, and two axes over one fact drift. The first time they disagreed, a reader would have to guess which one was the truth.
- **Reusing `modules/discord/bug-attachments.js` directly.** Rejected: ADR 0083 forbids one module requiring another, and the intake genuinely differs (that lib *downloads* from a CDN and needs an SSRF host allowlist; this one receives bytes from the shipping builder). The shapes are re-stated under the ADR 0091 §2 boundary-forced-duplication rule and cross-referenced in both file headers.
- **Rendering the image full-size in every feed.** Rejected as unreadable at scale: the ship ledger, a profile, and the status dashboard are scannable lists, so they show a small thumbnail that links to the full file. The task page renders it properly — that is where someone goes to *look*.

## Consequences

- A non-engineer can open the public status dashboard and **see** what shipped, not only read about it.
- Any future surface that renders `value_summary` inherits a settled answer for the visual beside it: same place, same audience, no new decision.
- The two mirrored copies of the audience rule (JS predicate, feed SQL) are a maintenance obligation, accepted deliberately over the alternative of the public feed learning what `security_sensitive` means.
