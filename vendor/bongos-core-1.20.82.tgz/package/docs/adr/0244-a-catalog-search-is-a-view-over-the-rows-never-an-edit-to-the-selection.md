# 0244 — A catalog search is a view over the rows, never an edit to the selection

- **Status:** Accepted
- **Date:** 2026-09-04
- **Tasks:** [#1002340](https://cloudbongos.com/builders#/task/1002340) (this decision — BV1.R21)
- **Amended:** 2026-09-22 by [task 1003500](https://cloudbongos.com/builders#/task/1003500) — §3's "no
  synonyms" is reversed (rows carry declared search `aliases`, so typing `chat` finds Discord); "not
  semantic" stands, the sentence case still finds nothing, and the embeddings layer §3 deferred to
  was declined. See the amendment note in §3.
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation, criterion
  `proj-module-select` ("during setup a default set of modules is pre-selected…")
- **Related:** [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
  (R19 — the per-type presets, and the file that already said "R21 searches the catalog"),
  [ADR 0240](0240-a-skipped-module-picker-stores-nothing-and-resolves-the-bundle-on-read.md)
  (R20 — the picker, and the three-valued `modules` column whose `null` this must not disturb),
  [ADR 0243](0243-a-bundle-adjustment-belongs-to-the-bundle-not-the-advice-about-it.md)
  (R22 — the tailored preselect the search now filters)

## 1. The problem

The picker paints one row per optional module. The catalog is three rows today
and is meant to grow — the module system's whole point is that an instance adds
modules — so R21 asks for a keyword search over it.

A search over a list of *links* is trivial. A search over a list of **toggles**
is not, because the list is also an answer. Two things can go wrong the moment a
row can be hidden:

1. **The filter edits the answer.** The natural implementation of "show only the
   matching rows" is to narrow the array the panel renders *and* the array it
   reads back — at which point typing `discord` and pressing Next files a project
   with one module instead of three. The bug is silent: every screen looks right.
2. **The filter lies about the answer.** Even a filter that only narrows the
   *render* leaves a switched-on module off screen. The owner sees one row, sees
   it unticked, and reasonably concludes nothing else is on. ADR 0237's standard
   for the preselect — "a preselect an owner cannot see the reason for is one
   they have to audit" — applies here in its harsher form: a preselect they
   cannot **see at all** is one they cannot audit.

## 2. Decision

**The search is a view. `state.modules` is the answer. The view may not write to
it.**

Concretely, in `modules/public-landing/public/projects.html`'s picker block:

- `moduleQuery` is a plain variable that holds what is typed. It is **not** part
  of the draft — `saveDraft()` is never called from the input handler — so a
  resumed draft never comes back mid-search, and a search can never be the thing
  that turns an untouched picker into an answered one (ADR 0240's `null`).
- `visibleModules()` derives, per render, the rows the current query leaves.
  `pickedModules()`, `modulesForCreate()` and `extrasRow()` are untouched and
  keep reading the whole catalog, so what rides the create request and what the
  review names are both independent of what is on screen.
- **The panel states the part the filter is hiding.** One line under the field:
  `Showing 1 of 3. 2 extras are switched on, including any this search is
  hiding.` It is silent with an empty query, and it counts what is *on*, not what
  is *visible* — which is the whole point of it existing.
- An empty query is not a search: every row shows, and the line goes quiet. So
  does a query of nothing but spaces.

## 3. What "matching" means, and what it deliberately does not

`moduleMatches(mod, terms)` is a pure function over one catalog row:

> lower-case the row's **label + summary + key** into one haystack; every
> whitespace-separated term must appear in it as a **substring**.

- **AND across terms.** An owner adding a word is saying the list is still too
  long; OR would grow it, which is the opposite of what they asked for.
- **Substring, not word-boundary.** A half-typed word must still find its module,
  because the field filters on every keystroke and a filter that shows nothing
  until you finish typing reads as a broken one.
- **The key is searchable even though it is never shown.** It costs nothing and
  it is what a returning owner (or a support answer, or our own docs) actually
  names a module by.
- **No ranking, no fuzziness, no synonyms.** The catalog is small enough that
  order is the catalog's order, and a rank that reorders toggles under a typing
  hand is a worse experience than a filter that does not.
- **Not semantic.** "Somewhere for people to chat" finds nothing, and that is the
  scope line: search by meaning is deferred to idea 1000552 with the rest of the
  AI layer for project creation. A lexical filter that admits it is lexical is
  honest; one that half-guesses is not.

> **AMENDED 2026-09-22 — "no synonyms" is reversed; "not semantic" stands**
> ([task 1003500](https://cloudbongos.com/builders#/task/1003500)). The haystack now also
> carries a row's declared `aliases` (`starter-bundles.js`), so typing **`chat`** finds
> Discord. Everything else here is unchanged: still AND across terms, still substring,
> still no ranking or fuzziness, and still nothing that understands a query.
>
> **What this does not fix, stated plainly because the example above invites the
> misreading.** The sentence "somewhere for people to chat" *still finds nothing*, and no
> alias list can change that: the matcher ANDs every whitespace-separated term, so
> `somewhere` and `people` must appear in the haystack too. Making a sentence work means
> OR-then-rank, which §3 and §5 reject on their own merits. Aliases raise the odds that an
> owner's **one word** lands on the right row; they do not teach the filter to read a
> phrase. `tests/projects_hub_module_picker.mjs` pins both halves — the word that now
> works, and the sentence that still does not — so this boundary is proven rather than
> promised.
>
> **Why this instead of the embeddings layer this section deferred to.** Task 1003500 was
> that layer, and it was declined on measurement rather than on principle. The catalog is
> 22 modules whose only free text is a title and one sentence — there is no `keywords` or
> `category` field in the manifest schema to embed. Against that, the semantic path costs a
> paid provider account, a key route, a `pgvector` migration and an index, on a project
> whose retrieval budget ([ADR 0060](0060-gds-retrieval-layer.md)) rules out exactly that
> kind of addition "unless lexical-in-Postgres demonstrably can't do the job". It was never
> shown that it can't: the go/no-go that was supposed to decide this (GDS-V4 R24, with
> pgvector as R32) was **abandoned in July 2026 by [ADR 0103](0103-gdsv4-bongos-consolidation.md)**
> and never run, so the "deferred" above had quietly been pointing at dead tasks.
>
> A declared word list is also the better artifact at this size: it is deterministic, it costs
> nothing to run, and when it gets something wrong the person who read the complaint can fix
> it in one line. `tests/provisioning_starter_bundles.mjs` requires at least three aliases per
> opt-in module and rejects one the row's own copy already contains, so the list cannot rot
> into decoration and a new opt-in module cannot ship unfindable.
>
> Aliases are **never rendered** — the same standing §3 already gives the key. The swap §4
> anticipated ("a future by-meaning search replaces `moduleMatches` and nothing else") is
> still available if the catalog ever outgrows this.

The whole matcher is a named function on the page precisely so the vm harness in
`tests/projects_hub_module_picker.mjs` can run it directly — the same reason
`bundleForAnswers` is a function and not an inline expression.

## 4. Consequences

- The picker scales past the point where the band is scannable, with no server
  work: the catalog already arrives whole in the one `GET
  /provisioning/starter-bundles` read (ADR 0237), so typing costs no round trip
  and adds no failure mode.
- BV1.R24's proof path — *create → bundle preselected → search + add → enabled* —
  works because a toggle made while filtered still re-derives the answer in
  **catalog order**, exactly as an unfiltered toggle does.
- When the catalog fails to load the field is hidden rather than disabled: a
  search box over a list that is not there can only disappoint.
- A future by-meaning search replaces `moduleMatches` and nothing else. The
  view/answer split is what makes that swap safe.

## 5. Alternatives considered

- **Filtering the array the panel reads back** (the "obvious" implementation) —
  rejected: it makes the search an editor of the answer, which is failure mode 1
  above, and it is silent.
- **Hiding matched-out rows with CSS instead of not rendering them** — same
  outcome for the owner, but it puts `aria-pressed` toggles in the accessibility
  tree that a sighted owner cannot see, and the empty-result case still needs its
  own line. Rendering fewer rows is the simpler truth.
- **Keeping switched-on rows pinned at the top regardless of the query** — it
  makes the count line unnecessary, but it means a search sometimes shows rows
  that do not match, which is a filter that lies in the other direction. The
  count says the same thing without breaking the band's one rule.
- **Persisting the query in the draft** — a search is a way of looking, not a
  decision. Restoring one on a resumed draft would hide most of the catalog from
  an owner who did not ask for that.
- **Debouncing the input** — the filter is a pass over three-to-a-few-dozen rows
  of already-loaded data. A delay would only make the field feel slower.
