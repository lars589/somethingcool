# 0287 — A backlog task that nothing gates promotes itself

**Status:** accepted · 2026-09-15 · [task 1003932](https://cloudbongos.com/builders#/task/1003932) (owner decision, same session)

## Context

Auto-promotion has been reactive-only since [migration 163](../../migrations/163_polymorphic_dependencies.sql). All three paths are `AFTER UPDATE` triggers that fire at the **dependency** end of an edge — a task ships, a criterion is satisfied, a goal is achieved — and then re-check `task_is_fully_unblocked` for that node's dependents.

Two states are unreachable by any of them, and neither is rare:

1. **No gating edge at all.** `createTask` inserts at `status='backlog'`. A task with no edges is nobody's dependent, so no trigger ever evaluates it.
2. **An edge added after the dependency shipped.** The ship event already happened; creating the edge later re-evaluates nothing.

Measured on the live database, 2026-09-15: **155 backlog tasks were promotable and parked** — 33 of 41 in goal 1000106 alone, the rest spread over ten other goals. 117 more were correctly waiting on unfinished work. The owner's framing was blunt: *"nothing should be owner held backlog, are things not auto promoting?"*

This is the same failure `runCriterionSweep` was built for on the criterion axis ([ADR 0183](0183-criteria-close-themselves.md)): a reactive rule cannot drain rows whose event has already passed, and nothing will ever fire for them again.

## Decision

**A backlog task with no unmet dependency and no open blocker becomes `ready` on its own**, via a `runPromotionSweep` on the publish-reconciler tick, beside the criterion sweep it copies.

The owner chose the widest rule: the sweep covers **spikes** (which migration 163 excluded on purpose) and the cascade's **artist-review** tasks (which `cascade.js` files at `backlog` deliberately). One rule, no carve-outs. Promoting only makes a task claimable; it compels nobody to take it, and `/builder-sequence` still halts on a `judgement_kind` spike.

**It ships disarmed.** The sweep reports what it would promote until `BONGOS_PROMOTION_SWEEP_ARMED=1`. The owner asked to see the list before ~155 rows change status at once, and a mass status change with no preview is exactly the kind of thing that is easy to do and tedious to unpick.

**The open-blocker guard lives in the sweep's own SQL**, not in `task_is_fully_unblocked`. [Migration 176](../../migrations/176_promotion_respects_open_blockers.sql) folded that clause into the predicate for V4.R15; [migration 178](../../migrations/178_reward_gate_auto_assign_revert_autopromote.sql) then replaced the body with one it described as "byte-identical to the 163 body" and dropped it. Production was verified during this task: the live predicate has no blocker clause, and one task already sits at `ready` carrying an open blocker. Restoring it is [task 1003934](https://cloudbongos.com/builders#/task/1003934). A sweep that promotes in bulk must not inherit a single point of failure that has already been reverted once, so it re-checks, and keeps re-checking even after 1003934 lands.

## Consequences

- **`backlog` stops being a resting state.** It becomes the brief gap between filing and being claimable. `/backlog-review` — "the state a human must say go on" — loses most of its purpose; it is not deleted here, but the next session to touch it should expect little left to walk.
- **The claimable feed grows by roughly 155 rows once armed**, across eleven goals. Nothing is force-assigned; the queue simply stops lying about what is available.
- **The `UPDATE` repeats the `WHERE`** rather than trusting the ids the `SELECT` returned, so a row that stops qualifying between the two statements is not promoted.
- **Idempotent**: it reads only `status='backlog'` rows, and an empty candidate set issues no write at all.
- Rejected — **promoting at creation time** (`createTask` inserting `ready` when a task has no edges): it would break `cascade.js`'s tested invariant that a cascade-filed review lands at `backlog`, and it fixes nothing already parked. A sweep handles both the backlog drain and the self-heal, which is why the criterion axis chose one too.
- Rejected — **scoping the first run to one goal**: it proves the mechanism on 37 rows while leaving the same defect live in ten other goals, and needs a second task to finish.
