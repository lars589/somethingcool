# ADR 0183 — A done-when criterion closes itself; the review queue becomes a place to look

- **Status:** superseded in part by [ADR 0351](0351-a-criterion-closes-on-a-uat.md) (2026-09-29): shipped linked tasks are now only the first of three checks, and a criterion closes on a UAT sign-off. The delivery guard below is kept.
- **Date:** 2026-08-21
- **Task:** 1002069 (owner request 2026-07-05, scope owner-confirmed)
- **Supersedes part of:** [ADR 0086](0086-goal-scoped-work-hierarchy.md) §6 / BV1.R63 — the criterion auto-flag stays, but confirming it is no longer the only way a criterion closes.

## Context

Under ADR 0086 §6 a criterion became `satisfied` in exactly one way: a Metic+ called `POST /done-when/:id/satisfy`, and if it was the goal's last criterion the goal flipped `open→achieved`. The "met — pending review" flag was **derived** — every gating task shipped, nothing stored — and `/goal-review` walked that queue so a human could confirm each one.

That gate cost more than it bought. The signal it gated on is already unambiguous: *every task under this criterion has shipped.* A human confirming that adds no information, and when nobody runs `/goal-review` the consequence is not "a careful pause" but a **lying board** — criteria sitting unsatisfied and goals sitting `open` long after the work landed. The owner asked for the flip to be automatic (2026-07-05).

This session supplied the evidence for how bad the drift gets: goal 1000072 read `6/9 shipped, 0/5 criteria` — six tasks landed, not one criterion moved.

## Decision

**A criterion satisfies itself once its gating set is fully delivered, and a goal achieves itself once all its criteria are satisfied.** One helper, `doneWhen.autoSatisfyShippedCriteria(exec, { taskId })`, run from two places:

| Where | Scope | Why both |
|---|---|---|
| `shipTask`, inside its transaction | `{ taskId }` — only what this ship gates | Immediate. A builder shipping a goal's last task sees the goal close *now*. On the txn client, so a rolled-back ship cannot leave a goal achieved. |
| `publish-reconciler` tick, every ~5 min | `{}` — every unsatisfied criterion | **Backlog drain** (criteria whose tasks shipped before this existed — nothing will ship against them again) and **self-heal** (a criterion linked after its tasks shipped, a hand-edited status, a ship whose best-effort in-txn close was skipped). |

`exec` is caller-supplied on purpose; the helper never reaches for a module pool. It is idempotent — it only reads `satisfied = false` rows — which is what makes an every-tick sweep safe.

`/goal-review` is **not** deleted. It stops being a gate and becomes a place to look: what closed, and the ambiguous cases automation deliberately refuses (below).

### The delivery guard, and a deliberate asymmetry

Auto-close requires **both**:

1. no linked task outside `{shipped, abandoned}` — nothing is still pending; and
2. **at least one linked task actually `shipped`** — something was delivered.

The second is not redundant, and it is the whole reason this ADR exists rather than a one-line commit. Since [task 1002651](https://cloudbongos.com/builders#/task/1002651) made `abandoned` terminal-not-pending, a criterion whose linked tasks were **all cut** satisfies condition 1 *vacuously* — every task is accounted for, none is pending. Automating on condition 1 alone would satisfy criteria on **zero delivered work** and cascade their goals to `achieved`. Measured, not hypothetical: `buildCriterionProgress` returns `pending_review: true` for exactly that shape today.

**But `pending_review` keeps that wider meaning.** It answers "should a human look at this?", and task 1002651 chose on purpose that an all-abandoned criterion surfaces there — its work was cut, so someone must decide whether the criterion still means anything. Auto-close answers the narrower "may this close itself, unattended?"

> Everything that auto-closes was flagged for review. Not everything flagged for review auto-closes.

An earlier draft of this task "aligned" the two predicates and broke 1002651's intent; `tests/criterion_progress.mjs` caught it. **Do not re-align them.** The gap is the design.

## Consequences

- **Criteria and goals stop lying by default.** No cadence discipline required.
- **`/goal-review` keeps a real job** — the all-abandoned case, and any criterion a human wants to reject.
- **The manual `POST /satisfy` route is untouched**, still Metic+. It remains the way to close a criterion that automation cannot judge (e.g. one with no linked tasks at all — automation requires ≥1, so a task-less criterion never auto-closes).
- **A close is only as good as its task links.** Auto-satisfy cannot help a criterion nothing is linked to; goal 1000072's five criteria have zero linked tasks and will stay `0/5` until they are linked. Automating the flip makes that gap *more* visible, not less — which is the point.
- **`achieveGoalIfComplete` (db.js) now has a sibling** that re-implements its rules in SQL on a caller's `exec`, because it reads through the module pool and could not see an uncommitted in-txn flip. The duplication is deliberate and noted at both sites; collapsing it would mean either a require cycle (`done-when` ↔ `db`) or moving goal reads out of `db.js`.
- **Observability:** the in-txn close logs from `closeCompletedWorkForShip`, which means it prints *before* commit — the one wart, accepted and documented there, because threading the summary back out through `withTx` would have cost ~5 lines in the over-threshold `db.js` (shrink-only ratchet policy).

## Alternatives rejected

- **Sweep only, no ship hook.** Simpler, but a builder who ships a goal's last task would wait up to 5 minutes to see it close — losing the moment that makes the board feel alive.
- **Ship hook only, no sweep.** Leaves every pre-existing completed criterion unsatisfied forever, since nothing will ship against them again.
- **A stored `pending_review` column.** ADR 0086 §6 deliberately derives the flag; storing it adds a second source of truth to keep in sync.
- **Deleting `/goal-review`.** It still has the all-abandoned case and rejection to handle.
