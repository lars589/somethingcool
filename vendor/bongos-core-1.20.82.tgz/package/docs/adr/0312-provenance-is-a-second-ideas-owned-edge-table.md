# ADR 0312 — Provenance is a second ideas-owned edge table, written by the seams that already know

**Status:** accepted · **Date:** 2026-09-19 · **Task:** [task 1004080](https://cloudbongos.com/builders#/task/1004080) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0311](0311-an-idea-is-a-permanent-origin-tag.md) (the origin tag this records the descent of) · [ADR 0236](0236-many-ideas-one-task-the-lineage-key-is-the-pair.md) (made co-source ideas real, which is why the edge cannot live on the lineage row) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) §Decision 5 (a module migration may only touch its own namespace) · [ADR 0054](0054-session-token-reward-cost-plus.md) (the credit the payout rides on) · [ADR 0015](0015-task-dependencies-and-auto-promotion.md)

## Context

A descent — `idea → task → rewrite → split → removal` — is four levels deep and crosses a version boundary. The obvious place to put it is the task hierarchy, and that place is closed.

`modules/lifecycle/hierarchy.js` `attachParent` enforces four invariants, verified by reading the code rather than the comment:

| Invariant | Error code |
|---|---|
| `target !== parent` | `SELF_PARENT` |
| `target.version_id === parent.version_id` | `VERSION_MISMATCH` |
| `parent.parent_task_id IS NULL` (depth cap, side 1) | `PARENT_HAS_PARENT` |
| target has no children (depth cap, side 2) | `TARGET_HAS_CHILDREN` |

All four are deliberate; ship rollup and claim safety lean on them, and spec decision 8 puts widening them out of scope. So provenance needs its own relation.

**The spike was told to confirm `ideas_task_lineage` rather than assume it. Confirmed for one half, and refuted for the other.**

## Decision

**Two tables, not one.** `ideas_task_lineage` stays exactly as it is and anchors depth 0. A new ideas-owned table records task→task edges.

### Why the edge cannot go on `ideas_task_lineage`

The table is bipartite (ideas × tasks) with `PRIMARY KEY (task_id, idea_id)` since `ideas_006`. It carries none of the hierarchy's invariants — no depth cap, no version predicate, no self-reference hazard — so as the **idea→task anchor** it is right, and that half of the assumption holds.

But a derivation is a property of the **task pair**, not of the (task, idea) pair. Adding `derived_from_task_id` to the lineage row would write the same derivation once per co-source idea, and `ideas_006` made co-source ideas both legal and expected (merging duplicate reports into one task is the triage move the inbox is built to encourage). Two rows for one task could then disagree about where that task came from, with nothing to arbitrate. That is not a hypothetical: `ideas_006` exists precisely because an under-keyed row silently lost attribution on prod, and it took months to notice.

A merge also gives a task **several** parents, so the relation is a DAG, not a tree — a single nullable column could not express it regardless.

### The edge table

`ideas_task_descent`, in the `ideas_` namespace (ADR 0083 §5 — `tasks` belongs to the protected `lifecycle` module and may not be altered from here; a FK to it is a read, the `ideas_002` precedent).

- `task_id` → the derived task, `parent_task_id` → what it came from, both FK to `tasks`.
- `relation` — a CHECK'd vocabulary: `rewrite`, `split`, `merge`, `fold`, `cascade`. Extended the `ideas_003` way (drop and re-add the same-named constraint, which `isConstraintWidening` exempts), with that migration's safety net proving the widening took.
- `PRIMARY KEY (task_id, parent_task_id)` — a task may have several parents; one pair is recorded once.
- Indexed both directions: descent walks down from a parent, payout walks up from a ship.

**No depth cap and no version predicate** — that is the entire point, and it is what the hierarchy could not give.

**Cycles must be refused at write time.** The payout walks this graph, so a cycle is a non-terminating walk, not a cosmetic error. A self-edge is refused by CHECK; a longer cycle is refused by the writer, which walks to the root before inserting. The walk is also depth-bounded when read, so a cycle that somehow lands cannot hang a page.

### Who writes the edge

The task set the real question: parentage today is a manual act, so an edge that depends on someone remembering will have holes. It does not have to. **Three seams already know a task was derived, and none of them is currently telling anyone:**

| Seam | What it already records | What it becomes |
|---|---|---|
| `modules/lifecycle/cascade.js` | `source_ref: cascade-<key>-<id>` — the originating task id, **encoded in a string** | `relation='cascade'`, written at creation |
| `tasks.merged_into_task_id` | supersede/fold provenance, CHECK'd to `abandoned` rows (`core_232`) | `relation='fold'` — the mockup's "satellite" |
| `tasks.parent_task_id` | the one-level split | `relation='split'` |

The cascade case is the telling one. The derivation is *already there* and already correct — it is simply stored as text inside `source_ref`, where nothing can join on it. Promoting it to an edge is not new bookkeeping, it is writing down a fact the system already computes.

That leaves `rewrite` and cross-version `merge` as genuinely manual, which is honest: those are editorial acts with no automatic signal behind them. They get an explicit write, and their absence degrades the picture rather than corrupting it.

## Consequences

**What this fixes.** `sourceIdeaForTask` (`inbox.js:870`) and `awardIdeaTaskShipCredit` (`credits.js:540`) both read `ideas_task_lineage` with `ORDER BY created_at, idea_id LIMIT 1` — a **direct, one-hop point read**. A derived task has no lineage row of its own, so today it resolves to `no_source_idea` and the origin idea is not paid at all. The descent walk is what closes that, and spec decision 6's depth decay is what keeps it from paying unboundedly.

**Two relations over the same pair of tasks now exist** — `parent_task_id` (work decomposition, capped, same-version) and this one (provenance, unbounded, cross-version). They are not redundant and must not be merged: the first answers "what is this work part of", the second "where did this work come from". The split edge is written to both, which is the only overlap.

**The display is wider than the count.** Per spec decision 7 the descent *shows* more than size *counts* — a separate thought citing an origin appears in the picture and pays nothing. The edge table carries both; the payout walk filters. Conflating them would let early filers farm the project.

**A backfill is possible and partial.** Every existing cascade task can be recovered by parsing `source_ref`, and every `merged_into_task_id` is already an edge. Historical rewrites are unrecoverable, which is consistent with spec decision 17: pre-existing ideas get lineage backfilled but not payouts, and the number must be marked as historical rather than quietly presented as a sum of payouts made.

## Alternatives rejected

- **Widen the task hierarchy.** Out of scope by spec decision 8, and the invariants are load-bearing for ship rollup and claim safety.
- **`derived_from_task_id` on `ideas_task_lineage`.** Duplicates the derivation per co-source idea and cannot express a merge. The reason it looks attractive — "extend, don't add" — is real, and the extension is of the lineage *ledger*, which is now two tables.
- **A column on `tasks`.** Forbidden from a module migration (ADR 0083 §5); `tasks` is the protected `lifecycle` module.
- **Derive the descent at read time from `source_ref` strings.** It covers only the cascade case, cannot express rewrite or merge, and makes a string format load-bearing for money.
