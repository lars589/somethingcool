# ADR 0339 — A project's owner upgrades it, and a hosted project hands off to the hub's door

- **Status:** Accepted
- **Date:** 2026-09-26
- **Task:** [task 1004174](https://cloudbongos.com/builders#/task/1004174) (goal 1000090 — BONGOS-V2)
- **Deciders:** the owner, Lars. On 2026-09-22 he said "every project has the option to upgrade its version of bongos including bongos itself", and that the control belongs in that project's own hall. On 2026-09-26 he ruled that **only a project's owner upgrades it**, adding that for him "owners and archons are the same", because he owns the platform.
- **Amends:** [ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md) D5 ("Archon-gated server-side"). The deploy door gains a second audience, as stated below. D1 (the web tier only asks, the control plane acts), D3, D4 and D6 are unchanged.
- **Amended by:** [ADR 0340](0340-every-hall-takes-its-update-from-settings-and-deploy-is-the-platform-halls-page.md) (task 1004296) — D3's hand-off moves from the banner and the rail to Settings → Software update's Update button, and `GET /core-update` no longer answers `deploy_url`.
- **Related:** [ADR 0328](0328-a-hosted-projects-authority-is-its-membership-row-not-its-owner-column.md) (the owner-OR-operator gate shape this reuses), [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) (the `alsoAdmits` page-gate door this reuses), [ADR 0246](0246-catalog-membership-is-a-projection-not-a-federation-side-effect.md) (a hosted project's hub client id is its slug), [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) / 0111 §2 (the web tier gains no capability)

## Context

The deploy door is `POST` and `GET /provisioning/instances/:id/core-upgrade` on the control plane, fronted by the hub's `/deploy` page. It was gated on `core.pin.move` alone. That atom has an archon floor and `system:true`: the catalog forbids granting it to metic, and no custom rank can hold it.

That produced two dead ends.

1. **The owner of a hosted project below Archon could see they were behind and could never act on it.** On a hosted project the banner (task 1004045) prints "Core X is available" with no action, because that project does not run the provisioning module. The door lives on the hub, and on the hub the owner (erikwils is Xenos; willHermesLines is Metic) is refused by the atom.
2. **A hosted project's own hall had a "Deploy" link that opened a page with nothing behind it.** The page's calls are provisioning routes, and a tenant has none.

Task 1004174's own text settled where the act must happen. It stays on the control plane, because ADR 0293 D1 and ADR 0043 both turn on the web tier never gaining a shell. The hosted project hands off rather than acting.

## Decision

### D1 — The owner of a hosted project may move that project's core, from the hub

The two per-project routes (the preview `GET` and the move `POST`) are gated by an OR, implemented in `modules/provisioning/core-upgrade-authz.js`:

1. **Ownership is asked first.** The caller is admitted if the row's `owner_builder_id` is the caller and the row is a tenant shape (`co-tenant` or `cloud-host`).
2. **Every other caller meets the unmodified `requirePermission('core.pin.move')`** and its unchanged refusal. That includes callers who are not the owner, a missing row, an unparseable id, and a database error during the ownership read.

This is the shape ADR 0328 Decision 2 and ADR 0210's `requireScoutingReader` already use. The atom is still spelled in each route's middleware list, where `route-rank-check.js` and `gen-api-docs.js` read it. The consequences:

- A non-owner below Archon gets exactly the 403 they always got, and learns nothing about whether the id exists.
- The Archon path is untouched.
- The widening can only admit.

### D2 — The platform's own row stays on the atom

`OWNER_SHAPES` excludes `control-plane`. Moving the platform changes the code that drives every hosted project, so only a holder of `core.pin.move` may do it. `GET /provisioning/control-plane` keeps the atom alone.

For Lars this is no restriction: he is both the platform's owner and an Archon, which is his ruling that the two are the same.

### D3 — A hosted project hands its owner to the hub, and gains nothing

`GET /api/bongos/core-update` (core) now also answers `deploy_url`: `<hub origin>/deploy?project=<slug>`.

- It is built from the two values provisioning already writes into a federated project's `web.env`: the hub origin and the hub client id, which is the slug (ADR 0246).
- It is null on an instance with no hub, such as a self-hosted instance or the hub itself.
- The client secret is never read for it.

The hall uses that address in two places, and only where it has no door of its own (the provisioning module is off):

- **The banner's "Upgrade" links there.**
- **The rail's "Deploy" item** is dropped where the provisioning module is off, and re-pointed at that address once it is known.

The hub's `/deploy?project=<slug>` page (task 1004171) was built as exactly this seam.

The hub's `/deploy` page shell is gated by `requireCorePinPage`. It now declares `alsoAdmits: 'isProjectOwner'`, the door `/people` uses: it admits the shell for an owner of any live project. Which project the owner may read or move is still the routes' decision, made per request against that project's row.

### D4 — The actor says which door was used, and still names the builder

An owner's move is recorded as `api:owner:<id>`, and an Archon's as `api:archon:<id>`. The runner's `requestedByOf` accepts both and passes the id through as `--requested-by`, so the `core_upgrades` ledger attributes the move either way (ADR 0293 D5).

## Rejected

- **A tenant-side API that authenticates back to the control plane and performs the upgrade.** It is rejected in writing, as the task asked. It would be a new cross-instance authentication surface on the most privileged action in the system, and it would give a tenant's web process a path to the act ADR 0293 D1 keeps on the control plane. The hand-off costs one navigation and adds no new capability anywhere.
- **Granting `core.pin.move` to owners.** The atom is `system:true` precisely so it cannot be handed down, and "may move core pins" is not "may move this one project's pin". Ownership is a separate axis, as ADR 0151 §3 keeps it.
- **Letting an owner move the platform row.** The platform row is not the owner's project in the sense the ruling means. Its only owner is the Archon who holds the atom anyway.
- **Asking the platform-identity membership ledger instead of `owner_builder_id`.** ADR 0328 Phase 2 (task 1004161) will widen project authority to members through that port. The ruling here is "owner", which the row already records, so this ADR takes the column and leaves the widening to that task.

## Consequences

- **erikwils (hoodify-finance) and willHermesLines (mercury) can upgrade their own projects.** They open `https://cloudbongos.com/deploy?project=<slug>` on the hub. The hub half works as soon as the platform runs a core carrying this ADR. The in-hall link reaches a hosted project only once that project runs such a core, because the banner ships inside the core. Until then the owner reaches the door by its address.
- **An owner's upgrade restarts their own site.** The runner's health gate and auto-rollback apply unchanged.
- **ADR 0328 Phase 1 must absorb this gate, not route around it.** When task 1004159 lands `requireProjectOwner` for the `/provisioning/instances/:id...` routes, the two core-upgrade routes should move onto it with the atom as their override. That keeps the same owner-OR-atom answer, and the platform row stays atom-only. Until then `requireOwnProjectOrPin` is the only owner gate on them. Task 1004160's `project_scope_missing` check lists `/provisioning/instances/:id` as a prefix, so it would flag these two routes. That is correct: it is the reminder to fold them in, not a sign that they are unguarded.
- **The page shell admits any live project owner.** An owner without the atom who opens `/deploy` without `?project=` sees the sealed state, because `/provisioning/control-plane` refuses them. The page is a shell, and every datum behind it is gated per request.
- **Proof:** `tests/core_upgrade_owner_door.mjs` covers each case:
  - the owner below Archon, admitted;
  - the Archon on another's project, admitted by the atom;
  - the non-owner below Archon, refused byte-for-byte as before, whether the id exists or not;
  - the platform row, owner or not, refused without the atom;
  - a failing ownership read, which falls to the atom;
  - the actor labels, and the runner's attribution parse;
  - the page shell admitting an owner and still refusing a stranger;
  - the `deploy_url`, and the hall's banner and rail on a hosted project and on the platform.
