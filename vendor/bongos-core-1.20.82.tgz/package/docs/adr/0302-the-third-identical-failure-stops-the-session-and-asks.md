# ADR 0302 — The third identical failure stops the session and asks

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003990](https://cloudbongos.com/builders#/task/1003990) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0301](0301-a-red-pr-names-its-failing-tests-in-a-commit-status.md) (a red PR names its failing tests) · [ADR 0291](0291-the-accessibility-dimension-scores-the-transcript-not-the-diff.md) (accessibility is scored after the ship) · [ADR 0162](0162-review-gates-retired-rank-consistent-ci-only.md) (review gates retired: no human approval in the land path) · [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (cooperative, fail-open hook layer)

## Context

The 2026-09-17 investigation of a non-technical builder's stalls found sessions that looped
without noticing: one pull request re-shipped into the same red check **nine times in four
hours**, and **45 of 169 claim attempts** in 4.5 days were refusals — the same task id retried
minutes apart. Each retry costs money the builder watches tick up, and they have no way to tell
that the agent is going round in a circle (idea 1000281).

Abandoned task 1002828 asked for a written bail-out rule. A rule in a memory file loses to the
next retry for the same reason the `git stash` ban did: the agent is not looking at it at the
moment it matters. Nothing else watches a session mid-flight — the accessibility score is
computed after the ship.

## Decision

1. **Count walls, per session, in a hook.** `.claude/hooks/stuck-detector.js` runs after every
   shell tool call (`PostToolUse` and `PostToolUseFailure`, `Bash|PowerShell`). On the **third**
   identical wall — and each one after — it injects one instruction: stop retrying, diagnose
   (the path is named), or run `/ask-for-help`.
2. **The failure signature is the `[otb-plain]` card** (task 1003989). Every failure a builder
   can be parked behind already prints one; its "What happened" line is static per failure code,
   and its "By design" line already says whether a retry can ever help, which picks the
   instruction's wording. Signature = that line + the task id in the command + the
   `the PR is RED` line when present, so a red check that names *different* failing tests each
   run reads as progress, not a wall. Only a builder CLI **run** (`node …scripts/gds/*.js`,
   `bongos <verb>`) is read: `cat` or `git diff` over a file that quotes a card prints the
   same text and is not a failure.
3. **A waiting card is not a wall.** Cards whose next step is "Nothing to do…" (`land_pending`,
   a pending check, a pending join request) tell the session to poll; counting them would turn
   the detector against the behaviour the card asks for. The set is pinned by test.
4. **The guards count through the same helper.** `git-guard.js` and `worktree-guard.js` call
   `stuck-strikes.js` when they block — keyed on the rule, and on the file, respectively — and
   append the instruction to the reason they already return. Three *different* wrong-tree files,
   each corrected on the next call, is the guard working and is not counted.
5. **It never blocks, and it echoes nothing.** `additionalContext` only, exit 0, silent without
   a card. Signatures are hashed before they touch `os.tmpdir()`; the instruction interpolates a
   count and a digits-only task id, never text a tool printed.

## Alternatives rejected

- **Count any repeated failing command.** Red → green on a test *is* the same command failing
  repeatedly; the detector would fire on ordinary work and become wallpaper.
- **Block the fourth attempt.** That is a new gate on the ship path with no escape hatch the
  stuck session can use (the admissibility test ADR 0241 draws from ADR 0162), and a wrong
  signature match would strand a builder behind the tool meant to unstick them.
- **Server-side detection.** The server sees refused claims but not guard blocks or local red
  runs, and cannot speak into the session at the moment of the retry.
- **Require `scripts/gds/plain-cards.js` from the hook.** Hooks are instance topology and the
  script may live in the installed package; reading the printed card keeps the hook
  dependency-free. The cost is a text coupling to the card's layout, pinned by test.

## Consequences

- Whether a non-zero exit routes to `PostToolUse` or `PostToolUseFailure` is the harness's
  business; the hook is wired on both and reads the output from any of the four fields either
  event has used. Only one event fires per call, so nothing is counted twice.
- The count is per session and lives in the OS temp dir as an **append-only** log of hashed
  signatures — tool calls run in parallel and three hooks share the file, so a
  read-modify-write would let one process wipe another's counts. A builder who opens a fresh
  session after being told to stop starts from zero — acceptable: the instruction's job is to
  break the loop inside one context, and the refusal itself still stands.
- Strikes do not decay inside a session: two hits, real progress, then a third hit hours later
  still draws the instruction. It costs one paragraph the agent can weigh, and a time window
  short enough to matter would have missed PR 922's runs, which were ~27 minutes apart.
- A box that cannot read which test failed gets a RED line with no names, so three red runs
  share a signature whatever their causes. That is the PR 922 case the detector exists for;
  the instruction says to run the suite locally when the status names nothing.
- A failure with no plain card is invisible to the detector. `tests/plain_cards.mjs` already
  reds when a CLI gains a failure code without one, so the two stay in step.
