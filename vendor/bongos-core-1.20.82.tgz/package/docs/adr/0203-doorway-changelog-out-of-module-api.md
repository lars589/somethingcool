# 0203 — The doorway changelog leaves `src/module-api.js`: the CI carrier appends to markdown

- **Status:** Accepted
- **Date:** 2026-08-28
- **Deciders:** the owner (Archon) — decision made directly on the incident: move the changelog out permanently and repoint the carrier; explicitly rejected trimming entries in place and raising the fitness baseline. Claude implemented.
- **Task:** task 1003335
- **Amends:** [ADR 0161](0161-publish-on-merge.md) §2 (the CI auto-patch carrier's write target)
- **Interacts with:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the doorway + `CORE_VERSION`), the `oversized_file_count` ratchet in `scripts/gds/fitness-ratchets.js` (task 1003129)

## Context

`CORE_VERSION` is the semver of the published module doorway `src/module-api.js`. Its release history lived in the same file, as a comment block between two `// ---` dividers directly above the literal — deliberately, so a bare version bump with no changelog line was impossible.

ADR 0161 then made **every merge to `main` publish**, and gave CI a carrier: when a merge lands with no human bump, `scripts/gds/bump-version.js` bumps the patch and appends a **two-line changelog entry**. That carrier commit is pushed by `github-actions[bot]` **straight to `main`** — it has to be, since the bump must precede the package step, and the default `GITHUB_TOKEN` cannot push past the required check. So the one writer that grows this file fastest is also the one writer that **does not pass through the `unit` gate**.

Two lines per release, one release per merge. On 2026-08-28 release **1.19.407** took `src/module-api.js` to **1501 lines** — one over the 1500-line `oversized_file_count` threshold. The consequences were structural, not cosmetic:

- `unit` went **red on `main`** (commit `4f99fa10`): `oversized_file_count regressed: 1 > baseline 0`, `excess_lines_total regressed: 2 > baseline 0`.
- Every **open PR inherited the red**, because `unit` builds the branch against current `main`. Four agents' work was parked behind it at once.
- The condition was **self-inflicting and monotonic**: each further release added two more lines, and the carrier could not be stopped by the very check it broke.

Of the file's 1501 lines, **1222 were changelog** — 448 released versions, the overwhelming majority of them one-per-merge carrier entries. The doorway's actual published surface is under 300 lines.

## Decision

**The release ledger moves out of `src/module-api.js` permanently, into markdown, and the carrier is repointed to write there.**

1. **New home: [`docs/module-api-changelog.md`](../module-api-changelog.md).** Markdown, not JavaScript. This is the load-bearing property, not a filing preference: `scripts/gds/fitness-ratchets.js` sizes `git ls-files '*.js'`, so a markdown ledger is **structurally exempt** from the line budget and can grow forever. Relocating to another `.js` file would only move the same time-bomb.
2. **The literal does not move.** `const CORE_VERSION` stays in `src/module-api.js` and stays the single source every reader parses. `deploy-divergence.js`, `package-core.js`, `publish.yml`, `module.js`, `init.js` and `provision-*.js` all read it exactly as before — the `^const CORE_VERSION = 'x.y.z';` line shape is unchanged, only its trailing comment now names the ledger's path.
3. **The history is preserved verbatim.** All 1222 lines / 448 versions moved byte-for-byte; only the `// ` comment marker that made each line a JS comment was stripped. The ledger sits in a fenced `text` block so the original hanging indentation survives markdown rendering intact. This is a release ledger, not scratch — nothing was summarised, trimmed, or reflowed.
4. **The insertion contract is unchanged.** Entries stay **oldest-first**, and the carrier inserts each new one **immediately above the divider that closes the ledger** — the same 75-dash divider, minus the `// `. `bump-version.js` throws rather than guess if that divider is missing, exactly as it did before.
5. **The carrier writes both files atomically-in-intent.** `bump-version.js --apply` reads *and transforms* both files before writing *either*, and refuses outright if the ledger transform did not happen. `publish.yml` stages both (`git add src/module-api.js docs/module-api-changelog.md`); `tests/bump_version.mjs` pins that staging list against the script so the two cannot drift.
6. **`src/module-api.js` keeps a pointer.** A short doc-comment where the block used to be says where the ledger went and why (ADR 0095 / `docs/code-conventions.md`) — someone will look for the history in the old place, and grep must answer them.
7. **The ledger still ships in the package.** `docs/` is default-deny in `PUBLISH_ALLOWLIST`, so the new file is registered explicitly. Without that line the history would silently stop reaching instances that install `@bongos/core` — today it reaches them inside `module-api.js`, and a module author checking what a `coreVersion` floor buys them is a real reader.
8. **The published copy is now genericized, and that is an improvement.** `package-core.js` treats a `.md` as a DOC: it runs mirror-redaction and any residual leak is fatal, where a `.js` shipped verbatim with brand strings as non-fatal advisories. So the ledger's historical mentions of the reference instance's brand and domains are rewritten to the neutral placeholders in the published core — which is what every other published doc already gets, and what a brand-neutral open-source core should carry. Verified by building the package: the no-leak gate passes and all 1255 lines ship.

### Rejected

- **Trim old entries in place.** Buys exactly one release, then the file crosses 1500 again. It also destroys ledger history to satisfy a size metric — the wrong thing to spend.
- **Raise the `oversized_file_count` baseline.** Out of policy: `config/fitness-baselines.json` says so in its own `_comment` ("Shrink-only — lower a value when the metric improves; raising one to pass CI is out of policy"), and the ratchet's whole purpose is that growth is not negotiable.
- **Exempt `src/module-api.js` from the ratchet.** Same objection, narrower blast radius: it would let the real doorway surface grow unwatched behind a changelog-shaped excuse.
- **Stop writing a changelog entry per release.** The entry is the provenance ADR 0161 §2 relies on and that `laneReleasedVersions()` reads release history from. The volume is a symptom of publish-on-merge working as designed, not a defect.

## Consequences

- `oversized_file_count` and `excess_lines_total` return to **0**; `src/module-api.js` drops from 1501 to **289** lines, leaving the doorway's real surface visible instead of buried under its own history.
- The failure mode is **eliminated, not deferred**. The ledger's growth rate is unchanged, but it no longer has a ceiling that a gate reads.
- **A version's history is one hop away** rather than inline. Mitigated by the pointer comment, the const line's trailing path, and the ledger's own header.
- **Two files now move per release** instead of one. The carrier commit's diff is slightly wider; the staging list is test-pinned so it cannot silently regress to one.
- ADR 0161 §2's sentence "bumps the patch and writes the changelog line" remains true — only the file it writes to changed. ADRs 0137 / 0161 / 0194 are historical records and were left as written; the operational instructions in `docs/recipes/core-release-pipeline.md` and `docs/recipes/private-npm-distribution.md` were repointed.

## When to revisit

If the ledger ever needs to be *queried* (release notes for a version range, a "what changed between my pin and latest" CLI), the fenced-text form is the wrong shape and it should become structured data (`docs/module-api-changelog.json` + a renderer). Nothing reads it programmatically today, so that stays YAGNI.
