# ADR 0248 — A hub project's owner is the provisioning row, carried on a port and bound to both halves of the catalog projection

- **Status:** accepted
- **Date:** 2026-09-04
- **Task:** [task 1003580](https://cloudbongos.com/builders#/task/1003580) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-invite-builders` / C6), GAP 2
- **Deciders:** Claude, under the Archon's standing scope
- **Implements:** [ADR 0246](0246-catalog-membership-is-a-projection-not-a-federation-side-effect.md)'s named remainder — *"what remains there is purely the ownership branch… the ownership proof it should carry is `provisioning_instances.owner_builder_id`"*
- **Related:** [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) (owner-or-rank as one middleware; the atom stays spelled in the route's own list) · [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) (the hub's `owner_github_id` columns are attribution, never authority) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way module rule — why this travels on a port) · [ADR 0182](0182-project-visibility-two-axes.md) D2a (a stealth project is anonymous, so a refusal may not identify it) · [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (fail-closed authority)

---

## Context

`POST /projects/invite` is gated `requirePermission('project.curate')`, floor `metic`
([ADR 0157](0157-archon-is-rank-and-identity-only.md)). It is a **curation** gate:
`requirePermission` is purely grant/rank-based and has no own-scope branch. The creation
wizard's audience is any signed-in GitHub user — on the hub, typically a `xenos` holding
nothing at all. So the person who created a project got **403 on inviting anyone into their
own project**, and BV1.R27 ([task 1002346](https://cloudbongos.com/builders#/task/1002346)),
R28, R29 and the C6 proof all sat behind it.

ADR 0246 closed the other half (the project is now a resolvable catalog row) and named this
one as its own decision, with the constraint it has to answer to: **ADR 0238 says the hub's
ownership columns are attribution, not authority.** Lowering `project.curate`'s floor is not
available either — the same reason ADR 0210 gives: a floor is a rank, ownership is a
relationship, and no floor low enough to reach a project's registrant excludes anybody.

## Decision

**Admit a `project.curate` holder OR the project's own owner, where "owner" means
`provisioning_instances.owner_builder_id` — asked of provisioning through a kernel port, and
bound to BOTH halves of the ADR 0246 projection.** Three parts:

1. **The proof is the provisioning row.** That column is the authority `instanceAccessDenied`
   already enforces on every owner-facing provisioning route (the manage page, both settings
   routes, the detail answers). The hub's `sso_clients.owner_github_id` and
   `platform_identity_projects.owner_github_id` stay what their migration comment and ADR 0238
   say they are: attribution. Nothing here promotes them.

2. **It travels on a NEW port, in the direction ADR 0246 did not open.** `project.catalog`
   carries a write hub-ward (provisioning → platform-identity); this question runs the other
   way, so provisioning provides **`provisioning.projectOwnedBy` ({ slug, host, builderId }) →
   boolean**, registered beside `provisioning.instanceState`. platform-identity resolves it
   with `resolveOptional` and does **not** declare it in `consumes` (the
   `provisioning.projectPlanets` precedent): provisioning is `default: false`, and a hub
   without it simply has no control-plane project to own. **A boolean, not the owner's id** —
   the comparison is authority and belongs on the plane holding the row, so no consumer ever
   handles an ownership fact it could mis-compare.

3. **The question names both halves of the projection.** ADR 0246 puts a project on the map as
   `client_id = slug` at `origin = https://<domain>`, and the port answers only when the
   caller owns the instance carrying **both**, in one statement. Matching the slug alone would
   let whoever registers an instance *named after* a client the control plane never created —
   a hand-seeded row, whose origin the catalog's own claim rule (ADR 0246 rule 1) already
   refuses to overwrite — speak for that project. The invite arm answers to the same binding
   the catalog write does.

### The OR is one middleware, and the atom stays spelled in the route

`modules/platform-identity/invite-authz.js` is `scouting-authz.js`'s shape, and it is that
shape for ADR 0210's reasons, restated because they are load-bearing rather than stylistic:

- **`requirePermission('project.curate')` is built in the route's own middleware list** and
  handed to the helper. A gate hidden inside a helper is invisible to `route-rank-check.js`
  and `gen-api-docs.js`, which classify a route from its middleware — this route would have
  been recorded `any-builder`, wrong in the dangerous direction, and the published API
  reference would have said so. It still classifies `metic+archon` with
  `x-permissions: ["project.curate"]`; the "or owner" lives in the description, which is the
  same over-strict-but-safe answer ADR 0210 accepted.
- **Ownership is asked FIRST, and a refusal falls through to the UNMODIFIED gate.** Asking the
  permission gate first is not available: a middleware that has denied has already *sent* its
  response, so there is nothing to fall through from. Paying one extra lookup on the curator
  path is what makes the 403 byte-identical — same code, same `required`/`held`, same floors
  map. **The widening can only ever ADMIT; it cannot change, soften, or swallow a refusal.**

### The refusal is not an existence oracle — in body OR in latency

This is why the gate runs **before** the target is resolved rather than after. Resolving first
and then authorizing would split the answer into 404-for-absent and 403-for-present, handing
any signed-in stranger a membership oracle over every private project on the platform —
exactly what ADR 0182 D2a's server-side anonymisation exists to prevent. Because the gate
delegates to the untouched permission middleware, a stranger's refusal is identical for a real
project, a stealth project, a project that does not exist, and a malformed body; the gate runs
before the body validator, exactly as `requirePermission` always did.

**A body-identical refusal that is measurably faster is still an oracle**, so every path does
the same two reads. An unknown `client_id` is asked about anyway, with the empty host, and
`projectOwnedBy` **queries** it rather than short-circuiting: an empty host names no address
and matches nothing (`domain` is a hostname or NULL, and `lower(NULL) = ''` is NULL), so it is
a real round-trip with a guaranteed-empty result rather than a dummy delay. That is the one
place in this design where the cheap-looking early return is the wrong call, and it is written
into the function's own doc-comment so a later "optimisation" cannot quietly reopen the
channel. Equalising the lookup must not DUPLICATE it, so the resolved row rides forward on
`req.inviteTargetClient` (the `req.builder` / `req.rawPermissionKeys` precedent) and the
handler reads it instead of fetching the same row again.

## Consequences

- **[task 1002346](https://cloudbongos.com/builders#/task/1002346) (BV1.R27) is unblocked**, and
  is the pure wizard-step task it was scoped as. The route path, body and responses are
  unchanged: `POST /api/bongos/projects/invite` with `{ client_id, github_login }` → `201
  { invited: true, row }` on a fresh invite, `200 { invited: false, alreadyMember: true }` when
  the membership already exists.
- **Owning a project buys exactly one act on the hub** — pre-seeding a `pending` membership on
  your own project. No rank, no curation, no read of anyone else's project, and nothing else
  consults it. The reverse also holds: this reads ownership and grants none.
- **Fail-closed in three directions.** No provisioning module → the old door, unchanged. A
  throwing ownership check → the old door, unchanged (never a 500, never an admit). A
  non-string `client_id` → not a claim, and neither the port nor the client registry is asked.
- **Every caller now costs two indexed reads before the permission gate runs**, including one
  who will be refused. That is the deliberate price of equal latency on a cold, authenticated
  route; it is bounded (two primary-key/`LIMIT 1` lookups) and it is why the equalisation is
  affordable here and would not be on a hot public path.
- **A re-pointed co-tenant project can lose the own arm.** The catalog's claim rule 1 refuses
  to rewrite a *credentialed* client's origin, so a federated project that moves address keeps
  a stale `origin` while its provisioning row carries the new domain, and the binding stops
  matching. That degrades to curator-only — the safe direction — and is named here so the next
  reader recognises it rather than rediscovering it as a bug.
- **The port is a general capability with one consumer.** Any future hub surface that wants to
  own-scope a control-plane project asks the same question rather than inventing a second
  answer — which is what keeps a hub ownership column from being promoted to authority the
  next time this comes up.

## Alternatives rejected

- **Read `sso_clients.owner_github_id` (candidate B as originally scouted).** Rejected: it is
  the exact thing its own migration comment and ADR 0238 forbid — a hub catalog column with no
  instance behind it, writable by hub curation, and NULL on the hand-seeded rows.
- **Lower `project.curate`'s floor to `xenos`.** Rejected on ADR 0210's grounds: it would admit
  every stranger who ever signed in, to every project on the platform.
- **Mint a `project.invite.own` ownership-scoped atom** and use `authorizeOwnedOrAny`.
  Rejected: the ownership-scoped axis resolves the *rank* fact from a catalog floor and the
  *owner* fact from a row the handler loaded, and here the owner fact lives on another module's
  plane entirely — so the atom would still need this port, plus a catalog-floor change this
  task is not authorised to make. The recruiting wave's `project.recruit`
  ([spike 1002786](https://cloudbongos.com/builders#/task/1002786) R3) is where a new atom is
  defined; when it lands it replaces the `project.curate` half of this OR and the ownership
  half is unaffected — the same seam ADR 0210 left.
- **Key the ownership question on the slug alone.** Rejected: see decision 3 — it makes a
  hand-seeded catalog row's name a squattable claim on that project's membership directory.
- **Reuse the `membership_kind = 'owner'` proof `scouting-authz.js` uses.** Rejected: that row
  is written by a federated instance's `POST /sso/membership/check-in`, which a standalone
  wizard-made project never calls — it would be empty for exactly the audience this task
  exists to admit.
