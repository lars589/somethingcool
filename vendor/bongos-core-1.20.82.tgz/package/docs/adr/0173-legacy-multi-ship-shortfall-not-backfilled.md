# 0173 — The legacy multi-ship reward shortfall is not backfilled; it closes as a transition cost

- **Status:** Accepted
- **Date:** 2026-08-16
- **Task:** [#1002520](https://cloudbongos.com/builders#/task/1002520) (goal 1000037 — pay-on-land incentive alignment)
- **Related:** ADR 0054 (cost-plus reward — `round(true_cost_usd × 1.20)`), ADR 0120 (pay-on-land), ADR 0146 (cost-plus-only), core migration `core_196_session_reward_topup.sql` (the `reward_basis` watermark)

## Context

Before `core_196` landed, the cost-plus session reward booked **one row per session**. A session that shipped more than once — the normal shape, since a builder ships, opens a new worktree, and claims again — was therefore paid at the level of its *first* ship and never topped up as the session kept spending. `core_196` fixed this forward with watermark accounting: uniqueness moved from `(session_id)` to `(session_id, reward_basis)`, where `reward_basis` is the cumulative total owed at the moment of the row, so each later ship books the difference.

That migration added `reward_basis integer NOT NULL DEFAULT 0`, which left every pre-existing row at `0`. Its own comment names the consequence and defers it:

> Existing rows therefore land on `reward_basis = 0` … The application refuses to top those up: doing so would be an uncontrolled retroactive payout across every historical session. Reconstructing what past sessions are owed is a deliberate, owner-signed-off backfill, tracked separately.

Task 1002520 was that tracked backfill. Its title asserted that `reward_basis = 0` identifies the underpaid population, and it carried two open questions: whether that marker over-selects, and what the total owed actually is. Both are now answered, measured against the live `cloudbongos.com` database on 2026-08-16.

**The marker over-selects by roughly 60%.** `reward_basis = 0` means "booked before top-ups existed", not "underpaid" — a single-ship legacy session was paid its full worth at the time and is owed nothing.

| population | sessions | credits already paid |
|---|---|---|
| legacy rows (`reward_basis = 0`) | 478 | 23,477 |
| — single-ship (paid in full, owed nothing) | 287 | 12,669 |
| — multi-ship (the real candidate set) | 191 | 10,808 |

**The reconstructable shortfall is 7,697 credits.** Each candidate's stored `session_records.model_usage` was re-priced through the locked `PRICES` table (`priceModelUsage`, including the `fable` family added the same day in task [#1002883](https://cloudbongos.com/builders#/task/1002883)) at `round(true_cost_usd × 1.20)`, minus what was actually paid:

- 119 of the 191 have priceable `model_usage` → **7,697 credits owed**
- 72 have **empty** `model_usage` → not reconstructable server-side at all; their transcripts exist only on builders' machines (the population task [#1002448](https://cloudbongos.com/builders#/task/1002448) covers)
- 16 were already paid at or above their worth — 1,131 credits of excess that no proposal proposed to claw back
- 0 unknown model ids, so the pricing carries no fallback error

Per builder: example-owner 5,296 (69%), jaxri 2,319, scootermack 82.

## Decision

**Do not backfill.** The legacy multi-ship shortfall closes as a one-time transition cost, and task 1002520 closes with no credits minted.

The owner was presented with four options — mint the 7,697 now, reconstruct the missing 72 first and mint once, substitute a flat reviewed per-session amount, or decline — and chose to decline (2026-08-16, blocker [#1000113](https://cloudbongos.com/builders#/blocker/1000113)).

## Rationale

1. **It is the same shape of decision as the ADR 0146 clawback, and answering it the same way keeps the ledger coherent.** That go-live reversed 343 credits of already-booked per-task estimate and did not re-pay it as an estimate; builders re-earn under the new rule instead. Declining here treats the pre-`core_196` underpayment symmetrically: the accounting changed, the boundary is where the change landed, and neither side is reopened.
2. **The reconstruction is structurally incomplete, and paying only the reconstructable part is arbitrary.** 72 of 191 candidate sessions have no usage data at all. Paying the 119 would settle the population that happens to have left a server-side trace and silently skip 38% of it — a distinction with no relationship to who was underpaid or by how much.
3. **The measured figure is not symmetric with how overpayment is handled.** 16 sessions were paid *above* their worth by 1,131 credits, and no version of this backfill proposed recovering that. A payout that corrects errors in one direction only is a policy choice, and the owner declined to adopt it.
4. **The forward fix is already live and is the thing that mattered.** `core_196`'s watermark accounting means no session underpays this way again. The backfill was always remediation of a closed window, not a defect that continues to cost builders.

## Consequences

- Task 1002520 ships with no artifact beyond this ADR and mints nothing. Blocker 1000113 resolves as decided.
- **Three builders are permanently short by the amounts above** — example-owner 5,296, jaxri 2,319, scootermack 82, plus whatever the 72 unreconstructable sessions were worth. This is a real cost borne by real builders, recorded here rather than left implicit, and the owner absorbs the largest share of it.
- Task [#1002448](https://cloudbongos.com/builders#/task/1002448) is **unaffected and still owed.** It is a different failure — the Windows `encodeProjectPath` bug meant those sessions were never *recorded*, so they were paid nothing at all rather than paid at a stale watermark. That population still has recoverable transcripts and its own owner sign-off step. Do not read this ADR as closing it.
- `reward_basis = 0` remains in the schema as the "booked before top-ups existed" marker. This ADR is the answer to anyone who later reads that column as an unpaid-work queue: it is not one, it over-selects by 60%, and the underpayment it partly marks was deliberately not settled.
