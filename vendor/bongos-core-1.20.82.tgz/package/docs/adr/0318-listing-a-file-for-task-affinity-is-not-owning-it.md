# ADR 0318 — Listing a file for task affinity is not claiming to own it

- **Status:** accepted — **implemented** by [task 1004110](https://cloudbongos.com/builders#/task/1004110) (2026-09-20)
- **Date:** 2026-09-20
- **Task:** [task 1004110](https://cloudbongos.com/builders#/task/1004110), goal 1000095 — BONGOS-V2
- **Extends** [ADR 0314](0314-module-protection-is-per-path-not-per-module.md), which left this case open by name.
- **Supersedes nothing.**

## The question

After [ADR 0314](0314-module-protection-is-per-path-not-per-module.md), nine
modules derive `protected` — making a goal scoped to them Archon-only to create.
`builder-settings` was one of them, and it earned that on exactly one glob:
`src/bongos/routes/me.js`, caught by the blanket `src/bongos/routes/` prefix in
`PROTECTED_GLOBS`.

ADR 0314 named this and left it, because clearing it looked like it needed one of
two expensive things: finishing the strangler move of `me.js` into
`modules/builder-settings/`, or narrowing a blanket protected glob. Both were
scoped out. The task that picked this up was written the same way — those two
options, and *"the choice is the deliverable"*.

Both are wrong, and measuring them is what shows a third thing was actually broken.

## What the measurements said

**Narrowing the blanket prefix removes the only wall that exists.** All eighteen
files under `src/bongos/routes/` are protected by that prefix *and nothing else* —
no route file has a second protecting glob. Narrowing it unwalls `auth.js`,
`builders.js`, `backup.js` and `core-update.js` in the same stroke. This is now
pinned as a test rather than left as a caution, so the next reader does not have
to re-derive it.

**Moving `me.js` into `modules/builder-settings/` inverts the port architecture.**
`GET /me` is a deliberate aggregator: it resolves **ten** module ports —
`lifecycle`, `reward`, `onboarding`, `government`, `specialities`, `grade`,
`box.hasEverConnected`, `art.sharedKeyConfigured`, `art.getBuilderGeminiKeyRow`,
`discord.isLinked` — and `builder-settings` is one of the ten. Hosting it inside
one module would mean that module resolving nine foreign ports from the inside,
which is the `core -> module` edge [ADR 0083](0083-modular-architecture-strangler-build-plan.md)
rule 1 exists to forbid. A core facade is precisely what prevents that.

Three places already said so, in the code, before this task was written: the file
header (*"This file kept only the read aggregation"*), `module.json` (*"the
`GET /me` aggregator stays a thin core facade"*), and `MODULE_GLOBS` itself.

## The decision

**`MODULE_GLOBS` listed `src/bongos/routes/me.js` under `builder-settings` for
task affinity — and said so in the same comment — while `isProtected()` read it
as an ownership claim.** Affinity is a convenience for authoring; ownership is a
statement about territory. One listing, read as the other, made a whole module
Archon-only on the strength of a file its own comment called core.

So: **ownership follows what the file is.** `src/bongos/routes/me.js` moves to
`kernel`, which already owns `src/bongos/routes/security.js` and is the home of
the core route surface. `builder-settings` keeps its own directory and its
pref-mirroring CLI, and stops being protected.

This is [ADR 0314](0314-module-protection-is-per-path-not-per-module.md) one step
on. That decision said *owning the command is not owning the authority*, for a CLI
entrypoint that merely lives near a module. The same error wearing different
clothes: **being listed next to a module is not owning it either.** 0314 solved
its case structurally, with a path test (`isCommandPath`). This one is solved by
correcting the data, because there is exactly one such listing — see below.

## Why not a general affinity tier

The obvious generalisation is to mark affinity entries in `MODULE_GLOBS` so
`isProtected()` skips them, mirroring `isCommandPath`. Rejected, because the
audit does not support it. Of the nine protected modules, three others
(`kernel`, `devsecops`, `methodology`) are protected only by paths outside their
own directory — but in every one of those the foreign path genuinely *is* the
domain: `kernel` **is** `src/bongos/auth.js`, `devsecops` **is** `.github/`,
`methodology` **is** `CLAUDE.md` and `docs/`.

`builder-settings` was the only module protected by a path its own source
described as belonging elsewhere. A new tier in `MODULE_GLOBS` would be a new
concept, and a new place for a hole to hide, built for a population of one.

## Consequences

- `protectedModules()` goes **9 -> 8**. `builder-settings` leaves the set.
- **The wall that matters does not move.** This decides who may CREATE a goal
  whose territory includes `/me`. It does not decide who may WRITE it: a
  sub-Metic builder touching `src/bongos/routes/me.js` is still refused by
  `checkPermissionPaths`, which the tests assert directly rather than assume.
- A `builder-settings`-scoped goal can no longer author a task touching `/me`;
  that needs `kernel` scope. Correct, rather than a loss — the aggregator spans
  ten modules and belongs to none of them.
- `src/bongos/routes/` now has **two** of eighteen files owned, up from two with
  one of them wrong. The other sixteen remain authorable by no goal;
  [task 1004116](https://cloudbongos.com/builders#/task/1004116) holds that
  decision, and this change removes the builder-settings overlap that made its
  option (a) awkward.

## Not built here

- **The other sixteen route files.** Still unowned, still
  [task 1004116](https://cloudbongos.com/builders#/task/1004116). The blanket-prefix
  tripwire added here is the measurement that task needs, landed early.
