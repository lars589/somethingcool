# ADR 0251 — A suggestion of who to invite is a recruiting surface, and owes the recruiting opt-out

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1002347](https://cloudbongos.com/builders#/task/1002347) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-invite-builders` / C6), BV1.R28
- **Deciders:** Claude, under the Archon's standing scope
- **Depends on:** [ADR 0239](0239-a-recommendation-is-a-table-that-carries-its-own-reason.md) §6 (the seam this fills: the engine emits `invites.seeking` and names R28 as its reader) · [ADR 0249](0249-the-invite-step-is-the-done-panel-s-first-act-not-a-rail-step.md) (the widget these names arrive in, and its "only door in" rule) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way import rule that makes this a port)
- **Related:** [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) (the `/scouting` gate this route deliberately does **not** reuse) · [ADR 0248](0248-a-hub-project-s-owner-is-the-provisioning-row-carried-on-a-port.md) (the ownership fact the invite route already admits on) · [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (a surface never re-derives a server rule)

---

## Context

[ADR 0239](0239-a-recommendation-is-a-table-that-carries-its-own-reason.md) §6 left one recommendation deliberately unfinished. The creation wizard's rule engine emits, per team shape, a **seek** rather than a list:

```
solo        → seeking: null                              ("suggest nobody", a real answer)
small-team  → seeking: { kind: 'top-builders', limit: 3 }
community   → seeking: { kind: 'top-builders', limit: 5 }
```

`invites.suggested` is always `[]` there, and a test pins that emptiness as a decision rather than a gap. The engine is a pure file that may run no query; ranking builders is a directory read; and `provisioning` may not import a sibling module. So the engine states *what to look for* and R28 — this ADR — turns it into names.

That leaves one genuinely open question, and it is not an architectural one: **which directory?**

## The decision that matters: the recruiting directory, not the leaderboard

Two readers could answer "who are the top builders", and they differ by exactly one SQL predicate:

| reader | lives in | consent |
|---|---|---|
| `leaderboard()` | `economy` | joins `rollupVisibleSql` — **honours no recruiting opt-out**, on purpose |
| `listScoutingRollup()` | `platform-identity` | joins `scoutingListableSql` — **the opt-out is inside the query** |

The leaderboard is the cheaper answer in every mechanical sense: it is an explicitly public read route, it needs no port, and a browser could call it directly with no new server code at all.

**We use the scouting rollup anyway, because the opt-out means this exact screen.** `account-visibility.js` states the split in its own words — `hide_stats` suppresses *numbers* everywhere, while the recruiting opt-out "removes an account from the RECRUITING SURFACE only", and the community spec's D3 says the opt-out "does not affect leaderboards; it governs the recruiting surface only". A list of people the platform is proposing you recruit into your project **is** the recruiting surface. Sourcing it from the leaderboard would not be a shortcut around some incidental gate; it would route around the one control that exists for precisely this case, and hand an owner the name of every builder who asked not to be recruited.

The rule this fixes for later readers: **the cheapness of a public read is not an argument about who consented to appear in it.** `listScoutingRollup`'s own header already warns in the other direction ("a public LEADERBOARD must not reuse this reader"); this is the same boundary approached from the other side.

## Where the lookup lives, and why it is a port

`modules/platform-identity` gets a new function, `listInviteSuggestions`, exposed on the existing `platform-identity.hub` port. `modules/provisioning` reaches it with `resolveOptional` — the `catalog-bridge.js` precedent, and **not** declared in `consumes`: platform-identity is hub-only (`default: false`), so an instance running provisioning without it has no directory to ask and the honest answer is "no suggestions", never a 500.

Two things are enforced inside the module rather than asked of callers:

1. **`github_id` does not cross the port.** The projection is an explicit whitelist — login, display name, avatar, disciplines, and two counts. The invite route takes a *login*; the id names someone who has accepted nothing, and the surface already has a test forbidding it on screen. An explicit whitelist also means a new column on the rollup cannot leak by default.
2. **The exclusion is applied inside.** A caller passes the ids to drop (in practice the owner's own) and gets back rows with no ids in them, so dropping yourself from your own list never requires holding one. The read is over-fetched by the exclusion count so filtering can never return short of the limit.

## The gate is the one that already exists

`GET /provisioning/instances/:id/invite-suggestions` is own-scoped by `instanceAccessDenied` — the same gate, and the same **404**, as the manage-page read beside it.

It deliberately does **not** reuse `/scouting`'s gate (`project.curate` or a hub-witnessed `membership_kind='owner'`). A brand-new owner has no witnessed owner-membership row at the moment the done panel paints — that row is written later, by the child instance at SSO check-in — so the correct-looking gate would refuse the exact caller the feature exists for.

Reaching this route **is** the ownership answer ([ADR 0249](0249-the-invite-step-is-the-done-panel-s-first-act-not-a-rail-step.md) §4), so the surface re-derives nothing and cannot become a weaker second copy of a server rule ([ADR 0016](0016-trust-boundary-server-enforced-permissions.md)). 404 rather than 403 keeps it leaking no more instance existence than its neighbour.

## What the surface does with the answer

The widget keeps its shape from [ADR 0249](0249-the-invite-step-is-the-done-panel-s-first-act-not-a-rail-step.md): it still answers neither "is anyone signed in" nor "is this their project", and gains a **second door in** (`setInviteSuggestions`) beside `setInviteSlug` rather than learning to fetch for itself.

- **The reason is always said, including when the answer is nobody.** `seeking: null` returns its own sentence and never touches the directory. A solo owner is suggested nobody *on purpose*, and rendering that as an empty list would turn a stated answer into what looks like a failed lookup.
- **A picked name takes the same write path as a typed one** — it fills the field and calls `doInvite`. One write path means the refusal vocabulary, the busy guard and the pending receipt cannot drift into a second copy.
- **A filed invite stops being a suggestion.** The pending line is its receipt; offering the same person twice invites a refusal the owner cannot act on.
- **Every failure is silent.** A suggestion is an extra, and a project that was just created successfully must never look broken because an optional directory read did not answer.

## Consequences

- A builder who opted out of recruiting is **absent from suggestions while still ranking on the leaderboard**. That is the opt-out working, not a bug — but it does mean the suggested names and the leaderboard's top names legitimately differ, and anyone comparing the two screens should expect that.
- Suggestions are **hub-only**. An instance without `platform-identity` gets `unavailable: 'no_directory'` and an empty list; the step still works for typed logins.
- `invites.suggested` stays `[]` in the pure engine forever. The filling happens one layer out, so ADR 0239's test still passes unchanged and the engine stays I/O-free.
- Guilds are still out (task 1002348, blocked on goal 1000045). `seeking.kind` is already a discriminator, so a `guilds` kind is an added branch rather than a reshaping.

## Rejected

- **Read the economy leaderboard from the browser.** Cheapest by far and needs no server code — rejected on consent, above. This is the whole decision.
- **Reuse `GET /scouting`.** The right data behind a gate that refuses the caller this feature is for.
- **Fill `invites.suggested` inside `recommendationsForDetails`.** Would make a pure, synchronous, dependency-free file do I/O and import a sibling module — the two things ADR 0239 §6 and ADR 0083 respectively forbid.
- **A `provisioning → economy` port for the leaderboard.** Architecturally legal and still the wrong directory; the boundary was never the objection.
