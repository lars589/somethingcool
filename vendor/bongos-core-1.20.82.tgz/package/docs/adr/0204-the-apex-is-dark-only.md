# 0204 — The apex is dark only; light is the builders' hall's

- **Status:** Accepted
- **Date:** 2026-08-29
- **Deciders:** the owner (Archon), on the planets review of 2026-08-28: "only black or only white is a bit bland, frankly I am leaning towards only dark mode for this page and keep the dark/light mode to be solely for the builder hall. That way we could focus in on that style. This would also mean we could invest into a cool space themed backdrop for the blobs." Confirmed the same day as the WHOLE apex (landing, hub, legal pages), not the map alone. Claude implemented.
- **Task:** task 1003336 (goal 1000080 — Apex UI pass 2)
- **Supersedes in part:** [ADR 0196](0196-chrome-world-token-contract-and-the-landing-sheets.md) — its Context ("light mode rebuilt to the dark standard") and the light-mode half of Decision 3 (world.css "the derived tier for both modes") no longer describe what the apex renders; the token contract, the sheet split, the plates and the sentinel rule stand. Also the landing direction's pick of option 3 in `docs/design/landing-page-direction-v2.md` §5/§6 (2026-08-27): option 4, "dark-only landing", is the one taken after all, widened to every apex page.
- **Interacts with:** ADR 0062 §3 (the pack's `theme.ui` is one-mode — light values — and is still spliced as the `:root`; the dark blocks override it exactly as before), the `ui-design` module's kit (ADR 0198 line; `modes` in a states file), the hall's own switch (`modules/hall-ui/public/shell.js`, `hall-theme`), the next task in the chain (1003337: a rendered space backdrop for the field — a black-ground plate, which is what a single mode makes possible).

## Context

The apex shipped with a real, tested light mode: the world round's light landing was called weak, the landing round offered four answers (`landing-page-direction-v2.md` §5), and on 2026-08-27 the owner picked "light rebuilt to the dark standard" — the chrome as alpha cutouts on paper — over "dark-only landing". The build made both modes real: every dark rule written twice (`:root[data-mode="dark"]` and its `prefers-color-scheme` twin), a pre-paint script on every apex page reading `?mode=`, the persisted `cb-color-mode` choice and the OS preference, a 44px moon/sun glyph in both bars, the kit rendering every state in both modes, and contrast measured in both.

Reviewing the planets (task 1003319), the owner saw the two grounds side by side and chose one: the apex commits to dark, so the field can carry a rendered space backdrop (a black-ground plate composites with nothing to hide; a pale ground would need a second, cut-out material for every plate), and the light/dark switch stays what it already is in the builders' hall — the hall's own, on its own key.

Three facts shaped the shape of the change:

1. **A fixed attribute beats a script.** `data-mode="dark"` on `<html>` in the served markup selects the same dark blocks the toggle used to select, before first paint, with nothing to flash, nothing to persist and nothing for the OS preference to reach — `:root[data-mode="dark"]` wins under `prefers-color-scheme: light`, and the `:root:not([data-mode="light"])` twin agrees under dark. The pack's one-mode `:root` (ADR 0062 §3) is untouched.
2. **The light tier is load-bearing for tests, not for pixels.** `tests/world_tokens.mjs` and `tests/cosmos_token_contrast.mjs` measure every light pair against AA, and the twins rule is pinned on both pages. Deleting the tier in the same task would be a second, larger diff under a UI change the owner has not seen yet; leaving it costs nothing a visitor can see.
3. **The kit had no way to say "one mode".** `render.js` walked `MODES` unless `--modes` was passed, and its floor audit flags `data-mode "dark" under a light scheme` — which is now the correct state of every apex page. A states file needs to declare the modes its page renders.

## Decision

1. **Every apex page pins `data-mode="dark"` on `<html>`**: `/`, `/projects`, `/privacy`, `/terms`, `/contact`. The pre-paint mode scripts leave all five pages; `cb-color-mode` is neither read nor written on the apex; `?mode=` no longer walks a second mode on the landing; no script calls `matchMedia('(prefers-color-scheme: dark)')`.
2. **The mode glyph leaves both bars** — the landing's `#mode` button and the hub's `#modeToggle`, their moon/sun SVGs, the `.modeBtn` rules (page-local on the landing, `cosmos.css` for the hub, both under-900 variants), the icon-swap twins, and the hub's `resolvedMode` / `paintModeToggle` wiring. The bar's right side closes up: Projects, then the identity slot.
3. **Light is the builders' hall's alone.** The hall's switch (`hall-theme`) is untouched and stays the only light/dark control on the platform.
4. **The light tier stays for now.** `world.css` and `cosmos.css` keep their light values and their dark twins; the dark-twins rule in `DESIGN.md` and the `/design` playbook stands as written until the tier's own removal, which is a follow-up task, not this one. The contrast tests keep measuring the light pairs meanwhile.
5. **The kit learns `modes`.** A states file may declare `"modes": ["dark"]` (validated: a non-empty subset of `dark` / `light`); `render.js` takes it as the default where `--modes` is not passed. `index.states.json` and `projects.states.json` declare `["dark"]` and set `modeQuery: false`; the hub's mode-toggle probe is gone.
6. **The record.** `DESIGN.md` gains a Modes section and loses the `mode-toggle` component row; both direction records carry a dated note; the copy registry regenerates (the two toggle labels leave it); the tests that pinned the toggle now pin its absence and the fixed attribute (`tests/landing_page.mjs`, `tests/projects_hub.mjs`, `tests/projects_hub_pre_uat.mjs`, `tests/landing_legal_pages.mjs`, `tests/ui_design_kit.mjs`).

## Consequences

- A visitor whose OS prefers light sees the dark apex; a visitor who had stored `light` on the apex before this change sees dark (the key is simply never read). The hall keeps whatever they chose there.
- The three alpha cutouts (`--plate-*-cut`) are no longer a light-mode material on the landing's hero; they remain the bongo pair's closing figure and the planets' masks (task 1003319), so they stay in `public-landing/assets/world/`.
- The next task (1003337) can treat the field's ground as black: a rendered deep-space plate, `cover`, still or a slow transform drift, dead under reduced motion.
- Rejected: keeping the toggle but defaulting dark (the owner's ask was one mode, not a default); deleting the light tier here (a larger diff than the decision needs, under a change not yet reviewed); moving `--modes dark` into every kit invocation instead of the states file (the file is the page's contract; the flag is a session's override).
