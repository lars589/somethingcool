# 0236 — Many ideas → one task: the lineage key is the pair

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1003515](https://cloudbongos.com/builders#/task/1003515) (this decision, promoted from
  idea 1000815), [#1002997](https://cloudbongos.com/builders#/task/1002997) (created the lineage table),
  [#1003065](https://cloudbongos.com/builders#/task/1003065) (the R01 diff whose grader flagged the shape)
- **Goal:** [#1000071](https://cloudbongos.com/builders#/goal/1000071) — Idea routing
- **Related:** [ADR 0172](0172-per-craft-compensation-ideator-credit-lane.md) (the ideator credit lane this
  table is the rail for), [ADR 0185](0185-spark-handoff-credit-split.md) (the other place an idea has more
  than one claimant), [ADR 0234](0234-idea-routing-capture-time-promotion-landing-matrix-homeless-inbox.md)
  (routing, the third `origin`)

## 1. The problem

`ideas_002_idea_tasks.sql` made `task_id` the **primary key** of
`ideas_task_lineage`, on the stated reasoning that "a task descends from at most
one idea". `linkIdeaTask` matched it:

```sql
ON CONFLICT (task_id) DO UPDATE SET idea_id = EXCLUDED.idea_id, origin = EXCLUDED.origin
```

So promoting a **second** idea into a task that already had a link did not fail
and did not warn — it *replaced* the first idea's lineage. `updateIdea` fires
`linkIdeaTask` on any promote that sets `promoted_to_task_id`, so two ordinary
triage promotes at one task were enough. That happened on prod on 2026-08-21:
ideas 1000811 and 1000812 were both promoted into task 1003150 (two call sites of
one mechanism), and idea 1000811's link is gone — only its weaker
`idea_inbox.promoted_to_task_id` pointer survived.

This table is the rail [ADR 0172](0172-per-craft-compensation-ideator-credit-lane.md)'s
stream 1 pays against (`<redacted>`, `sourceIdeaForTask`), so an
overwritten row is an ideator silently not paid for work their idea produced,
with no trace anywhere that it happened. It also made "N duplicate reports merged
into one task" a **lossy** operation — the exact triage move the inbox exists to
encourage.

The grading panel's hacker worker named this shape on the R01 diff and was told
it was unreachable. It was unreachable on the *routing* path it examined and
fully reachable on the ordinary *promote* path, which needs no idempotency edge
at all. The finding was right about the shape and wrong about the reach, and only
the half it named was checked.

## 2. The decision

**Many ideas → one task is a real relation, so the key is the pair.**
`ideas_006_lineage_many_ideas_one_task.sql` drops the single-column primary key
and re-adds `ideas_task_lineage_pkey` as `PRIMARY KEY (task_id, idea_id)`. Both
INSERT sites (`linkIdeaTask` and `routeIdeaToGoal`'s transaction) target the pair
and `DO UPDATE SET origin` — never `idea_id`, which is now part of the identity
rather than a mutable field. `created_at` is left alone by the upsert, so *which
link came first* is a durable fact a re-link cannot rewrite.

The alternatives were considered and rejected. **Refusing the second link**
(assert-no-existing-lineage) turns a legitimate triage merge into an error and
teaches triagers to avoid merging. **Logging the replacement loudly** keeps a
correct-by-luck ledger that is still lossy. The table was already the
"many-tasks" side table with a non-unique `idea_id`; making the other direction
real is the smaller change, not the bigger one.

**Where one row is still required, the earliest link wins** —
`ORDER BY created_at, idea_id`, stated in SQL rather than left to the planner.
That rule is shared by `sourceIdeaForTask`, `credits.awardIdeaTaskShipCredit`,
and the nod queue's one-row-per-task predicate (a single constant embedded in
both the list and its count, so the pill can never disagree with the rows).

## 3. Consequences

- **A task subsumed from N ideas counts once toward *each* idea's shipped-task
  credit.** Every co-source idea keeps its own row, so
  `<redacted>` no longer drops to zero for whoever was overwritten,
  and the idea trail on a builder's profile shows the shared task under each of
  their ideas. It cannot double-count within one idea: the pair is unique.
- **The per-ship payout still names one idea — the earliest.** Whether a shared
  task should pay *every* co-source ideator is a decision about how much a
  shipped task is worth in total, not a bug fix, and it is deliberately not made
  here. The idempotency key is already `idea.credit.task_ship:<idea>:<task>`, so
  it is a small change whenever the owner wants it.
- **The migration backfills.** Every `idea_inbox` row with a
  `promoted_to_task_id` whose task carries no row for *that* idea gets its link
  back (`ON CONFLICT DO NOTHING`, so surviving rows keep their own `origin` and
  `created_at`). Restored rows are labelled `origin='promote'`: where the erased
  row had been a routed one, its `'route'` provenance is unrecoverable from that
  column alone, and a restored link with a coarse origin beats a missing one —
  `origin` weighs a payout, the link is whether there is one.
- **A lineage write that fails is now reported.** `updateIdea` still swallows the
  failure (the triage verdict has already committed; lineage is a ledger
  convenience, not a gate) but logs a `LINEAGE GAP` line through
  `api.logger('ideas')`. A silent swallow on top of a silent overwrite was two
  layers of the same mistake.
- **`DROP CONSTRAINT` here is additive.** Postgres has no "widen a key" verb, so
  the change is drop-then-re-add of the same-named constraint — the shape
  `fitness.js`'s `isConstraintWidening` exempts, and the one
  [`ideas_003`](../../modules/ideas/migrations/ideas_003_lineage_origin_route.sql)
  already recorded for a CHECK. The new key permits a strict superset of the old
  one, so no existing row can be invalidated. The migration asserts its own
  effect and raises if the primary key is still single-column.
