# ADR 0354 — A builder hosts one project for free, and more takes the fleet permission

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1004412](https://cloudbongos.com/builders#/task/1004412) (goal 1000106 — working area 1, Project creation)
- **Amends:** the gate [task 1003370](https://cloudbongos.com/builders#/task/1003370) put on `cloud-host` (audit B4), for a builder's first hosted project only
- **Builds on:** [ADR 0345](0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md) decision 1 (we host every project's hall, and creating a project needs no platform account, key or bill) · [ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md) (the shared box holds about fifteen projects)
- **Decided with:** the owner chose D1 on 2026-09-30, from three options put to them in plain language.

## Context

The create wizard sends one request when the owner presses its last button, "Create my project", and that request always asks for `cloud-host`: the hall, hosted by us. Task 1003370 (2026-09-19) gated that shape behind `provisioning.fleet.manage` (floor: Metic), because a hosted hall runs code from its owner's repository on the platform's own box. A new hub signup is a Xenos. So from that day, every new user who pressed "Create my project" was refused with `permission_forbidden`. The wizard showed it as its generic "We couldn't file the request just now", with the permission name underneath. Task 1004412 confirmed this with a route-level test that uses the real permission gate and a Xenos's real grants.

ADR 0345 came nine days later and made `cloud-host` the free front door. The two decisions contradicted each other, and no test covered the path they shared.

## Decision

### D1 — One live hosted project per builder needs no permission

A builder may create a `cloud-host` project with no permission if they hold no other live `cloud-host` project. "Live" means any status except `torn_down`. A queued or failed project still holds its place, and its owner can retry it or take it offline. Asking again for your own project's slug (a retry or a revive) counts as that same project, not a second one. A further live hosted project needs `provisioning.fleet.manage`, and the refusal is the kernel gate's own `permission_forbidden`.

What stops one person taking every place on the box is this limit, not rank. `byo-host` stays open without limit, and `control-plane` and `co-tenant` stay unrequestable. The gate is still an allow-list, so a shape added later is gated by omission.

If the count cannot be read, the gate refuses with `request_failed`. It is an authority gate, so it fails closed (ADR 0016).

### D2 — One first-free request per builder at a time

The count and the insert are two separate steps, so two requests sent together would both count zero. The gate takes a Postgres advisory lock keyed on the builder (`free-place-lock.js`, a try-lock on its own connection) before it counts, and lets it go as soon as the route has inserted the row (or when the response closes, on any earlier exit). A second request sent in the meantime, from any web process, gets 409 `create_in_progress`. A lock that cannot be taken refuses, like an unreadable count. (The first version used a process-local mark; the grader flagged that it would not hold across processes, so it moved into the database before shipping.)

### D3 — The wizard states both refusals in plain words

- **`permission_forbidden` with a readable `held`:** "Each account can host one project for free, and yours already has one…". The sentence names the project page's own "Take it offline" control, and says that trusted builders can host more than one (the owner asked for that line when reviewing the wording).
- **`box_full`:** "Our shared server is full right now…", instead of the operator's sentence.
- **`permission_forbidden` with `held: null`:** authority could not be checked at all, so the wizard keeps its generic sentence.

## Consequences

- New users can create a project from the wizard again. Each project costs us about $0.80 a month (ADR 0285).
- A stranger's code now runs on the shared box, on the same server as the hub. It runs in its own locked account (task 1003369), and the hub's sign-in cookie no longer reaches project halls (task 1004357). **Nothing caps a hosted project's memory or CPU**, so one misbehaving project can slow every hall and the hub. That was already true of every hosted project; this decision widens who can have one.
- Each first-free request holds one database connection from its count to its insert. Creates are rare, so the pool can carry it.

## Alternatives considered

- **Open to everyone, limited only by the box's capacity.** The smallest change. But one person could take every free place, and the capacity gate would then refuse everyone else.
- **Trusted builders only, with a plain refusal.** Keeps task 1003370's rule whole. But new users still could not start a project, which ADR 0345 decision 1 rules out.
- **An approval queue for new users' projects.** Keeps the rule and admits new users. But it is new machinery, and it would collide with the owner's redesign of the creation flow (begun 2026-09-30).
