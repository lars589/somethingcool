# ADR 0353 — A hub invite is a notice of the project's own invite, and signing in accepts it

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1002818](https://cloudbongos.com/builders#/task/1002818) (R6 of the project admin console wave, goal 1000110 — BONGOS-V2)
- **Builds on:** [ADR 0335](0335-an-invite-is-a-pre-approved-row-on-the-projects-own-instance.md) D1/D2 (authority lives on the project's own instance; an invite is a pre-approved `access_requests` row; signing in is the acceptance act)
- **Interacts with:** [ADR 0141](<redacted>.md) §3 (membership check-in), [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) (client credentials never mint a membership), [ADR 0352](0352-a-rollup-report-carries-its-as-of-in-a-header.md) (hub↔instance wire skew)
- **Decided with:** the owner chose the split in D3 on 2026-09-30, over building the signed-assertion relay in this task.

## Context

ADR 0335 left one dead end that real users could reach. The hub had its own invite, `POST /projects/invite`, called from the creation wizard's invite step and from a project's manage page. It wrote a `pending` row in `<redacted>`, and accepting it (`POST /my-projects/invites/:clientId/accept`) flipped that row to `member`. No project reads that table to decide who may enter. So the invitee "accepted" and then met the project's own sign-in gate, which knew nothing about them. A hosted project's join door defaults to `apply`, so this was the common case, not an edge case.

The project's own invite (`POST /access-requests/invite`, R2) does admit: it writes the `invited` row the sign-in gate reads. But nothing told the invitee it existed, and rescinding it left nothing to clean up on the hub because the hub had never heard of it.

The task's done-when: **no state where an accepted invite leads to a locked door.**

## Decision

### D1 — The hub's `pending` row is a NOTICE of the project's own invite

The row stays, and My Projects lists it as before, but only the project writes it now. Two new server-to-server routes, authenticated by `client_id` + `client_secret` like the membership check-in:

| Route | When the project calls it | What the hub does |
|---|---|---|
| `POST /sso/invites/notify` | every outcome of its invite route that leaves the login holding an `invited` row: a fresh invite, a pending application approved in place, and a re-invite of one already standing | `INSERT … 'pending' ON CONFLICT DO NOTHING` for the account that login resolves to |
| `POST /sso/invites/clear` | a dismissal after which the login holds no `invited` row | `DELETE` that `pending` row, and only a `pending` one |

Both calls touch a `pending` row only, so client credentials still cannot create, change or remove a membership (ADR 0205). A login with no hub account is a no-op, because there is nobody on the hub to notify; the project's row still admits them. **The answer is always `{ ok: true }` once the client authenticates**, whether or not anything was written, so a project cannot use the route to learn which GitHub logins have platform accounts.

The sender is core's `notifyHubOfInvite` (`src/bongos/auth-admission.js`). It sits in the kernel beside the other hub calls that hold the client secret, and modules reach it as a narrow doorway port. It is fire-and-forget, time-bounded and swallows every failure: an invite must never wait on the hub or fail because of it. Re-inviting is how a notice the hub missed is healed, since the hub's insert is idempotent.

Only a dismissal that leaves no `invited` row clears the notice. If two archons invited the same login and one rescinds, the other invite still admits, so the notice stays. A declined application also sends a clear. That is a no-op unless the hub still holds a pre-ADR-0353 row for that login, which would be a dead end anyway.

### D2 — Accepting is signing in to the project; the hub-side accept is retired

`POST /my-projects/invites/:clientId/accept` is deleted, and `resolveInvite` becomes the decline-only `removePendingInvite`. The hub page has not called accept since the invitations list came back (task 1003774): each invitation renders as **Open project →** with "Sign in there to accept." What was missing was the server half, so no caller (an old cached page, a script) can still flip a row and admit nobody.

Signing in closes the loop without any new code. The hub's own sign-in witness (`recordFederatedSignin`, stamped at `/sso/token` and `/sso/device/poll`) already turns a `pending` row into `member` when the invitee signs in to that project.

### D3 — The hub's own invite writes nothing; it hands the owner to the project's hall

`POST /projects/invite` keeps its owner-or-curator gate and its byte-identical 403, and it still resolves the catalog client. It no longer writes. It answers `200 { invited: false, invite_url }`: the project's hall invite box with the login filled in, `<origin>/builders/watch?invite=<login>`. A 200 rather than a refusal, because it is the answer every admitted caller gets, and a 4xx on that path would log a failed request in the owner's browser on every invite. Every instance already canonicalises `/builders/watch` to its hall (a one-host instance serves `/watch`, a two-host one redirects to `builders.<apex>/watch`, both keeping the query), so the hub needs no hall address of its own. The sign-in redirect carries the full URL, so the name survives signing in.

The wizard and manage-page widget keep their field, their suggestions and their Skip button. Each name becomes a line reading "not sent yet — finish it on your project's hall" with a **Send the invite →** link. It is a link the owner clicks, never a window opened for them: an open triggered by a network answer is blocked by browsers, and a surprise navigation would lose the wizard.

The hall's Watch page reads `?invite=` once, only if it is a valid GitHub username, and **only fills the box**. Sending stays the owner's click, because a link anyone can craft must never be the act that admits.

The owner chose this over building the relay ADR 0335 foresaw (see Alternatives) in this task.

### D4 — Wire skew (ADR 0352's rule)

The two notice routes are **new**. An older hub answers 404, the sender swallows it, and the invite still admits: only the notice is lost. A newer hub with an older instance simply receives no notices. Each route's body is validated strictly (three fields), so a field added later must ride a header, or ship on the hub and be released before any instance sends it.

## Consequences

- **The done-when holds for every invite created from now on.** A hub notice exists only because the project wrote an `invited` row, and a rescind that closes the door removes the notice. The hub's own invite creates no row at all.
- **Rows written before this change are untouched.** Pending rows the old hub invite wrote still render as **Open project →**, and on a door other than `open` they still lead to the project's gate. The invitee can decline them, and the project can clear one by inviting and then rescinding. Deleting them at deploy would need a data migration, and it would also delete notices that do work (on `open` doors). That is left to the owner (see the task's handoff), not done silently here. **Amended (task 1004408):** the owner chose to delete them. Migration `<redacted>` deletes every `pending` row older than the hub's first upgrade to core 1.20.22 (the first release carrying this ADR), read from the `core_upgrades` ledger, or every `pending` row if there is no such upgrade. Old rows on `open` doors go too; those invitees can still sign in to the project, and the inviter can re-invite from the project's hall. Proof: `tests/pending_invite_purge_db.mjs`.
- **The hub's invite now reaches people with no platform account.** The project's own invite takes any GitHub login, so the old `account_not_found` refusal is gone. Such an invitee sees no hub notice, because there is no account to show it to, but they are admitted when they sign in.
- **Three things still bypass the notice**, all by scope: the reviewer queue's approve (`PATCH` pending → invited), the Discord approval reaction, and R3's future recruiter rescind route. The first two are approvals of an application the applicant already knows about. R3 (task 1002815) must call the same port when it adds its rescind.
- **The 30-day invite expiry** (task 1002969) is read-time on the instance. An expired invite's hub notice stays until the invitee declines it or the project re-invites and rescinds. Task 1002969 owns closing that. **Closed by [ADR 0356](0356-a-recruit-invite-expires-30-days-after-it-is-sent-read-time.md):** the hub stops listing a notice 30 days after it was sent, and a re-invite restamps it.

## Alternatives considered

- **The signed-assertion relay (ADR 0335's foreseen design).** The hub mints a new `purpose: 'invite'` token for the inviter, and a new token-authenticated route on the project checks that builder's own permission and writes the real row. It keeps the in-place form, but it adds an authentication path to every instance (security-sensitive), roughly doubles this task, needs a fallback for every older instance, and cannot work until the owner has signed in to a new project once (there is no local builder to check the permission against). The owner deferred it. D3's hand-off leaves room for it: if it is built, the route's `invited: false` becomes `true` for instances that support it.
- **Seed the hub row only when the project's door is `open`.** An owner who later closes the door strands every such notice in front of a locked door, and a self-hosted project's door is not known to the hub reliably.
- **Keep the hub-side accept, but have the instance read hub memberships at sign-in.** This puts a hub call inside the admission gate and moves a verdict onto the hub, which ADR 0335 D1 forbids.
- **A body field on the membership check-in instead of new routes.** The check-in body is validated strictly, so an older hub would 400 the whole check-in (ADR 0352), and a check-in is sent at sign-in, not at invite time.

Proof: `tests/hub_invite_notices.mjs` (the hub routes over the real domain functions: pending-only writes keyed on the authenticated client, the identical answer for an unknown login, the credential refusals, the three-field body, the hand-off link, and the sender), `tests/access_requests_invite.mjs` and `tests/application_lifecycle.mjs` (which invite outcomes notify and which dismissals clear), `tests/project_invite_ownership.mjs` and `tests/catalog_only_client.mjs` (the gate is unchanged and nothing is written), `tests/project_invite_ui.mjs` (the hand-off line, no non-http link, no window opened), `tests/watch_applications_queue.mjs` (the prefill fills and never sends), `tests/my_projects_surface.mjs` and `modules/platform-identity/tests/platform-identity.mjs` (the accept route and flip are gone).
