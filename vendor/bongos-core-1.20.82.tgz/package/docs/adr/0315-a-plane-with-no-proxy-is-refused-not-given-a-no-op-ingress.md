# ADR 0315 — A plane with no proxy is refused, not given a no-op ingress

**Status:** accepted · **Date:** 2026-09-20 · **Task:** [task 1004017](https://cloudbongos.com/builders#/task/1004017) (goal 1000106 — BONGOS-V2)

**Related:** [ADR 0303](0303-provisioning-verifies-the-base-caddyfile-and-never-edits-it.md) (detect-and-refuse on the base Caddyfile — the check this one sits in front of) · [ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md) (the supervision seam that explicitly deferred Caddy reload to this task) · [ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md) (the capacity preflight this one is ordered behind) · [ADR 0111](0111-instance-hosting-provisioning-module.md) (the standup runbook both checks live inside)

## Context

Provisioning step 6 writes a per-instance `<slug>.caddy` snippet and runs
`systemctl reload caddy`. The self-host image installs `postgresql-client bash tini curl
ca-certificates git`, runs `USER node`, and ships no proxy of any kind — so on a compose
self-host that step cannot work, and a child instance provisioned there has no front door.

ADR 0306 named this explicitly as the piece its seam does not cover: *"`systemctl reload
caddy` is shared-proxy config, governed by ADR 0303, and the container has no Caddy at
all — that is task 1004017, not this seam."*

**Two failure shapes, and only one of them was visible.** ADR 0303's preflight is gated on
`inst.domain`, so:

- A **domained** child already half-refused — `caddy adapt` fails with no binary, which
  ADR 0303's own `catch` turns into a gap string. But the message told the operator to add
  a directive to `/etc/caddy/Caddyfile`: a file the container does not have and that
  provisioning will never create (ADR 0303 §1 forbids writing it).
- A **domainless** child skipped the preflight entirely, walked to step 6, and died on
  `boxWriteFile('/etc/caddy/sites/<slug>.caddy', …, {sudo: true})`. That throw is uncaught,
  so it bypasses the `{ok:false}` pending-retry path and hard-errors the instance on attempt
  one. The runner recorded a crash where the honest answer was a refusal.

## Decision

**A plane with no reverse proxy is refused before anything is attempted, and the refusal
names what the plane lacks.**

`ingressPlaneGap(exec)` in `scripts/gds/provision-net.js` probes the plane with
`caddy version` — one cheap, unprivileged, read-only command, the same posture as
`checkCaddyWiring`'s `caddy adapt`. It returns `null` when a proxy answers, or a string
naming the missing proxy. Both standup legs (`provisionInstance` step 6's owner, and
`domainAttachInstance`) call it and return `{ok:false, error: 'Ingress preflight failed: …'}`.

**It is deliberately NOT domain-gated.** That is the whole point: the domainless child is
the one ADR 0303 could not see.

**A missing binary is the only failure that proves there is no proxy.** Under remote exec
`boxExec` is `ssh <host> bash -s`, so a briefly-unreachable co-hosting box throws here too —
and answering that with "this plane has no reverse proxy, provision from a host that runs
Caddy" would be a confident wrong diagnosis, burning the intent's retry budget on a network
blip. Exit 127 (and the `command not found` / `is not recognized` wordings) is read as proof;
anything else returns *"could not confirm a reverse proxy on this plane"* with the real cause
leading. ssh reports its own failures as 255 and otherwise propagates the remote command's
status, so 127 still means "no caddy" across the hop.

**The three refusals are ordered capacity → ingress → wiring**, cheapest and most
fundamental first, and all three return before anything on the box changes:

1. `capacityPreflight` measures locally (ADR 0285 promises a full box is measured first and
   refuses before anything else runs);
2. ingress asks whether this plane has a proxy **at all**;
3. ADR 0303 then asks whether that proxy is wired for **this domain**.

Asking 0303 first is what produced the "edit a Caddyfile you do not have" answer, so this
ADR moves 0303's preflight behind the capacity measurement to make room. Both still refuse
before any mutation, so neither guarantee is weakened — only the precedence between two
refusals changes.

**No ingress seam, and no no-op backend.** The obvious symmetry with ADR 0306 would be a
`resolveIngress()` registry with a `none` implementation whose `writeSite`/`reload` are
no-ops. That is rejected: a no-op backend lets the standup **succeed** while leaving the
child unreachable, which is neither "reachable at a documented address" nor "refuses with a
clear error" — it is the silently-broken instance this task exists to prevent. ADR 0306's
seam exists because two real planes both need supervising; here the second plane cannot
serve a child at all, and the honest encoding of that is a refusal, not an implementation.

## Consequences

- **A compose self-host still cannot provision a child instance — it now says so.** This
  closes the failure mode, not the capability. Giving the container a real front door
  (a published port, a bundled proxy, an explicit localhost-only shape) remains unbuilt, and
  a future ADR that adds one replaces this refusal rather than extending it.

- **One extra `caddy version` per applied standup.** Read-only, unprivileged, and it runs
  after the capacity measurement, so a full box still refuses without it. A dry run never
  probes, and a dedicated droplet is skipped — Caddy comes from cloud-init there.

- **ADR 0303's territory is untouched.** "Caddy is here but mis-wired" is still its question
  and still its message; this ADR only answers the prior one. Every command string ADR 0303
  pins in `tests/provision_caddy_wiring.mjs`, `tests/provision.mjs` and
  `tests/provision_teardown_address.mjs` is unchanged.

- **Teardown is not covered.** `provision-teardown.js` removes the snippet and reloads with
  `allowFail: true`, so it already degrades rather than crashing. Left alone deliberately: a
  refusal on the teardown path would strand a row instead of cleaning it.

- **The probe is a capability question, not a configuration knob.** There is no
  `PROVISION_INGRESS` env var. A plane either answers `caddy version` or it does not, and an
  operator who wants provisioning to proceed needs a proxy, not a flag that says to pretend.
