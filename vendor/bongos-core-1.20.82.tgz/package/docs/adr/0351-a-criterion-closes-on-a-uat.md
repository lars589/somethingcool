# ADR 0351 — A criterion closes on a UAT, not on its linked tasks shipping

- **Status:** accepted
- **Date:** 2026-09-29
- **Task:** [task 1004392](https://cloudbongos.com/builders#/task/1004392) (goal 1000089 — working area 3, Human project management); the hall half is [task 1004402](https://cloudbongos.com/builders#/task/1004402)
- **Deciders:** the owner (Archon) decided every point below in chat on 2026-09-29, from options Claude laid out. Claude wrote the record.
- **Supersedes:** [ADR 0183](0183-criteria-close-themselves.md)'s rule that a criterion whose linked tasks all shipped is satisfied. Its delivery guard (at least one task actually shipped) is kept, as the first of three checks.

## Context

ADR 0183 made a criterion close itself the moment every task linked to it shipped, because criteria waiting for a human confirm were leaving the board wrong. It fixed that, and it made a criterion something you could close without anyone reading it: link any tasks, ship them, done.

It happened. The owner asked why working area 7 (goal 1000111) was blocked, and on the way the criterion `wa7-government` showed satisfied. Its text asks for fully customizable ranks and recommended governments for different project types and sizes. The six tasks that closed it were Board Room navigation work. On the live site there were zero custom ranks, the government recommendation read headcount only and named a charter the page itself marks "documented for later", and a board amendment ratified on 25 Aug had never taken effect. Every check the system ran said done.

The owner's diagnosis: a criterion has to be achieved in the code **and** in what a person can actually do on the live site, and closing one is a bigger review step than a task shipping.

## Decision

### 1. Three checks, and only the first is automatic

| Check | Passes when |
|---|---|
| **Code** | every linked task is terminal and at least one shipped (ADR 0183's delivery guard) |
| **Live** | the shipped work is running on the deployed site |
| **UAT** | a signed-in person performed the criterion on the live site, and a recording of it is stored |

`autoSatisfyShippedCriteria` still runs from the ship transaction and the reconciler sweep, with its goal and version cascade, but a criterion is a candidate only when it also carries a **current** sign-off: a `uat` or `backend_signoff` row in `lifecycle_criterion_uats` created no earlier than the newest linked ship. Work linked and shipped after a sign-off is work nobody checked, so that criterion waits for a fresh UAT.

### 2. "Awaiting UAT" is a state people can see

A criterion whose Code check passes and has no current sign-off reads **Awaiting UAT**, so the board shows the baseline is met (the owner asked for this explicitly). The states, derived in one place (`modules/lifecycle/criterion-uat.js` `uatState`) and carried on every criterion read (`/status`, the goal page, the review queue): Open · Awaiting UAT · Satisfied (UAT) · Satisfied (backend sign-off) · Satisfied (override) · Closed before UAT.

### 3. The signer cannot have shipped the work, and one step is the sign-off

Whoever submits the recording is the sign-off; there is no second approver. The server refuses them if they shipped any linked task, with one exception, the **project owner**, so a solo project cannot deadlock on its own work. The permission is `criterion.review`, the review queue's own atom (Metic+), because the sign-off is that review now.

### 4. The recording lives on the project's own server

An mp4 or webm, up to 100 MB, uploaded as a raw body, screened by type and magic bytes, stored under a server-minted name outside the git tree, and served only to signed-in builders. No third-party service, no new monthly cost.

### 5. Backend-only is decided when the criterion is written

A criterion with no screen can be marked **backend-only**, and then takes a recording-free backend sign-off, still from a non-shipper. The flag is an authoring act (`criterion.create` plus the goal's authoring wall, ADR 0154) and the server refuses to change it once the criterion is Awaiting UAT or closed, so the person closing it cannot choose to skip the recording.

### 6. Live is read where the site can tell, and attested where it cannot

On the Bongos hall the `npm-release` module already places every task in a deploy stage; it now provides that as the `deploy.taskWhere` port, and a sign-off is refused while any linked shipped task is not running on the site. Most instances have no such reading, and a reading that fails is treated the same way: the signer confirms they tested it on the live site, and the row records `live_basis = 'attested'`. An outage never blocks a person; it only moves the claim to their word, which is recorded as such.

### 7. Criteria already closed stay closed

The owner chose not to reopen them: reopening every satisfied criterion would reopen finished goals across the project. They read "Closed before UAT" because they carry no sign-off row. `wa7-government` alone was reopened, by hand, with a task (1004400) linked to it so the sweep cannot close it again.

### 8. The manual confirm becomes a recorded override

`POST /done-when/:id/satisfy` survives as the escape hatch (a criterion met some other way still needs one) but requires `override_reason`, writes an `override` row, and the criterion reads "Satisfied (override)" permanently.

### 9. The walk is a skill

`/goal-uat` scripts the live-site test from the criterion's words, collects the recording and signs it off, through `scripts/gds/uat.js`. `/goal-review` keeps only the residue a UAT cannot test (all linked work abandoned, or none linked). The hall controls are task 1004402.

## Consequences

- From the release that carries this, no criterion closes without a person. Goals whose last criterion is Awaiting UAT wait for one. That is the intended cost; ADR 0183's worry was a board that lies, and a board that says "Awaiting UAT" is telling the truth.
- The pile-up ADR 0183 was written against can come back as an Awaiting UAT backlog. `/goal-uat` and the hall controls exist to keep that queue fast to work; if it grows anyway, the fix is making UAT cheaper, not letting criteria close themselves again.
- Between this piece and task 1004402 the hall's Confirm button no longer closes a criterion; it explains that criteria close on a UAT.

## Alternatives rejected

- **A human review of the task list instead of the live site.** That is what `/goal-review` was, and it checked the tasks, not the words.
- **Two-person sign-off** (a recorder and a separate approver). Heavier, and the non-shipper rule already puts a second person on the work.
- **A link to a recording on an outside service.** Links rot and leave the ledger; the owner chose the project's own server.
- **Refusing the sign-off when the deploy reading fails.** That blocks a person on an outage; attestation is recorded as attestation.
- **Reopening every satisfied criterion.** Rejected by the owner (decision 7).
