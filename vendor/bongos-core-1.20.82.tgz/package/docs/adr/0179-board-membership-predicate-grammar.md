# 0179 — `rank:metic+` means metic and above; a bare `rank:metic` still means exactly metic

- **Status:** Accepted
- **Date:** 2026-08-19
- **Tasks:** [#1003094](https://cloudbongos.com/builders#/task/1003094) (goal 1000069, the Board Room). Blocks R25's sign-off ([#1003038](https://cloudbongos.com/builders#/task/1003038)); unblocks the charter-library fix ([#1003095](https://cloudbongos.com/builders#/task/1003095))
- **Amends:** [ADR 0175](0175-the-board-room-full-idea-ratification.md) §7 — the constitution's `board.membership` predicate
- **Related:** ADR 0016 (authority server-side, per request, uncached), 0034 (rank inheritance), 0174 (ranks are ranks), 0083 (a module may not import a sibling)

## Context

ADR 0175 gave the constitution a membership predicate with exactly one form, `rank:<key>`, resolved by
`WHERE rank_key = $1`. An **exact** match. So:

- `rank:metic` seated metics **only** — Archons excluded;
- `rank:xenos` seated **newcomers only**, not "everyone";
- **"Metic and above" was inexpressible.**

Everywhere else in this system a rank is a **ladder** and authority is cumulative — ADR 0034's
inheritance, the floor-derived permission seed, `requireRank('metic','archon')`. Board membership was
the single place `rank:X` meant *exactly* X, and nothing said so.

Rehearsing R25 end to end on a real Postgres found what that costs. An Archon proposed and ratified
`{membership: 'rank:metic', pass_rule: 'consent', …}` under the day-one monarchy. The apply worked
perfectly; the live constitution flipped. Then they tried to vote on the next Full Idea:

```
POST /government/board/items/7/votes  →  403 { code: 'not_board_member' }
```

**The owner flipped the switch and fell off their own board.** The escape hatch that saved the sandbox
is itself the diagnosis: an Archon can still *propose* (`board.item.open` floors at metic) but not
*vote*, so the board would have deadlocked at one member with no one able to undo it.

The charter library made the same mistake one layer up — it told owners Direct Democracy was
selectable today by typing `membership rank:xenos (everyone)`, which seats newcomers only. Its own
recommended charter, "a consent circle of all trusted members", was not expressible at all.

## Decision

### 1. Explicit grammar — a bare key still means exactly that key

The owner's decision (2026-08-18), recorded on the task. Three forms:

```
rank:metic          exactly metic                     (v1 form, meaning UNCHANGED)
rank:metic+         metic and every rank above it     (ladder)
rank:metic,archon   exactly these ranks               (union)
rank:xenos+,ops     the ladder from xenos, plus a custom rank
```

**Rejected — Option 1, redefining the bare form as "and above."** It was the smaller diff and it
matched every other authority read in the system, which is exactly what made it dangerous: it would
have silently changed the meaning of every constitution already ratified, including the shipped
monarchy default, the moment an instance upgraded. **Nothing in a government should change meaning
without a vote.** Because the bare form is untouched, this whole change is meaning-preserving.

**Rejected — Option 3, keep exact-match and fix only the prose.** Cheapest, and it leaves the ladder
inconsistency and the foot-gun in place. The library would have had to describe a limitation instead
of stating a rule.

### 2. `+` is defined only on the standard ladder

`RANK_ORDER` is the four-rung standard ladder; a project's **custom** ranks are DB rows with no
position on it. "Metic and above" is a real question; "and above" about a rank that sits on no ladder
is not. So `rank:some-custom+` is a **parse refusal**, not a guess — and a refusal resolves to
**nobody**, per the module's existing fail-closed rule. A bare custom key is unaffected.

### 3. The grammar is written once

It had been written **twice**: a shape regex in R05's config sanitizer and a parse regex in R06's
resolver, held together by a property test asserting "config keeps it ⇔ the resolver parses it". That
is sound while the grammar is one literal form. It stops being sound the moment a rule needs a
*lookup* — and `+` is a lookup. **Two hand-written copies of a rule containing a lookup is the same
class of drift that produced this bug**, so both now call one pure module,
`modules/government/membership-predicate.js` (it requires only `catalog`, so the sanitizer can use it
during boot without dragging in the DB layer).

### 4. The disenfranchisement guard

A change to the government that removes the person making it is **the one shape that cannot
self-correct**: once it lands they can no longer vote, including to undo it.

`proposeAmendment` now refuses such a proposal **before any write**, naming the one-character fix
(`rank:<key>+`). It is overridable with an explicit `acknowledge_self_removal` — the owner's "refuse or
loudly confirm" — because handing the franchise to a wider body and stepping back is a legitimate
constitutional act, and a system that cannot express it is telling owners what they may decide. The
acknowledgement is a **separate parameter, never a proposal field**: the strict validator refuses
unknown fields, which is what keeps it out of the ratified text.

### 5. The surfaces must describe the franchise they actually have

The hall's Constitution panel rendered the raw predicate, which would have read `rank:metic+` as
"builders holding the **metic+** rank" — naming a rank that does not exist and hiding what the suffix
does. **A panel that misdescribes who governs is this same bug one layer up**, so it now renders every
form in plain language, and says plainly that an unreadable predicate seats nobody.

## Consequences

- **No ratified constitution changes meaning.** A one-element rank set queries byte-identically to the
  old exact match. `rank:archon` — the shipped default — resolves to the same board it always did.
- **The two DB reads take a set** (`= ANY($1)`), with **DISTINCT**: a set can now match a builder
  through more than one key, and a double-counted member silently raises the bar a consent vote must
  clear.
- **The structural filters had to survive the rewrite**, and are tested against a real Postgres: a
  deactivated builder and a machine principal still never govern. A widened franchise that also admits
  a bot would be a worse bug than the one being fixed.
- **The parse result shape changed** from `{ rankKey }` to `{ rankKeys }`. Deliberate rather than
  cosmetic — a caller reading "the" key was reading a single-rank assumption that is no longer true.
- **Task 1003095 can now write the TRUE predicate for each charter** — Direct Democracy becomes
  `rank:xenos+`, Timocratic Republic `rank:metic+` — rather than rewording around a limitation. That
  is the sibling fix this ADR unblocks, and it is what makes R26's honesty half pass.
- **Still not a source of authority truth.** The predicate names ranks; who holds a rank stays a DB
  row resolved per request, uncached. Nothing here names a builder.
