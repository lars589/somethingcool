# The module plugin-API contract (`src/module-api.js` + `modules/*/`)

> **Decision record:** [ADR 0083](adr/0083-modular-architecture-strangler-build-plan.md) — the build plan.
> **Live state:** the shipped modules under `modules/` are the three feature modules `game`, `discord`, `art-pipeline` (+ `character-anim`, declaration-only; ADR 0088) and the carved core-domain modules `memory` (R72), `grading` (R73), `economy` (R77), `ideas` (R78), `security` (R79), `builder-settings` (R80), `onboarding` (R81), and `sessions` (R82) — see [ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) for the remaining carve sequence.
> **Author a new module:** jump to [the module-author recipe](#module-author-recipe).

The module system turns optional features into self-contained directories. Adding a feature is "drop `modules/<key>/`"; the loader discovers, validates, and mounts it — no core file changes. The **one-way rule** is the load-bearing invariant:

```
module  ──require──▶  src/module-api.js  ──▶  kernel
core    ──✗──────────────────────────────▶  module   (forbidden)
module  ──✗──────────────────────────────▶  module   (forbidden; use a seam)
```

Two fitness checks enforce it on every build — a violation is a red CI gate, not a style note.

---

## The cut: core vs modules

- **Core** is the trust kernel + the lifecycle state machine + the domains not yet carved: auth/identity/audit/rank (the kernel, [ADR 0091](adr/0091-bounding-the-kernel-and-db-carve.md) §1), the lifecycle (tasks, claims, versions, done-when, ship — never split), and the still-core domains (autonomy/MAS, the two web UIs) plus always-on infra (analytics, audit-log, gate-approvals, healthz, public). The remaining tranche-2 domains carve out per [ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1; the lifecycle stays core. (Sessions/BFG — the `session_records` corpus + data plane + the BFG scorer + session-pulse — carved to `modules/sessions/` at R82; like `memory` it registers no port and core never calls back in. The per-claim `session_logs` ship LOG + `builder_sessions` auth tokens stay core.)
- **Modules** are optional features an instance turns on via `config/modules.json` or env (the feature modules `game`, `discord`, `art-pipeline`, `character-anim`, and the opt-in skill modules `pixel-art` + `design-styles` of task 1004470), plus the **core-domain modules** that are `default: true` (always on unless disabled): `memory` (R72), `grading` (R73), `economy` — credits/cost/streaks/achievements/leaderboard (R77), `ideas` — inbox/capture/triage/blockers (R78), `security` — red-team reports + bounty (R79), `builder-settings` — wandering/skill/sound/render prefs + builder-needs (R80), `onboarding` — admission/onboarding-state/newcomer-restock (R81), and `sessions` — session_records corpus + BFG + session-pulse (R82). Each is a self-contained directory under `modules/<key>/`.

---

## The published doorway — `src/module-api.js`

The **only** core file a module may `require`. It re-exports the kernel capabilities a module legitimately needs:

| Export | What it gives a module |
|---|---|
| `requireBuilder` / `requireRank` / `rankMeetsThreshold` | Auth gates (ADR 0016). Modules self-gate per route: write routes call `api.requireRank(rank)`; authenticated read routes call `api.requireBuilder`; intentionally public read routes (e.g. leaderboard, claimable tasks) need no gate. The fitness check enforces the write-route rule; audit is composed at the kernel level before module routes mount. |
| `requireBfgPrincipal` | Gate a route to the BFG agent principal. |
| `allowBoxScope` | **Deprecated no-op** (task 1003894): the narrowing session scope it opted a route into was retired, and a session of an undeclared source is now denied on every route regardless. Kept so the doorway loses no export inside 1.x; drop at the next MAJOR. |
| `pool` | The shared Postgres pool. A module owns its `<key>_*` tables via its migrations. |
| `instanceDbName` | The resolved DB name (from branding). |
| `db` | Kernel-managed DB helpers (`getBuilderById`, `getBuilderGeminiKeyRow`, `setBuilderGeminiKey`, `clearBuilderGeminiKey`, `insertAuditLog`, `createTask`). Grow this additive-only. |
| `branding` | The branding contract resolver — the resolved instance strings. |
| `instanceConfig` | Module enablement config + env override resolution. |
| `seams` | The seam registry (`registerProvider`, `hasProvider`, `resolve`, `resolveOptional`, `emit`, `on`) — how modules cooperate without importing each other. |
| `buildInfo` | `{ version, commit, builtAt }` for `/health`-style routes. |
| `validateOrRespond` / `LIMITS` / `parseId` | Route helpers (input validation, standard limits, numeric route-param parsing). |
| `classifiers` | `LIVE_RANK_LADDER`, `VOTABLE_TASK_STATUSES`. |
| `logger(key)` | Returns `{ info, warn, error }` — namespaced so module log lines are attributable. |
| `CORE_VERSION` | The semver of THIS surface (see below). |

### `CORE_VERSION` and semver compatibility

`CORE_VERSION` is declared in `src/module-api.js`. It follows semver:
- **MINOR bump** — adding an export (safe; existing modules keep working).
- **MAJOR bump** — changing or removing an export (breaking; enabled modules must update their `coreVersion` range).

A module's `module.json` declares `"coreVersion": "^1.4.0"` (a semver range). The loader silently skips any module whose range no longer satisfies `CORE_VERSION`. `bongos upgrade` reports this ahead-of-time and exits 1 on any enabled mismatch, so the silent drop is the last resort, not the first signal.

**Current `CORE_VERSION`:** `1.8.0`

> The table below is a hand-maintained summary of the MINOR bumps only, and it lags. The authoritative, complete release ledger — every version, including the CI carrier patches — is [`docs/module-api-changelog.md`](module-api-changelog.md) ([ADR 0203](adr/0203-doorway-changelog-out-of-module-api.md) moved it out of `src/module-api.js`); the live value is the `const CORE_VERSION` literal in `src/module-api.js`.

| Bump | What it added |
|---|---|
| 1.0.0 | Initial doorway: auth gates, pool accessor, config/branding, seams. |
| 1.1.0 | Contribution seam: `contribute`/`contributions`/`collectContributions`/`listContributionPoints`. |
| 1.2.0 | dev-box needs: `auth.allowBoxScope`, `db.getBuilderById`/`setBuilderBoxBlocked`, `buildInfo`, `validateOrRespond`/`LIMITS`. |
| 1.3.0 | art-pipeline needs: `db.getBuilderGeminiKeyRow`/`setBuilderGeminiKey`/`clearBuilderGeminiKey`. |
| 1.4.0 | discord needs: `db.insertAuditLog`/`createTask`, `inbox.captureIdea`, `LIVE_RANK_LADDER`, `VOTABLE_TASK_STATUSES`. |
| 1.5.0 | kernel-bounding (R68, ADR 0091): adds `withTx`; relocates `setBuilderBoxBlocked` → dev-box (lockstep-MINOR). |
| 1.6.0 | grading carve (R73): adds the kernel trust classifiers `routeRankCheck`/`permissionPathCheck` + `llmCache` (domain leak). |
| 1.7.0 | economy carve (R77): adds `llmPricing` (domain leak). |
| 1.8.0 | ideas carve (R78, ADR 0093 §5): adds `parseId`; **retires** the `captureIdea` doorway leak → the `ideas.capture` kernel port (lockstep-MINOR). |

---

## The manifest schema — `module.json`

Every module must have a `module.json` at its root (`modules/<key>/module.json`). The loader validates it against `src/module-loader/manifest-schema.js` before mounting.

```jsonc
{
  "key":         "discord",           // REQUIRED. ^[a-z][a-z0-9-]*$ — must match the dir name.
  "title":       "Discord",           // REQUIRED. Human label.
  "description": "…",                 // REQUIRED. One sentence.
  "version":     "1.0.0",             // REQUIRED. The module's OWN exact version "X.Y.Z" (not a range) —
                                      //   what update, rollout channels and re-assessment name (task 1003781).
  "coreVersion": "^1.4.0",           // REQUIRED. semver range of CORE_VERSION this module supports.
  "default":     false,               // OPTIONAL (default false). Fail-safe when no config names it.
  "author":      "…",                 // OPTIONAL. Attribution (ADR 0107 §2) — portable, not a cross-Bongos FK.
  "origin":      "…",                 // OPTIONAL. Origin instance/project this module was built in.
  "license":     "AGPL-3.0",          // OPTIONAL. License this module is offered under.
  "maintainer":  "…",                 // OPTIONAL. Who to credit/contact if this module is upstreamed.
  "maintenance": {                    // OPTIONAL in schema, REQUIRED to upstream (ADR 0166).
    "status": "maintained",           //   core-maintained | maintained | deprecated | orphaned
    "since":  "1.8.0",                //   OPTIONAL. Core version the status took effect.
    "removeAfter": "1.12.0",          //   OPTIONAL (sunset only). Core version after which it may go.
    "successor":   "econ-v2",         //   OPTIONAL. Module key that replaces it.
    "note":        "…"                //   OPTIONAL. The path out, in one sentence.
  },
  "contributes": {                    // REQUIRED object (may be empty {}).
    "routes":      ["discord"],       //   route-factory files in routes/ (one export = () => Router())
    "rooms":       ["WorldRoom"],     //   Colyseus room classes (game module only)
    "pollers":     ["discord-bot"],   //   background pollers (start/stop lifecycle)
    "disciplines": ["artist"],        //   builder disciplines this module adds
    "skills":      ["otb-tile-generate"], // slash-command skills it ships
    "uiSections":  ["task-where"],    //   hall/status UI sections gated by window.__MODULES__. Ship public/hall-widget.js
                                      //   and it is injected into the hall index; ship public/task-widget.js and it
                                      //   is injected into a task's page before task.js, to fill #task-contrib on
                                      //   `otb:task-shown` (task 1004301). The page itself names no module.
    "webSurfaces": [{ "host": "status.", "dir": "public" }], // static web surfaces: a Host PREFIX (BV1.R84)…
                                                            // …or { "apexRoot": true, "dir": "public" } for the
                                                            // apex root (ADR 0218). One or the other, never both.
    "migrations":  true               //   true → modules/<key>/migrations/*.sql applied if enabled
  },
  "provides": ["discord.isLinked"],     // OPTIONAL. Seam PORTS this module registers a provider for.
  "consumes": [],                       // OPTIONAL. Seam ports this module resolves (required caps).
  "prerequisites": { "modules": [] },   // OPTIONAL. Other modules that must be enabled first.
  "spend": { "requiresPayer": true },   // OPTIONAL. This module spends MONEY for whoever calls it.
  "howto": { "artifactUrl": "https://claude.ai/…" }, // OPTIONAL. A Claude page beside HOWTO.md — never instead of it (ADR 0347 D3).
  "dependencies": { "discord.js": "^14.26.4" } // OPTIONAL. External npm deps this module needs at runtime.
}
```

An unknown key throws at validate time — typos fail loud (top-level attribution fields have no closed allowlist; only `contributes` sub-keys do).

### `spend` — "my surfaces spend real money for whoever calls them" ([ADR 0282](adr/0282-a-module-that-spends-for-its-callers-declares-a-payer-and-the-core-refuses-it-without-one.md))

Declare `"spend": { "requiresPayer": true }` when a route of yours can spend money on behalf of the
caller — a paid model call, a metered third-party API, anything with a per-request bill. The core
then **refuses to enable your module** when the project's composed join door is `open` (anyone may
sign up) and the project has named no payer, and it refuses at **config load**, so your routes never
mount at all rather than 402-ing one caller at a time. A closed-door instance is unaffected.

The key set is closed: a misspelled `requirespayer` fails validation rather than silently declaring
no spend, because that is the direction that costs money.

**Why the declaration lives here rather than in the core.** The kernel may not name a module key
(fitness Check 10), so the guard is true of any module that says this about itself — which means the
next metered module inherits it by declaring one line instead of by someone remembering to widen a
list in `src/modules.js`.

**What declaring it does NOT give you.** A per-payer ceiling is still yours to build: the core
decides whether you may be *enabled*, not what you may *cost*. `modules/agents/lib/spend-ceiling.js`
is the worked example — it sums the module's own ledger per payer per calendar month and fails
closed on every unknown, including a ledger read it cannot complete.

### `dependencies` — a module's own npm deps ([ADR 0138](adr/0138-bundled-module-deps-declared-per-module.md))

`@bongos/core` ships lean — its synthesized `package.json` declares only `express` + `pg` ([ADR 0108](adr/0108-instance-composition-configurable-root.md)). A bundled module that needs an external npm package at runtime (e.g. `discord` → `discord.js`) declares it in its own `module.json` `dependencies` (`{ "<npm-name>": "<semver-range>" }`, schema-validated). **Core does not carry it**, so the *consumer* must — greenfield `bongos init` composes the ENABLED modules' declared deps into the instance `package.json` (`enabledModuleDeps` → `buildInstancePackageJson`; an explicit pre-existing pin wins, `@bongos/core` is always set), and the R89 cutover preserves the monolith's existing dependency closure. If a module needs a dep and neither declares it nor is it in the consumer's closure, an instance that enables the module crashes at boot — so **declare it here**.

**Attribution (`author`/`origin`/`license`/`maintainer`) is portable metadata, not a cross-Bongos link** — each repo runs its own Bongos with its own builder identities ([ADR 0100](adr/0100-two-repo-instance-model.md) §3), so credit travels *with the module* rather than through a foreign key ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §2). `bongos module new` stamps all four as TODO placeholders (license defaults to `AGPL-3.0`) so a module carries its authorship from the day it's scaffolded, not bolted on later at upstream-submit time.

**`bongos module list [--catalog] [--search <text>] [--json]`** ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §2/§3, [ADR 0167](adr/0167-module-catalog-source-vs-provenance.md)) is the browsable catalog from the terminal: every module on disk with its enabled state, its author + origin credit, and its upkeep posture. `--catalog` narrows to the **core-shipped** modules — the shared catalog an instance opts into (§6, default-off). Two axes travel on each row and they are *not* the same question: **`source`** (which tree ships it — the core package or this instance's own repo, read structurally from the loader's discovery root, [ADR 0108](adr/0108-instance-composition-configurable-root.md) §1) and **`provenance`** (who built it, derived from the declared `origin`). A core module that declares no attribution is credited to the platform and the credit is **marked inferred** (`*`) rather than left blank or silently invented. The hall's Modules tab renders the same model (`src/module-loader/catalog.js`) via `GET /modules`, so the two surfaces cannot drift.

**`bongos module check <key> [--sign-off "Name <email>"]`** ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §4) is the submit-time pre-check a module must clear before it can be upstreamed. It reuses (never re-types) the public-mirror publish denylist (`scripts/gds/publish-manifest.js`'s `matchesDeny`) to reject content that cannot ship under AGPL (game content, pixel art, copyrighted reference material) — deliberately the DENY half only, since a brand-new module is never on the publish ALLOWLIST until it's accepted into core (§6). It also requires `module.json`'s `license` to be AGPL-3.0 (inbound = outbound) and a declared `maintenance` posture — acceptance is a commitment to upkeep, so a module with no `maintenance.status`, or one already `deprecated`/`orphaned`, is refused ([ADR 0166](adr/0166-module-maintenance-and-deprecation-policy.md); see below). On a pass, `--sign-off` records a lightweight DCO-style affirmation (own work, licensed AGPL-3.0 — never a copyright-assignment CLA) to `modules/<key>/.upstream-signoff.json`.

### `maintenance` — who keeps this module true as the core advances ([ADR 0166](adr/0166-module-maintenance-and-deprecation-policy.md))

A module pinned to an old `coreVersion` rots as the core advances ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §7). The `maintenance` block is where a module states, in a place the upgrade pre-check can read, **who owns that upkeep** — and what happens if nobody does. It is optional in the schema (pre-policy manifests keep validating) but **required to be upstreamed**.

| `status` | Means | What it owes |
|---|---|---|
| `core-maintained` | The core team owns it; a core change that breaks it is the core's problem to fix before shipping. | — |
| `maintained` | A named person/handle owns it. | A non-empty top-level `maintainer`. An unnamed maintainer is rejected — that *is* the orphaning failure; say `orphaned` instead. |
| `deprecated` | On the way out. | A `successor` and/or a `note` (the deprecation path). May carry `removeAfter`. |
| `orphaned` | Nobody owns it. | A `successor` and/or a `note`, so the next reader gets the situation and not just the label. |

`orphaned` is a first-class, declarable state on purpose: a policy that only permits happy statuses gets satisfied by lying. `removeAfter` is rejected on a non-sunset status, and is **declarative** — nothing deletes a module automatically; `bongos upgrade` only reports that the core has advanced past the date.

**What surfaces it.** `bongos upgrade` appends a maintenance hint to every `coreVersion` mismatch row and rolls up deprecations, modules past `removeAfter`, and modules with no declared upkeep. A **real** bump (`bongos upgrade --to <version>`) does the same via `preflightModules` → `reportModulePreflight`, printed before the blocking check returns so a refused bump reports them too. The asymmetry is deliberate: an incompatible **enabled** module refuses the bump; an incompatible **disabled** one never blocks but is always reported with its owner named — accepted catalog modules ship `default: false` ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §6), so *every* rotted catalog entry is disabled by construction, and silence there is exactly how the catalog fills with broken entries. `GET /modules` and the hall Modules tab show an `upkeep:` chip, including `upkeep: undeclared`.

**`bongos module submit <key> [--sign-off "Name <email>"]`** ([ADR 0107](adr/0107-module-upstreaming-contribution-to-core-catalog.md) §1) re-runs the §4 pre-check + requires a sign-off, then packages the module (manifest + a full file snapshot + the sign-off) and files it into the rank-gated (metic+archon) upstreaming review queue via `POST /modules/:key/submit` — the same route the hall "Modules" tab's submit button calls. Refuses (exit 1) if the pre-check fails or no sign-off can be found/recorded. The queue currently lives in **this instance's own DB**, not a live call to the extracted core repo — see [ADR 0135](adr/0135-module-upstream-submission-interim-queue.md) for why, and `GET /modules/submissions` to read it back.

---

## The loader — `src/module-loader/loader.js`

> **Two-root discovery ([ADR 0108](adr/0108-instance-composition-configurable-root.md) §1, task 1881/W1 shipped):** `DEFAULT_ROOTS` resolves `modules/` off `resolveCoreRoot()` ([`src/instance-config.js`](../src/instance-config.js)), not a hardcoded `__dirname`-relative path. Today `resolveCoreRoot() === resolveInstanceRoot()` (both the repo root), so discovery is unchanged. Once a consumer installs the core as a package, an **instance-owned** `modules/` directory (host-authored modules, living in the instance repo, not the core package) becomes possible — the loader would then discover across both roots via `opts.roots`, same mechanism as below, no core-file change. That instance-root modules directory does not exist yet; this is the seam it will attach to.

At boot the loader (called from `src/modules.js` and the route mounter) runs:

1. **Discover** — scan `modules/*/module.json` (and any extra roots passed via `opts.roots`).
2. **Validate** — run each manifest against the schema; invalid manifests are skipped with an error log, never a crash.
3. **`coreVersion` check** — test the manifest's `coreVersion` range against `CORE_VERSION`; mismatch = skip with a warning.
4. **Enablement filter** — check `isModuleEnabled(key)` (env override → `config/modules.json` → `config/modules.neutral.json` → `manifest.default`); disabled modules are skipped.
5. **Mount routes** — for each `contributes.routes` key, `require(`modules/<key>/routes/<routeKey>.js`)` and call the factory. Audit is already composed at the kernel level (routes.js runs `auditMiddleware` before the loader mounts anything); each route self-gates at the appropriate rank via `api.requireBuilder` / `api.requireRank`. The fitness check (`BV1.R44`) ensures every write route is rank-gated.
6. **Start pollers** — call each `contributes.pollers` file's `start()` on successful mount.
7. **Serve web surfaces** — a `contributes.webSurfaces` entry says WHERE the surface answers in exactly one of two ways, never both and never neither ([ADR 0218](adr/0218-the-apex-root-web-surface.md)):
   - `{ host: "status.", dir: "public" }` — a **Host-header prefix**. `serve-internal.js` (via `loader.moduleWebSurfaces`) serves `modules/<key>/<dir>/` on the matching host, with the content-hash-stamped index + branding injection the status page always used. This is how the status dashboard (`status-ui`) reaches `status.<apex>` with no core edit (BV1.R84).
   - `{ apexRoot: true, dir: "public" }` — the **apex root**: whatever host is left once the subdomains are taken (`isApexHost` = `!isStatusHost && !isBuildersHost`). Declared by `public-landing`, the front door, and served by `platform-server.js`'s dedicated block. **`host: ""` is rejected, not read as "the root"** — the routers match with `host.startsWith(s.host)` and every string starts with `""`, so an empty prefix would answer on `builders.`/`status.` too and make `isModuleSurfaceHost()` true for every request, silently un-serving the hall.

   A disabled module's surface is never built, so its host routes nowhere — and for the apex root that means the front door is gone and the 404 tail answers.
8. **Apply migrations** — enabled-gated; `migrate.sh` discovers `modules/<key>/migrations/*.sql` only when the module is enabled.

The loader is safe-by-construction: with no `modules/` dir it returns empty and all functions are no-ops — the instance behaves identically to before the module move.

**Resolution precedence for enablement (highest wins):**

```
env override  →  config/modules.json  →  config/modules.neutral.json  →  manifest.default (false)
```

Env override key: `<envPrefix>_MODULE_<NAME>` (`NAME` = upper-snake of the key; `npm-release` → `NPM_RELEASE`). Example: `OTB_MODULE_DISCORD=0`.

A fresh instance with **no** config resolves to **vanilla**: every module off (fail-to-vanilla).

---

## Seam registry — `src/module-seams.js`

Modules cooperate through the kernel switchboard — never by importing each other. There are two seam types:

### Ports (required capability — single provider)

A provider module calls `api.seams.registerProvider(portName, fn)` at mount time. A consumer calls `api.seams.resolve(portName)` to get the function and call it. `resolve` throws if no provider is registered — a missing required capability is a fail-clear configuration error, not a silent no-op. `resolveOptional(portName, defaultFn)` returns `defaultFn` when nothing is registered (for graceful degradation on a module-less instance).

### Events (optional reaction — zero-or-many listeners)

A module calls `api.seams.emit(eventName, payload)` to broadcast. Any module that called `api.seams.on(eventName, listener)` at mount time reacts. `emit` isolates listener errors — one bad listener never breaks the emitter or other listeners.

### Live seam registry

| Port / Event | Provider | Consumer(s) | Contract |
|---|---|---|---|
| Port: `game.staticRoot` | `game` | `server.js` static-serve | `() → string` — absolute path to the game's static root. |
| Port: `game.registerRooms` | `game` | `server.js` Colyseus setup | `(matchMaker) → void` — registers WorldRoom + QueueRoom. |
| Port: `game.precreateWorldRoom` | `game` | `server.js` pre-create step | `(matchMaker) → Promise<void>` — pre-creates the singleton room. |
| Port: `discord.isLinked` | `discord` | core `routes/me.js` | `(builderId) → Promise<bool>` — whether the builder has linked their Discord account. |
| Port: `art.sharedKeyConfigured` | `art-pipeline` | core `routes/me.js` | `() → Promise<bool>` — whether a shared Gemini key is configured for the instance. |
| Port: `grade` | `grading` (R73) | the lifecycle (`routes/tasks.js`, `routes/public.js`) | the quality-gate capability the ship path resolves instead of importing `grader.js` ([ADR 0091](adr/0091-bounding-the-kernel-and-db-carve.md) §4). |
| Port: `reward` | `economy` (R77) | the lifecycle (`db.applyGrade`/`confirmTask`/…) + read routes (`me.js`/`public.js`/`builders.js`/`sessions.js`) | a **transaction-participant** port — credit/achievement writes take the caller's tx `client` ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §2). |
| Port: `ideas.capture` | `ideas` (R78) | the `discord` module (`discord-inbound.js`) | `(idea) → Promise<row>` — file an `idea_inbox` row. The **first module→module port** (every other is consumed by core); retired the `captureIdea` doorway leak ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §5). |
| Port: `security` | `security` (R79) | core `routes/public.js` (`/public/bounty-table`) | `{ bountyTableDetailed(), bountyTable() }` — the env-aware red-team bounty payout schedule. Core reads via `resolveOptional('security').bountyTableDetailed()` instead of importing the module (security is default-on; only <redacted> moved — [ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1, [02-module-map §5](design/modular-architecture/02-module-map.md)). |
| Port: `builder-settings` | `builder-settings` (R80) | core `routes/me.js` (`GET /me`) + `cascade-dispatch.js` | `{ getBuilderBehaviorPrefs, describeWandering, describeRender, computeNeeds, skillCeiling }` — the per-builder prefs read surface. The `GET /me` aggregator resolves it for its wandering/render/needs slices; the dormant cascade router for the skill ceiling. Default-on; degrades gracefully when off ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1, [02-module-map §2](design/modular-architecture/02-module-map.md)). |
| Port: `onboarding` | `onboarding` (R81) | the lifecycle (`db.js` claim/ship — transaction-participant `markStage`) + `auth.js` + `routes/me.js`/`builders.js`/`tasks.js`/`claims.js` | `{ getState, shapeForApi, safeMarkStage, markStage, broadcastGraduation, restockForClaim, restockAll, SOURCE_TAG }` — the onboarding state-machine + newcomer-restock surface. The FIRST core→module port the lifecycle ticks inside its own txn (alongside `reward`). Default-on; degrades to best-effort no-ops when off ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1). |
| Port: `request.divert` | `npm-release` (its version preview; task 1004300, [ADR 0349](adr/0349-a-version-preview-is-a-sandboxed-child-the-web-tier-launches.md)) | core `src/platform-server.js`, just before `mountInternalSurfaces(app)` | `(req, res, next) → void|Promise` — an **optional** provider, looked up on every request. It either answers the request or calls `next()`. With no provider registered the kernel calls `next()` at once, so an instance without the module is served exactly as before; a provider that throws is treated as absent for that request. Consumed with `resolveOptional`, never `resolve`. |
| Event: `builder.secrets-scrub-needed` | core `db.js` (`deactivateBuilder`) | `art-pipeline` (when installed) | `{ builderId, actor }` — task 1003338 / [ADR 0332](adr/0332-offboarding-secret-scrub-semantics.md): best-effort teardown port for a MODULE-owned builder-keyed secret (today: the Gemini BYOK key, `gemini_key_enc`/`last4`/`set_at`). Core does not write those columns directly (ADR 0102) — the module listens and clears its own store. `github_oauth_tokens` (core-owned) is deleted synchronously inside `deactivateBuilder`'s transaction instead, no event needed. |

---

## Rank-gate rule

Every write route in a module **must** be rank-gated:

```js
router.post('/my-feature/thing', api.requireRank('metic'), (req, res) => { … });
```

The `BV1.R44` fitness check (`fitness.js`) walks `modules/**/routes/` with the same "unknown write = blocker" rule that covers the core routes. A module write route that bypasses rank fails the build — this is not advisory.

Authenticated read routes call `api.requireBuilder`. Intentionally public read routes (leaderboard, version progress, claimable tasks list, etc.) need no gate — they are explicitly written without one.

---

## Module-owned migrations — `modules/<key>/migrations/`

A module puts its SQL files under `modules/<key>/migrations/NNN_description.sql` and sets `"migrations": true` in its manifest. `scripts/migrate.sh` discovers and applies them **only when the module is enabled**. The `schema_migrations` table is stem-keyed, so relocating a migration between directories (e.g. from `migrations/game/` to `modules/game/migrations/`) never re-runs it on prod.

Rules (enforced by the `BV1.R45` fitness check):
- **Own your namespace** — every table must be prefixed `<key>_*`.
- **Additive only** — `DROP TABLE`, `DROP COLUMN`, and destructive `ALTER` are rejected by the fitness check. **One acknowledged exception** (task 1003092): the *contract phase* of an expand-then-contract rename ([ADR 0177](adr/0177-goal-membership-kind.md)) may carry exactly `ALTER TABLE <own_table> DROP COLUMN <legacy>` when the file bears the same `-- forward-unsafe: <reason>` pragma core migrations use — one statement, one column, your own table; `DROP TABLE`, `TRUNCATE` and a bare `DROP CONSTRAINT` stay rejected even under the pragma (`scripts/gds/fitness-migration-contraction.js`).
- **Disable preserves data** — there is no down-migration; a disabled module's tables simply are never created (or are left untouched).

---

## Live module roster

| Module | `contributes` | Seam ports | `coreVersion` |
|---|---|---|---|
| **`game`** | routes: `game`; rooms: `WorldRoom`/`QueueRoom` | provides `game.staticRoot`, `game.registerRooms`, `game.precreateWorldRoom` | `^1.4.0` |
| **`discord`** | routes: `discord`, `bug-attachments`; pollers: `discord-bot` | provides `discord.isLinked`; consumes `ideas.capture` | `^1.4.0` |
| **`art-pipeline`** *(host module — no `module.json` in the core, never published: ADR 0098, ADR 0272)* | routes: `art-key`; uiSections: `art` (on an instance that carries it). Its skills are **not** its own any more — they are `pixel-art`'s, below; `artist` is a core discipline since ADR 0272 | provides `art.sharedKeyConfigured` | `^1.3.0` |
| **`character-anim`** *(host module — no `module.json` in the core)* | — its `otb-character-review` skill is `pixel-art`'s since task 1004470 | — (runtime is the Python pipeline under `art/`) | `^1.4.0` |
| **`pixel-art`** *(default-off; task 1004470)* | skills: `otb-tile-generate`, `otb-design-review`, `otb-character-review`, `otb-feedback-capture`, `otb-figma-sync` — skill text only, never a reference map, palette or generated art | — (declaration-only: NO port, NO routes; turning it on lands the five skills, the pipeline they drive is the instance's own `art-pipeline`) | `^1.19.0` |
| **`memory`** *(core-domain, default-on; R72)* | routes: `memory`, `search`, `learnings` | — | `^1.5.0` |
| **`grading`** *(core-domain, default-on; R73)* | routes: `grade` | provides `grade` | `^1.6.0` |
| **`economy`** *(core-domain, default-on; R77)* | routes: `cost`, `leaderboard`, `reward` | provides `reward` | `^1.7.0` |
| **`ideas`** *(core-domain, default-on; R78)* | routes: `inbox`, `blockers` | provides `ideas.capture` | `^1.8.0` |
| **`security`** *(core-domain, default-on; R79)* | routes: `reports` | provides `security` | `^1.8.0` |
| **`builder-settings`** *(core-domain, default-on; R80)* | routes: `settings` (the `/me/*-prefs` endpoints) | provides `builder-settings` | `^1.8.0` |
| **`onboarding`** *(core-domain, default-on; R81)* | routes: `onboarding` (the `/access-requests` admission endpoints) | provides `onboarding` | `^1.9.0` |
| **`sessions`** *(core-domain, default-on; R82)* | routes: `sessions` (the `/sessions` upload + cross-builder search/deep-dive) | — (registers NO port, like `memory`; *resolves* the economy `reward` port) | `^1.10.0` |
| **`autonomy`** *(core-domain, default-on; R83)* | routes: `autonomy` (the `/autonomy/precheck`); pollers: `routine-timers` | — (registers NO port; reaches the lifecycle `tallyPeerVotes` via the doorway) | `^1.11.0` |
| **`status-ui`** *(core-domain web surface, default-on; R84)* | webSurfaces: `{ host: "status.", dir: "public" }` (the status dashboard at `status.<apex>`) | — (registers NO port, NO routes; pure host-routed static surface) | `^1.11.0` |
| **`hall-ui`** *(core-domain web surface, default-on; R85)* | webSurfaces: `{ host: "builders.", dir: "public" }` (the authenticated builders' hall) | — (registers NO port; keeps a DEDICATED serving block in `serve-internal.js`, unlike `status-ui`) | `^1.11.0` |
| **`public-landing`** *(core-domain web surface, default-on; task 1003322 / ADR 0218)* | webSurfaces: `{ apexRoot: true, dir: "public" }` (the front door at the apex root: `/`, `/projects`, `/create`, `/privacy`, `/terms`, `/contact`) | — (registers NO port; the first surface that is not a subdomain, and like `hall-ui` it keeps a DEDICATED serving block — in `platform-server.js`) | `^1.19.0` |
| **`lifecycle`** *(core-domain, default-on; R86)* | routes: `tasks`, `claims`, `versions`, `done-when`, `goals`, `dependencies`, `gate-approvals`, `analytics` | provides `lifecycle` (createTask, classifyTaskKind, tallyPeerVotes, work-tracking reads); resolves `reward`, `onboarding` | `^1.12.0` |
| **`provisioning`** *(default-off; [ADR 0111](adr/0111-instance-hosting-provisioning-module.md))* | routes: `provisioning` (own+Archon rank-gated) | provides `provisioning.instanceState` | `^1.14.0` |
| **`ui-design`** *(core-domain, default-on; [ADR 0197](adr/0197-the-ui-design-module.md))* | skills: `design`, `design-sync`, `figma-design-sync` (the /design playbook + the two tool round-trips) and nothing else since task 1004470; the ADR 0081 adapters, sync CLIs, validator, kit and style library live in the module dir | — (registers NO port, NO routes; declaration-only — disabling it withdraws the skills and touches no served surface) | `^1.19.0` |
| **`design-styles`** *(default-off; task 1004470)* | skills: the thirteen design-style skills split out of `ui-design` — `design-taste-frontend`, `high-end-visual-design`, `redesign-existing-projects`, `impeccable`, `style`, `minimalist-ui`, `industrial-brutalist-ui`, `gpt-taste`, `stitch-design-taste`, `image-to-code`, `imagegen-frontend-web`, `imagegen-frontend-mobile`, `brandkit` — with `skills/policy.json` + `PREAMBLE.md` (ADR 0198) | — (declaration-only; `/design` names them when it is on and says they are off when it is not) | `^1.19.0` |

Each module's `modules/<key>/CLAUDE.md` is the authoritative per-module reference (files, seams, tests, what is NOT in the module).

> **Only <redacted> is the `security` module** ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1, [02-module-map §5](design/modular-architecture/02-module-map.md)): the red-team / vulnerability reports + bounty (rank-gated Metic+). <redacted> — the `permission-path-check`/`route-rank-check` authz machinery AND the `/security/adr` threat-model reader + Archon-only `/security/docs` exploit-detail store (`src/bongos/routes/security.js`, backed by the core `db.js` `security_docs` queries) — stays kernel.

> **`character-anim` is a host-side declaration** ([ADR 0088](adr/0088-consistent-character-generative-animation.md)): consistent-character generative animation. It has no `module.json` in the core and no routes/seams/migrations; the `otb-character-review` skill it was documented as contributing is the `pixel-art` module's since task 1004470, which is what an instance turns on to get it. The runtime — the contract entry point `art/pipeline/character_anim_module.py` (`animate(model-sheet + action-spec) → graded registered frame set + manifest`), with a config-driven rubric (a `character_anim` family) and a pluggable generator backend — lives under `art/` like the rest of the art pipeline, the same way `art-pipeline` keeps `art/` at the repo root.

---

## API surface — `src/modules.js`

`src/modules.js` is now a **back-compat facade** over the loader. Its exports are stable and unchanged:

| Export | Behaviour |
|---|---|
| `isModuleEnabled(name)` | Gate a mount or feature. Throws on an unknown name (programmer error). |
| `enabledModules()` | The resolved on-set (an array of enabled module keys). |
| `enabledDisciplines()` | The union of `contributes.disciplines` across enabled modules. |
| `clientModules()` | `{ enabled: {…booleans}, disciplines: […] }` — injected into hall/status HTML as `window.__MODULES__` and served at `GET /api/bongos/public/modules`. Front-ends read it to hide UI sections for off modules. |
| `resolveModules(opts)` | The pure resolver (unit-tested, zero I/O). |

---

## Module-author recipe

### 1. Scaffold

```sh
bongos module new <key>
```

This creates `modules/<key>/` with:
- `module.json` — a valid manifest seeded for the current `CORE_VERSION`.
- `routes/<key>.js` — a sample route factory with a health GET and a comment explaining the rank-gate rule.
- `migrations/` — empty directory.
- `ui/` — empty directory.
- `CLAUDE.md` — per-module reference explaining the boundary, the seam pattern, and what to keep out of the module.
- `HOWTO.md` — the how-to for the person who installs the module: the five required sections as headings, each with its prompt in an HTML comment (see §6).

### 2. Write the module

- Reach core only through `require('../../../src/module-api')`. Never deep-import core internals.
- Every write route: `api.requireRank('metic')` (or a higher rank). The fitness check enforces this.
- Register seam ports/listeners in the route factory (guarded by `api.seams.hasProvider` to survive re-instantiation in tests).
- Put DB tables in `modules/<key>/migrations/NNN_*.sql`, namespaced `<key>_*`.

### 3. Declare

Update `module.json`:
- Set `version` to the module's own exact version (`"1.0.0"` for a first release; bump it on every change you ship).
- Set `coreVersion` to `^<CORE_VERSION>` (the current doorway version).
- Declare everything the module contributes in `contributes`.
- List ports under `provides`/`consumes`.

### 4. Enable

Add the module to `config/modules.json`:

```json
{ "modules": { "<key>": true } }
```

Or via env: `<PREFIX>_MODULE_<KEY>=1`. The loader discovers and mounts it on next boot — no core file changes.

### 5. Verify

Run `bongos upgrade` to confirm coreVersion compatibility, then `node scripts/gds/fitness.js` to confirm the boundary checks pass. The `unit` CI job runs fitness on every PR.

### 6. Publish to the store (optional)

`bongos module publish <key>` packs `modules/<key>/` as one version for the Bongos-hosted module store ([ADR 0338](adr/0338-modules-travel-through-a-bongos-hosted-store.md)): a tarball plus hash manifest in the core release's own format (`scripts/gds/module-artifact.js` over `artifact-format.js`), then uploads it to `POST /store/modules/:key/versions`. `--dry-run` packs without uploading; `--out <dir>` also writes the tarball and its manifest.

- The version is `module.json`'s `version`. Each version is published **once** and must be newer than the last — bump it to publish a fix.
- Your first publish of a key makes you its author; only the author can publish later versions, and a delisted key takes none.
- The publish denylist applies (ADR 0098), plus a refusal of credential-named files (`.env*`, `*.pem`, `*.key`, `id_rsa`, …) anywhere in the module. The store re-checks every hash and the denylist itself.
- Gate: Metic+ (`module.submit`) for now. This is not `bongos module submit`, which proposes a module *into* core.
- **A how-to is required** ([ADR 0347](adr/0347-every-store-module-ships-a-how-to.md)). `modules/<key>/HOWTO.md` is what a buyer reads — the store shows it as the module's page — so it is written for the person who installs the module, not for an AI working inside it (that is `CLAUDE.md`). It is plain Markdown: any AI or person can write it. Publish refuses the version unless it has these five level-2 headings, in any order and any case, each with some text under it: `## What it does`, `## Install and enable`, `## How to use it` (with one worked example), `## Configuration` ("None." is fine) and `## Limits and known issues` ("None known." is fine). HTML comments don't count as text, so the scaffold's prompts must be replaced. The refusal names each failing section. The check is one function, `checkHowto` in `scripts/gds/module-artifact.js`; the CLI runs it before uploading and the store runs it again on upload, so a hand-built upload can't skip it. `bongos module check` reports it as advice only — an upstream submit is not gated by it. Install and update don't re-check it, so a version published before the gate still installs. The file travels in the tarball, so its hash pins it to the version. An optional `howto.artifactUrl` in `module.json` (an `https://` link on `claude.ai`) is shown as an extra, never graded.

### 7. Install from the store

`bongos module install <key> [--version X.Y.Z]` acquires a module from the store and places it under the instance's `modules/`. Three calls: `POST /store/modules/:key/acquire` takes your entitlement and names the version (the newest unless you pick one), `GET /store/modules/:key/versions/:version/tarball` downloads it, and once the files are placed, `POST /store/modules/:key/acquired` records the exact version.

- The download is checked with `verifyModuleArtifact`, the same checker the store runs on publish, and must match the version and hashes the store described. A failed check places nothing.
- A module with no price, or a zero price, is free and granted on the spot. A priced one answers 402 until buying exists (area 8). An entitlement is kept for good, even if a price is added later (ADR 0338 D2).
- Install never enables. Switch the module on from the hall's Modules tab.
- **Every version's how-to is a page** (task 1004366). `GET /store/modules/:key/versions/:version/howto` reads the `HOWTO.md` from that version's own stored tarball, after the same hash check install runs, and returns it as text; the hall shows it at `/builders/modules?howto=<key>&version=<X.Y.Z>`, rendered through the hall's escaping markdown reader (`md-reader.js`) because the file is author-written. Any signed-in builder can read it without holding the module; a delisted module's how-to reads only for people who hold it. "Save as PDF" is the browser's own print, with a print sheet that keeps only the document. The optional `howto.artifactUrl` shows as "Also available as a Claude page". Install prints the link, and a Modules-tab row links it when the module on disk is a published store version. A version published before the gate has none and answers 404 `howto_missing`.
- A module already on disk, in the instance's `modules/` or bundled with the core, is refused; moving one to a newer version is `update`. A module this core cannot mount is refused before download.
- A delisted module cannot be acquired or downloaded. Channels are not checked yet: every version is general until the channel tasks land.

`bongos module update <key> [--version X.Y.Z]` moves an installed store module forward through the same three calls, so a paid module and a free one take one identical path, and a module you already hold is never charged again (`tests/module_update.mjs` fails if a price-conditional branch appears).

- With no `--version` it takes the newest, and says "up to date" without downloading when that isn't newer. An older `--version` is refused: update only moves forward.
- The new version is written beside the old one and swapped in; any failure leaves the installed version in place. Files the new version dropped are gone afterwards.
- The on/off switch is untouched. A module bundled with the core is refused; it updates with the core (`bongos upgrade`).

**`bongos upgrade` says which installed modules have an update** (task 1003787), below its compatibility rows, so one command answers "what is stale here" for the core and its modules. It asks `GET /store/modules/latest?keys=…` for the newest version of every module here with an exact version — a read that takes no entitlement — and lists each newer one with `bongos module update <key>`, or says it waits for the core when that version needs a newer one. A delisted module is flagged as getting no further versions (ADR 0338 D2). None of this changes the exit code: an incompatible enabled module still blocks and nothing else does. With no session or no reachable store it says "not checked" and the pre-check stands; `--no-store` skips the read.

## Carving an existing core domain (the `db.js` per-domain pattern)

Most BONGOS-V1 module work is not scaffolding a *new* module — it's **carving an existing core domain out of the monolith** (ADR 0091, criterion C7). The reference carve is the kernel slice `src/bongos/db-kernel.js` (BV1.R69); the feature precedents are `modules/discord/db.js` + `modules/game/db.js`. Every later carve (memory R72, grading R73, …) copies this recipe. The invariant is **OTB byte-identical** at every step — you are *moving* code, not changing behavior.

1. **Identify the slice.** The domain's files (`src/bongos/<domain>*.js`) + its query cluster inside `src/bongos/db.js`. Confirm cohesion: who reads/writes its tables, and does anything in *core* still need those queries (a reader that stays core ⇒ a vendored twin, below).
2. **Create `modules/<key>/db.js`.** `require('../../src/module-api')` only; pull `pool` (and `withTx` for multi-statement writes) off the doorway. Move the domain's query functions verbatim. Re-export any **kernel** helper the module consumes (`insertAuditLog`, `getBuilderById`, `LIVE_RANK_LADDER`) straight off the doorway so a single `db.*` namespace serves both halves.
3. **Delete from core.** Remove the moved functions from `src/bongos/db.js` so the monolith shrinks. If a function genuinely lives in the kernel (identity/audit/rank/tx), it goes to `src/bongos/db-kernel.js` and `db.js` re-exports it (so the 23 importers stay byte-identical) — that is the db-kernel reference carve, not a module carve.
4. **Vendored twin when core still needs it.** If a core file *also* calls a moved query (e.g. `routes/me.js` reading a builder's art key), core keeps its own copy reading the same table and the module vendors its own — a module can never import core, and core can never import the module (the discord `getDiscordLink` precedent). Note the twin in the module's `CLAUDE.md`.
5. **Capabilities the lifecycle invokes go behind a kernel PORT,** never a direct import: the providing module `registerProvider('<cap>', fn)` at boot; the lifecycle `resolve('<cap>')(…)` at call time (R73 does this for `grade`).
6. **Verify byte-identical.** `node --check` each file; run the domain's `tests/*.mjs` + `tests/module_api.mjs` (the doorway surface contract) + `node scripts/gds/fitness.js`; regenerate the repo-map (`node scripts/gds/gen-repo-map.js`) since `db.js` exports changed.
