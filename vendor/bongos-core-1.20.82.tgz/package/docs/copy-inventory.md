# Copy inventory — every string the product shows a person

> **Generated** by `node scripts/gds/copy-inventory.js` (R01 of goal 1000074, the artist's loop).
> Deterministic on a given tree — regenerate and commit rather than hand-editing.
> Machine-readable twin: [`copy-registry.json`](copy-registry.json).

**2537 strings** across 3 surfaces · 2191 distinct pieces of copy · 2537 certain, 0 heuristic · 228 shown in more than one place.

## Surfaces

| surface | lives at | files | strings |
|---|---|---|---|
| `builders-hall` | `modules/hall-ui/public` | 119 | 1740 |
| `status-dashboard` | `modules/status-ui/public` | 4 | 100 |
| `landing` | `modules/public-landing/public` | 6 | 697 |

## Confidence, and why it is on every row

`certain` copy comes from markup only a person reads: an HTML text node, a `<title>`, or a copy-bearing attribute. `heuristic` copy is a JavaScript string literal that passed a prose filter — this tool does not parse JS, so a filtered literal is evidence, not proof. Treat a heuristic row as a candidate an artist confirms, and do not quote the total as "the number of strings in the product".

## What this cannot see

- Landing-page transforms: `modules/public-landing/public/*.html` is scanned as authored, but the server rewrites it before a visitor sees it — `{{token}}` placeholders are filled from the branding pack, and `<!--apex-only:start--> … <!--apex-only:end-->` sections are STRIPPED on a child instance (src/platform-server.js `landingPage()`). So a row here may be copy that this instance never renders, and a rendered sentence may differ from its authored form.
- Server-side messages: route failures (`res.fail` reasons), validation text and API error copy live in server JS and are not walked here. A person reads them, so widening to them is a deliberate later step, not an oversight to quietly fix.
- Skill and playbook prose: `.claude/skills/**/SKILL.md` is read by agents and by builders and is arguably the largest body of project voice. Out of scope on purpose — it is not UI, and mixing it in would drown the UI signal.
- Discord copy: outbound broadcast text is composed in `modules/discord/*.js` at send time. User-facing, but not part of any UI surface.
- JS literals with no render path: a string is listed only when it can be tied to one — markup built in a script, a toast/alert/confirm argument, or a textContent/innerText/title assignment. Copy reaching the DOM by any other route (a helper that takes a message parameter, a string held in a config object) is invisible here, deliberately: the alternative is a queue where most rows are code.
- Template literals containing a nested backtick: the literal scanner stops at the first closing backtick, so a nested template inside `${...}` truncates that one literal. Rare in this tree and cheap to spot (a row that ends mid-sentence); a real JS parser is the fix if it ever matters.
- Runtime-composed strings: anything assembled from fragments or interpolated at render time is captured only as its literal parts. A sentence that exists only once the browser runs cannot be inventoried by reading the tree.
- Generated pages: `docs/api-reference.md` and the OpenAPI surface are generated from route prose; that copy belongs to its generator, not to a designer.
- The design-contract surface layout: `modules/ui-design/docs/design-contract.md` expects `src/ui/<surface>/`, which this tree does not use (there is no `src/ui/`; the adapters live in `modules/ui-design/adapters/`). Surface ids here are a MAPPING onto real paths, not evidence the contract layout exists.

## The same words, shown twice

Identical copy within one surface. Sometimes right (a repeated button), sometimes two screens that should share one string.

| id | shown | text | where |
|---|---|---|---|
| `5df2baabf82e` | 12x | ← Back | modules/public-landing/public/projects.html:1443, modules/public-landing/public/projects.html:1486, modules/public-landing/public/projects.html:1512 |
| `eeda19200aeb` | 11x | Cloud Bongos | modules/public-landing/public/projects.html:663, modules/public-landing/public/projects.html:765, modules/public-landing/public/projects.html:810 |
| `0fbe47b01d2c` | 11x | Reading the project… | modules/public-landing/public/projects.html:1000, modules/public-landing/public/projects.html:1084, modules/public-landing/public/projects.html:1098 |
| `8c234d5c8bd4` | 7x | Could not save. Try again. | modules/hall-ui/public/settings-interaction.js:96, modules/hall-ui/public/settings-render.js:108, modules/hall-ui/public/settings.js:101 |
| `c661548d5140` | 7x | Next → | modules/public-landing/public/projects.html:1819, modules/public-landing/public/projects.html:1852, modules/public-landing/public/projects.html:1891 |
| `afe83bbbd0d4` | 6x | A non-profit, capture-resistant commons. | modules/public-landing/public/account.html:250, modules/public-landing/public/contact.html:71, modules/public-landing/public/index.html:903 |
| `5a2b73968b36` | 6x | Blocker # | modules/hall-ui/public/blockers.js:364, modules/hall-ui/public/blockers.js:368, modules/hall-ui/public/blockers.js:371 |
| `d6314ddcc1d0` | 6x | Open source | modules/public-landing/public/account.html:250, modules/public-landing/public/contact.html:71, modules/public-landing/public/index.html:903 |
| `9a685b01e2c6` | 6x | This page opens at a higher rank. | modules/hall-ui/public/deploy.html:31, modules/hall-ui/public/fleet.html:31, modules/hall-ui/public/gate.html:37 |
| `4d8ee7d68974` | 6x | task {…} | modules/hall-ui/public/gate.js:157, modules/hall-ui/public/hall-render.js:672, modules/hall-ui/public/idea.js:234 |
| `90a128c97eae` | 5x | Builders' hall | modules/public-landing/public/account.html:250, modules/public-landing/public/index.html:909, modules/public-landing/public/projects.html:814 |
| `bd315dd71ea7` | 5x | Built by agents, on Cloud&nbsp;Bongos. | modules/public-landing/public/account.html:250, modules/public-landing/public/contact.html:71, modules/public-landing/public/index.html:903 |
| `e57ec24e13ef` | 5x | Sign in with GitHub | modules/hall-ui/public/hall-render.js:278, modules/hall-ui/public/hall-render.js:370, modules/hall-ui/public/hall-render.js:394 |
| `a5257c88eb07` | 4x | GitHub username | modules/public-landing/public/projects.html:1241, modules/public-landing/public/projects.html:1242, modules/public-landing/public/projects.html:2144 |
| `971f3eb36342` | 4x | How to read the sky | modules/hall-ui/public/goal-map.html:78, modules/hall-ui/public/goal-map.html:117, modules/hall-ui/public/thinking.html:86 |
| `3eb67b892dea` | 4x | Percy Jackson | modules/public-landing/public/index.html:806, modules/public-landing/public/index.html:824, modules/public-landing/public/index.html:830 |
| `0887725744f2` | 4x | Restricted. | modules/hall-ui/public/board-room.js:526, modules/hall-ui/public/gate.js:234, modules/hall-ui/public/government.js:1013 |
| `47b6199cc471` | 4x | Show or hide the clock | modules/hall-ui/public/goal-map.html:77, modules/hall-ui/public/goal-map.html:77, modules/hall-ui/public/thinking.html:85 |
| `ad80586f802a` | 4x | Sign in | modules/public-landing/public/account.html:107, modules/public-landing/public/account.html:139, modules/public-landing/public/index.html:676 |
| `df38941b25a6` | 4x | Sign in with GitHub | modules/public-landing/public/account.html:143, modules/public-landing/public/projects.html:885, modules/public-landing/public/projects.html:987 |
| `2ae36be1c531` | 4x | Start a project | modules/public-landing/public/index.html:730, modules/public-landing/public/index.html:894, modules/public-landing/public/projects.html:773 |
| `eff70e59d12e` | 4x | Task {…} | modules/hall-ui/public/task.js:512, modules/hall-ui/public/task.js:548, modules/hall-ui/public/task.js:1038 |
| `72a29648399b` | 4x | Tweak a page | modules/hall-ui/public/tweak-editor.html:32, modules/hall-ui/public/tweak-editor.html:32, modules/hall-ui/public/tweak-editor.html:53 |
| `ed394c66d49c` | 4x | What the choice changes | modules/public-landing/public/projects.html:1186, modules/public-landing/public/projects.html:1263, modules/public-landing/public/projects.html:1275 |
| `4e25e6872321` | 4x | Your projects | modules/public-landing/public/account.html:116, modules/public-landing/public/index.html:691, modules/public-landing/public/projects.html:712 |
| `ed3e9f97ed31` | 3x | , not a | modules/hall-ui/public/studio.html:92, modules/hall-ui/public/thinking.html:40, modules/hall-ui/public/tweak-editor.html:49 |
| `20b0408512ae` | 3x | : the shell's top bar is the page's one | modules/hall-ui/public/studio.html:92, modules/hall-ui/public/thinking.html:41, modules/hall-ui/public/tweak-editor.html:49 |
| `08afb1257b71` | 3x | Back to home | modules/hall-ui/public/drachmae.html:87, modules/hall-ui/public/primer.html:90, modules/hall-ui/public/primer.js:282 |
| `118026595c16` | 3x | Board Room | modules/hall-ui/public/board-room.html:19, modules/hall-ui/public/board-room.html:19, modules/hall-ui/public/board-room.html:31 |
| `a78477a24a48` | 3x | Builders' Hall | modules/hall-ui/public/index.html:12, modules/hall-ui/public/index.html:12, modules/hall-ui/public/index.html:49 |
| `c10806b50c61` | 3x | Claim task {…} | modules/hall-ui/public/builders.js:973, modules/hall-ui/public/goals-render.js:370, modules/hall-ui/public/work.js:482 |
| `12ee050d0180` | 3x | Copy desk | modules/hall-ui/public/copy-desk.html:15, modules/hall-ui/public/copy-desk.html:15, modules/hall-ui/public/copy-desk.html:27 |
| `a873e7c29d80` | 3x | Copy prompt | modules/hall-ui/public/task.js:841, modules/hall-ui/public/task.js:863, modules/hall-ui/public/work.js:615 |
| `9c728558d6e7` | 3x | Drachmae &amp; karma | modules/hall-ui/public/drachmae.html:22, modules/hall-ui/public/drachmae.html:22, modules/hall-ui/public/drachmae.html:37 |
| `e0e2606e1104` | 3x | Fleet costs | modules/hall-ui/public/fleet.html:15, modules/hall-ui/public/fleet.html:15, modules/hall-ui/public/fleet.html:24 |
| `4a167ef6e515` | 3x | My projects | modules/public-landing/public/account.html:125, modules/public-landing/public/index.html:702, modules/public-landing/public/projects.html:723 |
| `0a81a82d10c4` | 3x | New project | modules/public-landing/public/account.html:117, modules/public-landing/public/index.html:692, modules/public-landing/public/projects.html:713 |
| `f6f68ba322be` | 3x | Open {…} | modules/hall-ui/public/goal-inbox.js:53, modules/hall-ui/public/goal-inbox.js:69, modules/hall-ui/public/goals.js:67 |
| `e08628967f2f` | 3x | Project settings | modules/hall-ui/public/project-settings.html:15, modules/hall-ui/public/project-settings.html:15, modules/hall-ui/public/project-settings.html:26 |
| `45f7bea67776` | 3x | Reading the project’s settings… | modules/public-landing/public/projects.html:1128, modules/public-landing/public/projects.html:1143, modules/public-landing/public/projects.html:1162 |
| … | | _188 more in the JSON registry_ | |

## `builders-hall` — 1740 strings

| id | conf | text | where |
|---|---|---|---|
| `926d5e9fa29d` | certain | ${…} of ${…} this month ({…}%). {…} | `modules/hall-ui/public/hall-render.js:704` |
| `b585019e3e1d` | certain | ' lines collapse into one | `modules/hall-ui/public/md-reader.js:189` |
| `44e29d37ddf6` | certain | '); out = out.replace(/(^\|[^*])\*([^*]+)\*(?!\*)/g, '$1 | `modules/hall-ui/public/md-reader.js:140` |
| `66cea7cefa4e` | certain | '; for (const row of bodyRows) { html += ' | `modules/hall-ui/public/md-reader.js:220` |
| `53e4ac514458` | certain | '; out.push(html); continue; } // Lists (unordered '- ' or ordered '1. '); consecutive items collapse. if (/^( | `modules/hall-ui/public/md-reader.js:224` |
| `87fa099f5068` | certain | '; } html += ' | `modules/hall-ui/public/md-reader.js:224` |
| `af615fa9f404` | certain | (checked {…}) | `modules/hall-ui/public/deploy.js:457` |
| `544794f1ec8f` | certain | (later in | `modules/hall-ui/public/index.html:9` |
| `3ac2eb36ba97` | certain | (no sections) | `modules/hall-ui/public/drachmae.js:260` |
| `a4614c0b8eb5` | certain | (or use the Claude Code CLI) and open the project. | `modules/hall-ui/public/hall-render.js:809` |
| `c7aecadc8133` | certain | (with {…}) | `modules/hall-ui/public/goals-render.js:592` |
| `c81e3a97b531` | certain | + Add goal | `modules/hall-ui/public/gate.js:368` |
| `650c0b90a095` | certain | + File a blocker | `modules/hall-ui/public/blockers.js:303` |
| `27d9721f358f` | certain | + Invite | `modules/hall-ui/public/goals-render.js:1219` |
| `646fab1157fe` | certain | + {…} more project{…} not publicly listed. | `modules/hall-ui/public/profile.js:375` |
| `05da3082c8c5` | certain | +{…} more | `modules/hall-ui/public/gate.js:149` |
| `9c8aba2b2fa4` | certain | , // membership | `modules/hall-ui/public/board-room.js:305` |
| `37964829d693` | certain | , and | `modules/hall-ui/public/government.html:55` |
| `1f8aceffb15e` | certain | , claiming, and shipping show — spend on explaining themselves. Richer cards say more and cost more tokens; le | `modules/hall-ui/public/settings.html:316` |
| `ac57fe1ccd6e` | certain | , follow its acceptance criteria, stay within touches[], /builder-ship | `modules/hall-ui/public/bulk-toolbar.js:78` |
| `574acf2f93bb` | certain | , never quietly ratified — so a clock is worth proposing. The recommended sitting is | `modules/hall-ui/public/government.js:605` |
| `ed3e9f97ed31` | certain | , not a | `modules/hall-ui/public/studio.html:92` |
| `ed3e9f97ed31` | certain | , not a | `modules/hall-ui/public/thinking.html:40` |
| `ed3e9f97ed31` | certain | , not a | `modules/hall-ui/public/tweak-editor.html:49` |
| `741e355954ac` | certain | , not at ship). | `modules/hall-ui/public/diagrams.html:52` |
| `b31a6bd7edc5` | certain | , or | `modules/hall-ui/public/profile.js:958` |
| `cc4fe2daf372` | certain | , so the brand is a | `modules/hall-ui/public/goal-map.html:66` |
| `c7c9b0afc38e` | certain | , then mark it as read on the Home page. | `modules/hall-ui/public/work.html:45` |
| `7a8111edba0a` | certain | , which is a containing block for its position: fixed layers (thinking.css), so the template's fixed layout is | `modules/hall-ui/public/thinking.html:37` |
| `24174ce79df3` | certain | 1 · Task lifecycle | `modules/hall-ui/public/diagrams.html:49` |
| `e4e929617054` | certain | 2 · Builder rank ladder | `modules/hall-ui/public/diagrams.html:57` |
| `a35dd1f12e78` | certain | 3 · {{Currency}} &amp; karma | `modules/hall-ui/public/diagrams.html:65` |
| `f1dec47e42d1` | certain | 4 · The complete architecture | `modules/hall-ui/public/diagrams.html:73` |
| `477235450d2b` | certain | 5 · Versioning | `modules/hall-ui/public/diagrams.html:82` |
| `20b0408512ae` | certain | : the shell's top bar is the page's one | `modules/hall-ui/public/studio.html:92` |
| `20b0408512ae` | certain | : the shell's top bar is the page's one | `modules/hall-ui/public/thinking.html:41` |
| `20b0408512ae` | certain | : the shell's top bar is the page's one | `modules/hall-ui/public/tweak-editor.html:49` |
| `353fff36068f` | certain | ; a later push must be re-approved. | `modules/hall-ui/public/gate.js:109` |
| `2a5aa36f4d29` | certain | ; the sky's first build made only the BRAND the header (the kit's top-bar-80px floor). In the hall the shell's | `modules/hall-ui/public/thinking.html:66` |
| `8ffdf4995e81` | certain | A Full Idea answers five questions, so that someone else can deliver against it without having to interview yo | `modules/hall-ui/public/ideas.html:146` |
| `3e5a62bc4887` | certain | A GitHub username is needed. | `modules/hall-ui/public/hall-render.js:426` |
| `3e5a62bc4887` | certain | A GitHub username is needed. | `modules/hall-ui/public/watch.js:334` |
| `b57b99aa31e9` | certain | A body on a ring. Lit and drifting while a builder holds it; a hairline, drifting slower, while it waits to be | `modules/hall-ui/public/sky-panel.js:103` |
| `568d58fd26cc` | certain | A configured value could not be used: | `modules/hall-ui/public/project-settings.js:103` |
| `518e5acc9184` | certain | A dependency keeps this task out of the claimable queue until that one ships. Remove one with the × beside it  | `modules/hall-ui/public/task.js:629` |
| `a22df5ebbd5e` | certain | A flag needs a reason an artist can act on. What is wrong with it, and what would better look like? | `modules/hall-ui/public/copy-desk.js:372` |
| `b8f70e36c7f9` | certain | A goal may only be added to a version that is still in planning. These were added after this version started b | `modules/hall-ui/public/roadmap.js:95` |
| `df5eb70b5a05` | certain | A higher rank. Its details are hidden until you reach the rank directly below it. | `modules/hall-ui/public/ranks.js:125` |
| `0150152ea9ec` | certain | A known snag stopped the move to core {…}: | `modules/hall-ui/public/deploy.js:206` |
| `2e17d7e236d9` | certain | A module built here can be submitted upstream for review, so it can join the shared catalog with your name and | `modules/hall-ui/public/modules.html:74` |
| `0c611f5a76af` | certain | A move to core {…} failed{…} — this project has moved on since, and is serving {…} now. Whatever stopped that  | `modules/hall-ui/public/deploy.js:366` |
| `a07c7b335a66` | certain | A protected-scope goal requires a Metic+ member. | `modules/hall-ui/public/goals-render.js:1316` |
| `a07c7b335a66` | certain | A protected-scope goal requires a Metic+ member. | `modules/hall-ui/public/goals-render.js:1338` |
| `5723baf26b2d` | certain | A quick idea is a thought filed fast. It is not an unfinished Full Idea — only its author can offer it up for  | `modules/hall-ui/public/idea.js:475` |
| `23dc5028183a` | certain | A quick report — title, what's going on, and where it belongs. Pick a goal and it lands there as a task the mo | `modules/hall-ui/public/ideas.html:56` |
| `08c1f66fd572` | certain | A refactor, a move, or work already superseded | `modules/hall-ui/public/goal-inbox.js:374` |
| `244ea2a3564e` | certain | A role says how you work. A speciality says what you work on — and how you, as someone who knows the subject,  | `modules/hall-ui/public/settings.html:230` |
| `eff6b977b1d2` | certain | A self-drawing map of the codebase: what each module is, and what depends on it. Redrawn from the code on ever | `modules/hall-ui/public/atlas.html:31` |
| `f3d6ed7c0d2c` | certain | A shipped task cannot be retired — it is immutable history now. | `modules/hall-ui/public/task.js:797` |
| `6359b5afbc6b` | certain | A short path to finding your feet. Tick the steps you’ve done; the rest are tracked for you. | `modules/hall-ui/public/hall-widgets.js:60` |
| `a3185a43c230` | certain | A sound plays at each turn of your work — a gentle chime when Claude finishes, a flourish when a task ships or | `modules/hall-ui/public/settings.html:352` |
| `57c247d4d8d8` | certain | A starting point by project type and size: a government you can adopt today, and the ranks worth adding to the | `modules/hall-ui/public/government.js:893` |
| `83b1274f9088` | certain | A tally of recorded work sessions, and the latest five. The full record lives on the Sessions page. | `modules/hall-ui/public/watch.html:96` |
| `0b9adf029094` | certain | A task cannot wait for itself. | `modules/hall-ui/public/task.js:954` |
| `0aaa0f2c4bdc` | certain | A title is required. | `modules/hall-ui/public/blockers.js:347` |
| `daf73127afff` | certain | A word on why | `modules/hall-ui/public/hall-render.js:297` |
| `996edffc1966` | certain | Access requests | `modules/hall-ui/public/watch.html:46` |
| `996edffc1966` | certain | Access requests | `modules/hall-ui/public/watch.html:61` |
| `303f8d90266f` | certain | Achievements could not be loaded. | `modules/hall-ui/public/builders.js:1196` |
| `6ca31dd5eb91` | certain | Acknowledge the primer | `modules/hall-ui/public/primer.html:99` |
| `74cc57f76b42` | certain | Active recently | `modules/hall-ui/public/watch.js:458` |
| `524188fe0078` | certain | Active sessions | `modules/hall-ui/public/settings.html:151` |
| `d628b36ec58e` | certain | Activity, by role | `modules/hall-ui/public/profile.html:137` |
| `2b94171ce525` | certain | Add dependency | `modules/hall-ui/public/task.js:629` |
| `da8659b0099b` | certain | Add something you wrote — notes, a standard, a worked example. It is indexed for recall, not pasted into every | `modules/hall-ui/public/settings-specialities.js:354` |
| `82a8bd77d374` | certain | Add these ranks | `modules/hall-ui/public/government.js:891` |
| `eded707fab69` | certain | Add to what it knows | `modules/hall-ui/public/settings-specialities.js:354` |
| `cc4125ca7cff` | certain | Added to this version after it started building — an Archon override of the scope gate. Open the goal to see w | `modules/hall-ui/public/goals-render.js:195` |
| `c600ff97ea70` | certain | Added — they are in the goal now, without being asked. | `modules/hall-ui/public/goals-render.js:1329` |
| `ff67fba11965` | certain | Admitted into {…} mid-build | `modules/hall-ui/public/goals-render.js:908` |
| `8b736e365191` | certain | All builders | `modules/hall-ui/public/hall-render.js:1180` |
| `b5e03617b319` | certain | All goals | `modules/hall-ui/public/goals.html:48` |
| `e08d410571e9` | certain | All kinds | `modules/hall-ui/public/sessions.js:286` |
| `9c34bccb06ef` | certain | All open asks | `modules/hall-ui/public/collab.html:79` |
| `bea7817e57a4` | certain | All surfaces | `modules/hall-ui/public/copy-desk.js:301` |
| `627c683a5e5d` | certain | All time | `modules/hall-ui/public/hall-widgets.js:161` |
| `b38c01691857` | certain | All your work → | `modules/hall-ui/public/hall-widgets.js:110` |
| `375b0e67bc30` | certain | Allow new releases and move to {…} | `modules/hall-ui/public/deploy.js:249` |
| `375b0e67bc30` | certain | Allow new releases and move to {…} | `modules/hall-ui/public/deploy.js:677` |
| `e99cc5d37404` | certain | Already a member? | `modules/hall-ui/public/hall-render.js:370` |
| `70ffbebe42fd` | certain | Also available as a Claude page | `modules/hall-ui/public/modules.html:87` |
| `da5368d10f85` | certain | Amendment {…} passed{…}, and the constitution below is not the one it decided: | `modules/hall-ui/public/government.js:633` |
| `2ca420e19dbb` | certain | An earlier attempt did not land. | `modules/hall-ui/public/deploy.js:366` |
| `69f0ca4a4d84` | certain | Analytics scope | `modules/hall-ui/public/hall-render.js:1178` |
| `1571577d39f0` | certain | Answer the five questions | `modules/hall-ui/public/ideas.html:154` |
| `14bdceaac078` | certain | Answer the five questions and this spark becomes a Full Idea. | `modules/hall-ui/public/ideas.js:921` |
| `0293418d5e8e` | certain | Answerable for: | `modules/hall-ui/public/profile.js:72` |
| `05761b08ec8f` | certain | Answering is optional and declining costs nothing. Nobody is assigned by being asked. | `modules/hall-ui/public/collab.html:143` |
| `52ed0e2e3470` | certain | Any rank | `modules/hall-ui/public/task-lib.js:82` |
| `8832c7204180` | certain | Anyone in the owning project | `modules/hall-ui/public/settings.html:268` |
| `7d2ab55d4112` | certain | Anyone on this instance | `modules/hall-ui/public/settings.html:269` |
| `20c98a4b630f` | certain | Approval queue | `modules/hall-ui/public/studio.html:121` |
| `0832ba017c90` | certain | Approve & re-run | `modules/hall-ui/public/gate.js:122` |
| `9ece0a6d3b4d` | certain | Approved. Re-check pending. | `modules/hall-ui/public/gate.js:164` |
| `4160b56d14af` | certain | Archive goal | `modules/hall-ui/public/goals-render.js:963` |
| `4160b56d14af` | certain | Archive goal | `modules/hall-ui/public/goals-render.js:1045` |
| `206acb4467a2` | certain | Archive this goal? | `modules/hall-ui/public/goals-render.js:1035` |
| `d9dd46194f35` | certain | Argue from mechanism, not vibes. Always name the assumption a number rests on. | `modules/hall-ui/public/settings.html:262` |
| `4d3b1bcae3eb` | certain | Artist Review Status | `modules/hall-ui/public/studio.html:125` |
| `5fcfdf8975cf` | certain | As configuration: | `modules/hall-ui/public/government.js:960` |
| `01a0f29ff406` | certain | As first filed | `modules/hall-ui/public/idea.js:467` |
| `9b02ba5e6d23` | certain | Asked of others | `modules/hall-ui/public/collab.html:131` |
| `688cc6dd38ee` | certain | Asked of you | `modules/hall-ui/public/collab.html:48` |
| `688cc6dd38ee` | certain | Asked of you | `modules/hall-ui/public/collab.html:122` |
| `b2656d0b2402` | certain | Asked {…} | `modules/hall-ui/public/collab.js:91` |
| `b2656d0b2402` | certain | Asked {…} | `modules/hall-ui/public/watch.js:517` |
| `8c8ec2597036` | certain | Assigned {…} to builder {…}. | `modules/hall-ui/public/government.js:463` |
| `46714066f2da` | certain | Audit log | `modules/hall-ui/public/watch.html:141` |
| `d7c574ba6b2a` | certain | Autobongos runner | `modules/hall-ui/public/gate.html:53` |
| `1de02052abf2` | certain | Available from the {…} rank up. | `modules/hall-ui/public/gate.js:237` |
| `1de02052abf2` | certain | Available from the {…} rank up. | `modules/hall-ui/public/government.js:1016` |
| `c78685da0e42` | certain | Awaiting UAT | `modules/hall-ui/public/criterion-uat-ui.js:77` |
| `bdbe9ff6a177` | certain | Awaiting the grader, or a confirmation, before it can ship. | `modules/hall-ui/public/task.js:760` |
| `ecfbb10d4ca9` | certain | Awaiting the owner/manager's approval | `modules/hall-ui/public/goals-render.js:970` |
| `08afb1257b71` | certain | Back to home | `modules/hall-ui/public/drachmae.html:87` |
| `08afb1257b71` | certain | Back to home | `modules/hall-ui/public/primer.html:90` |
| `08afb1257b71` | certain | Back to home | `modules/hall-ui/public/primer.js:282` |
| `ef2fab4901d6` | certain | Back to tasks | `modules/hall-ui/public/task.html:34` |
| `64e2fbc2c072` | certain | Back to your thinking | `modules/hall-ui/public/idea.html:31` |
| `f6bb75b08e98` | certain | Back to {…} | `modules/hall-ui/public/task.js:226` |
| `f6bb75b08e98` | certain | Back to {…} | `modules/hall-ui/public/task.js:235` |
| `28d8d79c4f21` | certain | Backend-only: nothing to record. Check it the way it can be checked (a log, a report, a test against the live  | `modules/hall-ui/public/criterion-uat-ui.js:147` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/blockers.js:364` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/blockers.js:368` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/blockers.js:371` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/blockers.js:413` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/blockers.js:417` |
| `5a2b73968b36` | certain | Blocker # | `modules/hall-ui/public/task-detail.js:226` |
| `cadad7e5dc2b` | certain | Blockers — {{worldName}} | `modules/hall-ui/public/blockers.html:6` |
| `cadad7e5dc2b` | certain | Blockers — {{worldName}} | `modules/hall-ui/public/blockers.html:6` |
| `aad792e2b480` | certain | Blocking task # (optional) | `modules/hall-ui/public/blockers.js:310` |
| `118026595c16` | certain | Board Room | `modules/hall-ui/public/board-room.html:19` |
| `118026595c16` | certain | Board Room | `modules/hall-ui/public/board-room.html:19` |
| `118026595c16` | certain | Board Room | `modules/hall-ui/public/board-room.html:31` |
| `2b8ad43383de` | certain | Board Room — {{worldName}} | `modules/hall-ui/public/board-room.html:6` |
| `2b8ad43383de` | certain | Board Room — {{worldName}} | `modules/hall-ui/public/board-room.html:6` |
| `da910fee01d7` | certain | Browse goals → | `modules/hall-ui/public/goals.js:83` |
| `1596210cea76` | certain | Build from your own machine — clone the repository, run the platform locally, and sign in from the terminal. | `modules/hall-ui/public/hall-render.js:809` |
| `08bfcc9198ba` | certain | Builder id | `modules/hall-ui/public/government.html:109` |
| `306bc316184d` | certain | Builders you may know | `modules/hall-ui/public/profile-connections.js:158` |
| `60b248791dc3` | certain | Builders — {{worldName}} | `modules/hall-ui/public/roster.html:6` |
| `60b248791dc3` | certain | Builders — {{worldName}} | `modules/hall-ui/public/roster.html:6` |
| `a78477a24a48` | certain | Builders' Hall | `modules/hall-ui/public/index.html:12` |
| `a78477a24a48` | certain | Builders' Hall | `modules/hall-ui/public/index.html:12` |
| `a78477a24a48` | certain | Builders' Hall | `modules/hall-ui/public/index.html:49` |
| `b51edc826cbe` | certain | Built by this project | `modules/hall-ui/public/modules.html:70` |
| `563d29ed86d8` | certain | Bulk actions | `modules/hall-ui/public/goals.html:179` |
| `563d29ed86d8` | certain | Bulk actions | `modules/hall-ui/public/work.html:161` |
| `46b33550d52b` | certain | Bulk claim | `modules/hall-ui/public/goals.html:182` |
| `46b33550d52b` | certain | Bulk claim | `modules/hall-ui/public/work.html:164` |
| `6d6d626fc518` | certain | Bulk release | `modules/hall-ui/public/goals.html:183` |
| `6d6d626fc518` | certain | Bulk release | `modules/hall-ui/public/work.html:165` |
| `181cfa50b127` | certain | By the numbers | `modules/hall-ui/public/profile.html:64` |
| `a015a43bfc7f` | certain | CLI access | `modules/hall-ui/public/settings.html:133` |
| `09e863eb90af` | certain | Can: {…} | `modules/hall-ui/public/government.js:873` |
| `084eb64bce72` | certain | Capabilities held by a machine identity, never by a person or a rank. Shown for completeness; nothing here can | `modules/hall-ui/public/government.html:123` |
| `bdca1f219e6f` | certain | Cast objection | `modules/hall-ui/public/board-room.js:368` |
| `a974494e44f3` | certain | Catalog at a glance | `modules/hall-ui/public/modules.html:53` |
| `c1c7158e0a43` | certain | Category saved. | `modules/hall-ui/public/project-settings.js:214` |
| `0279db21e29a` | certain | Change in Settings → | `modules/hall-ui/public/hall-render.js:580` |
| `2637480ee2b8` | certain | Change to | `modules/hall-ui/public/deploy.js:294` |
| `f040fb66f250` | certain | Changed files | `modules/hall-ui/public/gate.js:151` |
| `906c2947dfc1` | certain | Changes save at once and take effect the next time you start a session on this machine. | `modules/hall-ui/public/settings.html:363` |
| `52384bdc035c` | certain | Changes save at once. Your new choice plays the next time that event fires. | `modules/hall-ui/public/settings.html:376` |
| `cab7a9526ca1` | certain | Changes save the moment you pick. “Default” clears your override and falls back to the system's choice. | `modules/hall-ui/public/settings.html:346` |
| `4b714191b423` | certain | Changes touching protected build surfaces, held for your approval. | `modules/hall-ui/public/gate.js:605` |
| `864503935eca` | certain | Changing the rule… | `modules/hall-ui/public/deploy.js:671` |
| `55ad21bd03eb` | certain | Chart the routes | `modules/hall-ui/public/goal-map.html:100` |
| `55ad21bd03eb` | certain | Chart the routes | `modules/hall-ui/public/thinking.html:108` |
| `e6982a9ff948` | certain | Charter library | `modules/hall-ui/public/government.js:809` |
| `12db2eacb3f0` | certain | Check this line (Shift + Enter) | `modules/hall-ui/public/tweak-editor.js:226` |
| `98e16fff6561` | certain | Check this {…} line | `modules/hall-ui/public/tweak-editor.js:226` |
| `f66f5cdaa732` | certain | Checked against {…} — nothing blocks this move.{…} | `modules/hall-ui/public/deploy.js:460` |
| `f8725cf3ba62` | certain | Checking dependency order… | `modules/hall-ui/public/bulk-toolbar.js:217` |
| `5f8b267e47e5` | certain | Checking for a newer version… | `modules/hall-ui/public/settings-software-update.js:170` |
| `7a41b18c0de8` | certain | Checking for conflicts… | `modules/hall-ui/public/bulk-toolbar.js:196` |
| `ac7cf27bd7de` | certain | Checking what this would do, and what it would bring in. The answer comes from the machine itself, so it can t | `modules/hall-ui/public/deploy.js:449` |
| `aa3ba7d28a76` | certain | Checking your key… | `modules/hall-ui/public/settings.js:897` |
| `834f8c6f3b72` | certain | Choose a builder… | `modules/hall-ui/public/goals-render.js:1255` |
| `b3d0e2af5176` | certain | Choose a goal first. | `modules/hall-ui/public/task.js:1002` |
| `89ddfeda9566` | certain | Choose goals | `modules/hall-ui/public/gate.js:338` |
| `6bf684ebc1c3` | certain | Choose the skills for {…} | `modules/hall-ui/public/settings-specialities.js:180` |
| `2b504633779f` | certain | Choose which goals your own runner works while you are away. You can only choose from the goals the project al | `modules/hall-ui/public/settings.html:174` |
| `6c88cdf417f1` | certain | Choose which sound plays for each build event — one when Claude waits for your input, another when a task ship | `modules/hall-ui/public/settings.html:369` |
| `b7d5648b66db` | certain | Claim it | `modules/hall-ui/public/task.js:751` |
| `b7d5648b66db` | certain | Claim it | `modules/hall-ui/public/task.js:879` |
| `c10806b50c61` | certain | Claim task {…} | `modules/hall-ui/public/builders.js:973` |
| `c10806b50c61` | certain | Claim task {…} | `modules/hall-ui/public/goals-render.js:370` |
| `c10806b50c61` | certain | Claim task {…} | `modules/hall-ui/public/work.js:482` |
| `84664050c372` | certain | Claimed by another builder | `modules/hall-ui/public/goals-render.js:376` |
| `18a03475e536` | certain | Claude Code | `modules/hall-ui/public/hall-render.js:832` |
| `ccb94814e3c2` | certain | Claude can start it when you ask in plain words. | `modules/hall-ui/public/commands.html:36` |
| `6cb414d119be` | certain | Claude sees it and can start it when you ask in plain words | `modules/hall-ui/public/commands-lib.js:94` |
| `5b3b75ee0596` | certain | Claude's notes on this goal | `modules/hall-ui/public/goals.html:86` |
| `593dda3178eb` | certain | Click to copy | `modules/hall-ui/public/copy-on-click.js:137` |
| `bbe07ccbc2e4` | certain | Clone the project to your machine. The build commands live inside the repo, so this comes first. The remaining | `modules/hall-ui/public/hall-render.js:895` |
| `f42cb1edcf1e` | certain | Clone the repository | `modules/hall-ui/public/hall-render.js:809` |
| `70f6a704d504` | certain | Close it | `modules/hall-ui/public/copy-desk.html:140` |
| `d12a2fb5730d` | certain | Close this flag | `modules/hall-ui/public/copy-desk.html:116` |
| `9b9c2abeae90` | certain | Close this stage | `modules/hall-ui/public/genesis-home.js:206` |
| `3d148e19e03a` | certain | Closed. | `modules/hall-ui/public/copy-desk.js:510` |
| `2654dc3ded21` | certain | Closing is a judgement too — say what you decided, so the next person does not re-litigate it. | `modules/hall-ui/public/copy-desk.js:495` |
| `e5548861ad79` | certain | Coach the grader | `modules/hall-ui/public/studio.js:211` |
| `530d83153e17` | certain | Codebase detail | `modules/hall-ui/public/atlas.html:55` |
| `c72c97dc33fe` | certain | Collab — {{worldName}} | `modules/hall-ui/public/collab.html:6` |
| `c72c97dc33fe` | certain | Collab — {{worldName}} | `modules/hall-ui/public/collab.html:6` |
| `fe4a2b04eda5` | certain | Commands — {{worldName}} | `modules/hall-ui/public/commands.html:6` |
| `fe4a2b04eda5` | certain | Commands — {{worldName}} | `modules/hall-ui/public/commands.html:6` |
| `cfc287c42263` | certain | Complete your profile | `modules/hall-ui/public/profile-nudge.js:79` |
| `2867c85d196d` | certain | Confirm that verification for #{…} actually passed? | `modules/hall-ui/public/task.js:895` |
| `e74f4442c338` | certain | Confirm this stage | `modules/hall-ui/public/genesis-home.js:197` |
| `9b16a22bf24c` | certain | Connect Discord &amp; join the server | `modules/hall-ui/public/hall-render.js:955` |
| `9b16a22bf24c` | certain | Connect Discord &amp; join the server | `modules/hall-ui/public/settings.js:683` |
| `c07898571b24` | certain | Connects to | `modules/hall-ui/public/atlas.js:290` |
| `999e1955bb1c` | certain | Context layer | `modules/hall-ui/public/atlas.html:47` |
| `296eb6da10ca` | certain | Contribution to this goal | `modules/hall-ui/public/goals-render.js:791` |
| `4fb972405d3d` | certain | Copy all {…} for Session Start | `modules/hall-ui/public/collab.js:478` |
| `12ee050d0180` | certain | Copy desk | `modules/hall-ui/public/copy-desk.html:15` |
| `12ee050d0180` | certain | Copy desk | `modules/hall-ui/public/copy-desk.html:15` |
| `12ee050d0180` | certain | Copy desk | `modules/hall-ui/public/copy-desk.html:27` |
| `1214ea8e0d1b` | certain | Copy desk — {{worldName}} | `modules/hall-ui/public/copy-desk.html:6` |
| `1214ea8e0d1b` | certain | Copy desk — {{worldName}} | `modules/hall-ui/public/copy-desk.html:6` |
| `30764a4f0e28` | certain | Copy for Session Start | `modules/hall-ui/public/collab.js:137` |
| `ebc8a6c16a22` | certain | Copy parallel prompt | `modules/hall-ui/public/goals.html:184` |
| `ebc8a6c16a22` | certain | Copy parallel prompt | `modules/hall-ui/public/work.html:166` |
| `a873e7c29d80` | certain | Copy prompt | `modules/hall-ui/public/task.js:841` |
| `a873e7c29d80` | certain | Copy prompt | `modules/hall-ui/public/task.js:863` |
| `a873e7c29d80` | certain | Copy prompt | `modules/hall-ui/public/work.js:615` |
| `8e2046777710` | certain | Copy prompt for task {…} | `modules/hall-ui/public/goals-render.js:371` |
| `8e2046777710` | certain | Copy prompt for task {…} | `modules/hall-ui/public/work.js:482` |
| `8618c85d014f` | certain | Copy sequential prompt | `modules/hall-ui/public/goals.html:185` |
| `8618c85d014f` | certain | Copy sequential prompt | `modules/hall-ui/public/work.html:167` |
| `7306a1448097` | certain | Copy someone has judged as needing attention, with their reason. Anyone can file one; closing it needs the | `modules/hall-ui/public/copy-desk.html:47` |
| `3837f6d586a3` | certain | Copy the task prompt to your clipboard | `modules/hall-ui/public/goals-render.js:371` |
| `3837f6d586a3` | certain | Copy the task prompt to your clipboard | `modules/hall-ui/public/work.js:482` |
| `301afa9a94b9` | certain | Costs us / month | `modules/hall-ui/public/fleet-costs.js:70` |
| `e269ff7b3144` | certain | Could not add that builder just now. | `modules/hall-ui/public/goals-render.js:1341` |
| `16a4effbf95a` | certain | Could not add the ranks: {…} | `modules/hall-ui/public/government.js:938` |
| `7bcaeffb742f` | certain | Could not approve: {…} | `modules/hall-ui/public/gate.js:123` |
| `c922293e668c` | certain | Could not assign: {…} | `modules/hall-ui/public/government.js:468` |
| `e1fc7cedf4e7` | certain | Could not change rank: {…} | `modules/hall-ui/public/watch.js:889` |
| `b9e53fbd90e6` | certain | Could not change standing: {…} | `modules/hall-ui/public/watch.js:915` |
| `1ef1efc15b6c` | certain | Could not change that just now. | `modules/hall-ui/public/goals-render.js:1387` |
| `6214998a5ebe` | certain | Could not check for a newer version: {…}. | `modules/hall-ui/public/settings-software-update.js:135` |
| `9ab613a308d6` | certain | Could not check for updates: {…}. | `modules/hall-ui/public/settings-software-update.js:180` |
| `c3f99e7c6e6b` | certain | Could not copy automatically — select and copy manually. ({…}) | `modules/hall-ui/public/settings.js:776` |
| `e3fd1febf63d` | certain | Could not copy to the clipboard. Try again. | `modules/hall-ui/public/goals-page.js:408` |
| `e3fd1febf63d` | certain | Could not copy to the clipboard. Try again. | `modules/hall-ui/public/work.js:630` |
| `04824d351824` | certain | Could not copy — select the text and copy it manually. | `modules/hall-ui/public/copy-on-click.js:110` |
| `fa309d1d0104` | certain | Could not create rank: {…} | `modules/hall-ui/public/government.js:448` |
| `7054cd87b5ec` | certain | Could not end that session: {…} | `modules/hall-ui/public/settings-sessions.js:85` |
| `71da00d47492` | certain | Could not invite: {…} | `modules/hall-ui/public/watch.js:344` |
| `90691bceaf68` | certain | Could not load | `modules/hall-ui/public/project-settings.js:242` |
| `90691bceaf68` | certain | Could not load | `modules/hall-ui/public/task.js:1057` |
| `589a4cfc5442` | certain | Could not load idea {…}. | `modules/hall-ui/public/ideas.js:1018` |
| `192c893fc64e` | certain | Could not load modules. | `modules/hall-ui/public/modules.js:328` |
| `9912c3835136` | certain | Could not load requests — reload to try again. | `modules/hall-ui/public/collab.js:845` |
| `7775fec0fa85` | certain | Could not load sessions. | `modules/hall-ui/public/sessions.js:399` |
| `7775fec0fa85` | certain | Could not load sessions. | `modules/hall-ui/public/sessions.js:437` |
| `a2f2e8babef5` | certain | Could not load that page. Try again. | `modules/hall-ui/public/blockers.js:276` |
| `9d8192ac9098` | certain | Could not load the earnings. | `modules/hall-ui/public/profile-charts.js:546` |
| `b2147cc90e36` | certain | Could not load the idea template. Reload, or file from the terminal with capture.js. | `modules/hall-ui/public/ideas.js:1000` |
| `7604af13c40e` | certain | Could not load the profile. | `modules/hall-ui/public/profile.js:1035` |
| `8b69e445592a` | certain | Could not load the question labels; showing the answers as stored. | `modules/hall-ui/public/idea.js:458` |
| `edd5bafbe075` | certain | Could not load the queue just now. | `modules/hall-ui/public/ideas.js:885` |
| `02bb0570996a` | certain | Could not load the ranks. | `modules/hall-ui/public/ranks.js:197` |
| `2878778cf9f3` | certain | Could not load this page. | `modules/hall-ui/public/watch.js:1351` |
| `df4c2f78a3f6` | certain | Could not load this project’s skills — {…} | `modules/hall-ui/public/settings-specialities.js:311` |
| `4b0c8d94541c` | certain | Could not load your account. Reload the page to try again. | `modules/hall-ui/public/settings.js:1157` |
| `2a9fb4046bc4` | certain | Could not load your rank. Return to the hall and try again. | `modules/hall-ui/public/ranks.js:196` |
| `9d533e811dec` | certain | Could not load your sessions: {…} | `modules/hall-ui/public/settings-sessions.js:114` |
| `64f9d51f0fa2` | certain | Could not load your settings. | `modules/hall-ui/public/settings.js:1160` |
| `de244c45d916` | certain | Could not load {…} | `modules/hall-ui/public/task.js:1050` |
| `2366356926b4` | certain | Could not mark the primer just now. Try again. | `modules/hall-ui/public/primer.js:259` |
| `753987b5da13` | certain | Could not reach the submit endpoint. | `modules/hall-ui/public/modules.js:307` |
| `6f500726f0ac` | certain | Could not read the report: {…} | `modules/hall-ui/public/watch.js:669` |
| `21c2f33168a3` | certain | Could not read this project's deploy state: {…} | `modules/hall-ui/public/deploy.js:616` |
| `21a782f1af26` | certain | Could not read what this would bring in: {…}. The check below still applies. | `modules/hall-ui/public/deploy.js:534` |
| `8b470cebf53d` | certain | Could not remove your key. Try again. | `modules/hall-ui/public/settings.js:977` |
| `4cf6bc8b377b` | certain | Could not remove. Try again. | `modules/hall-ui/public/settings.js:976` |
| `7a778d188e87` | certain | Could not remove: {…} | `modules/hall-ui/public/government.js:369` |
| `bb5a7753e62b` | certain | Could not reset: {…} | `modules/hall-ui/public/government.js:301` |
| `b526ee0b8c48` | certain | Could not save just now. Try again. | `modules/hall-ui/public/builders.js:454` |
| `41a351aea8d4` | certain | Could not save the volume. Try again. | `modules/hall-ui/public/settings.js:219` |
| `5305186a4154` | certain | Could not save your choice. Try again. | `modules/hall-ui/public/settings.js:102` |
| `cfe6c5ceb3ef` | certain | Could not save your interaction profile. Try again. | `modules/hall-ui/public/settings-interaction.js:97` |
| `ea4fb30debd0` | certain | Could not save your key. Try again. | `modules/hall-ui/public/settings.js:921` |
| `ef609f2c0cb3` | certain | Could not save your name. Try again. | `modules/hall-ui/public/settings.js:637` |
| `59ecd5c52f59` | certain | Could not save your preference. Try again. | `modules/hall-ui/public/builders.js:367` |
| `59ecd5c52f59` | certain | Could not save your preference. Try again. | `modules/hall-ui/public/settings.js:557` |
| `bd197a4373c8` | certain | Could not save your rendering preference. Try again. | `modules/hall-ui/public/settings-render.js:109` |
| `3a10fab1252d` | certain | Could not save your runner’s goals. Try again. | `modules/hall-ui/public/settings-autobongos.js:132` |
| `f81ab95f1d88` | certain | Could not save your sound preference. Try again. | `modules/hall-ui/public/settings.js:239` |
| `f81ab95f1d88` | certain | Could not save your sound preference. Try again. | `modules/hall-ui/public/settings.js:329` |
| `14b698bc1042` | certain | Could not save your wandering level. Try again. | `modules/hall-ui/public/settings.js:459` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings-interaction.js:96` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings-render.js:108` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings.js:101` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings.js:458` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings.js:556` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings.js:636` |
| `8c234d5c8bd4` | certain | Could not save. Try again. | `modules/hall-ui/public/settings.js:920` |
| `5ef90fe7a6c2` | certain | Could not save: {…} | `modules/hall-ui/public/settings-autobongos.js:131` |
| `007b134d9366` | certain | Could not send that invitation just now. | `modules/hall-ui/public/goals-render.js:1319` |
| `31c6e3fd754b` | certain | Could not send the request just now. | `modules/hall-ui/public/goals-render.js:1402` |
| `1f4d9a989606` | certain | Could not set up key storage. Try again. | `modules/hall-ui/public/settings.js:957` |
| `e65b392144ac` | certain | Could not set up storage. Try again. | `modules/hall-ui/public/settings.js:956` |
| `d4601887a058` | certain | Could not sign out everywhere: {…} | `modules/hall-ui/public/settings-sessions.js:102` |
| `3db890b074a7` | certain | Could not update visibility just now. | `modules/hall-ui/public/goals-render.js:1371` |
| `112d12b24879` | certain | Could not verify your access. Go back and try again. | `modules/hall-ui/public/watch.js:1350` |
| `6bd74fd20311` | certain | Could not verify your access. Try again. | `modules/hall-ui/public/sessions.js:436` |
| `278e8281c82f` | certain | Could not vote: {…} | `modules/hall-ui/public/board-room.js:396` |
| `a48e9f098392` | certain | Could not {…} just now. | `modules/hall-ui/public/goals-render.js:1357` |
| `cb09ee26014f` | certain | Could not {…}: {…} | `modules/hall-ui/public/government.js:314` |
| `f53f7aaa189f` | certain | Couldn’t load this goal’s task dependencies right now. | `modules/hall-ui/public/goal-forest-render.js:111` |
| `737bef533845` | certain | Couldn’t refresh the queue — try reloading the page. | `modules/hall-ui/public/blockers.js:285` |
| `28ec06f6060a` | certain | Counted, not judged: each question is worth the same, and earns its share in proportion to how much real text  | `modules/hall-ui/public/ideas.html:220` |
| `38827a954f3b` | certain | Create a custom rank first. | `modules/hall-ui/public/government.js:459` |
| `20459b66303a` | certain | Create one | `modules/hall-ui/public/settings.html:241` |
| `dd8ead7adc9a` | certain | Create rank | `modules/hall-ui/public/government.html:92` |
| `af21de422c14` | certain | Create speciality | `modules/hall-ui/public/settings.html:284` |
| `d7beb841395e` | certain | Create task | `modules/hall-ui/public/task-detail.js:465` |
| `e91a4d2e3e1c` | certain | Created rank {…}. | `modules/hall-ui/public/government.js:442` |
| `a55e423263f0` | certain | Cross-project record | `modules/hall-ui/public/profile.html:98` |
| `24013a074724` | certain | Custom rank | `modules/hall-ui/public/government.html:113` |
| `cf7d7d5d5e83` | certain | Database behind. | `modules/hall-ui/public/deploy.js:579` |
| `6744aed3d15e` | certain | Dated exploit-detail engagement reports — kept out of the repo (threat-model §6.3) and served only to Archons. | `modules/hall-ui/public/watch.html:131` |
| `d388906f550b` | certain | Declared files overlap: {…} (advisory) | `modules/hall-ui/public/task-lib.js:74` |
| `7c6891813679` | certain | Default ({…}) | `modules/hall-ui/public/settings.js:63` |
| `7ec7dc1adaa6` | certain | Deploy — {{worldName}} | `modules/hall-ui/public/deploy.html:6` |
| `7ec7dc1adaa6` | certain | Deploy — {{worldName}} | `modules/hall-ui/public/deploy.html:6` |
| `05f1574ea13a` | certain | Develop it | `modules/hall-ui/public/idea.js:473` |
| `0a4fe7150971` | certain | Develop this idea | `modules/hall-ui/public/ideas.js:920` |
| `11b8266d6aab` | certain | Developing a Big Idea Spark | `modules/hall-ui/public/ideas.html:164` |
| `65322ac89221` | certain | Discard draft | `modules/hall-ui/public/ideas.html:197` |
| `0f685daf1bd5` | certain | Discord connected ✓ | `modules/hall-ui/public/settings.js:676` |
| `d8017b5ca98f` | certain | Discord unlinked. | `modules/hall-ui/public/settings.js:695` |
| `f3e09453374f` | certain | Dismissed — looked at, leaving it as it is | `modules/hall-ui/public/copy-desk.html:123` |
| `b384ec1a6fe4` | certain | Dismissed — the copy and visuals are good as shipped. | `modules/hall-ui/public/studio.js:391` |
| `3e561393f4e9` | certain | Display name | `modules/hall-ui/public/settings.html:77` |
| `3e561393f4e9` | certain | Display name | `modules/hall-ui/public/settings.html:83` |
| `5a95583f9bfa` | certain | Download Claude | `modules/hall-ui/public/hall-render.js:809` |
| `9cf07334a5a9` | certain | Downvote (−1) | `modules/hall-ui/public/builders.js:777` |
| `9c728558d6e7` | certain | Drachmae &amp; karma | `modules/hall-ui/public/drachmae.html:22` |
| `9c728558d6e7` | certain | Drachmae &amp; karma | `modules/hall-ui/public/drachmae.html:22` |
| `9c728558d6e7` | certain | Drachmae &amp; karma | `modules/hall-ui/public/drachmae.html:37` |
| `9d9cc4ef8557` | certain | Drachmae &amp; karma — {{worldName}} | `modules/hall-ui/public/drachmae.html:6` |
| `9d9cc4ef8557` | certain | Drachmae &amp; karma — {{worldName}} | `modules/hall-ui/public/drachmae.html:6` |
| `2f8d0404039e` | certain | Draft discarded. | `modules/hall-ui/public/ideas.js:560` |
| `d59beed97d58` | certain | Drag to pan, scroll to zoom | `modules/hall-ui/public/diagrams.html:33` |
| `67f09099c2d3` | certain | Duplicate — should be said once, in one place | `modules/hall-ui/public/copy-desk.html:93` |
| `1de61111bc00` | certain | Each builder's runner | `modules/hall-ui/public/gate.js:565` |
| `77b7e3abfb07` | certain | Each one touched a protected surface and stopped at the gate check. Approving records your seal on that commit | `modules/hall-ui/public/gate.html:65` |
| `0ddc87f11713` | certain | Each rank opens more of the system. You see full details for your current rank and the one directly above it;  | `modules/hall-ui/public/ranks.html:56` |
| `7f1b1c32d360` | certain | Each slash-command can run on a different model. The system has a default for every skill; choose another to o | `modules/hall-ui/public/settings.html:332` |
| `3f7d82a0d9b1` | certain | Each was filed when a ship changed copy or visuals. No new ones arrive; answer these and the door goes. | `modules/hall-ui/public/studio.html:156` |
| `8e04bed00757` | certain | Earnings over time | `modules/hall-ui/public/profile-charts.js:455` |
| `8e04bed00757` | certain | Earnings over time | `modules/hall-ui/public/profile-charts.js:546` |
| `854a21d2eb39` | certain | Eight achievements recognize sustained contribution. Earned ones are highlighted; the rest show what’s left to | `modules/hall-ui/public/hall-widgets.js:228` |
| `daed038e1162` | certain | End every session, including this one? You will need to sign in again, and any CLI token will need re-issuing. | `modules/hall-ui/public/settings-sessions.js:94` |
| `8d2b4f119ee3` | certain | End session | `modules/hall-ui/public/settings-sessions.js:46` |
| `8e82771e5b63` | certain | Ending a session takes effect immediately; the token stops working on its very next request. | `modules/hall-ui/public/settings.html:163` |
| `58d381535285` | certain | Engagement reports | `modules/hall-ui/public/watch.html:130` |
| `690609c8e9a9` | certain | Enter a goal number. | `modules/hall-ui/public/gate.js:470` |
| `4f776bc33d5f` | certain | Enter the builders’ hall | `modules/hall-ui/public/genesis-home.js:219` |
| `1825c9c467d8` | certain | Enter the id of the task this one should wait for. | `modules/hall-ui/public/task.js:951` |
| `bd7a40639a1c` | certain | Estimate (min) | `modules/hall-ui/public/task-detail.js:460` |
| `c15d1f0ddfb6` | certain | Estimation accuracy | `modules/hall-ui/public/watch.html:148` |
| `44f928d13699` | certain | Event sounds | `modules/hall-ui/public/settings.html:368` |
| `8690c6424585` | certain | Every builder in {{worldName}} — rank, {{currency}}, karma, and active claims. | `modules/hall-ui/public/watch.html:69` |
| `a97b064db76f` | certain | Every closed amendment sitting, ratified and returned alike, with the rule it was decided under. | `modules/hall-ui/public/government.js:971` |
| `2ae1eb35611e` | certain | Every done-when criterion for this goal, with its full detail. | `modules/hall-ui/public/goals.html:220` |
| `25b6c0f9e74e` | certain | Every page is taken or on its way to the site right now. Come back soon. | `modules/hall-ui/public/studio.js:679` |
| `c188854da766` | certain | Every place you are currently signed in — this browser, your terminal, any other machine. A session refreshes  | `modules/hall-ui/public/settings.html:152` |
| `47be006e5ad5` | certain | Every sitting since has been decided under the constitution below, not the ratified one. Nothing is re-applied | `modules/hall-ui/public/government.js:633` |
| `712d15341aeb` | certain | Every slash command and every terminal command this project has, with what each does, when to reach for it and | `modules/hall-ui/public/commands.html:28` |
| `6604d63c2fb4` | certain | Everyone who joined while this project was being founded, in the order they arrived. The mark is for good. | `modules/hall-ui/public/hall-widgets.js:124` |
| `04bbccfe7465` | certain | Everything a new builder needs before claiming their first task. About a ten-minute read. | `modules/hall-ui/public/primer.html:42` |
| `89d9c0962048` | certain | Everything that fell out of it | `modules/hall-ui/public/idea.js:420` |
| `37110f7e2b27` | certain | Everything this builder has shipped. Seen one role at a time, with goals and ideas, under | `modules/hall-ui/public/profile.html:112` |
| `efdb46f76b02` | certain | Everything this instance can run: what the core ships, what this project built, and who keeps each one true as | `modules/hall-ui/public/modules.html:35` |
| `57d5ba0fdefb` | certain | Exit full screen | `modules/hall-ui/public/shell.js:654` |
| `94339ddaeeea` | certain | Explore: the sky reveals itself as you follow routes from where you begin. | `modules/hall-ui/public/goal-map.html:74` |
| `de62f4cc7d2e` | certain | File a bug or idea | `modules/hall-ui/public/ideas.html:55` |
| `297a6d0a8608` | certain | File conflicts in your goals | `modules/hall-ui/public/goal-inbox.js:126` |
| `0f166311ff3f` | certain | File it | `modules/hall-ui/public/blockers.js:313` |
| `0f166311ff3f` | certain | File it | `modules/hall-ui/public/ideas.html:115` |
| `c8703afe2a3d` | certain | File it as a Full Idea: the line, then five questions, scored on completeness. Off = a quick idea, one line. | `modules/hall-ui/public/goal-map.html:91` |
| `c8703afe2a3d` | certain | File it as a Full Idea: the line, then five questions, scored on completeness. Off = a quick idea, one line. | `modules/hall-ui/public/thinking.html:99` |
| `0c4632f983db` | certain | File the change | `modules/hall-ui/public/copy-desk.html:173` |
| `536a7e99640a` | certain | File the flag | `modules/hall-ui/public/copy-desk.html:108` |
| `077cf99f49f6` | certain | File this idea | `modules/hall-ui/public/ideas.html:196` |
| `a7bdd4706975` | certain | Filed as task {…} — this review is closed against it. | `modules/hall-ui/public/studio.js:480` |
| `6430ee350486` | certain | Filed to the inbox. | `modules/hall-ui/public/ideas.js:785` |
| `0f10a69cabb7` | certain | Filed. | `modules/hall-ui/public/blockers.js:373` |
| `08ba8e3c1701` | certain | Filing is open to anyone. Linking to a task needs Metic+ — if you name one and aren’t, the blocker still files | `modules/hall-ui/public/blockers.js:320` |
| `e8dd9a8f3a7e` | certain | Filter sessions by kind | `modules/hall-ui/public/sessions.html:67` |
| `e77b158b074d` | certain | Find a skill | `modules/hall-ui/public/settings-specialities.js:242` |
| `1def0e7c716e` | certain | Find something to flag | `modules/hall-ui/public/copy-desk.html:64` |
| `32b40fdae34f` | certain | Finding the next page… | `modules/hall-ui/public/tweak-editor.html:99` |
| `e8738f535783` | certain | Finish later — everything stays off until you save | `modules/hall-ui/public/settings-specialities.js:180` |
| `1109aec05482` | certain | First install | `modules/hall-ui/public/hall-render.js:832` |
| `a9d31a8e7d74` | certain | First — obtain the repo | `modules/hall-ui/public/hall-render.js:895` |
| `149d97457483` | certain | Fit the sky (0) | `modules/hall-ui/public/goal-map.html:79` |
| `149d97457483` | certain | Fit the sky (0) | `modules/hall-ui/public/thinking.html:87` |
| `78c9f932657f` | certain | Fit the whole sky | `modules/hall-ui/public/goal-map.html:79` |
| `78c9f932657f` | certain | Fit the whole sky | `modules/hall-ui/public/thinking.html:87` |
| `86ef86c5c647` | certain | Fit to view | `modules/hall-ui/public/diagram-viewer.js:97` |
| `86ef86c5c647` | certain | Fit to view | `modules/hall-ui/public/diagram-viewer.js:100` |
| `78107a76a755` | certain | Five diagrams that show, at a glance, how work flows through {{worldName}}'s development system. | `modules/hall-ui/public/diagrams.html:33` |
| `18ab1be9d3ad` | certain | Five questions, and a score that counts how much of each you actually answered. | `modules/hall-ui/public/ideas.js:1010` |
| `c6c9d3129ab2` | certain | Five things every project settles. Two of them are knobs you can turn here; the other three are decided in com | `modules/hall-ui/public/project-settings.html:41` |
| `b9267033b1f1` | certain | Flag this copy | `modules/hall-ui/public/copy-desk.html:83` |
| `82149b1deacd` | certain | Flag this… | `modules/hall-ui/public/copy-desk.js:164` |
| `448d00771dc8` | certain | Flagged. It is in the queue. | `modules/hall-ui/public/copy-desk.js:391` |
| `e0e2606e1104` | certain | Fleet costs | `modules/hall-ui/public/fleet.html:15` |
| `e0e2606e1104` | certain | Fleet costs | `modules/hall-ui/public/fleet.html:15` |
| `e0e2606e1104` | certain | Fleet costs | `modules/hall-ui/public/fleet.html:24` |
| `9b0efcaac184` | certain | Fleet costs — {{worldName}} | `modules/hall-ui/public/fleet.html:6` |
| `9b0efcaac184` | certain | Fleet costs — {{worldName}} | `modules/hall-ui/public/fleet.html:6` |
| `42cee5cb3584` | certain | Fold this idea into # | `modules/hall-ui/public/task-detail.js:561` |
| `94c68a78cd89` | certain | Follow a route from a goal you know to reach it — or turn explore off to see everything. | `modules/hall-ui/public/sky-interaction.js:35` |
| `d5d7bad187ac` | certain | For a criterion with nothing to see on screen: it will be signed off without a recording | `modules/hall-ui/public/criterion-uat-ui.js:85` |
| `3001bd688837` | certain | Founding builders | `modules/hall-ui/public/ranks.html:46` |
| `647bcfcfdb03` | certain | Fresh CLI token issued. Paste it in your terminal: | `modules/hall-ui/public/settings.js:756` |
| `55c71d76a94c` | certain | From creation to production — and the exact step where {{currency}} are awarded (at | `modules/hall-ui/public/diagrams.html:52` |
| `d32c5e058d1e` | certain | From the system | `modules/hall-ui/public/hall-render.js:707` |
| `fc6fdfa639a7` | certain | Full log | `modules/hall-ui/public/task.js:501` |
| `11fc0483c149` | certain | Full screen — press Esc, or the button in the corner, to bring the bars back. | `modules/hall-ui/public/shell.js:619` |
| `ecae3916bf01` | certain | Gate — {{worldName}} | `modules/hall-ui/public/gate.html:6` |
| `ecae3916bf01` | certain | Gate — {{worldName}} | `modules/hall-ui/public/gate.html:6` |
| `c93912bbad76` | certain | Gathering the reviews and flagged copy that wait for you. | `modules/hall-ui/public/studio.html:160` |
| `4638e024f0af` | certain | Generated from the code on the last deploy · | `modules/hall-ui/public/atlas.js:431` |
| `3c1a5d27ef0b` | certain | Generated from the code on the last deploy. | `modules/hall-ui/public/atlas.js:431` |
| `e79fe220b0fc` | certain | Genesis stages | `modules/hall-ui/public/genesis-home.js:71` |
| `2ae2114b61db` | certain | Get a free key ↗ | `modules/hall-ui/public/settings.js:800` |
| `4794a991de3d` | certain | Getting started | `modules/hall-ui/public/hall-widgets.js:59` |
| `a28b1a567f1a` | certain | GitHub username | `modules/hall-ui/public/hall-render.js:297` |
| `8e52f0649662` | certain | Give the category a label. | `modules/hall-ui/public/project-settings.js:189` |
| `79934b879a12` | certain | Give the nod | `modules/hall-ui/public/goal-inbox.js:296` |
| `3225725455b7` | certain | Go through them again | `modules/hall-ui/public/settings-specialities.js:163` |
| `988e2c60df3d` | certain | Goal archived. | `modules/hall-ui/public/goals-render.js:1078` |
| `9e70797b7e97` | certain | Goal id | `modules/hall-ui/public/goals-render.js:859` |
| `529460e82058` | certain | Goal invitations to you | `modules/hall-ui/public/goal-inbox.js:150` |
| `ed1966d824a5` | certain | Goal number | `modules/hall-ui/public/gate.js:360` |
| `e2a9e33abe60` | certain | Goal tasks | `modules/hall-ui/public/goals.html:143` |
| `ec88b946ad16` | certain | Goal {…} | `modules/hall-ui/public/gate.js:353` |
| `6f0deb0b667d` | certain | Goal {…} added. | `modules/hall-ui/public/gate.js:473` |
| `8a421ae268e6` | certain | Goal {…} removed. | `modules/hall-ui/public/gate.js:497` |
| `e0bc28d10785` | certain | Goals could not be loaded. Refresh to try again. | `modules/hall-ui/public/goals-page.js:861` |
| `4517f2253d0f` | certain | Goals couldn’t be loaded just now. Refresh to try again. | `modules/hall-ui/public/goals.js:121` |
| `6a85997bda21` | certain | Goals created | `modules/hall-ui/public/profile.html:153` |
| `6bbd703b5aad` | certain | Goals it can work on | `modules/hall-ui/public/gate.js:369` |
| `2ed2cb8fbffd` | certain | Goals page | `modules/hall-ui/public/goals.js:94` |
| `320a0516a33e` | certain | Goals seeded — awaiting kickoff | `modules/hall-ui/public/roadmap.js:218` |
| `bba4caf837e9` | certain | Goals — {{worldName}} | `modules/hall-ui/public/goals.html:6` |
| `bba4caf837e9` | certain | Goals — {{worldName}} | `modules/hall-ui/public/goals.html:6` |
| `80fd51db38d7` | certain | Good evening. | `modules/hall-ui/public/studio.html:95` |
| `cab3de254155` | certain | Government — {{worldName}} | `modules/hall-ui/public/government.html:6` |
| `cab3de254155` | certain | Government — {{worldName}} | `modules/hall-ui/public/government.html:6` |
| `24d58d284952` | certain | Grades across all recent shipped work — a rolling aggregate. | `modules/hall-ui/public/watch.html:83` |
| `721fe281f993` | certain | Granted by | `modules/hall-ui/public/hall-widgets.js:193` |
| `fa087609bd2e` | certain | Hand a custom rank to a builder. The four ladder ranks are assigned by rank itself and cannot be granted here. | `modules/hall-ui/public/government.html:106` |
| `5fb6c11ea890` | certain | Having a command does not give you permission to use it: some refuse below a certain rank, and that is checked | `modules/hall-ui/public/commands.html:40` |
| `80e6bce01794` | certain | Headline numbers | `modules/hall-ui/public/profile.js:118` |
| `7cdddb5e2332` | certain | Held changes summary | `modules/hall-ui/public/gate.html:44` |
| `adac4cd8b973` | certain | Held pull requests | `modules/hall-ui/public/gate.html:64` |
| `3dec722a5f6e` | certain | Hidden from Claude's menu: type the slash command yourself | `modules/hall-ui/public/commands-lib.js:93` |
| `0f5541a412d5` | certain | Hide the clock | `modules/hall-ui/public/goal-map.html:129` |
| `0f5541a412d5` | certain | Hide the clock | `modules/hall-ui/public/thinking.html:130` |
| `ce8a068a34cf` | certain | Higher ranks only | `modules/hall-ui/public/sessions.html:40` |
| `d9bd3b703fe4` | certain | Hover an island to light its links, click one for its details, or open it from the index below. | `modules/hall-ui/public/atlas.html:68` |
| `6dd3c797943b` | certain | How Claude should engage you in it | `modules/hall-ui/public/settings.html:261` |
| `0469a83cf1e8` | certain | How Claude talks to you | `modules/hall-ui/public/settings.html:210` |
| `0469a83cf1e8` | certain | How Claude talks to you | `modules/hall-ui/public/settings.html:320` |
| `68382894d8f9` | certain | How a planning session seeds each version's task pool, and how a version closes and archives its scope. | `modules/hall-ui/public/diagrams.html:85` |
| `0bab9286ea38` | certain | How each builder's shipped work has been graded over the past thirty days. | `modules/hall-ui/public/watch.html:76` |
| `fb7489e8b67c` | certain | How it has changed | `modules/hall-ui/public/government.js:971` |
| `1afadcefd6ea` | certain | How many passes | `modules/hall-ui/public/genesis-home.js:105` |
| `d76a5fcbde7c` | certain | How much the claim and ship cards show. Richer cards explain more and cost more tokens; the confirmation line  | `modules/hall-ui/public/settings-render.js:84` |
| `160adde1e398` | certain | How much your session cards — what | `modules/hall-ui/public/settings.html:315` |
| `ec3f26ff8137` | certain | How planning sessions feed each version's task pool and how a version closes. | `modules/hall-ui/public/diagrams.html:84` |
| `0bae5deb899d` | certain | How readily Claude opens a | `modules/hall-ui/public/settings.html:296` |
| `63dbe9873b4e` | certain | How replies are pitched for you — the vocabulary assumed, how much hand-holding local tooling gets, how long a | `modules/hall-ui/public/settings.html:211` |
| `868cf6930d64` | certain | How task estimates compare with the time work actually took. | `modules/hall-ui/public/watch.html:149` |
| `6fad68f727e2` | certain | How the session read to this builder, scored against their own interaction profile. Advisory — it gates nothin | `modules/hall-ui/public/sessions.html:78` |
| `81fa43a51f8f` | certain | How the system works | `modules/hall-ui/public/diagrams.html:32` |
| `06cb721a03e1` | certain | How the system works — {{worldName}} | `modules/hall-ui/public/diagrams.html:6` |
| `06cb721a03e1` | certain | How the system works — {{worldName}} | `modules/hall-ui/public/diagrams.html:6` |
| `4f3802e6c81e` | certain | How the whole build is doing — the program at a glance, then each version. Shipped work stays out of the way. | `modules/hall-ui/public/roadmap.js:433` |
| `b536897de6a3` | certain | How this project is governed. | `modules/hall-ui/public/government.js:1054` |
| `971f3eb36342` | certain | How to read the sky | `modules/hall-ui/public/goal-map.html:78` |
| `971f3eb36342` | certain | How to read the sky | `modules/hall-ui/public/goal-map.html:117` |
| `971f3eb36342` | certain | How to read the sky | `modules/hall-ui/public/thinking.html:86` |
| `971f3eb36342` | certain | How to read the sky | `modules/hall-ui/public/thinking.html:118` |
| `7d502584e741` | certain | How to read the sky (?) | `modules/hall-ui/public/goal-map.html:78` |
| `7d502584e741` | certain | How to read the sky (?) | `modules/hall-ui/public/thinking.html:86` |
| `0f99c224fa95` | certain | How we price a swap | `modules/hall-ui/public/settings-specialities.js:354` |
| `2d156231e9fe` | certain | How you advance | `modules/hall-ui/public/ranks.html:64` |
| `c763425718f2` | certain | How you get paid, and how you earn trust. A reference to jump around in: every section has its own link, and t | `modules/hall-ui/public/drachmae.html:38` |
| `4c247368c384` | certain | How you got here, what you'd build | `modules/hall-ui/public/hall-render.js:297` |
| `3438c73d4f3d` | certain | How you start it | `modules/hall-ui/public/commands-lib.js:100` |
| `298ff22576ee` | certain | How your output has changed over time — work shipped, cost and time per work, and how reviews held up. | `modules/hall-ui/public/hall-widgets.js:213` |
| `08d3bf741a2c` | certain | I have read it | `modules/hall-ui/public/primer.html:102` |
| `08d3bf741a2c` | certain | I have read it | `modules/hall-ui/public/primer.js:258` |
| `edc4ed246faf` | certain | I tried this on the live site | `modules/hall-ui/public/criterion-uat-ui.js:145` |
| `a4ff1e9c34e3` | certain | Idea {…} | `modules/hall-ui/public/idea.js:445` |
| `a4ff1e9c34e3` | certain | Idea {…} | `modules/hall-ui/public/idea.js:487` |
| `ba82ec56f1e3` | certain | Idea — {{worldName}} | `modules/hall-ui/public/idea.html:6` |
| `ba82ec56f1e3` | certain | Idea — {{worldName}} | `modules/hall-ui/public/idea.html:6` |
| `e181637c5a5e` | certain | Ideas awaiting triage | `modules/hall-ui/public/builders.js:897` |
| `379b20d548ad` | certain | Ideas whose author has said "I had the thought but not the full picture". Anyone can develop one — the author  | `modules/hall-ui/public/ideas.html:127` |
| `ef224c9de7c8` | certain | Ideas — {{worldName}} | `modules/hall-ui/public/ideas.html:6` |
| `ef224c9de7c8` | certain | Ideas — {{worldName}} | `modules/hall-ui/public/ideas.html:6` |
| `9e9f8a44276b` | certain | Identity vouched | `modules/hall-ui/public/watch.js:396` |
| `7d6a7de7a69e` | certain | If the {…} has invited you, sign in with GitHub and you're in. If not, ask them for an invite — this project d | `modules/hall-ui/public/hall-render.js:289` |
| `4ef9f2a4df3b` | certain | If you own this project, | `modules/hall-ui/public/deploy.js:416` |
| `b6c47d4ee42c` | certain | Image key removed. | `modules/hall-ui/public/settings.js:973` |
| `783853467d52` | certain | Image-generation key | `modules/hall-ui/public/settings.html:190` |
| `5c2e2bcbd5fb` | certain | In Progress | `modules/hall-ui/public/work.html:115` |
| `75cfcdd41661` | certain | In this primer | `modules/hall-ui/public/primer.html:58` |
| `dad3388b49c9` | certain | Invitation rescinded. | `modules/hall-ui/public/goals-page.js:657` |
| `12561be47da9` | certain | Invitation sent — they join once they accept. | `modules/hall-ui/public/goals-render.js:1300` |
| `24f9e88c21f6` | certain | Invite by GitHub username | `modules/hall-ui/public/watch.js:295` |
| `33a35c77d372` | certain | Invite expired {…} — invite them again to reopen the door | `modules/hall-ui/public/watch.js:501` |
| `b9cb720ad5d1` | certain | Invited? Sign in | `modules/hall-ui/public/hall-render.js:289` |
| `0e48bb2c8c94` | certain | Island index | `modules/hall-ui/public/atlas.html:76` |
| `2170b74c6526` | certain | Isometric map of the repository | `modules/hall-ui/public/atlas.html:54` |
| `bd8d04eb265c` | certain | It cleared the completeness grade at {…}/100. | `modules/hall-ui/public/board-room.js:331` |
| `bef8dbf78170` | certain | It comes back to your studio once it is applied, and nothing ships until you have seen it. | `modules/hall-ui/public/tweak-editor.html:95` |
| `4f5b39802b07` | certain | It holds no unfinished work, so this is a single step. Archiving is reversible — an archived goal can be reope | `modules/hall-ui/public/goals-render.js:1035` |
| `72ebf29c46e8` | certain | It needs a recording again | `modules/hall-ui/public/criterion-uat-ui.js:84` |
| `a28aa368453f` | certain | It shipped and it is live. Say what you see — your review coaches the grader and never blocks what shipped. | `modules/hall-ui/public/studio.js:231` |
| `d751fe51e178` | certain | It shipped and it is live. Your review coaches the grader on how it judged the work, then remakes or tweaks th | `modules/hall-ui/public/studio.js:232` |
| `a21788f84e29` | certain | Its author gave no scope recommendation. | `modules/hall-ui/public/board-room.js:300` |
| `a21788f84e29` | certain | Its author gave no scope recommendation. | `modules/hall-ui/public/idea.js:162` |
| `b0bcb3f844ec` | certain | Its author marked this as needing development — anyone can turn it into a Full Idea, and they keep the credit  | `modules/hall-ui/public/idea.js:473` |
| `680491549e47` | certain | Its author recommends this becomes | `modules/hall-ui/public/board-room.js:299` |
| `680491549e47` | certain | Its author recommends this becomes | `modules/hall-ui/public/idea.js:166` |
| `5e62ee5addf1` | certain | Its details are below. | `modules/hall-ui/public/shell.js:851` |
| `d42a078838bf` | certain | Its notes could not be read. | `modules/hall-ui/public/settings-software-update.js:101` |
| `1e81d59d6955` | certain | Its work has shipped; someone who did not build it needs to try it on the live site | `modules/hall-ui/public/criterion-uat-ui.js:77` |
| `b7719e855009` | certain | Join goal | `modules/hall-ui/public/goals-render.js:980` |
| `9f9424a5100b` | certain | Join our Discord | `modules/hall-ui/public/hall-render.js:807` |
| `7ee76a958445` | certain | Join requests | `modules/hall-ui/public/goals-render.js:1441` |
| `b7ab5922126b` | certain | Join-requests to approve | `modules/hall-ui/public/goal-inbox.js:154` |
| `d305f0df6f25` | certain | Jump to | `modules/hall-ui/public/palette.js:351` |
| `01176c156112` | certain | Jump to a goal or a thought | `modules/hall-ui/public/goal-map.html:84` |
| `01176c156112` | certain | Jump to a goal or a thought | `modules/hall-ui/public/thinking.html:92` |
| `2bfc5a50ce88` | certain | Jump to a page or record | `modules/hall-ui/public/shell.js:493` |
| `eba610d25523` | certain | Jump to… | `modules/hall-ui/public/shell.js:495` |
| `de0e1590667f` | certain | Keep all {…} {…} — they are the values the code drops in, and the change cannot land without them. | `modules/hall-ui/public/copy-desk.js:442` |
| `c82dfb20818c` | certain | Kept out of Claude's menu to save room; type | `modules/hall-ui/public/commands.html:37` |
| `fbe40b5818a3` | certain | Key removed. | `modules/hall-ui/public/settings.js:972` |
| `93c17262bacf` | certain | Key storage is being set up by an Archon — check back shortly. {…} | `modules/hall-ui/public/settings.js:851` |
| `2a3c9e501f8e` | certain | Key storage isn't set up yet. As an Archon you can turn it on now — the server generates and safely stores the | `modules/hall-ui/public/settings.js:847` |
| `e3b473af2f69` | certain | Kind of work | `modules/hall-ui/public/hall-render.js:1145` |
| `7d6eaa8d4514` | certain | Kinds of work shipped | `modules/hall-ui/public/hall-render.js:1258` |
| `81f62e066dbf` | certain | Last 14 days: {…} / 10 average across {…} graded work{…} ({…} passed). | `modules/hall-ui/public/builders.js:585` |
| `35a15eb0a117` | certain | Last 30 days | `modules/hall-ui/public/hall-widgets.js:160` |
| `9be8b839eff8` | certain | Last 7 days | `modules/hall-ui/public/hall-widgets.js:160` |
| `59f0bc78a28f` | certain | Last 90 days | `modules/hall-ui/public/hall-widgets.js:161` |
| `13bae4dfb28e` | certain | Last claimed by | `modules/hall-ui/public/task.js:679` |
| `9e8828d602bc` | certain | Lay your thoughts over the project map. | `modules/hall-ui/public/goal-map.html:75` |
| `7c9b7a89353b` | certain | Leave goal | `modules/hall-ui/public/goals-render.js:967` |
| `6137d2679912` | certain | Leave it off | `modules/hall-ui/public/settings-specialities.js:138` |
| `f192ff6563f9` | certain | Leave your GitHub username and an Archon will let you in. No coding needed to start — once you're approved, si | `modules/hall-ui/public/hall-render.js:297` |
| `e14ebcf3eec5` | certain | Legislation has passed. Genesis is complete. | `modules/hall-ui/public/genesis-home.js:188` |
| `d6a78b9e5368` | certain | Let it be for now | `modules/hall-ui/public/studio.js:233` |
| `d6a78b9e5368` | certain | Let it be for now | `modules/hall-ui/public/studio.js:248` |
| `b8ba1fa4457c` | certain | Link a task | `modules/hall-ui/public/blockers.js:148` |
| `43660902bf79` | certain | Link copied. | `modules/hall-ui/public/drachmae.js:332` |
| `a53e0cde7ff7` | certain | Link first — your rank role is set the moment you join. | `modules/hall-ui/public/settings.js:684` |
| `64e85f1691f9` | certain | Link your Discord account and you're added to the {{worldName}} server with your rank role already set — no in | `modules/hall-ui/public/settings.html:64` |
| `9a31cf5fe05b` | certain | Linking opens Discord's consent screen; unlinking applies at once. | `modules/hall-ui/public/settings.html:69` |
| `daf84bba41b1` | certain | Loading goals… | `modules/hall-ui/public/goals.html:36` |
| `93ceeaa4e226` | certain | Loading idea | `modules/hall-ui/public/idea.html:32` |
| `2b5826012538` | certain | Loading profile… | `modules/hall-ui/public/profile.html:35` |
| `554b156a08d6` | certain | Loading sessions… | `modules/hall-ui/public/sessions.html:32` |
| `a0c18cece568` | certain | Loading sittings… | `modules/hall-ui/public/board-room.js:544` |
| `7ca55f9ba183` | certain | Loading task | `modules/hall-ui/public/task.html:35` |
| `20d8552e13db` | certain | Loading tasks… | `modules/hall-ui/public/work.html:32` |
| `217f64ef8667` | certain | Loading the catalog… | `modules/hall-ui/public/modules.html:62` |
| `a8b3b04b0b4d` | certain | Loading the copy desk… | `modules/hall-ui/public/copy-desk.html:28` |
| `fcd755e8dd30` | certain | Loading the five questions… | `modules/hall-ui/public/ideas.html:183` |
| `e201b4962858` | certain | Loading the idea | `modules/hall-ui/public/idea.html:43` |
| `9972fc9b4727` | certain | Loading the map… | `modules/hall-ui/public/atlas.html:51` |
| `ceec2218efe3` | certain | Loading the roadmap… | `modules/hall-ui/public/roadmap.html:28` |
| `ceec2218efe3` | certain | Loading the roadmap… | `modules/hall-ui/public/roadmap.html:33` |
| `db04803d9e72` | certain | Loading the roster… | `modules/hall-ui/public/roster.html:39` |
| `fd40f6543419` | certain | Loading the slash commands… | `modules/hall-ui/public/commands.html:39` |
| `0cdad42009e6` | certain | Loading the task | `modules/hall-ui/public/task.html:46` |
| `af8ea41cdf53` | certain | Loading the terminal commands… | `modules/hall-ui/public/commands.html:46` |
| `1dffb93947f2` | certain | Loading this project’s skills… | `modules/hall-ui/public/settings.html:281` |
| `d28d321e8a1e` | certain | Loading versions… | `modules/hall-ui/public/task-detail.js:418` |
| `3c43f157035e` | certain | Loading your goals… | `modules/hall-ui/public/goals.js:95` |
| `7a239a17afc8` | certain | Loading your preferences… | `modules/hall-ui/public/settings.html:35` |
| `04df1bd30129` | certain | Loading your rank… | `modules/hall-ui/public/ranks.html:30` |
| `c27711f9eb4d` | certain | Locked until you reach the end of the article above. | `modules/hall-ui/public/primer.html:103` |
| `4017ee030bc2` | certain | Lookback window | `modules/hall-ui/public/profile-charts.js:526` |
| `73677b6839d7` | certain | Looks good | `modules/hall-ui/public/studio.js:191` |
| `06b4ede3fb58` | certain | Machine principals | `modules/hall-ui/public/government.html:122` |
| `6b3d660e0e31` | certain | Map view | `modules/hall-ui/public/atlas.html:46` |
| `525e085a6770` | certain | Mark backend-only | `modules/hall-ui/public/criterion-uat-ui.js:85` |
| `4924438fb299` | certain | Mark resolved | `modules/hall-ui/public/collab.js:278` |
| `4924438fb299` | certain | Mark resolved | `modules/hall-ui/public/collab.js:304` |
| `8bdec961e84a` | certain | Markets, incentives, and how to price them. | `modules/hall-ui/public/settings.html:258` |
| `6e73716aec6c` | certain | May be offered for sale later | `modules/hall-ui/public/settings.html:274` |
| `df335a1224ae` | certain | Member since {…} | `modules/hall-ui/public/hall-render.js:566` |
| `df335a1224ae` | certain | Member since {…} | `modules/hall-ui/public/profile.js:118` |
| `c7a670e9552d` | certain | Merged into | `modules/hall-ui/public/profile.js:539` |
| `f3ba5b1b7849` | certain | Merging work does not put it in front of anyone. This is the step that does: it moves this project onto a newe | `modules/hall-ui/public/deploy.html:54` |
| `7637613c231b` | certain | Metic rank and above may vote | `modules/hall-ui/public/builders.js:781` |
| `91328a97fe68` | certain | Mingle pairs you with someone from another role. Saying no costs nothing. | `modules/hall-ui/public/collab.html:96` |
| `d7ce4a3bb745` | certain | Minimize the welcome panel | `modules/hall-ui/public/hall-widgets.js:52` |
| `19b0ed5781ae` | certain | Minimum rank required to claim this task | `modules/hall-ui/public/task-lib.js:85` |
| `64e91044df43` | certain | Mint a fresh CLI token using this browser session and paste it into your terminal — the quick way back in when | `modules/hall-ui/public/settings.html:134` |
| `0f8ea58a536b` | certain | Module catalog | `modules/hall-ui/public/modules.html:49` |
| `adcfddee56a8` | certain | Module scope — tasks authored in this goal are bounded to these modules | `modules/hall-ui/public/goals-render.js:865` |
| `9af4b7a3a36f` | certain | Module truth | `modules/hall-ui/public/atlas.html:48` |
| `319e9db996ea` | certain | Modules — {{worldName}} | `modules/hall-ui/public/modules.html:6` |
| `319e9db996ea` | certain | Modules — {{worldName}} | `modules/hall-ui/public/modules.html:6` |
| `9dacaf382dc8` | certain | More ways to open the page | `modules/hall-ui/public/tweak-editor.html:57` |
| `1ae18e58fead` | certain | Most recent first. Each load of this page is itself recorded in the audit log. | `modules/hall-ui/public/sessions.js:340` |
| `f14a91b3f625` | certain | Most recent first. Each row is one recorded work session; every id on it opens its record. | `modules/hall-ui/public/sessions.html:56` |
| `e52ae74f0052` | certain | Move to goal | `modules/hall-ui/public/task.js:599` |
| `e77d5f3beaef` | certain | Move to {…} | `modules/hall-ui/public/deploy.js:561` |
| `e77d5f3beaef` | certain | Move to {…} | `modules/hall-ui/public/deploy.js:723` |
| `a851e4dc141b` | certain | Moved {…}, and the box confirmed it. The project’s repository on GitHub still names the old core, so changes p | `modules/hall-ui/public/deploy.js:382` |
| `393139f648b8` | certain | Moving to core | `modules/hall-ui/public/deploy.js:330` |
| `3d0d554cd684` | certain | Name (optional) | `modules/hall-ui/public/gate.js:360` |
| `ae84ebe1d735` | certain | Name cannot be blank. | `modules/hall-ui/public/settings.js:605` |
| `31e91ee6ce03` | certain | Name must be {…} characters or fewer. | `modules/hall-ui/public/settings.js:610` |
| `5e8199266a8a` | certain | Name unvouched | `modules/hall-ui/public/watch.js:397` |
| `83197947ee8d` | certain | Needed by | `modules/hall-ui/public/goal-forest-render.js:146` |
| `3970d299c95a` | certain | Needs work | `modules/hall-ui/public/studio.js:191` |
| `7def635421ea` | certain | Needs your attention | `modules/hall-ui/public/goal-inbox.js:597` |
| `87f09d983f6c` | certain | New category label | `modules/hall-ui/public/project-settings.js:138` |
| `d427d9dab01c` | certain | New claims are paused: {…} confirmed {…} can't land yet, so {…} reward is pending. Rebase and re-ship, or rele | `modules/hall-ui/public/hall-render.js:677` |
| `7fcc2583c372` | certain | New custom rank | `modules/hall-ui/public/government.html:79` |
| `9e06c14d155a` | certain | New here — request access | `modules/hall-ui/public/hall-render.js:297` |
| `ccf08aecab86` | certain | New here — sign in to join | `modules/hall-ui/public/hall-render.js:280` |
| `de1713edd4aa` | certain | Next page | `modules/hall-ui/public/hall-kit.js:74` |
| `659d8256139c` | certain | Next up — ready to claim | `modules/hall-ui/public/hall-widgets.js:103` |
| `f52ba261d930` | certain | Next › | `modules/hall-ui/public/hall-kit.js:74` |
| `41ec1cf65d6f` | certain | No GitHub account yet? Make a free one at | `modules/hall-ui/public/hall-render.js:297` |
| `c255749ec989` | certain | No achievements earned yet. | `modules/hall-ui/public/builders.js:470` |
| `c255749ec989` | certain | No achievements earned yet. | `modules/hall-ui/public/profile.js:199` |
| `479c1a45f39d` | certain | No backlog tasks match these filters. Try widening them. | `modules/hall-ui/public/work.js:812` |
| `83f62fc94271` | certain | No builder account found for this sign-in. | `modules/hall-ui/public/settings.js:1165` |
| `2e9c154c09cd` | certain | No builder selected. Open a builder from the | `modules/hall-ui/public/profile.js:958` |
| `449db2ead464` | certain | No changes are listed for this version. | `modules/hall-ui/public/settings-software-update.js:103` |
| `6d6fd2314248` | certain | No cross-project activity reported yet. | `modules/hall-ui/public/profile.js:378` |
| `b1ada579483c` | certain | No custom ranks yet | `modules/hall-ui/public/government.js:358` |
| `6e2d2e11f84a` | certain | No description. | `modules/hall-ui/public/idea.js:122` |
| `881d06b5e79f` | certain | No done-when criteria yet | `modules/hall-ui/public/goals-render.js:160` |
| `93c00cb1423a` | certain | No goal | `modules/hall-ui/public/work.js:590` |
| `d10dca462260` | certain | No goal (homeless) | `modules/hall-ui/public/ideas.js:581` |
| `fbb887a9b678` | certain | No goal has criteria met yet — work is in the task queue. | `modules/hall-ui/public/roadmap.js:128` |
| `6771a8966ec3` | certain | No goals declared yet — this version is tracked by its {…} done-when criteria. | `modules/hall-ui/public/roadmap.js:106` |
| `abc64639b134` | certain | No goals seeded yet. | `modules/hall-ui/public/roadmap.js:205` |
| `139ec3636c22` | certain | No introductions right now. One appears here when a pairing round runs. | `modules/hall-ui/public/collab.html:99` |
| `3b9823dd4579` | certain | No maintenance declared — nobody is on the hook for this module as the core advances. | `modules/hall-ui/public/modules.js:92` |
| `64a4281934d1` | certain | No match. Try a page name, or an id like | `modules/hall-ui/public/palette.js:307` |
| `f52552a6afcd` | certain | No notes were packed for this version. | `modules/hall-ui/public/settings-software-update.js:102` |
| `4f89817b92e5` | certain | No onboarding steps recorded yet. | `modules/hall-ui/public/hall-render.js:883` |
| `421ae031594e` | certain | No open goals in this version | `modules/hall-ui/public/task.js:598` |
| `2a6d7552e21f` | certain | No other sessions. | `modules/hall-ui/public/settings-sessions.js:64` |
| `90623fec4cfa` | certain | No page is open. | `modules/hall-ui/public/tweak-editor.js:563` |
| `1a46c31343cb` | certain | No projects are hosted here yet. | `modules/hall-ui/public/fleet-costs.js:68` |
| `9f73b3f3dad0` | certain | No rank floor — any builder can claim this task | `modules/hall-ui/public/task-lib.js:82` |
| `722d107d7a90` | certain | No render is attached to this page yet. /tweak attaches them when it applies a page; until then there is nothi | `modules/hall-ui/public/approval-queue.js:135` |
| `3fd0c6fcb92e` | certain | No request and no invite needed. Sign in with GitHub, and a step-by-step guide takes you the rest of the way. | `modules/hall-ui/public/hall-render.js:280` |
| `2947c1ddea9a` | certain | No running box to deploy. | `modules/hall-ui/public/deploy.js:700` |
| `b67c628da0c1` | certain | No screen to record: this is signed off without a video | `modules/hall-ui/public/criterion-uat-ui.js:64` |
| `9fb9f766450d` | certain | No sections yet | `modules/hall-ui/public/primer.js:130` |
| `bef9fe43ba84` | certain | No sessions recorded yet. They land here as builders ship and end sessions. | `modules/hall-ui/public/sessions.js:146` |
| `084748fd85b4` | certain | No shipped work is recorded between core {…} and {…}. | `modules/hall-ui/public/deploy.js:541` |
| `4485497d87bb` | certain | No specialities yet. Create one below — it takes a name and a craft, and you can train it afterwards. | `modules/hall-ui/public/settings-specialities.js:416` |
| `545dc44ad427` | certain | No task in this goal depends on another task in this goal. | `modules/hall-ui/public/goal-forest-render.js:126` |
| `da838f6056b1` | certain | No tasks for this stage yet. | `modules/hall-ui/public/genesis-home.js:178` |
| `712b64d8273f` | certain | No tasks match these filters. Try widening them. | `modules/hall-ui/public/work.js:427` |
| `2302ee46744e` | certain | No terminal commands found. | `modules/hall-ui/public/commands.js:46` |
| `78f78d1d1e1f` | certain | No version is in flight right now. | `modules/hall-ui/public/roadmap.js:409` |
| `c9800f8b6bc8` | certain | No versions declared yet. | `modules/hall-ui/public/roadmap.js:427` |
| `4654849396a3` | certain | No work reviewed yet. | `modules/hall-ui/public/hall-widgets.js:181` |
| `9cf1c752b65d` | certain | No works shipped yet — the works charts draw once the first one lands. | `modules/hall-ui/public/profile-charts.js:574` |
| `9dbe1981055c` | certain | No {…} render is attached to this page. | `modules/hall-ui/public/approval-queue.js:134` |
| `086665af6208` | certain | No {…} sessions recorded. Choose another kind to widen the ledger. | `modules/hall-ui/public/sessions.js:145` |
| `730a248e7888` | certain | No {…} {…} render; showing {…} {…}. | `modules/hall-ui/public/approval-queue.js:139` |
| `1967d2176f2e` | certain | Nobody has an open ask right now. | `modules/hall-ui/public/collab.html:84` |
| `c65c9f5c02e3` | certain | Nobody is waiting on you. Requests reach you by role — | `modules/hall-ui/public/collab.html:54` |
| `d5cf262e671d` | certain | Nobody is writing this page. Take it, and every line here is yours to type over. | `modules/hall-ui/public/tweak-editor.js:314` |
| `91c409a4aea5` | certain | Nobody vouched for this name — anyone can file a request naming anyone. Confirm who is asking before you admit | `modules/hall-ui/public/watch.js:397` |
| `4016b9cf8d57` | certain | None of your asks have been settled yet. | `modules/hall-ui/public/collab.html:134` |
| `fdfceec7ff97` | certain | Not backend-only | `modules/hall-ui/public/criterion-uat-ui.js:84` |
| `428a62539050` | certain | Not checked yet — the runner takes this reading on its own tick. | `modules/hall-ui/public/deploy.js:455` |
| `c72e0bdb834a` | certain | Not declared in module.json — this is who ships the module. | `modules/hall-ui/public/modules.js:62` |
| `361b353ded5e` | certain | Not enough shipped work yet to chart. | `modules/hall-ui/public/hall-widgets.js:215` |
| `90230572d017` | certain | Not found | `modules/hall-ui/public/task.js:1045` |
| `8226c979db4d` | certain | Not now | `modules/hall-ui/public/collab.js:668` |
| `5ffcdc1a0176` | certain | Not scored — this builder’s own profile waived every signal, or the session predates this measure. | `modules/hall-ui/public/sessions.js:100` |
| `61250b49a90b` | certain | Not scored. | `modules/hall-ui/public/idea.js:84` |
| `8d6afe6def47` | certain | Not signed in | `modules/hall-ui/public/settings.html:43` |
| `a290f6c14df9` | certain | Not taking requests | `modules/hall-ui/public/goals-render.js:975` |
| `20bb29015a84` | certain | Not yet classified. | `modules/hall-ui/public/sessions.js:72` |
| `571b9b22dbda` | certain | Not yet ready — blocked by dependencies or awaiting promotion. These become claimable when their blockers ship | `modules/hall-ui/public/work.html:130` |
| `0c59d118db9b` | certain | Note (optional) | `modules/hall-ui/public/task-detail.js:564` |
| `9ca8cd37cac2` | certain | Note (optional) — why you're asking | `modules/hall-ui/public/goals-render.js:1244` |
| `73c72974f4f9` | certain | Note it | `modules/hall-ui/public/studio.js:191` |
| `c404f22d7892` | certain | Noted on the review — it stays open. | `modules/hall-ui/public/studio.js:423` |
| `1376762e97db` | certain | Nothing anyone asked of you has been settled yet. | `modules/hall-ui/public/collab.html:125` |
| `cd652d04d616` | certain | Nothing changes yet. This files a task carrying your wording; whoever claims it lands the diff, and it ships g | `modules/hall-ui/public/copy-desk.html:168` |
| `b4b8ed14e704` | certain | Nothing explored yet. Pick a starting point in the sky. | `modules/hall-ui/public/sky-panel.js:134` |
| `fec5d78497e8` | certain | Nothing in the backlog right now. | `modules/hall-ui/public/work.js:798` |
| `905e99f158c2` | certain | Nothing is discarded by omission: every task needs a decision before this can be submitted. Abandoning stamps  | `modules/hall-ui/public/goals-render.js:1042` |
| `8edb2116af0d` | certain | Nothing is on your desk yet. The Tweak/CopyWrite Flow has a page ready for you. | `modules/hall-ui/public/studio.html:96` |
| `2ec0fbb20a42` | certain | Nothing is waiting. A spark appears here when its author offers a quick idea up for development. | `modules/hall-ui/public/ideas.js:863` |
| `9ac63d97239a` | certain | Nothing newer is published that this box can take. There is nothing to deploy. | `modules/hall-ui/public/deploy.js:596` |
| `43626cff7071` | certain | Nothing of that kind in your sky. | `modules/hall-ui/public/sky-panel.js:123` |
| `ad9a17a8a5eb` | certain | Nothing shipped yet. | `modules/hall-ui/public/profile.js:297` |
| `f326632f2013` | certain | Nothing to submit — every module here ships with the core. | `modules/hall-ui/public/modules.js:268` |
| `27c0d872db2d` | certain | Nothing you have typed above is lost by opening this. | `modules/hall-ui/public/ideas.html:155` |
| `26a07b64f49d` | certain | Now running core {…} | `modules/hall-ui/public/deploy.js:392` |
| `21cb60a8a96a` | certain | Now running core {…} — but GitHub was not updated. | `modules/hall-ui/public/deploy.js:382` |
| `9d25ba1d2f17` | certain | Off voice — says it in the wrong register | `modules/hall-ui/public/copy-desk.html:89` |
| `3d5d0f81eeac` | certain | Offering a skill turns nothing on. Everyone who uses this speciality is shown each one and chooses for themsel | `modules/hall-ui/public/settings-specialities.js:242` |
| `b89ad49770e7` | certain | On Windows, run | `modules/hall-ui/public/hall-render.js:832` |
| `11a1905c76b2` | certain | On the board | `modules/hall-ui/public/hall-render.js:629` |
| `ea1f179dd878` | certain | On this page | `modules/hall-ui/public/drachmae.html:51` |
| `ea1f179dd878` | certain | On this page | `modules/hall-ui/public/drachmae.html:56` |
| `f7e17c78c8b6` | certain | One line is enough. Developing it is a later step. | `modules/hall-ui/public/ideas.html:37` |
| `d5f0b7156024` | certain | One line. This is what the idea is called everywhere else. | `modules/hall-ui/public/ideas.html:172` |
| `0bc1d1470e22` | certain | Only an open goal can be managed. | `modules/hall-ui/public/goals-render.js:1370` |
| `0bc1d1470e22` | certain | Only an open goal can be managed. | `modules/hall-ui/public/goals-render.js:1386` |
| `3e1d0b2334d1` | certain | Only if it needs it — with the AI at your side, or on your own. | `modules/hall-ui/public/studio.js:211` |
| `45b667751b95` | certain | Only me | `modules/hall-ui/public/settings.html:267` |
| `f9f2a3af318a` | certain | Only mine | `modules/hall-ui/public/work.html:70` |
| `ab48bab11b70` | certain | Only the artist who wrote this page, or another artist, can approve it or send it back. | `modules/hall-ui/public/approval-queue.js:168` |
| `e11eae1d0a92` | certain | Only the goals your thoughts touched — everything else fades. | `modules/hall-ui/public/thinking.html:83` |
| `f74ec527907f` | certain | Only the people allowed to upgrade this project see an Update button here. | `modules/hall-ui/public/settings-software-update.js:73` |
| `f28917ca859e` | certain | Only the thoughts of the last thirty days. | `modules/hall-ui/public/thinking.html:81` |
| `3468d58eb1fd` | certain | Only this goal's owner or a manager (or an Archon) may add members. | `modules/hall-ui/public/goals-render.js:1339` |
| `fa818ee444b4` | certain | Only this goal's owner or a manager (or an Archon) may do this. | `modules/hall-ui/public/goals-render.js:1369` |
| `fa818ee444b4` | certain | Only this goal's owner or a manager (or an Archon) may do this. | `modules/hall-ui/public/goals-render.js:1385` |
| `544011db314a` | certain | Only this goal's owner or a manager (or an Archon) may invite. | `modules/hall-ui/public/goals-render.js:1317` |
| `42bb75e4297c` | certain | Open Settings | `modules/hall-ui/public/gate.js:339` |
| `ade0e39c65e9` | certain | Open blockers | `modules/hall-ui/public/blockers.html:36` |
| `261d123970e8` | certain | Open goal #{…} | `modules/hall-ui/public/roadmap.js:112` |
| `5f3e0b179839` | certain | Open in Sessions | `modules/hall-ui/public/task.js:501` |
| `9f55e4674ebb` | certain | Open in the copy desk | `modules/hall-ui/public/studio.js:248` |
| `3366b115217b` | certain | Open navigation | `modules/hall-ui/public/shell.js:483` |
| `855277dff074` | certain | Open task #{…} | `modules/hall-ui/public/goals-render.js:436` |
| `855277dff074` | certain | Open task #{…} | `modules/hall-ui/public/work.js:835` |
| `99c630009152` | certain | Open tasks whose declared files overlap — sequence these before two builders collide. | `modules/hall-ui/public/goals.html:117` |
| `99c630009152` | certain | Open tasks whose declared files overlap — sequence these before two builders collide. | `modules/hall-ui/public/goals.html:197` |
| `fe9986a9d821` | certain | Open the Board Room | `modules/hall-ui/public/genesis-home.js:198` |
| `fe9986a9d821` | certain | Open the Board Room | `modules/hall-ui/public/genesis-home.js:203` |
| `e073aa0c3847` | certain | Open the conflicts for {…} | `modules/hall-ui/public/goal-inbox.js:112` |
| `676361254d92` | certain | Open the idea composer | `modules/hall-ui/public/idea.js:504` |
| `29e1cb2d32fc` | certain | Open the recording | `modules/hall-ui/public/criterion-uat-ui.js:121` |
| `1cb80282de09` | certain | Open this review | `modules/hall-ui/public/studio.js:233` |
| `ec2a3a90b788` | certain | Open your account page | `modules/hall-ui/public/settings.html:110` |
| `f6f68ba322be` | certain | Open {…} | `modules/hall-ui/public/goal-inbox.js:53` |
| `f6f68ba322be` | certain | Open {…} | `modules/hall-ui/public/goal-inbox.js:69` |
| `f6f68ba322be` | certain | Open {…} | `modules/hall-ui/public/goals.js:67` |
| `7a8dfadb7468` | certain | Opening the rendered page… | `modules/hall-ui/public/approval-queue.js:129` |
| `62e75a9d0af4` | certain | Opening the reviews… | `modules/hall-ui/public/studio.html:159` |
| `a2bd76ae030d` | certain | Opens this project's upgrade{…}: you see what would move, confirm it, and it installs, checks itself, and roll | `modules/hall-ui/public/settings-software-update.js:85` |
| `569980a263ae` | certain | Optional. This is the ledger link — a copy change ships as a task like every other change. | `modules/hall-ui/public/copy-desk.html:130` |
| `f2e9e8f21e8e` | certain | Or add someone without asking… | `modules/hall-ui/public/goals-render.js:1264` |
| `d89d1923ecf9` | certain | Over the last {…} days | `modules/hall-ui/public/watch.js:1188` |
| `695ffff13730` | certain | Over time | `modules/hall-ui/public/profile.html:76` |
| `5ded44da0cc5` | certain | Override requests | `modules/hall-ui/public/watch.html:136` |
| `0046e08db06a` | certain | Owner’s bill / month (est.) | `modules/hall-ui/public/fleet-costs.js:70` |
| `15a49bf15007` | certain | Page {…} of {…} | `modules/hall-ui/public/hall-kit.js:112` |
| `cf68a394cfa5` | certain | Paste command copied. | `modules/hall-ui/public/settings.js:775` |
| `6036f69e13bd` | certain | Paste or write it here. | `modules/hall-ui/public/settings-specialities.js:354` |
| `a495649d1f82` | certain | Paste your key first. | `modules/hall-ui/public/settings.js:896` |
| `542f801cc77f` | certain | Path-based estimate from declared files. Glob-aware detection with claim collisions — and lead resolution acti | `modules/hall-ui/public/goals-render.js:605` |
| `54fa47e421a5` | certain | Peer recognition | `modules/hall-ui/public/hall-widgets.js:199` |
| `47d609ece51c` | certain | Pending invitations | `modules/hall-ui/public/goals-render.js:1442` |
| `a69aff719f1a` | certain | People asking to join. Approve or dismiss each request, re-read the ones you already decided, and take back an | `modules/hall-ui/public/watch.html:62` |
| `4a46b478edaf` | certain | Per page | `modules/hall-ui/public/hall-kit.js:74` |
| `e1e10dc5e357` | certain | Permissions is the Archon administration surface. The Constitution and the Board Room are yours to read. | `modules/hall-ui/public/government.js:1030` |
| `6bc03d97457b` | certain | Pick a priority first. | `modules/hall-ui/public/task.js:936` |
| `fcf996d77050` | certain | Pick a rank to see what it may do. The four ladder ranks ship with the platform; a custom rank is yours to sha | `modules/hall-ui/public/government.html:76` |
| `45378ea261f6` | certain | Pick one… | `modules/hall-ui/public/settings.html:249` |
| `25815a34d246` | certain | Plain speech | `modules/hall-ui/public/sessions.html:78` |
| `07d7e62640d6` | certain | Post &amp; resolve | `modules/hall-ui/public/collab.js:170` |
| `5b08da0632c7` | certain | Post reply | `modules/hall-ui/public/collab.js:175` |
| `5b08da0632c7` | certain | Post reply | `modules/hall-ui/public/collab.js:768` |
| `e883f2789cae` | certain | Preferred roles | `modules/hall-ui/public/settings.html:115` |
| `f03d68e60416` | certain | Preferred work | `modules/hall-ui/public/hall-render.js:629` |
| `ed8edd684547` | certain | Preferred work: | `modules/hall-ui/public/hall-render.js:580` |
| `152331290026` | certain | Preview {…} sound | `modules/hall-ui/public/settings.js:311` |
| `4644c8289f13` | certain | Previous page | `modules/hall-ui/public/hall-kit.js:74` |
| `d637875ef146` | certain | Primer acknowledged. | `modules/hall-ui/public/primer.js:254` |
| `0ecbc4ee23f0` | certain | Primer required | `modules/hall-ui/public/work.html:42` |
| `04f8740a0cb4` | certain | Primer — {{worldName}} | `modules/hall-ui/public/primer.html:6` |
| `04f8740a0cb4` | certain | Primer — {{worldName}} | `modules/hall-ui/public/primer.html:6` |
| `6dc9979d25a1` | certain | Priority is already {…}. | `modules/hall-ui/public/task.js:939` |
| `92d8fad6dc91` | certain | Private account — this is all they share by applying. | `modules/hall-ui/public/watch.js:459` |
| `2b88c01d1697` | certain | Private — join is by invitation or an approved request | `modules/hall-ui/public/goals-render.js:877` |
| `a5cd9cbfe82a` | certain | Profile and privacy | `modules/hall-ui/public/settings.html:103` |
| `f796836eac4e` | certain | Profile sections | `modules/hall-ui/public/profile.html:45` |
| `935b317ce2d8` | certain | Profile — {{worldName}} | `modules/hall-ui/public/profile.html:6` |
| `935b317ce2d8` | certain | Profile — {{worldName}} | `modules/hall-ui/public/profile.html:6` |
| `cf8d14410264` | certain | Project founding mode | `modules/hall-ui/public/shell.js:1023` |
| `e08628967f2f` | certain | Project settings | `modules/hall-ui/public/project-settings.html:15` |
| `e08628967f2f` | certain | Project settings | `modules/hall-ui/public/project-settings.html:15` |
| `e08628967f2f` | certain | Project settings | `modules/hall-ui/public/project-settings.html:26` |
| `1fe749ae5677` | certain | Project settings — {{worldName}} | `modules/hall-ui/public/project-settings.html:6` |
| `1fe749ae5677` | certain | Project settings — {{worldName}} | `modules/hall-ui/public/project-settings.html:6` |
| `16521a997ade` | certain | Project type | `modules/hall-ui/public/government.js:856` |
| `dd4bc23c7759` | certain | Prompt for #{…} copied to your clipboard. | `modules/hall-ui/public/goals-page.js:401` |
| `dd4bc23c7759` | certain | Prompt for #{…} copied to your clipboard. | `modules/hall-ui/public/work.js:617` |
| `cd7dc83871b6` | certain | Prompt for #{…} copied. | `modules/hall-ui/public/goals-page.js:407` |
| `cd7dc83871b6` | certain | Prompt for #{…} copied. | `modules/hall-ui/public/work.js:628` |
| `fe7f3488fda8` | certain | Propose new wording | `modules/hall-ui/public/copy-desk.html:152` |
| `abee9a18325d` | certain | Propose wording… | `modules/hall-ui/public/copy-desk.js:179` |
| `3f85bdc47099` | certain | Protected module scope — join by request; an Archon admits members | `modules/hall-ui/public/goals-render.js:883` |
| `e5c292c8b361` | certain | Provides (seams) | `modules/hall-ui/public/atlas.js:288` |
| `93b836382ec7` | certain | Put it to the board again | `modules/hall-ui/public/genesis-home.js:202` |
| `4de232a05888` | certain | Raise after | `modules/hall-ui/public/project-settings.js:113` |
| `0608f71f78fe` | certain | Rank is earned by shipping work. The founding mark is for good: it is numbered in the order people joined whil | `modules/hall-ui/public/ranks.html:47` |
| `b9c6def6b120` | certain | Rank set to {…}. | `modules/hall-ui/public/watch.js:883` |
| `ff50a1395cbc` | certain | Rank: {…} | `modules/hall-ui/public/profile.js:50` |
| `6824ec470f99` | certain | Ranks — {{worldName}} | `modules/hall-ui/public/ranks.html:6` |
| `6824ec470f99` | certain | Ranks — {{worldName}} | `modules/hall-ui/public/ranks.html:6` |
| `e60039795803` | certain | Re-issue CLI token | `modules/hall-ui/public/settings.html:140` |
| `101a51902f53` | certain | Re-issue failed: {…} | `modules/hall-ui/public/settings.js:780` |
| `fae2f90927bd` | certain | Read an idea, then decide. An objection needs a reason and the section it faults. | `modules/hall-ui/public/board-room.html:51` |
| `b03e17693dcd` | certain | Read it as a table | `modules/hall-ui/public/drachmae.js:148` |
| `b03e17693dcd` | certain | Read it as a table | `modules/hall-ui/public/watch.js:1161` |
| `b6fcfdd652a7` | certain | Read it here | `modules/hall-ui/public/work.html:45` |
| `053df132e22c` | certain | Read the full ask | `modules/hall-ui/public/collab.js:133` |
| `c5f19a888a15` | certain | Read the handoff notes | `modules/hall-ui/public/task.js:499` |
| `f9e998f4af3d` | certain | Read to the end and the button below unlocks. It is an honour system — nothing here checks your comprehension. | `modules/hall-ui/public/primer.html:100` |
| `26e6c9879035` | certain | Reading the diagrams | `modules/hall-ui/public/diagrams.html:39` |
| `b862e546bc90` | certain | Reading the page… | `modules/hall-ui/public/tweak-editor.html:75` |
| `5b581cca590f` | certain | Ready — tasks to do | `modules/hall-ui/public/work.html:102` |
| `9ea556e7b78b` | certain | Reason (optional) | `modules/hall-ui/public/task-detail.js:615` |
| `4f619c19a8e7` | certain | Rebase owed | `modules/hall-ui/public/hall-render.js:676` |
| `06cbba1440b1` | certain | Rebase owed — new claims paused | `modules/hall-ui/public/hall-render.js:561` |
| `d65a380a71c4` | certain | Recent filings | `modules/hall-ui/public/ideas.html:109` |
| `58fb6fe4b47e` | certain | Recent history could not be loaded right now. | `modules/hall-ui/public/work.js:931` |
| `0b2d1327608f` | certain | Recently shipped | `modules/hall-ui/public/hall-widgets.js:107` |
| `cd2bffe2e5b9` | certain | Recognize your peers’ finished work. A vote up (+) or down (−) shapes their karma after a one-week cooling per | `modules/hall-ui/public/hall-widgets.js:200` |
| `5419ad9503ef` | certain | Recommended for your project | `modules/hall-ui/public/government.js:893` |
| `986ecda14881` | certain | Record your owner approval for | `modules/hall-ui/public/gate.js:109` |
| `dba9d3f3af13` | certain | Recorded sessions | `modules/hall-ui/public/sessions.html:55` |
| `b40c4a61070e` | certain | Records your decision only — there is no marketplace yet, and nothing is listed anywhere. | `modules/hall-ui/public/settings.html:276` |
| `6d8347c3575a` | certain | Release a thought | `modules/hall-ui/public/goal-map.html:90` |
| `6d8347c3575a` | certain | Release a thought | `modules/hall-ui/public/thinking.html:98` |
| `58af483d7a84` | certain | Release task {…} | `modules/hall-ui/public/goals-render.js:373` |
| `6f86e17007c6` | certain | Release your claim on #{…}? It returns to the queue and no {…} are earned. | `modules/hall-ui/public/goals-page.js:516` |
| `6f86e17007c6` | certain | Release your claim on #{…}? It returns to the queue and no {…} are earned. | `modules/hall-ui/public/work.js:722` |
| `975ffb256651` | certain | Release {…}? {…} to the queue and no {…} are earned. | `modules/hall-ui/public/bulk-toolbar.js:249` |
| `c49f9b9f8864` | certain | Remake or tweak | `modules/hall-ui/public/studio.js:211` |
| `65e3399a8fbf` | certain | Remove filter | `modules/hall-ui/public/hall-kit.js:311` |
| `12c3328b937c` | certain | Remove goal {…} | `modules/hall-ui/public/gate.js:353` |
| `dacd113fb3b2` | certain | Remove your image-generation key? Art generation will stop until you add one again. | `modules/hall-ui/public/settings.js:964` |
| `20882d6ffdd0` | certain | Removed {…} from builder {…}. | `modules/hall-ui/public/government.js:365` |
| `9be75ebd8d67` | certain | Replay the sky from the first day | `modules/hall-ui/public/goal-map.html:126` |
| `9be75ebd8d67` | certain | Replay the sky from the first day | `modules/hall-ui/public/thinking.html:127` |
| `2063826d05f1` | certain | Replied. | `modules/hall-ui/public/collab.js:763` |
| `9f4e519ea3e2` | certain | Repo Atlas | `modules/hall-ui/public/atlas.html:18` |
| `9f4e519ea3e2` | certain | Repo Atlas | `modules/hall-ui/public/atlas.html:18` |
| `7d4149cee474` | certain | Repo Atlas — a self-drawing map of the codebase | `modules/hall-ui/public/atlas.html:6` |
| `7d4149cee474` | certain | Repo Atlas — a self-drawing map of the codebase | `modules/hall-ui/public/atlas.html:6` |
| `4d40a68605e1` | certain | Repo atlas | `modules/hall-ui/public/atlas.html:30` |
| `52d7d4309540` | certain | Repo health | `modules/hall-ui/public/watch.html:104` |
| `e6629398d47c` | certain | Report {…}. | `modules/hall-ui/public/watch.js:603` |
| `ab456f09c0f6` | certain | Request access | `modules/hall-ui/public/hall-render.js:297` |
| `ab456f09c0f6` | certain | Request access | `modules/hall-ui/public/hall-render.js:473` |
| `820f47ce5f16` | certain | Request sent | `modules/hall-ui/public/profile-connections.js:95` |
| `820f47ce5f16` | certain | Request sent | `modules/hall-ui/public/profile-connections.js:143` |
| `e86e43684bce` | certain | Request sent — the owner or a manager will review it. | `modules/hall-ui/public/goals-render.js:1393` |
| `280f20e7ddf5` | certain | Request withdrawn. | `modules/hall-ui/public/goals-render.js:1409` |
| `a030881168b5` | certain | Reset to default | `modules/hall-ui/public/government.js:267` |
| `fd89b5be9d3b` | certain | Reset zoom to fit | `modules/hall-ui/public/diagram-viewer.js:97` |
| `9d9567d1dead` | certain | Reset {…} to its default permissions?\n\nEvery change you've made to this rank is discarded, and it takes effe | `modules/hall-ui/public/government.js:293` |
| `a52e93780e6d` | certain | Resize the split: drag, or use the up and down arrows | `modules/hall-ui/public/tweak-editor.html:82` |
| `10d8f8c501b0` | certain | Resolution note (optional) | `modules/hall-ui/public/blockers.js:131` |
| `10d8f8c501b0` | certain | Resolution note (optional) | `modules/hall-ui/public/task-detail.js:207` |
| `3ef9382d4726` | certain | Resolved — the copy was changed | `modules/hall-ui/public/copy-desk.html:122` |
| `1e99596fc787` | certain | Restore the original words | `modules/hall-ui/public/tweak-editor.js:225` |
| `60d8790ebce8` | certain | Restore the page's words for this {…} line | `modules/hall-ui/public/tweak-editor.js:225` |
| `0887725744f2` | certain | Restricted. | `modules/hall-ui/public/board-room.js:526` |
| `0887725744f2` | certain | Restricted. | `modules/hall-ui/public/gate.js:234` |
| `0887725744f2` | certain | Restricted. | `modules/hall-ui/public/government.js:1013` |
| `0887725744f2` | certain | Restricted. | `modules/hall-ui/public/watch.js:1300` |
| `b99a71747432` | certain | Retire task {…}? It leaves the claimable queue. Promote restores it to the backlog. | `modules/hall-ui/public/task.js:989` |
| `b33dde402434` | certain | Retire this goal — you will be asked what happens to any unfinished work | `modules/hall-ui/public/goals-render.js:963` |
| `d0d5b4300f28` | certain | Retire this task | `modules/hall-ui/public/task.js:825` |
| `deafad2284f4` | certain | Retire this task… | `modules/hall-ui/public/task.js:836` |
| `908a0d5d0685` | certain | Review how it judged this work, and teach it what good looked like. | `modules/hall-ui/public/studio.js:211` |
| `f1b2b158c3b1` | certain | Review quality | `modules/hall-ui/public/watch.html:82` |
| `4e062d4f8d69` | certain | Reviews by builder | `modules/hall-ui/public/watch.html:75` |
| `5c233879ce4e` | certain | Reviews from before Tweak Mode | `modules/hall-ui/public/studio.html:153` |
| `4c112975a739` | certain | Rewrite it in the editor | `modules/hall-ui/public/studio.js:796` |
| `f7ed4ba07178` | certain | Roadmap — {{worldName}} | `modules/hall-ui/public/roadmap.html:6` |
| `f7ed4ba07178` | certain | Roadmap — {{worldName}} | `modules/hall-ui/public/roadmap.html:6` |
| `12af2af5acf2` | certain | Role it sits under | `modules/hall-ui/public/settings.html:247` |
| `48e5f1d19e90` | certain | Runner allowed to work | `modules/hall-ui/public/gate.js:418` |
| `41730c113dd5` | certain | Runners work only the goals above, and only while the switch is on. Each builder picks which of them their own | `modules/hall-ui/public/gate.js:418` |
| `b6596905f845` | certain | Said more than once | `modules/hall-ui/public/copy-desk.html:56` |
| `ce046dcbd8e1` | certain | Save as PDF | `modules/hall-ui/public/modules.html:88` |
| `0c79b504aebe` | certain | Save key | `modules/hall-ui/public/settings.js:832` |
| `b3d55c8c765a` | certain | Save my choices | `modules/hall-ui/public/settings-specialities.js:163` |
| `13ca64ad2498` | certain | Save rule | `modules/hall-ui/public/deploy.js:294` |
| `a98b96e49388` | certain | Save what it offers | `modules/hall-ui/public/settings-specialities.js:276` |
| `e5e50cc034d6` | certain | Saved — {…} of {…} skill{…} on. | `modules/hall-ui/public/settings-specialities.js:204` |
| `72f24fcbe9e0` | certain | Saves the moment you choose; applies from your next session. | `modules/hall-ui/public/settings.html:324` |
| `e8e4e49fe8f4` | certain | Saves when you press Save; shows everywhere at once. | `modules/hall-ui/public/settings.html:91` |
| `42cbc20a6ec8` | certain | Saves when you press Save; your next | `modules/hall-ui/public/settings.html:125` |
| `645dd8117cf3` | certain | Say why it is being retired — the reason goes in the record. | `modules/hall-ui/public/task.js:988` |
| `fc9d783ed0f5` | certain | Say why it is better. Whoever reviews this decides it from your reason, without asking you. | `modules/hall-ui/public/copy-desk.js:446` |
| `12c1ec21a2c6` | certain | Say yes | `modules/hall-ui/public/collab.js:668` |
| `4cfb02fbe696` | certain | Screen recording of you doing this on the live site (mp4 or webm, up to 100 MB) | `modules/hall-ui/public/criterion-uat-ui.js:142` |
| `46711f7bc3df` | certain | Search every string the product shows a person, by what it says or the file it lives in. | `modules/hall-ui/public/copy-desk.html:65` |
| `5d2ba8e72fa1` | certain | Search failed. | `modules/hall-ui/public/copy-desk.js:343` |
| `373a7639bcb9` | certain | Sections in this primer | `modules/hall-ui/public/primer.html:52` |
| `00ca4e3c7c7d` | certain | Sections in this reference | `modules/hall-ui/public/drachmae.html:49` |
| `ab8af800f2bb` | certain | Security reports | `modules/hall-ui/public/watch.html:47` |
| `9e370ee74bc4` | certain | See all ready work → | `modules/hall-ui/public/hall-widgets.js:105` |
| `324af64c8b6e` | certain | See all {…} goals {…} | `modules/hall-ui/public/roadmap.js:128` |
| `324af64c8b6e` | certain | See all {…} goals {…} | `modules/hall-ui/public/roadmap.js:207` |
| `00473a773fd7` | certain | See the UAT | `modules/hall-ui/public/criterion-uat-ui.js:80` |
| `a9c398651862` | certain | See the cross-project record | `modules/hall-ui/public/profile-canonical.js:114` |
| `17d5b5739f46` | certain | See the work board → | `modules/hall-ui/public/hall-render.js:945` |
| `55cde0774831` | certain | See what would change | `modules/hall-ui/public/deploy.js:422` |
| `292761c89fae` | certain | See which goals wait on each other → | `modules/hall-ui/public/goals.html:39` |
| `75dc5463facc` | certain | Select at least 2 waiting tasks to copy a parallel-session prompt. | `modules/hall-ui/public/bulk-toolbar.js:181` |
| `a98882faa482` | certain | Select at least 2 waiting tasks to copy a sequential prompt. | `modules/hall-ui/public/bulk-toolbar.js:206` |
| `582bdd9435eb` | certain | Select task {…} for bulk actions | `modules/hall-ui/public/work.js:468` |
| `d91c8e9be76c` | certain | Select task {…} for bulk claim | `modules/hall-ui/public/goals-render.js:362` |
| `7e1d54119e08` | certain | Select task {…} for bulk release | `modules/hall-ui/public/goals-render.js:364` |
| `7e1d54119e08` | certain | Select task {…} for bulk release | `modules/hall-ui/public/work.js:258` |
| `ae43a132699b` | certain | Selectable today | `modules/hall-ui/public/government.js:809` |
| `53cc6d8dd23c` | certain | Send invitation | `modules/hall-ui/public/goals-render.js:1244` |
| `a39b0f9d86e5` | certain | Serving {…} — read from the box itself, {…}. | `modules/hall-ui/public/deploy.js:599` |
| `64a1f055129e` | certain | Session card richness | `modules/hall-ui/public/settings-render.js:83` |
| `d14e8e9acaff` | certain | Session ended. | `modules/hall-ui/public/settings-sessions.js:81` |
| `55e0a34bafed` | certain | Session log{…} | `modules/hall-ui/public/task.js:505` |
| `cccb362bd6da` | certain | Sessions — {{worldName}} | `modules/hall-ui/public/sessions.html:6` |
| `cccb362bd6da` | certain | Sessions — {{worldName}} | `modules/hall-ui/public/sessions.html:6` |
| `c11213056bab` | certain | Set priority | `modules/hall-ui/public/task.js:629` |
| `b823d9a37a35` | certain | Set up key storage | `modules/hall-ui/public/settings.js:848` |
| `84f31c3c3797` | certain | Set up your machine / get the code | `modules/hall-ui/public/hall-render.js:832` |
| `f639250de42f` | certain | Setting up key storage… | `modules/hall-ui/public/settings.js:932` |
| `62c3ea026095` | certain | Settings sections | `modules/hall-ui/public/settings.html:54` |
| `2566a43904cb` | certain | Settings — {{worldName}} | `modules/hall-ui/public/settings.html:6` |
| `2566a43904cb` | certain | Settings — {{worldName}} | `modules/hall-ui/public/settings.html:6` |
| `ac44b08aec92` | certain | Ship it | `modules/hall-ui/public/task.js:756` |
| `b94a6b5b3d8c` | certain | Shipped with the core | `modules/hall-ui/public/modules.html:59` |
| `0c0a50ba1666` | certain | Shipped {…}{…}, {…}. | `modules/hall-ui/public/task.js:714` |
| `6dde12eb0c78` | certain | Show all {…} | `modules/hall-ui/public/collab.js:432` |
| `47b6199cc471` | certain | Show or hide the clock | `modules/hall-ui/public/goal-map.html:77` |
| `47b6199cc471` | certain | Show or hide the clock | `modules/hall-ui/public/goal-map.html:77` |
| `47b6199cc471` | certain | Show or hide the clock | `modules/hall-ui/public/thinking.html:85` |
| `47b6199cc471` | certain | Show or hide the clock | `modules/hall-ui/public/thinking.html:85` |
| `dc0f9fe50a65` | certain | Show the setup guide again | `modules/hall-ui/public/index.html:68` |
| `df16bd23e58e` | certain | Show the thoughts a session filed under your name. Off by default: only what a person filed. | `modules/hall-ui/public/thinking.html:82` |
| `a81ec73539ef` | certain | Show {…} more | `modules/hall-ui/public/profile.js:769` |
| `44945da22716` | certain | Show {…} more version{…} | `modules/hall-ui/public/settings-software-update.js:119` |
| `2af4c0f2b4b9` | certain | Showing {…} of {…}. | `modules/hall-ui/public/ideas.js:867` |
| `2af4c0f2b4b9` | certain | Showing {…} of {…}. | `modules/hall-ui/public/profile.js:769` |
| `838b17fa8d93` | certain | Shown on your public profile — it helps others know what you work on. | `modules/hall-ui/public/profile-nudge.js:86` |
| `b20cd8a4fa21` | certain | Shown to Claude | `modules/hall-ui/public/commands-lib.js:94` |
| `b20cd8a4fa21` | certain | Shown to Claude | `modules/hall-ui/public/commands.html:36` |
| `9bea6404e6e1` | certain | Sign in | `modules/hall-ui/public/profile.js:263` |
| `9bea6404e6e1` | certain | Sign in | `modules/hall-ui/public/settings.html:45` |
| `19ab56cc3932` | certain | Sign in to filter to your goals | `modules/hall-ui/public/goals-page.js:838` |
| `969f95f183ca` | certain | Sign in to the platform once to activate your profile before connecting. | `modules/hall-ui/public/profile-connections.js:253` |
| `e57ec24e13ef` | certain | Sign in with GitHub | `modules/hall-ui/public/hall-render.js:278` |
| `e57ec24e13ef` | certain | Sign in with GitHub | `modules/hall-ui/public/hall-render.js:370` |
| `e57ec24e13ef` | certain | Sign in with GitHub | `modules/hall-ui/public/hall-render.js:394` |
| `e57ec24e13ef` | certain | Sign in with GitHub | `modules/hall-ui/public/hall-render.js:464` |
| `e57ec24e13ef` | certain | Sign in with GitHub | `modules/hall-ui/public/shell.js:453` |
| `1883ad7f07fc` | certain | Sign out | `modules/hall-ui/public/shell.js:471` |
| `1883ad7f07fc` | certain | Sign out | `modules/hall-ui/public/shell.js:893` |
| `8ad669ab2565` | certain | Sign out everywhere | `modules/hall-ui/public/settings.html:160` |
| `b71029028a4e` | certain | Signing off… | `modules/hall-ui/public/criterion-uat-ui.js:232` |
| `ecc12c1dd4de` | certain | Skill voices | `modules/hall-ui/public/settings.html:331` |
| `4b0ca7d7171f` | certain | Skill {…} of {…} in {…} | `modules/hall-ui/public/settings-specialities.js:130` |
| `bbbb6e8ab564` | certain | Skills it offers | `modules/hall-ui/public/settings.html:280` |
| `87cee78ca134` | certain | Skip to content | `modules/hall-ui/public/shell.js:884` |
| `3de3d5f97e2a` | certain | Slash commands in Claude Code | `modules/hall-ui/public/commands.html:33` |
| `688ca7b6e30f` | certain | Slop — reads as machine-written | `modules/hall-ui/public/copy-desk.html:90` |
| `82df09a08476` | certain | So the Archon knows who you are | `modules/hall-ui/public/hall-render.js:297` |
| `207af7ce6828` | certain | Software update | `modules/hall-ui/public/settings.html:390` |
| `e7b592185803` | certain | Someone is holding a claim on this task. It has to be released before the task can be retired. | `modules/hall-ui/public/task.js:799` |
| `867df58c9aaa` | certain | Something else | `modules/hall-ui/public/copy-desk.html:95` |
| `e11c18877155` | certain | Something is here. | `modules/hall-ui/public/sky-interaction.js:35` |
| `c377d8ed744b` | certain | Something went wrong. Try again. | `modules/hall-ui/public/profile-connections.js:319` |
| `e0767e80206c` | certain | Sound for {…} | `modules/hall-ui/public/settings.js:309` |
| `7f4f7b25c61f` | certain | Sound preference saved. | `modules/hall-ui/public/settings.js:326` |
| `d03aa6752970` | certain | Specialities this project recommends. Nothing here is switched on — read what each one adds to your sessions,  | `modules/hall-ui/public/settings-specialities.js:384` |
| `01f1d2b03eb4` | certain | Speciality created. | `modules/hall-ui/public/settings-specialities.js:554` |
| `f2a4d855d82d` | certain | Stale claims | `modules/hall-ui/public/watch.html:48` |
| `6d4a7bf5ab0e` | certain | Stale timer is now {…} days. | `modules/hall-ui/public/project-settings.js:176` |
| `98d037e427b8` | certain | Stale — describes something that changed | `modules/hall-ui/public/copy-desk.html:92` |
| `9d4372b173cf` | certain | Standing sections | `modules/hall-ui/public/index.html:83` |
| `ec1c2dae4a90` | certain | Standing there | `modules/hall-ui/public/profile.js:369` |
| `eaad12cacb9d` | certain | Start over | `modules/hall-ui/public/studio.js:264` |
| `b01258e8242a` | certain | Starting government | `modules/hall-ui/public/genesis-home.js:131` |
| `efe530c0e3a7` | certain | Still open | `modules/hall-ui/public/profile.js:544` |
| `490a3cbb8c1c` | certain | Still working on core {…}. It keeps going without this page — reload to see where it got to. | `modules/hall-ui/public/deploy.js:761` |
| `9a4ced1afb6c` | certain | Stop waiting on task {…} | `modules/hall-ui/public/task.js:287` |
| `b0861c874a2f` | certain | Stopped using it. | `modules/hall-ui/public/settings-specialities.js:457` |
| `6c6544f5c011` | certain | Stored encrypted; never shown again after saving — only its last four digits. | `modules/hall-ui/public/settings.html:199` |
| `5831de503015` | certain | Studio — {{worldName}} | `modules/hall-ui/public/studio.html:10` |
| `5831de503015` | certain | Studio — {{worldName}} | `modules/hall-ui/public/studio.html:10` |
| `f79e1fb8ebd4` | certain | Suggested as you type; leave it on "no goal" and it waits for triage. | `modules/hall-ui/public/ideas.html:84` |
| `a1482eff4ead` | certain | Suggested for you | `modules/hall-ui/public/settings-specialities.js:384` |
| `1e40f33483eb` | certain | Switch theme | `modules/hall-ui/public/shell.js:499` |
| `93fa2e97dd35` | certain | System default for this skill | `modules/hall-ui/public/settings.js:72` |
| `4894b1d9b0de` | certain | System oversight: people, operations and security. | `modules/hall-ui/public/watch.js:1364` |
| `aa8da34fe237` | certain | Take the next page, or pick one from the studio. | `modules/hall-ui/public/tweak-editor.js:564` |
| `e604fc3ace79` | certain | Task # | `modules/hall-ui/public/blockers.js:139` |
| `a0f384b022fd` | certain | Task dependencies | `modules/hall-ui/public/goals.html:132` |
| `91576eb7c880` | certain | Task dependency forest — scrolls sideways inside this box | `modules/hall-ui/public/goal-forest-render.js:146` |
| `dfc967a63d57` | certain | Task lifecycle from backlog to shipped, showing states and transitions and the edge where credits are awarded. | `modules/hall-ui/public/diagrams.html:51` |
| `10cc12f37636` | certain | Task sections | `modules/hall-ui/public/work.html:53` |
| `0e636ea41b29` | certain | Task status | `modules/hall-ui/public/goals-lib.js:88` |
| `af527fbc48e1` | certain | Task that carried the fix | `modules/hall-ui/public/copy-desk.html:127` |
| `eff70e59d12e` | certain | Task {…} | `modules/hall-ui/public/task.js:512` |
| `eff70e59d12e` | certain | Task {…} | `modules/hall-ui/public/task.js:548` |
| `eff70e59d12e` | certain | Task {…} | `modules/hall-ui/public/task.js:1038` |
| `eff70e59d12e` | certain | Task {…} | `modules/hall-ui/public/task.js:1050` |
| `1d714be820d3` | certain | Task — {{worldName}} | `modules/hall-ui/public/task.html:6` |
| `1d714be820d3` | certain | Task — {{worldName}} | `modules/hall-ui/public/task.html:6` |
| `860fa4af9917` | certain | Tasks could not be loaded. | `modules/hall-ui/public/goals-render.js:1148` |
| `0a471ed243db` | certain | Tasks in the ledger are numbered separately from GitHub pull requests, so this may be a PR number rather than  | `modules/hall-ui/public/task.js:1038` |
| `2fc66e722e33` | certain | Tasks open once you have read the builder primer. | `modules/hall-ui/public/work.html:43` |
| `44579eef0c8d` | certain | Tasks — {{worldName}} | `modules/hall-ui/public/work.html:6` |
| `44579eef0c8d` | certain | Tasks — {{worldName}} | `modules/hall-ui/public/work.html:6` |
| `c4b62de31830` | certain | Technical detail — what the upgrade said | `modules/hall-ui/public/deploy.js:362` |
| `1e4285bdfaef` | certain | Terminal commands (bongos) | `modules/hall-ui/public/commands.html:44` |
| `8584832c348f` | certain | Test and sign off | `modules/hall-ui/public/criterion-uat-ui.js:76` |
| `2f4f047dc1b4` | certain | Text size | `modules/hall-ui/public/shell.js:498` |
| `f420429f942e` | certain | That builder no longer exists. | `modules/hall-ui/public/goals-render.js:1314` |
| `545c59c1deb7` | certain | That is the session you are using right now. Ending it signs you out of this page. | `modules/hall-ui/public/settings-sessions.js:74` |
| `282c3fa2d456` | certain | That is the wording it already has. Change something, or file a flag instead if you only want to mark it. | `modules/hall-ui/public/copy-desk.js:438` |
| `c0e28f30524d` | certain | That project's own standing, as reported by that project. | `modules/hall-ui/public/profile.js:369` |
| `e99d4a811e92` | certain | That request is no longer available. | `modules/hall-ui/public/profile-connections.js:314` |
| `34017119ce22` | certain | That work is genuinely gone | `modules/hall-ui/public/goal-inbox.js:374` |
| `6e5a324b2972` | certain | That's you | `modules/hall-ui/public/watch.js:832` |
| `50198c465225` | certain | The 16-value rank enum in three bands, which ranks are live, and the permissions each rank holds. | `modules/hall-ui/public/diagrams.html:59` |
| `c5e6bdd32fe3` | certain | The Board Room is open to the builders this project’s constitution seats on its board. | `modules/hall-ui/public/board-room.js:529` |
| `6e93ef49d63f` | certain | The adversarial panel. Each worker reports pass, concerns or fail on its own; the gating workers must all pass | `modules/hall-ui/public/task.js:449` |
| `89c7bd971440` | certain | The approved pages could not be read just now. | `modules/hall-ui/public/profile.js:763` |
| `600b90074021` | certain | The art pipeline draws tiles and sprites with Google AI Studio (Gemini). Needed only if you generate art — you | `modules/hall-ui/public/settings.html:191` |
| `4462dcaaaa7d` | certain | The artist reads this instead of guessing. A pointer with no judgement costs them a look and tells them nothin | `modules/hall-ui/public/copy-desk.html:103` |
| `195b295d0bf3` | certain | The atlas regenerates itself on the server every time code ships; it has not been generated on this deploy yet | `modules/hall-ui/public/atlas.html:63` |
| `f38140e472df` | certain | The board ratified a change that is not in force. | `modules/hall-ui/public/government.js:633` |
| `ecc7215524c0` | certain | The board sent this stage back. Read why in the Board Room, then put it up again. | `modules/hall-ui/public/genesis-home.js:201` |
| `e8f011fdaa6b` | certain | The complete architecture: your machine (the worker, the code, and local memory), the server (authority and pr | `modules/hall-ui/public/diagrams.html:76` |
| `2dc061096c48` | certain | The copy desk — every flagged string | `modules/hall-ui/public/studio.html:165` |
| `325daac25a9a` | certain | The day the sky is drawn for | `modules/hall-ui/public/goal-map.html:127` |
| `325daac25a9a` | certain | The day the sky is drawn for | `modules/hall-ui/public/thinking.html:128` |
| `bac12faf3328` | certain | The developmental ladder: {…}. Formality is adopted only where informal coordination breaks. | `modules/hall-ui/public/government.js:816` |
| `239d641c20fa` | certain | The document | `modules/hall-ui/public/settings-specialities.js:354` |
| `ffaa4df90f66` | certain | The editor could not load. | `modules/hall-ui/public/tweak-editor.js:712` |
| `6e2554615883` | certain | The event sounds could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings.js:391` |
| `7e77b1ed9c86` | certain | The founding wall | `modules/hall-ui/public/hall-widgets.js:123` |
| `36ed1b04583e` | certain | The full queues | `modules/hall-ui/public/studio.html:164` |
| `cb7c7879eeba` | certain | The fundamentals | `modules/hall-ui/public/project-settings.html:40` |
| `4dd13bc5a35b` | certain | The goal's leads have paused applications; they can still invite you | `modules/hall-ui/public/goals-render.js:975` |
| `19b23f2cc45b` | certain | The grading panel could not run when this task was shipped, so no quality signal was recorded — an outage, not | `modules/hall-ui/public/task.js:431` |
| `027e9420daa2` | certain | The headline lands, but the sub-line reads like a brochure. | `modules/hall-ui/public/studio.js:191` |
| `f08587a38a2a` | certain | The hero line is too long on a phone. | `modules/hall-ui/public/approval-queue.js:174` |
| `9f45c63c9697` | certain | The kinds of work you prefer. Task suggestions lean toward your choices — pick one, several, or none. | `modules/hall-ui/public/settings.html:116` |
| `2a2152c7bcfb` | certain | The ladder's own shape at this size is {…}. {…} | `modules/hall-ui/public/government.js:888` |
| `814eb6889339` | certain | The ledger | `modules/hall-ui/public/goal-map.html:102` |
| `dbbcedba5f3c` | certain | The list | `modules/hall-ui/public/thinking.html:110` |
| `e6536b9628cd` | certain | The live page | `modules/hall-ui/public/tweak-editor.html:81` |
| `e6536b9628cd` | certain | The live page | `modules/hall-ui/public/tweak-editor.html:87` |
| `a02d386fbc13` | certain | The map | `modules/hall-ui/public/atlas.html:45` |
| `e1ce3766c6fe` | certain | The map has not been generated on this deploy yet. | `modules/hall-ui/public/atlas.js:416` |
| `689a13ba5bd6` | certain | The map is being drawn. | `modules/hall-ui/public/atlas.html:63` |
| `7f03838faf0c` | certain | The markdown behind this page could not be fetched. Reload to try again, or read it in the repo. | `modules/hall-ui/public/drachmae.html:86` |
| `7f03838faf0c` | certain | The markdown behind this page could not be fetched. Reload to try again, or read it in the repo. | `modules/hall-ui/public/primer.html:89` |
| `381f29be7497` | certain | The most recently shipped tasks. | `modules/hall-ui/public/work.html:140` |
| `82479c539fca` | certain | The name shown beside your work — in the roster, the leaderboard, and the work feed. Your sign-in and the cred | `modules/hall-ui/public/settings.html:78` |
| `4b20ecf5528b` | certain | The next page could not be read. | `modules/hall-ui/public/tweak-editor.js:575` |
| `b88dd8b96b72` | certain | The next person to notice this sentence reads your note instead of re-litigating it. | `modules/hall-ui/public/copy-desk.html:135` |
| `329a1d350f07` | certain | The page changed after your draft was saved, so the draft is not shown over its new words. Rewrite the lines a | `modules/hall-ui/public/tweak-editor.js:310` |
| `aa716f3dd551` | certain | The page could not be loaded. Try again. | `modules/hall-ui/public/builders.js:1467` |
| `28e0c1457b08` | certain | The page is in. | `modules/hall-ui/public/tweak-editor.html:94` |
| `4821b0e74460` | certain | The page, rendered | `modules/hall-ui/public/approval-queue.js:198` |
| `74bc22f38140` | certain | The platform confirmed this request came from the account it names. | `modules/hall-ui/public/watch.js:396` |
| `6c3d88de42de` | certain | The primer | `modules/hall-ui/public/primer.html:41` |
| `dea378cd4837` | certain | The primer did not load | `modules/hall-ui/public/primer.html:88` |
| `dc2d6fd0350a` | certain | The project’s life so far | `modules/hall-ui/public/genesis-home.js:145` |
| `3bc5ec5f35ec` | certain | The ranks, lowest to highest | `modules/hall-ui/public/ranks.html:55` |
| `c0034db3281c` | certain | The reason is recorded in the audit log. This is recoverable: a retired task can be restored to the backlog wi | `modules/hall-ui/public/task.js:825` |
| `1ce78006fe00` | certain | The reference did not load | `modules/hall-ui/public/drachmae.html:85` |
| `c43812b59e97` | certain | The release notes could not be read: {…}. The versions are still listed. | `modules/hall-ui/public/settings-software-update.js:115` |
| `8040b1d05ff2` | certain | The renders could not be read just now. Close the queue and open it again. | `modules/hall-ui/public/approval-queue.js:130` |
| `3b5260b8780a` | certain | The reserved 16-rank ladder, which ranks are live today (archon, metic, thetes, xenos), and what each may do. | `modules/hall-ui/public/diagrams.html:60` |
| `cfa55899240b` | certain | The roadmap could not be loaded right now. Reload to try again. | `modules/hall-ui/public/roadmap.js:440` |
| `2dea5ed89aa1` | certain | The roadmap failed to load. Reload to try again. | `modules/hall-ui/public/roadmap.js:441` |
| `38ce5d68c182` | certain | The roster | `modules/hall-ui/public/roster.html:36` |
| `dd6a926b8137` | certain | The same sentence, in several places. Sometimes that is right and the answer is to dismiss it; sometimes it is | `modules/hall-ui/public/copy-desk.html:57` |
| `314a635412fe` | certain | The same sky, as a list (L) | `modules/hall-ui/public/goal-map.html:73` |
| `314a635412fe` | certain | The same sky, as a list (L) | `modules/hall-ui/public/thinking.html:80` |
| `ec849c59d583` | certain | The same work from any terminal, outside Claude Code. Run | `modules/hall-ui/public/commands.html:45` |
| `cd4ceb6e7e48` | certain | The seeded plan | `modules/hall-ui/public/roadmap.js:207` |
| `d01d36a596b0` | certain | The session log could not be loaded. Try again. | `modules/hall-ui/public/sessions.js:398` |
| `d01d36a596b0` | certain | The session log could not be loaded. Try again. | `modules/hall-ui/public/sessions.js:450` |
| `e48a9b77d91b` | certain | The session log opens from a higher rank. | `modules/hall-ui/public/sessions.html:41` |
| `af664a644b13` | certain | The seven government structures, for getting a team up to speed before deciding when to flip a switch. | `modules/hall-ui/public/government.js:809` |
| `6360a5988f26` | certain | The shape and health of the codebase. | `modules/hall-ui/public/watch.html:105` |
| `fc422cced9e3` | certain | The shared goals you’ve joined. Browse, join, and leave goals — and read their criteria — on the | `modules/hall-ui/public/goals.js:94` |
| `ac46dc53d95f` | certain | The shared repository the core ships and the modules this project built for itself, each credited to its autho | `modules/hall-ui/public/modules.html:50` |
| `5f631f51f29e` | certain | The skill list could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings.js:127` |
| `6b617d158e40` | certain | The sky | `modules/hall-ui/public/goal-map.html:49` |
| `6b617d158e40` | certain | The sky | `modules/hall-ui/public/goal-map.html:49` |
| `a36879d66516` | certain | The sky reveals itself as you go. Pick a well to start in; every route you chart brings the goal at its far en | `modules/hall-ui/public/goal-map.html:113` |
| `47e67052ff0b` | certain | The sky — {{worldName}} | `modules/hall-ui/public/goal-map.html:6` |
| `47e67052ff0b` | certain | The sky — {{worldName}} | `modules/hall-ui/public/goal-map.html:6` |
| `972dbf6f7e1f` | certain | The sky, drawn from the ledger. Every thought and goal here is also a row in the list; press L to open it, ? t | `modules/hall-ui/public/thinking.html:64` |
| `6cad067b617f` | certain | The sky, drawn from the ledger: every goal a gravity well, every dependency a route. Every goal here is also a | `modules/hall-ui/public/goal-map.html:62` |
| `e9a14eab8e96` | certain | The sounds could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings.js:276` |
| `d00666a91ac4` | certain | The studio page is yours, but its words could not be read just now. Open it in the editor. | `modules/hall-ui/public/studio.js:862` |
| `7d016f4a65bf` | certain | The system is mid-build. These diagrams deliberately separate what stands today from what is yet planned, so t | `modules/hall-ui/public/diagrams.html:40` |
| `599fd0e82d1c` | certain | The task board — all work | `modules/hall-ui/public/studio.html:166` |
| `198ba9353bf6` | certain | The task feed did not answer. Nothing on the record has changed, only the read failed. Try again in a moment,  | `modules/hall-ui/public/task.js:1050` |
| `34555793f33e` | certain | The task list could not be loaded right now. | `modules/hall-ui/public/work.js:999` |
| `8c991355687d` | certain | The upgrade checked {…} and refused:{…} | `modules/hall-ui/public/deploy.js:465` |
| `a42a37c43bfb` | certain | The words this project shows people — what has been flagged, and what nobody has looked at. | `modules/hall-ui/public/copy-desk.js:328` |
| `d51b954e0aa9` | certain | The words you changed | `modules/hall-ui/public/approval-queue.js:198` |
| `bcdbded93d4e` | certain | The work board failed to load. Reload to try again. | `modules/hall-ui/public/work.js:1185` |
| `25794c439321` | certain | Then copy the project onto your machine and run the one-shot bootstrap (it checks your setup, installs depende | `modules/hall-ui/public/hall-render.js:832` |
| `d6b9826f1bd3` | certain | These words are the studio page itself. Take the page, type over them here, and submit it from the editor when | `modules/hall-ui/public/studio.html:100` |
| `775a73b066e3` | certain | These words come from the skill’s own description, which was written for Claude to recognise rather than for y | `modules/hall-ui/public/settings-specialities.js:128` |
| `a0140098c0e0` | certain | They already have an invitation or a join-request pending on this goal. | `modules/hall-ui/public/goals-render.js:1312` |
| `5151cf635644` | certain | They have asked to connect. | `modules/hall-ui/public/profile-connections.js:236` |
| `10219b02433e` | certain | They join as a member once they accept — you can change that afterwards. Nobody is added until they do. | `modules/hall-ui/public/goals-render.js:1244` |
| `ccd0ccb80fae` | certain | They joined this goal already. | `modules/hall-ui/public/goals-render.js:1313` |
| `27f77408aed0` | certain | Things stuck on the owner — a credential, a purchase, a product call only they can make. Resolving one un-stic | `modules/hall-ui/public/blockers.html:26` |
| `6e46811189db` | certain | This PR is held by the gate-review check. | `modules/hall-ui/public/gate.js:144` |
| `b7c288328f79` | certain | This builder hides their cross-project record. | `modules/hall-ui/public/watch.js:440` |
| `ed313d96b419` | certain | This builder keeps their track record private. | `modules/hall-ui/public/profile.js:349` |
| `3f9e476e22db` | certain | This clears {…}. The gate check re-runs and the PR merges once it goes green. Your approval applies only to co | `modules/hall-ui/public/gate.js:109` |
| `c2a0e726bd97` | certain | This goal is Archon-mediated — request to join instead. | `modules/hall-ui/public/goals-render.js:1353` |
| `0dd14cf15c8b` | certain | This goal is blocked until each prerequisite goal is achieved | `modules/hall-ui/public/goals-render.js:871` |
| `e9a366866022` | certain | This goal is not open. | `modules/hall-ui/public/goals-render.js:1318` |
| `e9a366866022` | certain | This goal is not open. | `modules/hall-ui/public/goals-render.js:1340` |
| `e9a366866022` | certain | This goal is not open. | `modules/hall-ui/public/goals-render.js:1356` |
| `6d499c7d37ab` | certain | This goal is open — joining directly instead. | `modules/hall-ui/public/goals-render.js:1400` |
| `e8c7a2e41278` | certain | This goal is private — request to join instead. | `modules/hall-ui/public/goals-render.js:1354` |
| `ac621aa8ce06` | certain | This goal is scoped to a protected module — only an Archon may add members. | `modules/hall-ui/public/goals-render.js:1337` |
| `604292be5554` | certain | This goal is scoped to a protected module — only an Archon may bring someone in. | `modules/hall-ui/public/goals-render.js:1315` |
| `ba404d3207f7` | certain | This goal isn't taking requests right now. | `modules/hall-ui/public/goals-render.js:1401` |
| `c7d2bc751184` | certain | This goal was added to {…} after it had already started building — an Archon override of the scope gate | `modules/hall-ui/public/goals-render.js:902` |
| `23f531302e9e` | certain | This is you — | `modules/hall-ui/public/profile.js:345` |
| `f303bd107422` | certain | This page has been submitted and is on its way to the site. Its words are frozen until it ships or is sent bac | `modules/hall-ui/public/tweak-editor.js:322` |
| `e54578188187` | certain | This page is for members of the board. | `modules/hall-ui/public/board-room.html:44` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/deploy.html:31` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/fleet.html:31` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/gate.html:37` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/government.html:37` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/project-settings.html:36` |
| `9a685b01e2c6` | certain | This page opens at a higher rank. | `modules/hall-ui/public/watch.html:40` |
| `e7a289134dc3` | certain | This page shows no words the reader could find. | `modules/hall-ui/public/tweak-editor.js:246` |
| `5368a0140fa4` | certain | This project already exists, so start by gathering what it has | `modules/hall-ui/public/genesis-home.js:113` |
| `5bdcbec770dd` | certain | This project has no slash commands yet. | `modules/hall-ui/public/commands.js:38` |
| `fcd43f045614` | certain | This project is upgraded on the server that runs it: | `modules/hall-ui/public/settings-software-update.js:76` |
| `3c8aaec39c40` | certain | This project's code expects {…} database change{…} that its database has not applied yet. Anything that relies | `modules/hall-ui/public/deploy.js:579` |
| `6e9dfe1fb903` | certain | This restarts {…} onto core | `modules/hall-ui/public/deploy.js:561` |
| `b9ed9a5f38dd` | certain | This round changed no lines. | `modules/hall-ui/public/approval-queue.js:149` |
| `69e8beced2ff` | certain | This sends the idea back to its author. Say why, and which section. | `modules/hall-ui/public/board-room.js:368` |
| `09256febc32d` | certain | This sentence has {…} {…} where a value is dropped in when it is shown. | `modules/hall-ui/public/copy-desk.js:422` |
| `9333d71e3e15` | certain | This speciality offers no skills to choose. | `modules/hall-ui/public/settings-specialities.js:106` |
| `c9e50a67988a` | certain | This task has shipped and its credits have landed. Neither Ship it nor Confirm is available. | `modules/hall-ui/public/task.js:765` |
| `62b0940efd7d` | certain | This task is already retired. Promote restores it to the backlog. | `modules/hall-ui/public/task.js:801` |
| `fe992d25f60a` | certain | This task is waiting on {…} {…}. It cannot be claimed until {…} — see Blocked by above. | `modules/hall-ui/public/task.js:754` |
| `4301ecd67891` | certain | This would fail. | `modules/hall-ui/public/deploy.js:465` |
| `2ad5823d2cd7` | certain | Three dials, all settings rather than code: | `modules/hall-ui/public/government.html:55` |
| `f158ed1c24a2` | certain | Toggle fullscreen | `modules/hall-ui/public/diagram-viewer.js:101` |
| `7dfdc26f9f79` | certain | Tokens refresh on use; re-issuing never signs you out anywhere else. | `modules/hall-ui/public/settings.html:144` |
| `8f38bbae750b` | certain | Tool errors | `modules/hall-ui/public/sessions.html:76` |
| `becc35640e42` | certain | Trained on | `modules/hall-ui/public/settings-specialities.js:322` |
| `1bb6c792ceb9` | certain | Try again | `modules/hall-ui/public/deploy.js:265` |
| `b50089eda0a4` | certain | Try now | `modules/hall-ui/public/deploy.js:214` |
| `26ec8100bc6f` | certain | Turn it on | `modules/hall-ui/public/settings-specialities.js:138` |
| `72a29648399b` | certain | Tweak a page | `modules/hall-ui/public/tweak-editor.html:32` |
| `72a29648399b` | certain | Tweak a page | `modules/hall-ui/public/tweak-editor.html:32` |
| `72a29648399b` | certain | Tweak a page | `modules/hall-ui/public/tweak-editor.html:53` |
| `72a29648399b` | certain | Tweak a page | `modules/hall-ui/public/tweak-editor.html:71` |
| `478fa9eefbe2` | certain | Tweak a page — {{worldName}} | `modules/hall-ui/public/tweak-editor.html:8` |
| `478fa9eefbe2` | certain | Tweak a page — {{worldName}} | `modules/hall-ui/public/tweak-editor.html:8` |
| `7a29c910cc5b` | certain | Tweak {…} — {…} | `modules/hall-ui/public/tweak-editor.js:286` |
| `18801fb6845f` | certain | Tweak/CopyWrite Flow | `modules/hall-ui/public/studio.html:117` |
| `18801fb6845f` | certain | Tweak/CopyWrite Flow | `modules/hall-ui/public/studio.html:141` |
| `4a25dba3ef56` | certain | Type it yourself | `modules/hall-ui/public/commands-lib.js:93` |
| `4a25dba3ef56` | certain | Type it yourself | `modules/hall-ui/public/commands.html:37` |
| `348507a25334` | certain | Type these in a Claude Code session on this project. Most also start when you simply say what you want in plai | `modules/hall-ui/public/commands.html:34` |
| `33e828352ba3` | certain | Type to narrow the list | `modules/hall-ui/public/settings-specialities.js:242` |
| `1a64679fbb42` | certain | Typo or grammar | `modules/hall-ui/public/copy-desk.html:94` |
| `6516cc82021a` | certain | UI design | `modules/hall-ui/public/settings.html:253` |
| `2c1c20785a6e` | certain | Unclear — a person would not know what to do | `modules/hall-ui/public/copy-desk.html:91` |
| `aa445f06cc5e` | certain | Unlink failed: {…} | `modules/hall-ui/public/settings.js:700` |
| `4a716d7d8d46` | certain | Up to date | `modules/hall-ui/public/settings-software-update.js:142` |
| `13ced9b2fa12` | certain | Update ready | `modules/hall-ui/public/settings-software-update.js:145` |
| `1e091df06692` | certain | Update rule: {…} | `modules/hall-ui/public/deploy.js:294` |
| `55fde21d907b` | certain | Update to {…}{…} | `modules/hall-ui/public/settings-software-update.js:85` |
| `67fbc770b3b3` | certain | Upvote (+1) | `modules/hall-ui/public/builders.js:777` |
| `16d7f809be8a` | certain | Use the control below to take it. | `modules/hall-ui/public/shell.js:848` |
| `e7e2a99a2bea` | certain | Use this | `modules/hall-ui/public/settings-specialities.js:395` |
| `fe0f438b2ff9` | certain | Use this plan | `modules/hall-ui/public/genesis-home.js:115` |
| `e1ecd543a2ca` | certain | Using this speciality. | `modules/hall-ui/public/settings-specialities.js:454` |
| `6200bac6bdca` | certain | View all sessions | `modules/hall-ui/public/watch.html:99` |
| `9b92aa01516d` | certain | View all {…} {…} → | `modules/hall-ui/public/goals-render.js:617` |
| `4babdfeaf27f` | certain | View full standing → | `modules/hall-ui/public/hall-widgets.js:86` |
| `f8546b3e285e` | certain | View tasks {…} | `modules/hall-ui/public/roadmap.js:147` |
| `71c09cda8246` | certain | Voice for {…} | `modules/hall-ui/public/settings.js:74` |
| `2940b7828d26` | certain | Volume {…}%. | `modules/hall-ui/public/settings.js:216` |
| `6905f2ee5702` | certain | Vote on this work | `modules/hall-ui/public/builders.js:777` |
| `b2937e14ee9b` | certain | Vote yes | `modules/hall-ui/public/board-room.js:368` |
| `8cc425582984` | certain | Vulnerability reports | `modules/hall-ui/public/watch.html:125` |
| `b1e63e33f739` | certain | Vulnerability reports, engagement reports, override requests, and the audit log. | `modules/hall-ui/public/watch.html:122` |
| `411b2ff58094` | certain | Wait for task | `modules/hall-ui/public/task.js:629` |
| `b18832e219dc` | certain | Waiting on {…} | `modules/hall-ui/public/goals-lib.js:91` |
| `f2e019bfdbe8` | certain | Waiting to be developed | `modules/hall-ui/public/ideas.html:126` |
| `9bc8f6bb1d47` | certain | Waiting to try core {…} again at {…}. | `modules/hall-ui/public/deploy.js:209` |
| `9bc8f6bb1d47` | certain | Waiting to try core {…} again at {…}. | `modules/hall-ui/public/deploy.js:212` |
| `8e4f0179e1d3` | certain | Waits on | `modules/hall-ui/public/goal-forest-render.js:146` |
| `3a9cd9a27a84` | certain | Walk the full ladder → | `modules/hall-ui/public/hall-render.js:84` |
| `18f2f54de2a8` | certain | Watch sections | `modules/hall-ui/public/watch.html:54` |
| `c1fcfa9b48c2` | certain | Watch — {{worldName}} | `modules/hall-ui/public/watch.html:6` |
| `c1fcfa9b48c2` | certain | Watch — {{worldName}} | `modules/hall-ui/public/watch.html:6` |
| `0658f0358ffd` | certain | Welcome back, {…}. | `modules/hall-ui/public/hall-render.js:599` |
| `04ef2f1bc4c4` | certain | Welcome, {…}. Claim and release tasks and follow work in progress — no terminal needed. | `modules/hall-ui/public/work.js:922` |
| `d6bae87dc29b` | certain | What builders will see | `modules/hall-ui/public/government.html:86` |
| `f3d93a872a38` | certain | What counts | `modules/hall-ui/public/drachmae.js:107` |
| `6bf049a0c943` | certain | What each project costs | `modules/hall-ui/public/fleet.html:35` |
| `21b7bd90ce2a` | certain | What happens to task {…} | `modules/hall-ui/public/goals-render.js:1006` |
| `066425caef96` | certain | What if: invents removals, dimming and nods — none has happened in the ledger yet — so you can see how the dea | `modules/hall-ui/public/goal-map.html:76` |
| `066425caef96` | certain | What if: invents removals, dimming and nods — none has happened in the ledger yet — so you can see how the dea | `modules/hall-ui/public/thinking.html:84` |
| `0874800c694a` | certain | What is being built right now. See | `modules/hall-ui/public/work.html:116` |
| `70dc106494cf` | certain | What is wrong with it, and what would better look like? | `modules/hall-ui/public/copy-desk.html:101` |
| `65fd1339e2f2` | certain | What it costs | `modules/hall-ui/public/commands-lib.js:100` |
| `65fd1339e2f2` | certain | What it costs | `modules/hall-ui/public/settings-specialities.js:130` |
| `0efa2f18bb6c` | certain | What it does | `modules/hall-ui/public/commands-lib.js:100` |
| `0efa2f18bb6c` | certain | What it does | `modules/hall-ui/public/commands-lib.js:122` |
| `0efa2f18bb6c` | certain | What it does | `modules/hall-ui/public/settings-specialities.js:130` |
| `ae44a375e814` | certain | What it unlocks | `modules/hall-ui/public/ranks.js:109` |
| `00dc1f0f83e1` | certain | What kind of wrong? | `modules/hall-ui/public/copy-desk.html:87` |
| `c9a4c6f16433` | certain | What needs changing | `modules/hall-ui/public/approval-queue.js:174` |
| `9a85f2c19b48` | certain | What should it say? | `modules/hall-ui/public/copy-desk.html:156` |
| `2dd116d2d817` | certain | What the current wording gets wrong, and what yours does about it. | `modules/hall-ui/public/copy-desk.html:166` |
| `e179870922a3` | certain | What the session did, derived from its own transcript: whether it wrote files, used tools, and how many prompt | `modules/hall-ui/public/sessions.html:74` |
| `868cf4bbe616` | certain | What the start-it markers mean | `modules/hall-ui/public/commands.html:35` |
| `5a58392783fd` | certain | What this brings in | `modules/hall-ui/public/deploy.js:550` |
| `a444ad812e4f` | certain | What this builder has done, seen one role at a time. | `modules/hall-ui/public/profile.html:138` |
| `32d675a2b022` | certain | What this rank is for (optional) | `modules/hall-ui/public/government.html:90` |
| `04b3ff4c4f4c` | certain | What users can see | `modules/hall-ui/public/deploy.html:47` |
| `1d5bfd09068c` | certain | What you saw | `modules/hall-ui/public/studio.js:191` |
| `a9e95b5fda1d` | certain | What {…} offers | `modules/hall-ui/public/settings-specialities.js:276` |
| `b8743d16eab8` | certain | What {…} unlocks | `modules/hall-ui/public/hall-render.js:82` |
| `6ff24dd04d46` | certain | What\u2019s this? | `modules/hall-ui/public/shell.js:1027` |
| `ecfd34bf5e6f` | certain | What’s stuck (optional) | `modules/hall-ui/public/blockers.js:308` |
| `55ef095fe001` | certain | When every task above is finished, this stage can be put to the board. | `modules/hall-ui/public/genesis-home.js:208` |
| `a6e102816e92` | certain | When to reach for it | `modules/hall-ui/public/commands-lib.js:100` |
| `a6e102816e92` | certain | When to reach for it | `modules/hall-ui/public/settings-specialities.js:130` |
| `5d73558dae0e` | certain | Where do you begin? | `modules/hall-ui/public/goal-map.html:110` |
| `5d73558dae0e` | certain | Where do you begin? | `modules/hall-ui/public/goal-map.html:112` |
| `ec1a438eee3f` | certain | Where each comes from and where each goes. {{Currency}} = credits; karma is a separate peer-trust signal, not  | `modules/hall-ui/public/diagrams.html:68` |
| `c44892e8870d` | certain | Where it went | `modules/hall-ui/public/drachmae.js:218` |
| `5999540bb2da` | certain | Where the asks stand | `modules/hall-ui/public/collab.html:43` |
| `4052378c3e04` | certain | Where the words stand | `modules/hall-ui/public/copy-desk.html:38` |
| `158499e38ceb` | certain | Where you stand | `modules/hall-ui/public/ranks.html:36` |
| `2bf84fa67b46` | certain | Where your work runs and how it reaches production, in one diagram. | `modules/hall-ui/public/diagrams.html:74` |
| `d3a8b2b5b93f` | certain | Where {{currency}} and karma come from and where they go. | `modules/hall-ui/public/diagrams.html:67` |
| `68da8cb13058` | certain | Which version of Cloud Bongos this project runs, whether a newer one is ready for it, and what each newer vers | `modules/hall-ui/public/settings.html:391` |
| `f9ab9eb870a6` | certain | While you wait: install the Claude desktop app at | `modules/hall-ui/public/hall-render.js:440` |
| `74d8c58ef235` | certain | Who builds on this project, ranked by work shipped. This project's own ledger — everyone who builds here is li | `modules/hall-ui/public/roster.html:28` |
| `b79ea4077bc5` | certain | Who can use it | `modules/hall-ui/public/settings.html:265` |
| `045c629729b7` | certain | Who’s on this goal, and what they’ve contributed to it. | `modules/hall-ui/public/goals.html:208` |
| `5cc53380b1e8` | certain | Why (optional) | `modules/hall-ui/public/goals-render.js:1035` |
| `62ab2e60f629` | certain | Why is this better? | `modules/hall-ui/public/copy-desk.html:164` |
| `ef4614d549d5` | certain | Why retire this task? | `modules/hall-ui/public/task.js:825` |
| `2b047710fd6d` | certain | Why this goal is being retired (required) | `modules/hall-ui/public/goals-render.js:1045` |
| `fbd8a815b808` | certain | Why — the reason the author will act on | `modules/hall-ui/public/board-room.js:368` |
| `a3ac116b499a` | certain | Why? | `modules/hall-ui/public/copy-desk.html:99` |
| `c5fd76a9e03d` | certain | Won {…} | `modules/hall-ui/public/builders.js:477` |
| `c5fd76a9e03d` | certain | Won {…} | `modules/hall-ui/public/profile.js:206` |
| `986514f35589` | certain | Work board | `modules/hall-ui/public/work.html:31` |
| `520d139df9eb` | certain | Work is complete but the version is held — no tasks are being claimed here right now. | `modules/hall-ui/public/roadmap.js:236` |
| `0e6b8e8f26cc` | certain | Works completed | `modules/hall-ui/public/profile.html:148` |
| `52e5fe3c6075` | certain | Write a Full Idea | `modules/hall-ui/public/ideas.html:145` |
| `ad1e1ab1ecac` | certain | Write a reply… | `modules/hall-ui/public/collab.js:175` |
| `47f61e576454` | certain | Write the wording you want instead. | `modules/hall-ui/public/copy-desk.js:436` |
| `b6b0fcb2bcee` | certain | You already have a pending request or invitation for this goal. | `modules/hall-ui/public/goals-render.js:1398` |
| `52e93bbc07a6` | certain | You are already a member of this goal. | `modules/hall-ui/public/goals-render.js:1399` |
| `46b1265ef172` | certain | You are not a member of this goal. | `modules/hall-ui/public/goals-render.js:1355` |
| `921cb15a8188` | certain | You can still press Move — the runner will refuse it the same way, and the box is left where it is. | `modules/hall-ui/public/deploy.js:465` |
| `bcf33947aff6` | certain | You created this task and it is already retired. | `modules/hall-ui/public/task.js:817` |
| `23c68db6db4e` | certain | You created this task, but it has already moved past planning. Retiring it now is a change to the record, so i | `modules/hall-ui/public/task.js:822` |
| `cf0c107a39fc` | certain | You created this task, but it has shipped. Shipped work is immutable history — nobody can retire it, whatever  | `modules/hall-ui/public/task.js:815` |
| `b91183c02c63` | certain | You created this task, but someone is holding a claim on it. Once that is released you can retire it yourself. | `modules/hall-ui/public/task.js:820` |
| `da274462bb30` | certain | You have no open asks. | `modules/hall-ui/public/collab.html:72` |
| `6b759151f722` | certain | You have reached the end. The button below is now active. | `modules/hall-ui/public/primer.js:309` |
| `6d5a4ca58dd6` | certain | You haven’t joined any goals yet. | `modules/hall-ui/public/goals.js:83` |
| `8e527ab12334` | certain | You {…}. One vote per member. | `modules/hall-ui/public/board-room.js:440` |
| `8e1915b19274` | certain | You're in the {…} server with your rank role. | `modules/hall-ui/public/settings.js:677` |
| `56cfdcc60079` | certain | You're not signed in yet. Sign in to manage your connections, your keys and the way the hall behaves. | `modules/hall-ui/public/settings.html:44` |
| `3a6ed99ec333` | certain | You've been approved before — sign in and pick up where you left off. | `modules/hall-ui/public/hall-render.js:370` |
| `3749997eef4a` | certain | Your Autobongos runner | `modules/hall-ui/public/settings.html:173` |
| `7d26333b5fb0` | certain | Your asks | `modules/hall-ui/public/collab.html:68` |
| `f96bc227dba0` | certain | Your choice | `modules/hall-ui/public/settings.html:340` |
| `44a68d05519e` | certain | Your choices for {…} | `modules/hall-ui/public/settings-specialities.js:152` |
| `909b0b7c6ffa` | certain | Your display name | `modules/hall-ui/public/settings.html:87` |
| `dc9cfd1519a4` | certain | Your file was not saved. | `modules/hall-ui/public/tweak-editor.html:120` |
| `466457c34316` | certain | Your handle, bio and links, whether your profile page is public, whether recruiters can find you, and whether  | `modules/hall-ui/public/settings.html:104` |
| `a47f15b6a33c` | certain | Your image-generation key settings could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings.js:999` |
| `00fb37fd5adf` | certain | Your interaction profile could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings-interaction.js:122` |
| `51fd6f1ecb2f` | certain | Your key | `modules/hall-ui/public/settings.js:828` |
| `773647c1e453` | certain | Your machine | `modules/hall-ui/public/diagrams.html:74` |
| `8200f8b5fa45` | certain | Your machine · memory · server (authority + prod) · GitHub — and the full path from your machine to production | `modules/hall-ui/public/diagrams.html:77` |
| `20d453b11ae5` | certain | Your name | `modules/hall-ui/public/hall-render.js:297` |
| `6dadadffa36e` | certain | Your name cannot be blank. | `modules/hall-ui/public/settings.js:606` |
| `bd77210a8c90` | certain | Your name must be {…} characters or fewer. | `modules/hall-ui/public/settings.js:611` |
| `c0a01a95e97e` | certain | Your own idea. You may vote, but it can’t be decided by your vote alone, and a vote on your own idea earns no  | `modules/hall-ui/public/board-room.js:366` |
| `5e0ec4cd1cfe` | certain | Your own row carries no controls. Nobody can change their own rank or standing — that guard is what stops the  | `modules/hall-ui/public/watch.js:864` |
| `8fc605026acf` | certain | Your pending join {…}: {…} — awaiting approval. | `modules/hall-ui/public/goal-inbox.js:88` |
| `e91418db3962` | certain | Your preferences, {…}. | `modules/hall-ui/public/settings.js:630` |
| `e91418db3962` | certain | Your preferences, {…}. | `modules/hall-ui/public/settings.js:1174` |
| `f39746e3d66b` | certain | Your rendering preference could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings-render.js:133` |
| `b2dfd7120052` | certain | Your request is sent ✓ | `modules/hall-ui/public/hall-render.js:440` |
| `6202f9953f41` | certain | Your runner settings could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings-autobongos.js:151` |
| `b410b052f000` | certain | Your shipping year | `modules/hall-ui/public/profile-charts.js:358` |
| `e25863ab2311` | certain | Your sky — {{worldName}} | `modules/hall-ui/public/thinking.html:6` |
| `e25863ab2311` | certain | Your sky — {{worldName}} | `modules/hall-ui/public/thinking.html:6` |
| `dd419ffd76f0` | certain | Your specialities | `modules/hall-ui/public/settings.html:229` |
| `a588fb76667f` | certain | Your team now ({…} builder{…}) | `modules/hall-ui/public/government.js:853` |
| `aeaab4969b68` | certain | Your thinking | `modules/hall-ui/public/thinking.html:51` |
| `aeaab4969b68` | certain | Your thinking | `modules/hall-ui/public/thinking.html:51` |
| `a824e3e2057a` | certain | Your verdict on a review is recorded from the review itself — open it to dismiss it, note what you saw, or fil | `modules/hall-ui/public/studio.js:188` |
| `f6b12676169b` | certain | Your vote | `modules/hall-ui/public/hall-widgets.js:201` |
| `fe94ff29a2cc` | certain | Your wandering level could not be loaded. Reload the page to try again. | `modules/hall-ui/public/settings.js:484` |
| `60550f388cc9` | certain | Your work | `modules/hall-ui/public/hall-widgets.js:101` |
| `60550f388cc9` | certain | Your work | `modules/hall-ui/public/hall-widgets.js:157` |
| `137b07b42203` | certain | Zoom in | `modules/hall-ui/public/diagram-viewer.js:98` |
| `0d0bfa651b36` | certain | Zoom out | `modules/hall-ui/public/diagram-viewer.js:96` |
| `cc361cc7333a` | certain | \s?/.test(raw)) { const quoteLines = []; while (i | `modules/hall-ui/public/md-reader.js:189` |
| `8fdcb0439d2f` | certain | a sentence of context | `modules/hall-ui/public/blockers.js:309` |
| `a02616e47d11` | certain | a year of qualifying ships, in your timezone \u00b7 only you see this one | `modules/hall-ui/public/profile-charts.js:358` |
| `5070ebfedc48` | certain | access: the hub keeps a key of its own for this repository, so this change and every later upgrade are saved t | `modules/hall-ui/public/deploy.js:416` |
| `9612c983451f` | certain | achieved · | `modules/hall-ui/public/roadmap.js:288` |
| `dbfc9e6e921b` | certain | active builder{…}: {…} | `modules/hall-ui/public/government.js:809` |
| `6ea7c97a6583` | certain | alive · | `modules/hall-ui/public/sky-interaction.js:129` |
| `754babaae931` | certain | and ask in | `modules/hall-ui/public/hall-render.js:807` |
| `bc960f460250` | certain | and install dependencies ( | `modules/hall-ui/public/hall-render.js:809` |
| `2177da93be9b` | certain | and leave this alone. | `modules/hall-ui/public/settings.html:320` |
| `0257cb508ae7` | certain | and {…} more below this thought | `modules/hall-ui/public/profile.js:465` |
| `d86265f99668` | certain | and {…} more waiting{…} | `modules/hall-ui/public/studio.js:311` |
| `9bf4d3cabf80` | certain | approval queue | `modules/hall-ui/public/approval-queue.js:192` |
| `ac37199ccdbb` | certain | approve and ship | `modules/hall-ui/public/approval-queue.js:172` |
| `b4033000c537` | certain | as a table | `modules/hall-ui/public/profile-charts.js:267` |
| `72f977e4c47f` | certain | as configuration: membership rank:{…} — the council rank below, once you have added it and assigned its member | `modules/hall-ui/public/government.js:885` |
| `d7c511423bc0` | certain | as configuration: {…} | `modules/hall-ui/public/government.js:795` |
| `6d91bea9b24e` | certain | as of {…} | `modules/hall-ui/public/sky-interaction.js:122` |
| `a756e47632cd` | certain | at {…} — {…}. The timer above is the fallback that is actually in force. | `modules/hall-ui/public/project-settings.js:103` |
| `63bd14f73960` | certain | author trusted | `modules/hall-ui/public/gate.js:156` |
| `24a2c1d958da` | certain | back to the studio | `modules/hall-ui/public/tweak-editor.html:106` |
| `e81d92078af1` | certain | bongos help | `modules/hall-ui/public/commands.html:45` |
| `9193bf136fed` | certain | bongos upgrade | `modules/hall-ui/public/settings-software-update.js:76` |
| `552e00198649` | certain | builders, on the People tab | `modules/hall-ui/public/watch.html:48` |
| `c36033fdd528` | certain | built &amp; enforced today | `modules/hall-ui/public/diagrams.html:42` |
| `a87a3c30b1b5` | certain | built here | `modules/hall-ui/public/modules.js:53` |
| `263a210459d6` | certain | burned out · | `modules/hall-ui/public/sky-interaction.js:128` |
| `e6a48f17d75e` | certain | burning · | `modules/hall-ui/public/sky-interaction.js:128` |
| `b73a83223bc0` | certain | cannot be read, so | `modules/hall-ui/public/government.js:547` |
| `0c57dbbdbdd4` | certain | chart every route from {…} | `modules/hall-ui/public/sky-interaction.js:45` |
| `9203a7283960` | certain | claim next | `modules/hall-ui/public/goals-render.js:170` |
| `e73a4375e7d0` | certain | claude layer | `modules/hall-ui/public/thinking.html:82` |
| `3a49b4974af1` | certain | clean ship you are promoted automatically to | `modules/hall-ui/public/ranks.js:83` |
| `8d46c902a9d5` | certain | click any words here to rewrite them | `modules/hall-ui/public/studio.html:97` |
| `5899363f4836` | certain | close split view | `modules/hall-ui/public/tweak-editor.html:85` |
| `e15ebbd43778` | certain | collapsed · | `modules/hall-ui/public/sky-interaction.js:129` |
| `508ff7083048` | certain | command says your session expired. | `modules/hall-ui/public/settings.html:136` |
| `ef93fb8ebb26` | certain | could not nod — no task to make claimable | `modules/hall-ui/public/sky-composer.js:146` |
| `de87e7f6cdcb` | certain | could not nod — {…} | `modules/hall-ui/public/sky-composer.js:151` |
| `b2ed350c2c2c` | certain | criteria planned · no tasks yet | `modules/hall-ui/public/roadmap.js:218` |
| `0e2bef756977` | certain | days ({…}–{…}) | `modules/hall-ui/public/project-settings.js:113` |
| `4adbb8da9999` | certain | default ({…}) | `modules/hall-ui/public/settings-render.js:64` |
| `4a287afb0892` | certain | default for your rank | `modules/hall-ui/public/settings.js:420` |
| `563e03d200c6` | certain | designed, task-tracked, not yet built | `modules/hall-ui/public/diagrams.html:43` |
| `a3fd52d9513b` | certain | document{…} you added · learned | `modules/hall-ui/public/settings-specialities.js:322` |
| `fcec9cad1c69` | certain | download .docx | `modules/hall-ui/public/tweak-editor.html:63` |
| `7c1f761ff7c0` | certain | download this page again | `modules/hall-ui/public/tweak-editor.html:129` |
| `87129aa3ab0a` | certain | downloaded .docx | `modules/hall-ui/public/tweak-editor.js:472` |
| `16d18b40bd23` | certain | drag to pan · ⌘/ctrl + scroll to zoom · ⤢ fullscreen | `modules/hall-ui/public/diagram-viewer.js:121` |
| `1f80614e6960` | certain | drag to pan, scroll to zoom, or open it fullscreen | `modules/hall-ui/public/diagrams.html:74` |
| `77b0b2b446a1` | certain | e.g. octocat | `modules/hall-ui/public/hall-render.js:297` |
| `77b0b2b446a1` | certain | e.g. octocat | `modules/hall-ui/public/watch.js:296` |
| `675bdfc49e03` | certain | e.g. superseded by task 1002891 | `modules/hall-ui/public/task.js:825` |
| `0360797d3570` | certain | e.g. “{…}” and “{…}” | `modules/hall-ui/public/goal-inbox.js:110` |
| `12a23cc46ace` | certain | ends every session including this one — you will be asked to sign in again. | `modules/hall-ui/public/settings.html:161` |
| `5321f9da0841` | certain | exists in schema, no behavior yet | `modules/hall-ui/public/diagrams.html:44` |
| `df941da50c7c` | certain | fell short | `modules/hall-ui/public/builders.js:562` |
| `31735e119a04` | certain | first vote | `modules/hall-ui/public/government.js:570` |
| `9563bd9f4971` | certain | first — your username is all we need. | `modules/hall-ui/public/hall-render.js:297` |
| `2e111f3a4912` | certain | flagged by | `modules/hall-ui/public/copy-desk.js:148` |
| `ef297e8f8d5f` | certain | folded in · | `modules/hall-ui/public/sky-interaction.js:128` |
| `50eb308666b2` | certain | for version-level progress and goals. | `modules/hall-ui/public/work.html:116` |
| `cc72f8a00297` | certain | from the {…} module | `modules/hall-ui/public/commands-lib.js:88` |
| `85ee22a0f184` | certain | full idea | `modules/hall-ui/public/goal-map.html:91` |
| `85ee22a0f184` | certain | full idea | `modules/hall-ui/public/thinking.html:99` |
| `064c72453555` | certain | goals · | `modules/hall-ui/public/roadmap.js:218` |
| `064c72453555` | certain | goals · | `modules/hall-ui/public/sky-interaction.js:38` |
| `064c72453555` | certain | goals · | `modules/hall-ui/public/sky-interaction.js:129` |
| `8e66451d0c12` | certain | gravity — the goal that catches it lights as you type; letting it float is a real answer | `modules/hall-ui/public/goal-map.html:94` |
| `8e66451d0c12` | certain | gravity — the goal that catches it lights as you type; letting it float is a real answer | `modules/hall-ui/public/thinking.html:102` |
| `c5862d055f1a` | certain | hard floor | `modules/hall-ui/public/gate.js:142` |
| `55d673a5f0ec` | certain | highest credits | `modules/hall-ui/public/hall-widgets.js:166` |
| `c2267f78f931` | certain | highlighted: the words you changed | `modules/hall-ui/public/approval-queue.js:168` |
| `c2267f78f931` | certain | highlighted: the words you changed | `modules/hall-ui/public/approval-queue.js:181` |
| `da40bf505b89` | certain | hist. | `modules/hall-ui/public/sky-panel.js:40` |
| `fda88709bc50` | certain | holds the repo. Follow the numbered path to see how your work gets to prod. This is the largest diagram — | `modules/hall-ui/public/diagrams.html:74` |
| `17ab8db79e1f` | certain | holds the worker, the code, and your local memory; the | `modules/hall-ui/public/diagrams.html:74` |
| `78dba41dbc9d` | certain | how far each surface has come | `modules/hall-ui/public/studio.html:126` |
| `7d5cbe3d81e4` | certain | how long a vote stays open | `modules/hall-ui/public/government.html:55` |
| `ae8d31e7c29e` | certain | how to read the sky · {…} of {…} | `modules/hall-ui/public/sky-tour.js:58` |
| `dacb901c4f10` | certain | idea number | `modules/hall-ui/public/task-detail.js:562` |
| `7df22e74c87a` | certain | idea {…} | `modules/hall-ui/public/idea.js:237` |
| `7df22e74c87a` | certain | idea {…} | `modules/hall-ui/public/ideas.js:546` |
| `b2b399fdd6a4` | certain | in progress | `modules/hall-ui/public/roadmap.js:120` |
| `b2b399fdd6a4` | certain | in progress | `modules/hall-ui/public/roadmap.js:207` |
| `0af147b7fd54` | certain | in progress · | `modules/hall-ui/public/roadmap.js:288` |
| `275e222d5448` | certain | instead of the last line. New to the steps? The | `modules/hall-ui/public/hall-render.js:832` |
| `01ae1a45baff` | certain | invited by {…} | `modules/hall-ui/public/goal-inbox.js:53` |
| `77ad318bb546` | certain | invited — awaiting their response | `modules/hall-ui/public/goals-render.js:1433` |
| `6cfd7c0e0db6` | certain | is both the authority and production; | `modules/hall-ui/public/diagrams.html:74` |
| `af0777cd098b` | certain | is hardcoded back inside this | `modules/hall-ui/public/index.html:60` |
| `d0e722302840` | certain | is published and this box is not on it yet. | `modules/hall-ui/public/deploy.js:422` |
| `aa530bd15088` | certain | itself). The registry stays the single source of truth for what the hall shows; a fitness check (scripts/gds/f | `modules/hall-ui/public/index.html:57` |
| `6b530a7007bc` | certain | jump to a goal or a thought | `modules/hall-ui/public/goal-map.html:84` |
| `6b530a7007bc` | certain | jump to a goal or a thought | `modules/hall-ui/public/thinking.html:92` |
| `9328033a890a` | certain | land every shuttle | `modules/hall-ui/public/sky-interaction.js:45` |
| `9018bf6e99eb` | certain | last used {…} · signed in {…} | `modules/hall-ui/public/settings-sessions.js:46` |
| `2ce7738b1eb0` | certain | loading goals… | `modules/hall-ui/public/task-detail.js:482` |
| `754bdec368ed` | certain | lowest credits | `modules/hall-ui/public/hall-widgets.js:167` |
| `bc7923324b96` | certain | manage its visibility in Settings → Profile and privacy | `modules/hall-ui/public/profile.js:345` |
| `359768b007ee` | certain | map every route in the sky | `modules/hall-ui/public/sky-interaction.js:45` |
| `5c3fdd34cd02` | certain | means expressible through the real configuration — a rank-based membership plus a pass rule — with no new code | `modules/hall-ui/public/government.js:809` |
| `0eefd625d954` | certain | merged into | `modules/hall-ui/public/idea.js:237` |
| `70c234985d42` | certain | most recent first | `modules/hall-ui/public/hall-widgets.js:165` |
| `e7213f35cd9a` | certain | move → #{…} {…} | `modules/hall-ui/public/goals-render.js:1005` |
| `b73da75989f0` | certain | my ideas | `modules/hall-ui/public/goal-map.html:75` |
| `3f4dc14e6ed1` | certain | my influence | `modules/hall-ui/public/thinking.html:83` |
| `86f235ddfe01` | certain | new thread | `modules/hall-ui/public/settings.html:297` |
| `73bfe3b1ff54` | certain | next up | `modules/hall-ui/public/tweak-editor.html:98` |
| `b9f2e0d43c94` | certain | no clock | `modules/hall-ui/public/government.js:607` |
| `e3317d58ec83` | certain | no cost logged | `modules/hall-ui/public/hall-render.js:355` |
| `e02979266baf` | certain | no data | `modules/hall-ui/public/hall-kit.js:735` |
| `9e194a57d054` | certain | no reading | `modules/hall-ui/public/deploy.js:130` |
| `8769ce8ea030` | certain | no size | `modules/hall-ui/public/profile-crafts.js:156` |
| `33ca71bef112` | certain | no tasks yet | `modules/hall-ui/public/goals-render.js:174` |
| `9063008d412e` | certain | nodded — a builder can claim it now | `modules/hall-ui/public/sky-composer.js:149` |
| `739a4bd6bd83` | certain | node scripts/setup-builder.js | `modules/hall-ui/public/hall-render.js:832` |
| `61f0f4b2f4ab` | certain | not categorised yet | `modules/hall-ui/public/goals-page.js:297` |
| `7b5ad068dc26` | certain | not graded | `modules/hall-ui/public/hall-render.js:346` |
| `01a3d68d80c1` | certain | not graded (grader outage) | `modules/hall-ui/public/builders.js:557` |
| `d43b9bbb8d4d` | certain | not graded (quality lens unavailable) | `modules/hall-ui/public/builders.js:559` |
| `c04e4491af67` | certain | not now | `modules/hall-ui/public/studio.html:104` |
| `3916a3dc8e98` | certain | not started | `modules/hall-ui/public/roadmap.js:120` |
| `3916a3dc8e98` | certain | not started | `modules/hall-ui/public/roadmap.js:288` |
| `b4d87a62ec85` | certain | nothing by that name — or not explored yet | `modules/hall-ui/public/sky-interaction.js:138` |
| `8ca0a499ec86` | certain | nothing recorded yet · {…} | `modules/hall-ui/public/profile-charts.js:288` |
| `a85339717a72` | certain | nothing was saved | `modules/hall-ui/public/tweak-editor.html:119` |
| `e2c643fbf4d6` | certain | npm install | `modules/hall-ui/public/hall-render.js:809` |
| `e90b5601ce16` | certain | objected to | `modules/hall-ui/public/board-room.js:173` |
| `351d56b80a6c` | certain | of all in-flight tasks shipped | `modules/hall-ui/public/roadmap.js:298` |
| `09172f45e6da` | certain | of the 90% needed | `modules/hall-ui/public/primer.html:101` |
| `99f88f2af2ee` | certain | of work — a tangent, an investigation, an unprompted suggestion — instead of staying on your claimed task. It  | `modules/hall-ui/public/settings.html:297` |
| `5e7a2220c6a9` | certain | of {…} | `modules/hall-ui/public/roadmap.js:288` |
| `759c12b5f983` | certain | oldest first | `modules/hall-ui/public/hall-widgets.js:165` |
| `f5a9579bbc36` | certain | open in new tab | `modules/hall-ui/public/tweak-editor.html:59` |
| `e2431ea36238` | certain | open in split view | `modules/hall-ui/public/tweak-editor.html:60` |
| `08f1f614253c` | certain | open the page ↗ | `modules/hall-ui/public/tweak-editor.html:57` |
| `cbaf58cdbe35` | certain | open the queue | `modules/hall-ui/public/goal-inbox.js:561` |
| `af3a8e0fe6a8` | certain | open your goals | `modules/hall-ui/public/goal-inbox.js:127` |
| `af3a8e0fe6a8` | certain | open your goals | `modules/hall-ui/public/goal-inbox.js:158` |
| `9a803563c948` | certain | open {…} | `modules/hall-ui/public/approval-queue.js:163` |
| `4f279d68175f` | certain | open, on the Security tab | `modules/hall-ui/public/watch.html:47` |
| `7b85e6494596` | certain | opens a new tab | `modules/hall-ui/public/palette.js:315` |
| `c38db02adb61` | certain | or above | `modules/hall-ui/public/government.js:564` |
| `271de72308a4` | certain | pages tweaked | `modules/hall-ui/public/studio.html:83` |
| `356573640ce1` | certain | pages tweaked, per surface | `modules/hall-ui/public/profile.js:183` |
| `884948925fcb` | certain | paste command | `modules/hall-ui/public/settings.js:758` |
| `25d2c940e672` | certain | paste it into your terminal — bypasses Device Flow. | `modules/hall-ui/public/settings.html:141` |
| `2fb1dad96280` | certain | pending, on the People tab | `modules/hall-ui/public/watch.html:46` |
| `b6ceacaad5e5` | certain | pick another | `modules/hall-ui/public/studio.js:682` |
| `b6ceacaad5e5` | certain | pick another | `modules/hall-ui/public/tweak-editor.html:105` |
| `3b22c5af029b` | certain | rank or above, or that it is your own. | `modules/hall-ui/public/copy-desk.html:47` |
| `80ddf28baee7` | certain | rank-key (kebab-case) | `modules/hall-ui/public/government.html:82` |
| `41a4b66c21e5` | certain | reads the control plane's own observation · ADR 0293 · every move is recorded with who asked | `modules/hall-ui/public/deploy.js:704` |
| `8d810f134b7b` | certain | reconnect GitHub with repository access | `modules/hall-ui/public/deploy.js:416` |
| `f83f0a9d6b6a` | certain | recorded, on the Operations tab | `modules/hall-ui/public/watch.html:49` |
| `26da1df6fd4a` | certain | reflects it. | `modules/hall-ui/public/settings.html:125` |
| `9eca058c6ad2` | certain | release a thought — one line | `modules/hall-ui/public/goal-map.html:90` |
| `9eca058c6ad2` | certain | release a thought — one line | `modules/hall-ui/public/thinking.html:98` |
| `d4bb81532896` | certain | repro steps, context, anything that helps… | `modules/hall-ui/public/ideas.html:80` |
| `58b4e7a48d86` | certain | reviews from before Tweak Mode | `modules/hall-ui/public/studio.html:131` |
| `f37f5043f81b` | certain | ring {…} of {…} · {…} | `modules/hall-ui/public/sky-interaction.js:34` |
| `7a398ca1a286` | certain | route · {…} | `modules/hall-ui/public/sky-interaction.js:37` |
| `90da768431d5` | certain | routes · | `modules/hall-ui/public/sky-interaction.js:129` |
| `594962dc9ec3` | certain | s into the view containers below (falling back to | `modules/hall-ui/public/index.html:56` |
| `2a42549b34ae` | certain | said, when flagged: | `modules/hall-ui/public/copy-desk.js:124` |
| `9bec9eb4829e` | certain | scope: {…} | `modules/hall-ui/public/goals-render.js:865` |
| `9c35bc28a3e9` | certain | see it | `modules/hall-ui/public/goal-map.html:96` |
| `9c35bc28a3e9` | certain | see it | `modules/hall-ui/public/thinking.html:104` |
| `92775a3d8d0d` | certain | send it back | `modules/hall-ui/public/approval-queue.js:179` |
| `a13ee0cde7f2` | certain | set yours in Settings | `modules/hall-ui/public/collab.html:55` |
| `be368c58934a` | certain | settled · | `modules/hall-ui/public/sky-interaction.js:129` |
| `a6f55d7aa6f7` | certain | shipped (live) | `modules/hall-ui/public/roadmap.js:298` |
| `026ba1289d4d` | certain | shipped · | `modules/hall-ui/public/goals-render.js:787` |
| `8e30267795a7` | certain | show me everything | `modules/hall-ui/public/sky-layout.js:50` |
| `b250b5c4eb03` | certain | shuttle · {…} | `modules/hall-ui/public/sky-interaction.js:45` |
| `ec6d8c900bc8` | certain | sign in | `modules/hall-ui/public/profile-charts.js:605` |
| `ec6d8c900bc8` | certain | sign in | `modules/hall-ui/public/profile.js:817` |
| `ec6d8c900bc8` | certain | sign in | `modules/hall-ui/public/profile.js:958` |
| `c8c2551006dc` | certain | skip the tour | `modules/hall-ui/public/goal-map.html:121` |
| `c8c2551006dc` | certain | skip the tour | `modules/hall-ui/public/thinking.html:122` |
| `0215b2cdca8c` | certain | submit for review | `modules/hall-ui/public/modules.js:142` |
| `43e6f1592ae3` | certain | submit it in the editor | `modules/hall-ui/public/studio.js:797` |
| `9ec19e32f86f` | certain | submit page | `modules/hall-ui/public/tweak-editor.html:66` |
| `da30b952a60b` | certain | system / unattributed | `modules/hall-ui/public/goals-page.js:269` |
| `da30b952a60b` | certain | system / unattributed | `modules/hall-ui/public/work.js:562` |
| `70bbd20d223f` | certain | take it | `modules/hall-ui/public/studio.js:685` |
| `d4f99c118825` | certain | take next | `modules/hall-ui/public/tweak-editor.html:104` |
| `357cc737dd98` | certain | take the studio page | `modules/hall-ui/public/studio.html:103` |
| `24fc2b94ea7d` | certain | take this page | `modules/hall-ui/public/tweak-editor.js:315` |
| `a6e803a31a4d` | certain | task #{…} | `modules/hall-ui/public/copy-desk.js:105` |
| `eb808f2daba3` | certain | task dependenc{…} · click to chart it · double-click to chart every route from here | `modules/hall-ui/public/sky-interaction.js:37` |
| `3906fbc07bbe` | certain | task id | `modules/hall-ui/public/task.js:629` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/gate.js:157` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/hall-render.js:672` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/idea.js:234` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/ideas.js:201` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/ideas.js:782` |
| `4d8ee7d68974` | certain | task {…} | `modules/hall-ui/public/watch.js:1271` |
| `e4e423344746` | certain | task · {…} | `modules/hall-ui/public/sky-interaction.js:36` |
| `e4e423344746` | certain | task · {…} | `modules/hall-ui/public/sky-panel.js:95` |
| `a41659dc2bee` | certain | tasks remaining | `modules/hall-ui/public/roadmap.js:298` |
| `34cacf1b2c8f` | certain | tasks · {…} · click to fill the screen with it | `modules/hall-ui/public/sky-interaction.js:38` |
| `bd3402efa59e` | certain | task{…} shipped | `modules/hall-ui/public/goals-render.js:828` |
| `77711fffcb5d` | certain | the goal | `modules/hall-ui/public/sky-panel.js:84` |
| `17b7539c5472` | certain | the ledger | `modules/hall-ui/public/goal-map.html:103` |
| `17b7539c5472` | certain | the ledger | `modules/hall-ui/public/sky-panel.js:126` |
| `436506f4bc94` | certain | the live page | `modules/hall-ui/public/tweak-editor.html:84` |
| `abddfb2b1022` | certain | the newest {…} only | `modules/hall-ui/public/sky-interaction.js:124` |
| `4ad74172c874` | certain | the next page to tweak | `modules/hall-ui/public/studio.html:118` |
| `2be732b11690` | certain | the owner’s blockers | `modules/hall-ui/public/deploy.js:226` |
| `95854f8315ca` | certain | the page everyone else reads | `modules/hall-ui/public/profile.html:33` |
| `2f48995206d4` | certain | the pages /tweak has applied | `modules/hall-ui/public/studio.html:122` |
| `4bde7b562cf4` | certain | the record | `modules/hall-ui/public/sky-panel.js:51` |
| `2e24d473cfcc` | certain | the room | `modules/hall-ui/public/sky-panel.js:118` |
| `2e24d473cfcc` | certain | the room | `modules/hall-ui/public/thinking.html:111` |
| `5e1eda03fa73` | certain | the sky | `modules/hall-ui/public/goal-map.html:69` |
| `911e948a33ae` | certain | the task | `modules/hall-ui/public/sky-panel.js:103` |
| `2e5539862eb0` | certain | there takes this version, with the same health check and rollback. | `modules/hall-ui/public/settings-software-update.js:76` |
| `632527db5bca` | certain | this session | `modules/hall-ui/public/settings-sessions.js:44` |
| `130c3731ad83` | certain | this week | `modules/hall-ui/public/studio.html:85` |
| `4b6321a50a2d` | certain | thoughts · | `modules/hall-ui/public/sky-interaction.js:128` |
| `d70c287bcd7f` | certain | to authenticate this machine, then | `modules/hall-ui/public/hall-render.js:809` |
| `65702f92a8c8` | certain | to claim your first task. | `modules/hall-ui/public/hall-render.js:809` |
| `5520469f2834` | certain | to copy the task prompt and paste it into a fresh Claude Code session to begin. | `modules/hall-ui/public/work.html:103` |
| `94735a2353aa` | certain | to run it. | `modules/hall-ui/public/commands.html:37` |
| `7d54a818850d` | certain | to see the full record. | `modules/hall-ui/public/profile.js:263` |
| `3c9ba5dc851d` | certain | to see this list there. | `modules/hall-ui/public/commands.html:45` |
| `47204e5f11de` | certain | to see your own profile. | `modules/hall-ui/public/profile.js:958` |
| `23488ca48320` | certain | to take a task right here — no terminal needed. Then click | `modules/hall-ui/public/work.html:103` |
| `1b88ce51fd84` | certain | to tend now · {…} | `modules/hall-ui/public/studio.js:233` |
| `1b88ce51fd84` | certain | to tend now · {…} | `modules/hall-ui/public/studio.js:248` |
| `5b37996e87cb` | certain | trace only the latest | `modules/hall-ui/public/sky-interaction.js:45` |
| `edd5e9f56c25` | certain | unanimous agreement | `modules/hall-ui/public/government.js:587` |
| `f98966dc7cac` | certain | upkeep undeclared | `modules/hall-ui/public/modules.js:92` |
| `432def6844b7` | certain | upload .docx | `modules/hall-ui/public/tweak-editor.html:64` |
| `432def6844b7` | certain | upload .docx | `modules/hall-ui/public/tweak-editor.js:497` |
| `4de556377db2` | certain | verdict {…} | `modules/hall-ui/public/task.js:453` |
| `f20985df3729` | certain | version · {…} | `modules/hall-ui/public/sky-interaction.js:38` |
| `969577b937d6` | certain | versions in flight | `modules/hall-ui/public/roadmap.js:298` |
| `8cd3cc4005fc` | certain | via goal | `modules/hall-ui/public/dom-utils.js:441` |
| `007b28a56031` | certain | view diff | `modules/hall-ui/public/gate.js:160` |
| `18cf722bdd7e` | certain | waiting · | `modules/hall-ui/public/sky-interaction.js:128` |
| `35be9e0923da` | certain | walks the whole path in plain language. | `modules/hall-ui/public/hall-render.js:832` |
| `db42054582ed` | certain | wells · | `modules/hall-ui/public/sky-interaction.js:129` |
| `17705daf7b85` | certain | what counts as passing | `modules/hall-ui/public/government.html:55` |
| `96a8971a5c44` | certain | what got un-stuck | `modules/hall-ui/public/blockers.js:132` |
| `96a8971a5c44` | certain | what got un-stuck | `modules/hall-ui/public/task-detail.js:208` |
| `c084b0e8d497` | certain | what if | `modules/hall-ui/public/goal-map.html:76` |
| `c084b0e8d497` | certain | what if | `modules/hall-ui/public/thinking.html:84` |
| `3126bb540c89` | certain | what needs the owner’s decision | `modules/hall-ui/public/blockers.js:307` |
| `b1c5eaa20a9d` | certain | what the idea is, in one line | `modules/hall-ui/public/ideas.html:175` |
| `542c3516c904` | certain | what to do | `modules/hall-ui/public/tweak-editor.html:125` |
| `e72c90163726` | certain | what's blocking | `modules/hall-ui/public/goals-render.js:172` |
| `81f05d9b2bbf` | certain | what's wrong, or what you'd like to see | `modules/hall-ui/public/ideas.html:65` |
| `0d4acfac53bc` | certain | where it came from | `modules/hall-ui/public/profile-charts.js:455` |
| `c3959ea9d43b` | certain | where my thoughts are | `modules/hall-ui/public/sky-layout.js:50` |
| `1651cb1876f5` | certain | who sits on the board | `modules/hall-ui/public/government.html:55` |
| `143f77e2b782` | certain | why these are the same | `modules/hall-ui/public/task-detail.js:565` |
| `ec7c228cb4ce` | certain | why this isn’t worth doing | `modules/hall-ui/public/task-detail.js:616` |
| `98297cf0fa4d` | certain | with help from {…} | `modules/hall-ui/public/builders.js:767` |
| `c612ab426c2f` | certain | your sky | `modules/hall-ui/public/thinking.html:72` |
| `3491d859e66a` | certain | your thinking | `modules/hall-ui/public/thinking.html:77` |
| `66d979d0db89` | certain | your vote | `modules/hall-ui/public/board-room.js:168` |
| `78a3ca07861a` | certain | { const parts = window.OTB.splitCriterion ? window.OTB.splitCriterion(c.criterion_md) : { label: c.criterion_m | `modules/hall-ui/public/goals-render.js:722` |
| `d2bd1c3ab0f5` | certain | { if (row.key === 'rot_timer' && row.editable) return rowHtml(row, rotBodyHtml(row)); if (row.key === 'work_ca | `modules/hall-ui/public/project-settings.js:152` |
| `3d8611c2e79d` | certain | {{worldName}} · studio | `modules/hall-ui/public/studio.html:79` |
| `50d4a70a2eb2` | certain | {…} Access is invite-based: an Archon approves each new builder. To begin, request access below. | `modules/hall-ui/public/hall-render.js:297` |
| `9aac280c89ec` | certain | {…} Anyone with a GitHub account can join: sign in and you're in, starting at the newcomer rank. | `modules/hall-ui/public/hall-render.js:280` |
| `de5b58a187c6` | certain | {…} Change that profile and this follows it. | `modules/hall-ui/public/settings-render.js:65` |
| `e4b36621d4f1` | certain | {…} Nothing needs doing — this page shows the result when it lands. | `modules/hall-ui/public/deploy.js:214` |
| `6c08bfe92e2b` | certain | {…} This project is invite-only: the {…} invites each builder, and there is nothing to apply for here. | `modules/hall-ui/public/hall-render.js:289` |
| `c5623d60015d` | certain | {…} Your standing is {…}. | `modules/hall-ui/public/hall-render.js:844` |
| `a91e1e702d4d` | certain | {…} achieved, {…} in progress, {…} not started of {…} goals | `modules/hall-ui/public/roadmap.js:73` |
| `a65d371b5cb3` | certain | {…} and above can enable or disable a module | `modules/hall-ui/public/modules.js:140` |
| `98b1c674fc37` | certain | {…} and up | `modules/hall-ui/public/sessions.js:187` |
| `111b71a9acaf` | certain | {…} and up. | `modules/hall-ui/public/sessions.js:185` |
| `56b00d773232` | certain | {…} and {…} | `modules/hall-ui/public/profile-nudge.js:77` |
| `0da0e247ff0f` | certain | {…} asking to connect | `modules/hall-ui/public/profile-connections.js:145` |
| `788ff11f1135` | certain | {…} awarded | `modules/hall-ui/public/task.js:496` |
| `9d160147b34a` | certain | {…} criteria · since {…} | `modules/hall-ui/public/roadmap.js:153` |
| `9d160147b34a` | certain | {…} criteria · since {…} | `modules/hall-ui/public/roadmap.js:176` |
| `78ba2bd4bc44` | certain | {…} criteria · started {…} | `modules/hall-ui/public/roadmap.js:236` |
| `cf89ac85440d` | certain | {…} earned | `modules/hall-ui/public/goals-render.js:828` |
| `3efa67dc6e07` | certain | {…} file{…} | `modules/hall-ui/public/gate.js:151` |
| `00c50715f271` | certain | {…} fundamentals · {…} you can change here | `modules/hall-ui/public/project-settings.js:228` |
| `55b949873848` | certain | {…} is in. | `modules/hall-ui/public/tweak-editor.js:566` |
| `80b4aa799a4b` | certain | {…} is writing this page now. You can read it, download it, or take another page from the studio. | `modules/hall-ui/public/tweak-editor.js:319` |
| `830d2be6f859` | certain | {…} line | `modules/hall-ui/public/tweak-editor.js:235` |
| `511a4b6073cf` | certain | {…} more PR{…} still being checked. Refresh shortly. | `modules/hall-ui/public/gate.js:225` |
| `73c1372b43d9` | certain | {…} of {…} | `modules/hall-ui/public/sky-panel.js:120` |
| `cc5106af4b35` | certain | {…} of {…} criteria satisfied | `modules/hall-ui/public/goals-lib.js:32` |
| `cc5106af4b35` | certain | {…} of {…} criteria satisfied | `modules/hall-ui/public/goals-render.js:711` |
| `cc5106af4b35` | certain | {…} of {…} criteria satisfied | `modules/hall-ui/public/goals.js:45` |
| `c3d9687e2375` | certain | {…} of {…} shipped | `modules/hall-ui/public/profile.js:647` |
| `f32710d0ef37` | certain | {…} of {…} steps cleared. | `modules/hall-ui/public/hall-render.js:979` |
| `f5e456c3aaf6` | certain | {…} of {…} turned on. Each one, in a line: | `modules/hall-ui/public/settings-specialities.js:152` |
| `60743fe1e40d` | certain | {…} per page | `modules/hall-ui/public/hall-kit.js:74` |
| `771bef3d31b5` | certain | {…} project{…} | `modules/hall-ui/public/fleet.js:39` |
| `154bc518bab4` | certain | {…} proposed | `modules/hall-ui/public/government.js:705` |
| `275f3565c78b` | certain | {…} reset to its default {…} permissions. | `modules/hall-ui/public/government.js:297` |
| `33afba17ee0f` | certain | {…} seeded | `modules/hall-ui/public/roadmap.js:207` |
| `732b4c935e36` | certain | {…} sessions | `modules/hall-ui/public/task.js:504` |
| `e08fa22622f0` | certain | {…} shipped, {…} confirmed, {…} completed, {…} remaining of {…} | `modules/hall-ui/public/roadmap.js:67` |
| `e08fa22622f0` | certain | {…} shipped, {…} confirmed, {…} completed, {…} remaining of {…} | `modules/hall-ui/public/roadmap.js:298` |
| `5d79bba0d667` | certain | {…} task {…} on live work — {…}. Sequence them before two builders collide. | `modules/hall-ui/public/goal-inbox.js:112` |
| `ad27ae9f5433` | certain | {…} tasks · {…} | `modules/hall-ui/public/roadmap.js:423` |
| `955499559f0a` | certain | {…} tokens | `modules/hall-ui/public/sessions.js:170` |
| `8e28c14b106d` | certain | {…} total | `modules/hall-ui/public/roadmap.js:120` |
| `1a8a6267e490` | certain | {…} unfinished task{…} — say what happens to each | `modules/hall-ui/public/goals-render.js:1042` |
| `3ad8f32dd43b` | certain | {…} you have sent | `modules/hall-ui/public/profile-connections.js:146` |
| `2f75f69cdb2f` | certain | {…} {…} changed | `modules/hall-ui/public/profile-crafts.js:218` |
| `8186b562553a` | certain | {…} {…} waiting | `modules/hall-ui/public/work.js:420` |
| `a9216af9b05e` | certain | {…} {…} — how-to | `modules/hall-ui/public/modules.js:383` |
| `0d4016a5531c` | certain | {…} {…}{…} | `modules/hall-ui/public/watch.js:503` |
| `0d4016a5531c` | certain | {…} {…}{…} | `modules/hall-ui/public/work.js:265` |
| `b3757ba3bb46` | certain | {…} · Stored encrypted; never shown again after saving. | `modules/hall-ui/public/settings.js:834` |
| `a6e4ed98fbea` | certain | {…} · revoke it any time under Active sessions. | `modules/hall-ui/public/settings.js:766` |
| `d73256fbc395` | certain | {…} · who votes, and how it {…} | `modules/hall-ui/public/board-room.js:449` |
| `cab2a4296aec` | certain | {…} · {…} · {…}{…} | `modules/hall-ui/public/goal-inbox.js:458` |
| `1ac723849449` | certain | {…} · {…}{…} | `modules/hall-ui/public/sky-interaction.js:33` |
| `ddd2bfc1fb60` | certain | {…} — how to use it | `modules/hall-ui/public/modules.js:385` |
| `085f93f3f775` | certain | {…} — see all standings | `modules/hall-ui/public/hall-render.js:80` |
| `2a2728a4ec4f` | certain | {…}% of tasks complete | `modules/hall-ui/public/roadmap.js:63` |
| `15e545eb3ce2` | certain | {…}, no such task | `modules/hall-ui/public/task.js:1038` |
| `8944d0dcf563` | certain | {…}, on the {…} page, is where you left it. | `modules/hall-ui/public/studio.js:658` |
| `7763e6f28c67` | certain | {…}, on the {…} page, is where you left it. {…} of its {…} lines are yours so far. | `modules/hall-ui/public/studio.js:656` |
| `2f5096e752bf` | certain | {…}. Size is what the ledger paid this thought's descent — a slice of every task that fell out of it, thinning | `modules/hall-ui/public/sky-panel.js:51` |
| `c43050b62297` | certain | {…}/100 complete | `modules/hall-ui/public/idea.js:87` |
| `cbc5a8c686b2` | certain | {…}We store only your GitHub login, avatar, and the work you ship. | `modules/hall-ui/public/hall-render.js:395` |
| `8e8c7da4f7f5` | certain | {…}criteria met · awaiting review | `modules/hall-ui/public/goals-render.js:166` |
| `1e275ee0299c` | certain | {…}s only | `modules/hall-ui/public/government.js:1030` |
| `499916045b19` | certain | {…}{…} asks to join | `modules/hall-ui/public/goal-inbox.js:69` |
| `97e27ab169ae` | certain | {…}{…} session{…} across {…} builder{…}. | `modules/hall-ui/public/sessions.js:338` |
| `3d74668f69e5` | certain | {…}{…} · {…} | `modules/hall-ui/public/task.js:676` |
| `7f79bedecf60` | certain | {…}{…} — open it to see what went | `modules/hall-ui/public/goal-inbox.js:374` |
| `1026fd5f68b7` | certain | · version | `modules/hall-ui/public/modules.js:388` |
| `4a5ff4f662df` | certain | — ${…} of ${…} this month ({…}%). {…} | `modules/hall-ui/public/hall-render.js:520` |
| `a6ae9cbdee30` | certain | — all builders — | `modules/hall-ui/public/builders.js:711` |
| `729d4ce22b99` | certain | — any — | `modules/hall-ui/public/hall-widgets.js:163` |
| `d2c30a1ee74e` | certain | — decide — | `modules/hall-ui/public/goals-render.js:1006` |
| `e31a588bb9e1` | certain | — moved {…}, and the box confirmed it. | `modules/hall-ui/public/deploy.js:392` |
| `417adabd1a00` | certain | — no goal suggested — open the goal board and pick one — | `modules/hall-ui/public/task-detail.js:412` |
| `da9962dc1729` | certain | — or open any diagram fullscreen. | `modules/hall-ui/public/diagrams.html:33` |
| `e5c5e94152b3` | certain | — that's all the tooling you need up front. | `modules/hall-ui/public/hall-render.js:832` |
| `85f1dd2ee732` | certain | — the whole project | `modules/hall-ui/public/goal-map.html:69` |
| `ff7514f48a7b` | certain | — untouched {…}+ days | `modules/hall-ui/public/goal-inbox.js:495` |
| `8f1d0e229725` | certain | — your thinking | `modules/hall-ui/public/thinking.html:72` |
| `d3afa6d6dd9e` | certain | — your words, in your voice. Needed for a note or a follow-up. | `modules/hall-ui/public/studio.js:191` |
| `68b547166d48` | certain | — {…} confirmed {…} can't land yet, so {…} reward is pending (it lands on ship). Rebase + re-ship or release { | `modules/hall-ui/public/hall-render.js:561` |
| `8f2eba6e0da8` | certain | — {…} {…} of work landed between core {…} and {…}{…}: | `modules/hall-ui/public/deploy.js:550` |
| `28fef677706c` | certain | — {…}. The project restarts as part of this, and puts itself back on {…} if the new core does not answer. This | `modules/hall-ui/public/deploy.js:330` |
| `9a1cef2da08d` | certain | …and {…} more goals — | `modules/hall-ui/public/goal-inbox.js:127` |
| `5b9fa7cb4fb0` | certain | …and {…} more waiting — | `modules/hall-ui/public/goal-inbox.js:158` |
| `b797996b2e4f` | certain | …and {…} more, not listed. | `modules/hall-ui/public/deploy.js:548` |
| `9132930284c4` | certain | …and {…} older version{…}, also in this update. | `modules/hall-ui/public/settings-software-update.js:120` |
| `b2a04abfead0` | certain | …{…} more awaiting a nod. | `modules/hall-ui/public/goal-inbox.js:316` |
| `f16717b3e122` | certain | …{…} more awaiting an answer. | `modules/hall-ui/public/goal-inbox.js:396` |
| `616fb9adf3cf` | certain | …{…} more going quiet. | `modules/hall-ui/public/goal-inbox.js:485` |
| `e35f11bdc5d7` | certain | …{…} more open ideas — triage clears them one at a time. | `modules/hall-ui/public/builders.js:895` |
| `5f1d914ad45e` | certain | …{…} more — | `modules/hall-ui/public/goal-inbox.js:561` |
| `de8fa5223aee` | certain | ‹ Prev | `modules/hall-ui/public/hall-kit.js:74` |
| `d4b84b7fbdeb` | certain | ← All goals | `modules/hall-ui/public/goals.html:75` |
| `9159687c73ff` | certain | ← All modules | `modules/hall-ui/public/modules.html:85` |
| `7926e30955d2` | certain | ← Back to goal | `modules/hall-ui/public/goals.html:194` |
| `7926e30955d2` | certain | ← Back to goal | `modules/hall-ui/public/goals.html:205` |
| `7926e30955d2` | certain | ← Back to goal | `modules/hall-ui/public/goals.html:217` |
| `3ad4e941d265` | certain | ← studio | `modules/hall-ui/public/tweak-editor.html:52` |
| `2180e0ecf138` | certain | → no idea # | `modules/hall-ui/public/task-detail.js:583` |
| `d5d76f1c0dfe` | certain | ○ reserved | `modules/hall-ui/public/diagrams.html:44` |
| `97b0773e72a5` | certain | ● LIVE | `modules/hall-ui/public/diagrams.html:42` |
| `946efde0885f` | certain | ⚖ Admitted by {…} | `modules/hall-ui/public/goals-render.js:902` |
| `5d6f38a02386` | certain | ⚖ admitted | `modules/hall-ui/public/goals-render.js:195` |
| `9a4bcd727224` | certain | ⚠ overlaps {…} | `modules/hall-ui/public/task-lib.js:74` |
| `fe81a8973cc2` | certain | ✎ {…} file{…} | `modules/hall-ui/public/goals-render.js:344` |
| `fe81a8973cc2` | certain | ✎ {…} file{…} | `modules/hall-ui/public/work.js:456` |
| `5938da97d113` | certain | ⤍ PLANNED | `modules/hall-ui/public/diagrams.html:43` |
| `65790f65c6f4` | certain | 🔒 Private | `modules/hall-ui/public/goals-render.js:877` |
| `7e1bb38d4777` | certain | 🔒 Request to join | `modules/hall-ui/public/goals-render.js:977` |
| `cce9c199e874` | certain | 🛡 Archon-mediated | `modules/hall-ui/public/goals-render.js:883` |

## `status-dashboard` — 100 strings

| id | conf | text | where |
|---|---|---|---|
| `33aaf5eb47b2` | certain | ${…} of ${…} spent | `modules/status-ui/public/status.js:222` |
| `d31b6094f7ac` | certain | , {{companyTagline}} | `modules/status-ui/public/index.html:356` |
| `2045078fb115` | certain | 90 days ago | `modules/status-ui/public/status.js:477` |
| `e4848e2d9386` | certain | A new portrait is set down each time the city's stones are reshaped. Scroll to see how {{worldName}} has grown | `modules/status-ui/public/index.html:344` |
| `390faeaffb47` | certain | A project | `modules/status-ui/public/explore.js:71` |
| `f4a664041da5` | certain | A shipping container has washed ashore upon the coast south of Athens. About it a new civilization rises. Set  | `modules/status-ui/public/index.html:126` |
| `623d6b7ae6b7` | certain | A true-to-life portrait of {{worldName}} as she stands today, rendered from the city's own stones. | `modules/status-ui/public/index.html:332` |
| `155d14ab692a` | certain | All categories | `modules/status-ui/public/index.html:280` |
| `cb7eae1a30d5` | certain | All sources | `modules/status-ui/public/index.html:274` |
| `a072071b893c` | certain | All time | `modules/status-ui/public/index.html:286` |
| `a072071b893c` | certain | All time | `modules/status-ui/public/index.html:313` |
| `1fb3f6a598cd` | certain | Architects of {{worldName}} | `modules/status-ui/public/index.html:200` |
| `4b16eed738cf` | certain | Attributed to builders: {…} · Shared keep (unattributed): {…} ({…}%). | `modules/status-ui/public/status.js:718` |
| `20a83501bba6` | certain | Avg time per work (min) | `modules/status-ui/public/status.js:1225` |
| `c8959bdc0e59` | certain | Breakdown filtered to {…}: {…} of {…} ({…}% of all spend). | `modules/status-ui/public/status.js:659` |
| `1fe8937399f5` | certain | By order of the Senate | `modules/status-ui/public/index.html:354` |
| `21f644463d57` | certain | Citizens who have set the most stone. | `modules/status-ui/public/index.html:201` |
| `87af953708b3` | certain | Couldn't load projects right now. | `modules/status-ui/public/explore.html:109` |
| `3aa071ef1142` | certain | Cross into the city → | `modules/status-ui/public/index.html:128` |
| `f151456aedc1` | certain | Explore — projects on the map | `modules/status-ui/public/explore.html:6` |
| `f151456aedc1` | certain | Explore — projects on the map | `modules/status-ui/public/explore.html:6` |
| `14d6b38bc659` | certain | Filter inscriptions by date range | `modules/status-ui/public/index.html:309` |
| `194f07002413` | certain | Filter spend by category | `modules/status-ui/public/index.html:279` |
| `183993d780be` | certain | Filter spend by source | `modules/status-ui/public/index.html:273` |
| `feeee5571be7` | certain | Filter spend by time window | `modules/status-ui/public/index.html:285` |
| `e8e3e5f24055` | certain | Filter the spend breakdown | `modules/status-ui/public/index.html:270` |
| `9d046b3a8d87` | certain | History accumulating — returns after the first day of watch. | `modules/status-ui/public/status.js:486` |
| `b8e9f90e225c` | certain | How the city's craft is changing — works shipped and time per work over the last ninety days. The whole, not t | `modules/status-ui/public/index.html:214` |
| `41cc7f5ec97e` | certain | Last 30 days | `modules/status-ui/public/index.html:288` |
| `41cc7f5ec97e` | certain | Last 30 days | `modules/status-ui/public/index.html:311` |
| `b3bb6b729d30` | certain | Last 7 days | `modules/status-ui/public/index.html:287` |
| `b3bb6b729d30` | certain | Last 7 days | `modules/status-ui/public/index.html:310` |
| `726d3470f7a0` | certain | Last 90 days | `modules/status-ui/public/index.html:289` |
| `726d3470f7a0` | certain | Last 90 days | `modules/status-ui/public/index.html:312` |
| `2634481c0143` | certain | Lately Inscribed | `modules/status-ui/public/index.html:304` |
| `f445a6183300` | certain | Lately Inscribed pages | `modules/status-ui/public/index.html:320` |
| `dc9eab0a02e2` | certain | Newest entries set down upon the ledger. | `modules/status-ui/public/index.html:305` |
| `9ef3aaa7b441` | certain | Next page | `modules/status-ui/public/index.html:323` |
| `37b171a6195a` | certain | No architects yet — be the first to lay a stone. | `modules/status-ui/public/index.html:205` |
| `7816fbe0add8` | certain | No builders yet — be the first. | `modules/status-ui/public/status.js:1119` |
| `0b097f051d6f` | certain | No endeavors underway just now. | `modules/status-ui/public/status.js:516` |
| `ed9b06f79234` | certain | No projects on the map yet — check back soon. | `modules/status-ui/public/explore.html:108` |
| `4b1a11bfdf10` | certain | No works yet inscribed in this window. | `modules/status-ui/public/status.js:947` |
| `7a8afe641683` | certain | No works yet inscribed. | `modules/status-ui/public/index.html:318` |
| `3e8205a358d9` | certain | No {…} yet attributed to a hand. | `modules/status-ui/public/status.js:746` |
| `c9efa62c36e7` | certain | No {…} yet spent. | `modules/status-ui/public/status.js:684` |
| `2df94faddc8c` | certain | Not enough shipped works yet to draw the curve. | `modules/status-ui/public/index.html:224` |
| `9d8692476139` | certain | Previous page | `modules/status-ui/public/index.html:321` |
| `f1b103f87df2` | certain | Projects on the map, and how each one stands on it. | `modules/status-ui/public/explore.html:105` |
| `48473324e839` | certain | Sections of the ledger | `modules/status-ui/public/index.html:144` |
| `81cb441627b8` | certain | Show history of earlier portraits | `modules/status-ui/public/index.html:342` |
| `abd2ce869517` | certain | Something is here. Its name, and everything else about it, stay with its owner. | `modules/status-ui/public/explore.js:74` |
| `0cc023b5f470` | certain | Split by hand — {{currency}} spent by each builder at the workshop. | `modules/status-ui/public/index.html:295` |
| `fddc39dcf1eb` | certain | Tablet being consulted… | `modules/status-ui/public/index.html:130` |
| `8f86e1c9ad44` | certain | Text size | `modules/status-ui/public/index.html:18` |
| `385a347d1a7f` | certain | The City At A Glance | `modules/status-ui/public/index.html:159` |
| `e4073b17b693` | certain | The Foundry | `modules/status-ui/public/index.html:213` |
| `acdf97805931` | certain | The Public Ledger of the City's Making | `modules/status-ui/public/index.html:125` |
| `0dd5f86e182c` | certain | The Treasury | `modules/status-ui/public/index.html:244` |
| `5c7f268ea647` | certain | The Watch | `modules/status-ui/public/index.html:187` |
| `3e465b62cea8` | certain | The World | `modules/status-ui/public/index.html:331` |
| `16f6b8dcd3ec` | certain | The cartographers are still at their survey… | `modules/status-ui/public/index.html:336` |
| `308949fbd4a0` | certain | The chart above always shows the whole project; the filters below slice the breakdown. | `modules/status-ui/public/index.html:269` |
| `3890ae78799a` | certain | The endeavours now underway in the city. | `modules/status-ui/public/index.html:232` |
| `a40c05981183` | certain | The line of value above the line of spend means the city is wrought richer than it is dear. | `modules/status-ui/public/index.html:269` |
| `1d55bc17185e` | certain | The masons are at their tools… | `modules/status-ui/public/index.html:236` |
| `5e9930b49abe` | certain | The sentinels are taking their positions… | `modules/status-ui/public/index.html:192` |
| `3d63946be730` | certain | The sentinels have not yet taken their posts. | `modules/status-ui/public/status.js:377` |
| `d1add9aa4db0` | certain | The standing of each pillar — whether it holds or has fallen. | `modules/status-ui/public/index.html:188` |
| `c1ab82f376ec` | certain | The work, in brief | `modules/status-ui/public/status.js:594` |
| `6cc811f31b3a` | certain | Works in Progress | `modules/status-ui/public/index.html:231` |
| `4abea0f631eb` | certain | Works shipped / day | `modules/status-ui/public/status.js:1224` |
| `b2f58817e34e` | certain | World snapshots over time | `modules/status-ui/public/index.html:343` |
| `ebdc5ecf315c` | certain | avg time / work | `modules/status-ui/public/index.html:220` |
| `774e102fc137` | certain | city's standing | `modules/status-ui/public/index.html:163` |
| `2ce99fa81342` | certain | cumulative {{currency}} spent against cumulative value wrought, day by day | `modules/status-ui/public/index.html:267` |
| `c2db58231e50` | certain | hands at the forge | `modules/status-ui/public/index.html:219` |
| `20d61cef9be6` | certain | is the shared keep: infrastructure and domains the whole city pays for, plus the early days before each hand c | `modules/status-ui/public/index.html:295` |
| `9b019d632d3e` | certain | later page › | `modules/status-ui/public/index.html:323` |
| `5b653a87c53c` | certain | of the purse | `modules/status-ui/public/index.html:263` |
| `c10ffea69d1c` | certain | of the year's purse spent | `modules/status-ui/public/index.html:171` |
| `89ef611c7d37` | certain | page 1 of 1 | `modules/status-ui/public/index.html:322` |
| `4a00bdbfd9be` | certain | page {…} of {…} | `modules/status-ui/public/status.js:1012` |
| `1d0fbe3e5927` | certain | passed the inspector, last 7 days | `modules/status-ui/public/index.html:178` |
| `c1e3c2212207` | certain | tablet last consulted at {…} | `modules/status-ui/public/status.js:1169` |
| `fefb0130c7ae` | certain | value wrought | `modules/status-ui/public/index.html:255` |
| `b97f429c33fe` | certain | works shipped (90d) | `modules/status-ui/public/index.html:218` |
| `71a303e1ba09` | certain | works wrought, last 7 days | `modules/status-ui/public/index.html:167` |
| `24ea04f49b3d` | certain | year's purse | `modules/status-ui/public/index.html:259` |
| `4c45bbf03088` | certain | {{Currency}} are wrought by the lawmen's review; redemption awaits their seal. | `modules/status-ui/public/index.html:357` |
| `89aa84ef4595` | certain | {{Currency}} spent, against the value wrought. | `modules/status-ui/public/index.html:245` |
| `35872b9ecc49` | certain | {{currency}} spent | `modules/status-ui/public/index.html:251` |
| `e87f28d25342` | certain | {{worldName}} is the work of | `modules/status-ui/public/index.html:356` |
| `7a15e19adbd2` | certain | {{worldName}} — the public ledger | `modules/status-ui/public/index.html:6` |
| `7a15e19adbd2` | certain | {{worldName}} — the public ledger | `modules/status-ui/public/index.html:6` |
| `12e0efd49a32` | certain | {…} goal{…} · {…} achieved | `modules/status-ui/public/status.js:582` |
| `78c552726882` | certain | {…}% complete · weighted by priority | `modules/status-ui/public/status.js:571` |
| `3b340d722976` | certain | {…}: no data | `modules/status-ui/public/status.js:458` |
| `7667eb552781` | certain | {…}: {…}% ({…}/{…} checks) | `modules/status-ui/public/status.js:468` |
| `6d0d64f10bd9` | certain | ‹ earlier page | `modules/status-ui/public/index.html:321` |

## `landing` — 697 strings

| id | conf | text | where |
|---|---|---|---|
| `f342820f63c4` | certain | (a sentence or two) | `modules/public-landing/public/projects.html:1837` |
| `76061f79311d` | certain | (chrome, frost, gold, obsidian), a | `modules/public-landing/public/projects.html:1264` |
| `218c8d7463e6` | certain | (the blob, the bongo pair, the bead), a | `modules/public-landing/public/projects.html:1264` |
| `6e4f596f58a5` | certain | (tinted: the colour replaces the material’s own; washed: the material lit by the colour; plain: as it is) and  | `modules/public-landing/public/projects.html:1264` |
| `a8cbbd639329` | certain | (user or org) | `modules/public-landing/public/projects.html:1950` |
| `07f422cbdb7e` | certain | ) and capture-resistant by design. | `modules/public-landing/public/projects.html:1391` |
| `07f422cbdb7e` | certain | ) and capture-resistant by design. | `modules/public-landing/public/projects.html:1790` |
| `547622a4ccf8` | certain | , and when. | `modules/public-landing/public/projects.html:876` |
| `b104d5b32b22` | certain | , one of the world’s five. Until you choose, the platform picks one for it. Saving here changes nothing on the | `modules/public-landing/public/projects.html:1264` |
| `98c8eeb65e17` | certain | 0 of 280 characters | `modules/public-landing/public/account.html:165` |
| `86698dbf6021` | certain | 0 of 7 | `modules/public-landing/public/projects.html:1766` |
| `22825067f4c5` | certain | 1 builder | `modules/public-landing/public/index.html:750` |
| `22825067f4c5` | certain | 1 builder | `modules/public-landing/public/index.html:755` |
| `14277fea260d` | certain | 1,111 of 1,561 shipped on V1 | `modules/public-landing/public/index.html:799` |
| `d4d07fb07cc8` | certain | 12 builder-hours in total. When it runs out you are asked whether to keep your planet; your work is never stop | `modules/public-landing/public/projects.html:1495` |
| `6f2bebe7f121` | certain | 13 to 15 | `modules/public-landing/public/projects.html:1615` |
| `0134c20f050c` | certain | 16 to 17 | `modules/public-landing/public/projects.html:1616` |
| `bd8e114579ad` | certain | 18 and over | `modules/public-landing/public/projects.html:1617` |
| `8525371bf56a` | certain | 3 people × 4 hours = 12 builder-hours. | `modules/public-landing/public/projects.html:1476` |
| `d0cbde998b8c` | certain | 4 hours each | `modules/public-landing/public/projects.html:1495` |
| `603c51615454` | certain | A co-op farming game where the seasons never repeat. | `modules/public-landing/public/projects.html:1585` |
| `603c51615454` | certain | A co-op farming game where the seasons never repeat. | `modules/public-landing/public/projects.html:1838` |
| `68c974604d73` | certain | A demo nobody keeps goes offline 30 days after it starts. You are told before, and it can be brought back. | `modules/public-landing/public/projects.html:1510` |
| `524e46d2f113` | certain | A growth guess | `modules/public-landing/public/projects.html:1677` |
| `545c82e99696` | certain | A laddered beat progresses all tasks. | `modules/public-landing/public/index.html:766` |
| `c1a1aacad3cd` | certain | A new app, or one you already run | `modules/public-landing/public/projects.html:2055` |
| `d974dc8b9ab9` | certain | A new, empty | `modules/public-landing/public/projects.html:1908` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/account.html:250` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/contact.html:71` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/index.html:903` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/privacy.html:80` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/projects.html:2243` |
| `afe83bbbd0d4` | certain | A non-profit, capture-resistant commons. | `modules/public-landing/public/terms.html:85` |
| `c209b53693c0` | certain | A note for the owner (optional) — what you’d like to work on, who you are. | `modules/public-landing/public/projects.html:948` |
| `2363998aa2be` | certain | A pair of bongo drums | `modules/public-landing/public/projects.html:2172` |
| `407982c3d4ff` | certain | A project as a codebase, regardless of function. | `modules/public-landing/public/index.html:765` |
| `c3504a900b0f` | certain | A project stood up from the hub runs on the platform's servers at your request. Any cost is shown before you c | `modules/public-landing/public/terms.html:61` |
| `6cb796f01882` | certain | A project you create | `modules/public-landing/public/privacy.html:57` |
| `4ef3b1f36577` | certain | A shared reading list for our team: everyone adds books, we vote, and the winner is next month’s read. | `modules/public-landing/public/projects.html:1472` |
| `f8ab957b5d52` | certain | A single contributor. | `modules/public-landing/public/projects.html:1665` |
| `bc0a81fdaa8a` | certain | A small team | `modules/public-landing/public/projects.html:1843` |
| `4e41bba6ea93` | certain | A small, time-boxed project to learn the platform by doing. Everyone uses their own AI plan. | `modules/public-landing/public/projects.html:1454` |
| `3369c02bd3bf` | certain | A stake in the entity. | `modules/public-landing/public/projects.html:1697` |
| `3cc8f26a3e24` | certain | A team | `modules/public-landing/public/projects.html:1666` |
| `8f00fc6a6483` | certain | A team, now or soon. | `modules/public-landing/public/projects.html:1666` |
| `5434b502f16b` | certain | A · All managed | `modules/public-landing/public/projects.html:1707` |
| `632b49062d74` | certain | AI agents claim tasks and ship the code. You set the direction and the gates. | `modules/public-landing/public/index.html:725` |
| `af8d9d8b96b1` | certain | AI usage | `modules/public-landing/public/projects.html:1500` |
| `245d6bdb5100` | certain | About your data | `modules/public-landing/public/contact.html:58` |
| `9b02ec8a2e21` | certain | Accounts from before these terms. | `modules/public-landing/public/terms.html:71` |
| `ccc1cf1babbb` | certain | Add a note (optional) | `modules/public-landing/public/projects.html:947` |
| `c684f20e82de` | certain | Adjust month three | `modules/public-landing/public/projects.html:1684` |
| `e7f2a4b93816` | certain | Adopt a repo I have | `modules/public-landing/public/projects.html:1912` |
| `d07902ff5ee1` | certain | Adopting never overwrites your files: you get a conflict pre-flight first, nothing is written until you accept | `modules/public-landing/public/projects.html:1918` |
| `87d6cfa2b04d` | certain | All managed for you | `modules/public-landing/public/projects.html:1498` |
| `6308ff336f73` | certain | Allow repo access | `modules/public-landing/public/projects.html:1927` |
| `cb168be00a43` | certain | An open community | `modules/public-landing/public/projects.html:1844` |
| `54bf9a39d47f` | certain | And one more | `modules/public-landing/public/projects.html:1506` |
| `a1000bb68acb` | certain | Answer a few questions about your project, choose where its code and its app live, and it stands up as yours. | `modules/public-landing/public/projects.html:1534` |
| `bae3f4298d72` | certain | Anyone can join | `modules/public-landing/public/projects.html:1146` |
| `2620b4583b20` | certain | Anyone can open your profile page and find you by name. | `modules/public-landing/public/account.html:209` |
| `b2259f896807` | certain | Anything you want to make | `modules/public-landing/public/projects.html:1409` |
| `766def944c53` | certain | Apply to join | `modules/public-landing/public/projects.html:1146` |
| `b99ea6917ce9` | certain | At present, Bongos projects are all held by Verro Labs or its pilot clients. | `modules/public-landing/public/index.html:740` |
| `b7aeb15f09d2` | certain | Auto-fill from my account | `modules/public-landing/public/projects.html:1565` |
| `ce964e23bf8b` | certain | B · Hybrid | `modules/public-landing/public/projects.html:1708` |
| `b7ac7fbd7209` | certain | Back to your projects | `modules/public-landing/public/projects.html:996` |
| `b64d73445655` | certain | Because of the sensitive nature of this platform and its projects, we highly recommend you review the legal te | `modules/public-landing/public/projects.html:1411` |
| `087734f49364` | certain | Begin planet creation | `modules/public-landing/public/projects.html:1440` |
| `4782de01c86b` | certain | Bongos Managed. | `modules/public-landing/public/index.html:867` |
| `998fbc46a927` | certain | Build as a game or a learning experience. | `modules/public-landing/public/index.html:883` |
| `3aaad242a24c` | certain | Build command | `modules/public-landing/public/projects.html:2066` |
| `0f1ec6cf9dfa` | certain | Build equity in multiple projects. | `modules/public-landing/public/index.html:881` |
| `0379baef7921` | certain | Builder guild access | `modules/public-landing/public/projects.html:1721` |
| `9f530bc7864b` | certain | Builders at the start, you included | `modules/public-landing/public/projects.html:1669` |
| `0bcc62bf4bdc` | certain | Builders under 18 | `modules/public-landing/public/projects.html:1608` |
| `90a128c97eae` | certain | Builders' hall | `modules/public-landing/public/account.html:250` |
| `90a128c97eae` | certain | Builders' hall | `modules/public-landing/public/index.html:909` |
| `90a128c97eae` | certain | Builders' hall | `modules/public-landing/public/projects.html:814` |
| `90a128c97eae` | certain | Builders' hall | `modules/public-landing/public/projects.html:814` |
| `90a128c97eae` | certain | Builders' hall | `modules/public-landing/public/projects.html:2243` |
| `16bc370da814` | certain | Building Digitally, | `modules/public-landing/public/index.html:723` |
| `1e3de399e779` | certain | Built by Verro Labs, Cloud Bongos is our way of making AI co-building usable by entire project groups, whether | `modules/public-landing/public/index.html:850` |
| `ee7d8b276a29` | certain | Built by agents, on | `modules/public-landing/public/projects.html:2243` |
| `bd315dd71ea7` | certain | Built by agents, on Cloud&nbsp;Bongos. | `modules/public-landing/public/account.html:250` |
| `bd315dd71ea7` | certain | Built by agents, on Cloud&nbsp;Bongos. | `modules/public-landing/public/contact.html:71` |
| `bd315dd71ea7` | certain | Built by agents, on Cloud&nbsp;Bongos. | `modules/public-landing/public/index.html:903` |
| `bd315dd71ea7` | certain | Built by agents, on Cloud&nbsp;Bongos. | `modules/public-landing/public/privacy.html:80` |
| `bd315dd71ea7` | certain | Built by agents, on Cloud&nbsp;Bongos. | `modules/public-landing/public/terms.html:85` |
| `78fd8d18ba64` | certain | Built on Cloud Bongos | `modules/public-landing/public/index.html:739` |
| `8639cc7fcada` | certain | Buttons here ask the platform to act; each row reports only what was verified, and when. A standup keeps going | `modules/public-landing/public/projects.html:921` |
| `101339c676b4` | certain | Buy microtransaction packages of code modules on our marketplace. | `modules/public-landing/public/index.html:869` |
| `aae97f9d46e9` | certain | By GitHub username. The invite is sent from your project’s own hall — that is the invite that lets them in — a | `modules/public-landing/public/projects.html:1239` |
| `59ff75cae5aa` | certain | C · Local or internal | `modules/public-landing/public/projects.html:1709` |
| `50d493f08964` | certain | Can find me | `modules/public-landing/public/account.html:216` |
| `48d721eb2ed7` | certain | Can’t find me | `modules/public-landing/public/account.html:217` |
| `1e0354f3ac58` | certain | Carry it over | `modules/public-landing/public/projects.html:1054` |
| `8bd986ac83bd` | certain | Cash for work | `modules/public-landing/public/projects.html:1696` |
| `6fc00a88741a` | certain | Check key | `modules/public-landing/public/projects.html:2047` |
| `44510c66e7c4` | certain | Checking the repository on GitHub… | `modules/public-landing/public/projects.html:1112` |
| `c445e03a55f6` | certain | Choose from the suite, and keep your data on your own machines. | `modules/public-landing/public/projects.html:1709` |
| `7b20a72415ea` | certain | Choose what you want from the full suite. | `modules/public-landing/public/projects.html:1708` |
| `775763c69e5e` | certain | Claim a task and ship it | `modules/public-landing/public/projects.html:1479` |
| `422a8dd2d452` | certain | Clear the filters | `modules/public-landing/public/projects.html:913` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:663` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:765` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:810` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1365` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1390` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1410` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1584` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1704` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1738` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1789` |
| `eeda19200aeb` | certain | Cloud Bongos | `modules/public-landing/public/projects.html:1913` |
| `6f3d0df5b51c` | certain | Code files | `modules/public-landing/public/projects.html:1579` |
| `9f5307303ddb` | certain | Code files is the main one | `modules/public-landing/public/projects.html:1579` |
| `a72ec8a2a3ff` | certain | Colours for light and dark mode, and a logo, so builders who work in several projects always know which hall t | `modules/public-landing/public/projects.html:2097` |
| `f0bcc3a2ff77` | certain | Company creation | `modules/public-landing/public/projects.html:1723` |
| `14501a76de15` | certain | Connect Render | `modules/public-landing/public/projects.html:1072` |
| `14501a76de15` | certain | Connect Render | `modules/public-landing/public/projects.html:1075` |
| `6603d4504ebd` | certain | Contact us | `modules/public-landing/public/projects.html:1742` |
| `3596c03573ce` | certain | Continue → | `modules/public-landing/public/projects.html:1749` |
| `3596c03573ce` | certain | Continue → | `modules/public-landing/public/projects.html:1785` |
| `15104deb6b84` | certain | Contributors at the start | `modules/public-landing/public/projects.html:1669` |
| `1a8c7472a7b0` | certain | Create a builder guild | `modules/public-landing/public/projects.html:1722` |
| `37aa0c0fbf3d` | certain | Create a key in Render | `modules/public-landing/public/projects.html:2042` |
| `21db11ef932e` | certain | Create a project | `modules/public-landing/public/projects.html:1364` |
| `330038e92a44` | certain | Create my project | `modules/public-landing/public/projects.html:2115` |
| `85e879b4d4ab` | certain | Create the project now. You can choose where your app runs afterwards. | `modules/public-landing/public/projects.html:2037` |
| `c01533093b42` | certain | Create your first project | `modules/public-landing/public/projects.html:918` |
| `fe34dacebb27` | certain | Create your planet | `modules/public-landing/public/projects.html:1533` |
| `b07e75a05f48` | certain | Creating the repo yourself on GitHub? Public or private is your choice there — both work here, and we never ch | `modules/public-landing/public/projects.html:1958` |
| `3aeefb044b9f` | certain | Creation steps | `modules/public-landing/public/projects.html:1347` |
| `8c05a4d2ddac` | certain | D · Open source, local | `modules/public-landing/public/projects.html:1710` |
| `6d3b3fa8aea1` | certain | Database plan | `modules/public-landing/public/projects.html:2078` |
| `7aba7394c6d6` | certain | Decide later | `modules/public-landing/public/projects.html:2036` |
| `e0ca2fee29d8` | certain | Demo planet | `modules/public-landing/public/projects.html:1048` |
| `6d9150b340d4` | certain | Digital files | `modules/public-landing/public/projects.html:1580` |
| `b8a8011d4656` | certain | Digital files is the main one | `modules/public-landing/public/projects.html:1580` |
| `86e7699c0737` | certain | Disconnect from Bongos entirely | `modules/public-landing/public/projects.html:1315` |
| `86e7699c0737` | certain | Disconnect from Bongos entirely | `modules/public-landing/public/projects.html:1323` |
| `97509672c5cc` | certain | Display name | `modules/public-landing/public/account.html:161` |
| `5c04c361eb9d` | certain | Division of a corporation | `modules/public-landing/public/projects.html:1641` |
| `2f12266c6e37` | certain | Docker — use my repository’s Dockerfile | `modules/public-landing/public/projects.html:2063` |
| `47d1558b17a3` | certain | Domain you own | `modules/public-landing/public/projects.html:1998` |
| `8d812912c392` | certain | Don't use {{productName}} to break the law, to attack this site or other people's projects, to mine, spam or o | `modules/public-landing/public/terms.html:74` |
| `924762da2116` | certain | Don’t know yet | `modules/public-landing/public/projects.html:1631` |
| `d919980d2ca5` | certain | Download our core code and protocols, and build instantly with your team. | `modules/public-landing/public/index.html:865` |
| `18b6b56edc93` | certain | Each sign-in creates a session: a random token, whether it came from the browser or the command line, the brow | `modules/public-landing/public/privacy.html:54` |
| `caa3f69db725` | certain | Each young builder’s guardian signs for them, and their payouts go to an account the guardian controls. These  | `modules/public-landing/public/projects.html:1619` |
| `9a4a940d2a56` | certain | Emersonian Circles | `modules/public-landing/public/index.html:754` |
| `9150fa905ba4` | certain | Enough for a small version. Trim it to one shared list, voting and a winner reveal; accounts and notifications | `modules/public-landing/public/projects.html:1476` |
| `4cefa0096c53` | certain | Entertainment, learning, experience, volunteering. | `modules/public-landing/public/projects.html:1695` |
| `af5ca714d375` | certain | Equity issuance, business filing, and builder compensation. | `modules/public-landing/public/index.html:872` |
| `f7678131cd40` | certain | Equity or shares | `modules/public-landing/public/projects.html:1697` |
| `ca61755eef01` | certain | Erased for good: | `modules/public-landing/public/projects.html:1327` |
| `78611d18f54b` | certain | Every part of this — what is stored, where, and for how long — is public. This site runs Cloud Bongos, free so | `modules/public-landing/public/privacy.html:75` |
| `069634b92263` | certain | Every project gets one on this platform, at its own handle. You can point a domain you already own at it inste | `modules/public-landing/public/projects.html:1101` |
| `b1cf8460ad34` | certain | Every project is a real GitHub repository that you own. Start from a clean slate, or bring a repo you already  | `modules/public-landing/public/projects.html:1900` |
| `71b0ef2552c4` | certain | Every project you own, in one place — its live status, its address, and the controls that matter. Sign in with | `modules/public-landing/public/projects.html:883` |
| `478bc7f0e492` | certain | Every project you own: what it is, whether it is answering, and the controls that matter. Each row says what t | `modules/public-landing/public/projects.html:875` |
| `ad1e4b2464cb` | certain | Everyone building is an adult. | `modules/public-landing/public/projects.html:1609` |
| `aef38c31f1f3` | certain | Everyone uses their own AI plan | `modules/public-landing/public/projects.html:1500` |
| `1b5a6cfc494c` | certain | Example World | `modules/public-landing/public/index.html:744` |
| `70e3e447cf7c` | certain | Expert consulting | `modules/public-landing/public/projects.html:1724` |
| `7c8dcf228e70` | certain | Extras for this project | `modules/public-landing/public/projects.html:1873` |
| `2585087f4873` | certain | Fair use | `modules/public-landing/public/terms.html:73` |
| `0697fa588e3a` | certain | Fill it in myself | `modules/public-landing/public/projects.html:1566` |
| `fec69b6c7458` | certain | Filter by state | `modules/public-landing/public/projects.html:905` |
| `0208e4bbba9c` | certain | Find a project | `modules/public-landing/public/index.html:895` |
| `0208e4bbba9c` | certain | Find a project | `modules/public-landing/public/projects.html:676` |
| `483a7eff25f2` | certain | Find a project to join | `modules/public-landing/public/index.html:729` |
| `903f76325cf6` | certain | First read | `modules/public-landing/public/projects.html:1475` |
| `0a0667aea2db` | certain | Footer doors before launch: privacy, terms and contact pages linked from the landing page and the hub | `modules/public-landing/public/index.html:829` |
| `2e09492f49d8` | certain | For Cloud Bongos itself — the platform these projects run on — the same two doors apply, on this site. | `modules/public-landing/public/contact.html:66` |
| `f510ba460300` | certain | For builders | `modules/public-landing/public/index.html:878` |
| `dbced351ca0d` | certain | For founders | `modules/public-landing/public/index.html:862` |
| `6007218fd3d9` | certain | For-profit company | `modules/public-landing/public/projects.html:1640` |
| `655cfdd22c8d` | certain | Found a way in? Please don't put the details in a public issue. Reach the owner through the hall, or open an i | `modules/public-landing/public/contact.html:62` |
| `aab2b51efeab` | certain | Free while we find our feet. Your project’s repo and server are yours — | `modules/public-landing/public/projects.html:1389` |
| `aab2b51efeab` | certain | Free while we find our feet. Your project’s repo and server are yours — | `modules/public-landing/public/projects.html:1788` |
| `0808df6e434c` | certain | From your settings you can hide your statistics, drop out of the recruiting directory, or make your account pr | `modules/public-landing/public/terms.html:69` |
| `255bc1ce35eb` | certain | Full access | `modules/public-landing/public/projects.html:1617` |
| `a1c52728defc` | certain | Future profits or payouts | `modules/public-landing/public/projects.html:1698` |
| `8bb1f00b1558` | certain | Get access to our advanced project presets and module packages. | `modules/public-landing/public/index.html:871` |
| `98eb6344d39e` | certain | GitHub owner | `modules/public-landing/public/projects.html:1950` |
| `a5257c88eb07` | certain | GitHub username | `modules/public-landing/public/projects.html:1241` |
| `a5257c88eb07` | certain | GitHub username | `modules/public-landing/public/projects.html:1242` |
| `a5257c88eb07` | certain | GitHub username | `modules/public-landing/public/projects.html:2144` |
| `a5257c88eb07` | certain | GitHub username | `modules/public-landing/public/projects.html:2145` |
| `b9e691814b98` | certain | Give it a look | `modules/public-landing/public/projects.html:2096` |
| `4995791c6449` | certain | Go to the hall | `modules/public-landing/public/contact.html:56` |
| `41778f67b4c9` | certain | Have us handle your hosting. | `modules/public-landing/public/index.html:870` |
| `ccd4861996eb` | certain | Hide it | `modules/public-landing/public/account.html:240` |
| `978da2e651bd` | certain | Hosted projects | `modules/public-landing/public/terms.html:60` |
| `980106c03cfe` | certain | Hours each | `modules/public-landing/public/projects.html:1463` |
| `3dad9ceda105` | certain | How long, and how to leave | `modules/public-landing/public/privacy.html:69` |
| `206352545e56` | certain | How many people | `modules/public-landing/public/projects.html:1662` |
| `97c0329fc07b` | certain | How much is run for you | `modules/public-landing/public/projects.html:1706` |
| `d2fef2902932` | certain | How much should | `modules/public-landing/public/projects.html:1704` |
| `485c565b5745` | certain | How people join | `modules/public-landing/public/projects.html:1142` |
| `4b542b000afa` | certain | How this project is drawn: on the sky, in your list, at the top of this page and on its card. A planet is a | `modules/public-landing/public/projects.html:1264` |
| `9d76a5ea4fd9` | certain | How to begin | `modules/public-landing/public/projects.html:1438` |
| `121839282e1e` | certain | How to start | `modules/public-landing/public/projects.html:1564` |
| `343f574026a8` | certain | How will builders | `modules/public-landing/public/projects.html:1692` |
| `ef36c54b8af9` | certain | How will contributors | `modules/public-landing/public/projects.html:1692` |
| `a86a02b0ded9` | certain | How your project’s own hall looks: its colours in light and dark mode, whether its dark mode takes a tint of y | `modules/public-landing/public/projects.html:1294` |
| `4b4b42fbaa21` | certain | I already have a legal entity | `modules/public-landing/public/projects.html:1633` |
| `b5c45051385d` | certain | I can sign legally, or can get a signature, for the use of this platform, and I acknowledge the terms and cond | `modules/public-landing/public/projects.html:1415` |
| `cc44a5cbdbaa` | certain | If that sounds like too much for now, try our demo system. Otherwise, proceed with planet initiation :) | `modules/public-landing/public/projects.html:1436` |
| `9f31eaed8252` | certain | If you grant repository access while creating a project, that permission is used to create or adopt your repos | `modules/public-landing/public/privacy.html:55` |
| `d37e2fbde8c6` | certain | If your account already existed when this version took effect, the platform accepted it on your behalf, rather | `modules/public-landing/public/terms.html:71` |
| `607551ae732b` | certain | Invite a builder | `modules/public-landing/public/projects.html:1237` |
| `20786b02f47a` | certain | Invite builders | `modules/public-landing/public/projects.html:2141` |
| `3f2e43c432aa` | certain | Invite by GitHub handle | `modules/public-landing/public/projects.html:1503` |
| `a1256030d879` | certain | Invite only | `modules/public-landing/public/projects.html:1146` |
| `d0b9fd71a284` | certain | Is your planet new, | `modules/public-landing/public/projects.html:1572` |
| `feaba7cb0970` | certain | It becomes a real project: its settings, team and work stay as they are, and the demo’s time limit and 30-day  | `modules/public-landing/public/projects.html:1055` |
| `1f5d4b500966` | certain | It is provided as it is, without warranty of any kind, as its licence — the AGPL-3.0 — says. | `modules/public-landing/public/terms.html:50` |
| `43a874f27956` | certain | Its address | `modules/public-landing/public/projects.html:1097` |
| `cff8279a62e6` | certain | Its address in the sky | `modules/public-landing/public/projects.html:1985` |
| `639cb136cd20` | certain | Its address, its repository, what the platform last | `modules/public-landing/public/projects.html:979` |
| `c30fde6c0be9` | certain | Its card | `modules/public-landing/public/projects.html:1272` |
| `7ad12a8a0b97` | certain | Its environment variables | `modules/public-landing/public/projects.html:1218` |
| `218224e0007c` | certain | Its extras | `modules/public-landing/public/projects.html:1203` |
| `e8c62e287ab5` | certain | Its kind | `modules/public-landing/public/projects.html:1183` |
| `1b9db3c80b46` | certain | Its look | `modules/public-landing/public/projects.html:1286` |
| `1fef507d3c18` | certain | Its planet | `modules/public-landing/public/projects.html:1260` |
| `3ef67dbfb2a7` | certain | It’s a demo, for learning. | `modules/public-landing/public/projects.html:1497` |
| `1ccb288a1db6` | certain | Join a project | `modules/public-landing/public/projects.html:940` |
| `da59dc2c668d` | certain | Just me | `modules/public-landing/public/projects.html:1842` |
| `bceb47546714` | certain | Just me for now | `modules/public-landing/public/projects.html:1630` |
| `18a87a580131` | certain | Just me, building solo. | `modules/public-landing/public/projects.html:1665` |
| `1ff18e6db28b` | certain | Just the free core. Build on your own machines and pay only for what you add. | `modules/public-landing/public/projects.html:1710` |
| `b20ca082ee3c` | certain | Keep it as a demo | `modules/public-landing/public/projects.html:1058` |
| `d7963e943bf2` | certain | Keep your planet? | `modules/public-landing/public/projects.html:1051` |
| `65ec327451c0` | certain | Labor payment and HR | `modules/public-landing/public/projects.html:1717` |
| `376b549bf7c8` | certain | Landing composition round: three versions of the approved world | `modules/public-landing/public/index.html:805` |
| `8dad7d9edb99` | certain | Leave it as it is: a finished demo you can come back to until it goes offline. | `modules/public-landing/public/projects.html:1059` |
| `07a4c3686414` | certain | Locked to one agent | `modules/public-landing/public/index.html:771` |
| `5ceffa7b9d7e` | certain | Lowercase letters, numbers and hyphens, up to 39. You can change it once a week, and your old handle keeps lea | `modules/public-landing/public/account.html:191` |
| `34a7872cc0f6` | certain | Module marketplace: buy | `modules/public-landing/public/projects.html:1719` |
| `b34c8d4cc6d7` | certain | Module marketplace: sell | `modules/public-landing/public/projects.html:1720` |
| `80021c40079a` | certain | Monarchy / BDFL | `modules/public-landing/public/projects.html:1496` |
| `1a102ac4f608` | certain | Month 1 | `modules/public-landing/public/projects.html:1680` |
| `41739d8c4d5c` | certain | Month 2 | `modules/public-landing/public/projects.html:1681` |
| `7986ca8d79d6` | certain | Month 3 | `modules/public-landing/public/projects.html:1682` |
| `4c5e09459054` | certain | My app needs a database (Render Postgres) | `modules/public-landing/public/projects.html:2076` |
| `19d026e1511d` | certain | My project has already been started. | `modules/public-landing/public/projects.html:1575` |
| `4a167ef6e515` | certain | My projects | `modules/public-landing/public/account.html:125` |
| `4a167ef6e515` | certain | My projects | `modules/public-landing/public/index.html:702` |
| `4a167ef6e515` | certain | My projects | `modules/public-landing/public/projects.html:723` |
| `cdb2568510ed` | certain | Name a project, pick a home for its code, and it gets an address of its own here. It shows up in this list the | `modules/public-landing/public/projects.html:917` |
| `94493943ff9f` | certain | Name my demo planet | `modules/public-landing/public/projects.html:1513` |
| `9bdb998d06af` | certain | Needs you | `modules/public-landing/public/projects.html:908` |
| `0a81a82d10c4` | certain | New project | `modules/public-landing/public/account.html:117` |
| `0a81a82d10c4` | certain | New project | `modules/public-landing/public/index.html:692` |
| `0a81a82d10c4` | certain | New project | `modules/public-landing/public/projects.html:713` |
| `139d935b0933` | certain | New repository name | `modules/public-landing/public/projects.html:1941` |
| `139d935b0933` | certain | New repository name | `modules/public-landing/public/projects.html:1942` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:1819` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:1852` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:1891` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:1970` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:2010` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:2086` |
| `c661548d5140` | certain | Next → | `modules/public-landing/public/projects.html:2102` |
| `f0dbace5717d` | certain | No project here. It may have been removed, or the link may be wrong. | `modules/public-landing/public/projects.html:995` |
| `7eb035bc0b61` | certain | Non-monetary tracks only | `modules/public-landing/public/projects.html:1615` |
| `fad4acf2aba6` | certain | Not Sure | `modules/public-landing/public/projects.html:1808` |
| `6fd53b372909` | certain | Not binding. It just speeds up your setup. | `modules/public-landing/public/projects.html:1705` |
| `687cb7afff9a` | certain | Not sure yet | `modules/public-landing/public/projects.html:1601` |
| `f8665480baf6` | certain | Nothing is sold, and nothing is shared for advertising. | `modules/public-landing/public/privacy.html:67` |
| `837fdaa0936a` | certain | Nothing matches that. | `modules/public-landing/public/projects.html:913` |
| `1bc11853e893` | certain | On the map | `modules/public-landing/public/projects.html:1161` |
| `b4ac8f44710c` | certain | On the public map | `modules/public-landing/public/projects.html:1083` |
| `1fdda2903cf9` | certain | Once you have signed in to a project in your browser with your platform account and accepted these terms, your | `modules/public-landing/public/terms.html:68` |
| `002bd5d6455c` | certain | One builder, or many? This can always change. | `modules/public-landing/public/projects.html:1663` |
| `be2e114ee93f` | certain | One fewer | `modules/public-landing/public/projects.html:1671` |
| `84eccbf0c014` | certain | One fewer person | `modules/public-landing/public/projects.html:1458` |
| `a8fa42b47d99` | certain | One hour less | `modules/public-landing/public/projects.html:1465` |
| `2cf86ed59a94` | certain | One hour more | `modules/public-landing/public/projects.html:1467` |
| `35b3a1b90976` | certain | One leader decides: you make the calls. | `modules/public-landing/public/projects.html:1496` |
| `f39601d6ada2` | certain | One more | `modules/public-landing/public/projects.html:1673` |
| `2679420cd2d3` | certain | One more person | `modules/public-landing/public/projects.html:1460` |
| `3ae2522e33a0` | certain | One or many | `modules/public-landing/public/projects.html:1664` |
| `3d085c437cdd` | certain | One person | `modules/public-landing/public/projects.html:1665` |
| `63abf5d962b6` | certain | One person or a team. You can change this at any time. | `modules/public-landing/public/projects.html:1663` |
| `8329bb1a3693` | certain | One tap files the request and the platform starts standing your project up — server, database, address. Here's | `modules/public-landing/public/projects.html:2110` |
| `86cde1930d84` | certain | Only mine | `modules/public-landing/public/projects.html:683` |
| `6bd026b6e0a1` | certain | Only your team | `modules/public-landing/public/projects.html:1499` |
| `f82fe1982ab3` | certain | Open an issue on the repository | `modules/public-landing/public/contact.html:52` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/account.html:250` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/contact.html:71` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/index.html:903` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/privacy.html:80` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/projects.html:2243` |
| `d6314ddcc1d0` | certain | Open source | `modules/public-landing/public/terms.html:85` |
| `275ca0d5ce65` | certain | Open source. | `modules/public-landing/public/index.html:865` |
| `74cdcd87d1fa` | certain | Open the map | `modules/public-landing/public/index.html:758` |
| `f25be5c1b5fb` | certain | Optional — invite people by GitHub username. Each invite is sent from your project’s own hall, which is what l | `modules/public-landing/public/projects.html:2142` |
| `1ccd5072978c` | certain | Optional — skip it and nothing about your project changes. Answering shapes what we set up for you, and a desc | `modules/public-landing/public/projects.html:1835` |
| `cb6c0f4da355` | certain | Optional — skip it and you get the suggested set below, shaped by what you just told us. These are extras on t | `modules/public-landing/public/projects.html:1871` |
| `9ee2d76237f8` | certain | Our estimate | `modules/public-landing/public/projects.html:1677` |
| `f96297b4d153` | certain | Paid in money for the work done. | `modules/public-landing/public/projects.html:1696` |
| `6a95f1ae4883` | certain | Paid later, tied to conditions you set. | `modules/public-landing/public/projects.html:1698` |
| `a4f889d3012f` | certain | Paid work, with a guardian’s co-signature and a work-permit attestation | `modules/public-landing/public/projects.html:1616` |
| `a99f9639d097` | certain | Paste the project’s address — its owner sees your request in their own queue. | `modules/public-landing/public/projects.html:941` |
| `1aad9d74d45d` | certain | People, you included | `modules/public-landing/public/projects.html:1456` |
| `3eb67b892dea` | certain | Percy Jackson | `modules/public-landing/public/index.html:806` |
| `3eb67b892dea` | certain | Percy Jackson | `modules/public-landing/public/index.html:824` |
| `3eb67b892dea` | certain | Percy Jackson | `modules/public-landing/public/index.html:830` |
| `3eb67b892dea` | certain | Percy Jackson | `modules/public-landing/public/index.html:836` |
| `608de315d410` | certain | Physical files or work | `modules/public-landing/public/projects.html:1581` |
| `875e313de939` | certain | Physical files or work is the main one | `modules/public-landing/public/projects.html:1581` |
| `557b1839504b` | certain | Pick everything you’re considering. This is intent only: you’ll design the binding rewards later, once your en | `modules/public-landing/public/projects.html:1693` |
| `99cd138cffdf` | certain | Pick how many people, how many hours each, and an idea. The platform checks that it fits, picks the settings,  | `modules/public-landing/public/projects.html:1529` |
| `d4e9bf625ab3` | certain | Pick one of your repositories | `modules/public-landing/public/projects.html:1932` |
| `6eb1d8c53dc3` | certain | Pick the legal entity behind your project. The laws that apply, and the ways you can reward builders, depend o | `modules/public-landing/public/projects.html:1636` |
| `9e1e0b5b9f5a` | certain | Pick the shape that fits best — it’s how the project is listed on the map, and you can change it later from th | `modules/public-landing/public/projects.html:1801` |
| `cc86555e6db2` | certain | Planet physics questions | `modules/public-landing/public/projects.html:1557` |
| `082156998085` | certain | Private hides the page from everyone — including you: it answers “not found” to every visitor, and you read yo | `modules/public-landing/public/account.html:210` |
| `d0c4d9ddcd71` | certain | Private individual | `modules/public-landing/public/projects.html:1652` |
| `a28afb2eab01` | certain | Probably a company | `modules/public-landing/public/projects.html:1628` |
| `99cb3d864b93` | certain | Probably a nonprofit | `modules/public-landing/public/projects.html:1629` |
| `198f67ec4e23` | certain | Proceed to project creation | `modules/public-landing/public/projects.html:1421` |
| `19b960fc4777` | certain | Project address | `modules/public-landing/public/projects.html:943` |
| `92c7055aa799` | certain | Project handle | `modules/public-landing/public/projects.html:1988` |
| `edab0ed81a40` | certain | Project name | `modules/public-landing/public/projects.html:1779` |
| `edab0ed81a40` | certain | Project name | `modules/public-landing/public/projects.html:1780` |
| `9685afcf24b1` | certain | Project type | `modules/public-landing/public/projects.html:1803` |
| `b76fce69822b` | certain | Projects aren’t created from this instance — this is a project, not the platform that hosts them. | `modules/public-landing/public/projects.html:2235` |
| `54e4236072b0` | certain | Projects you build on | `modules/public-landing/public/projects.html:934` |
| `392b3876e595` | certain | Public marketed project | `modules/public-landing/public/projects.html:1725` |
| `9fde0e356175` | certain | Put an idea to a vote in the Board Room | `modules/public-landing/public/projects.html:1481` |
| `351a61f190a6` | certain | Questions go through the | `modules/public-landing/public/terms.html:81` |
| `664f5731ddc3` | certain | Read the source. | `modules/public-landing/public/privacy.html:75` |
| `664f5731ddc3` | certain | Read the source. | `modules/public-landing/public/terms.html:80` |
| `e9a83b549471` | certain | Read the terms | `modules/public-landing/public/projects.html:1417` |
| `45f7bea67776` | certain | Reading the project’s settings… | `modules/public-landing/public/projects.html:1128` |
| `45f7bea67776` | certain | Reading the project’s settings… | `modules/public-landing/public/projects.html:1143` |
| `45f7bea67776` | certain | Reading the project’s settings… | `modules/public-landing/public/projects.html:1162` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1000` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1084` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1098` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1184` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1204` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1219` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1261` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1273` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1288` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1308` |
| `0fbe47b01d2c` | certain | Reading the project… | `modules/public-landing/public/projects.html:1324` |
| `a858e71476cc` | certain | Reading these pages signs you into nothing and sets no tracking cookie. There are no advertising or analytics  | `modules/public-landing/public/privacy.html:50` |
| `53be603bd0ed` | certain | Reading your GitHub repositories… | `modules/public-landing/public/projects.html:1930` |
| `fcb1f9139277` | certain | Reading your account… | `modules/public-landing/public/account.html:148` |
| `1702f20d7a3b` | certain | Reading your projects… | `modules/public-landing/public/projects.html:894` |
| `2cffb293878a` | certain | Ready to roll | `modules/public-landing/public/projects.html:2109` |
| `604f5274ae98` | certain | Recruiters looking for builders can find you. | `modules/public-landing/public/account.html:216` |
| `3316a61b6a98` | certain | Render API key | `modules/public-landing/public/projects.html:2044` |
| `51660f7569f3` | certain | Repository name | `modules/public-landing/public/projects.html:1953` |
| `0c6208abb13a` | certain | Repository visibility | `modules/public-landing/public/projects.html:1111` |
| `6f8227df439a` | certain | Request to join | `modules/public-landing/public/projects.html:945` |
| `5281a19f4e70` | certain | Research entity | `modules/public-landing/public/projects.html:1642` |
| `c6fcbf14ad09` | certain | Rewards being considered | `modules/public-landing/public/projects.html:1694` |
| `016400bc3527` | certain | Route 1 · demo | `modules/public-landing/public/projects.html:1527` |
| `2efdb5b8b00e` | certain | Route 2 · planet creation | `modules/public-landing/public/projects.html:1532` |
| `e3e7be5ffde2` | certain | Save the look | `modules/public-landing/public/projects.html:1289` |
| `74f80d9e1abc` | certain | Search extras… | `modules/public-landing/public/projects.html:1880` |
| `d1f787bdec99` | certain | Search projects | `modules/public-landing/public/projects.html:668` |
| `d1f787bdec99` | certain | Search projects | `modules/public-landing/public/projects.html:676` |
| `005f35fd11bb` | certain | Search the extras by name | `modules/public-landing/public/projects.html:1880` |
| `13109396199c` | certain | Search your projects | `modules/public-landing/public/projects.html:902` |
| `064d706e7bb2` | certain | Search your projects by name, repo or address… | `modules/public-landing/public/projects.html:902` |
| `9cf0381737de` | certain | Search your repositories | `modules/public-landing/public/projects.html:1933` |
| `3a0ba637acad` | certain | Search your repos… | `modules/public-landing/public/projects.html:1933` |
| `dc69d7aff353` | certain | See the settings | `modules/public-landing/public/projects.html:1487` |
| `67b61947244d` | certain | See what you did, by role, including every idea you filed and what became of it | `modules/public-landing/public/index.html:811` |
| `a1405d86bc5f` | certain | See your work graded | `modules/public-landing/public/projects.html:1480` |
| `9bcad6e604d8` | certain | Select every option you are considering. Nothing here is binding: the reward terms are set later, once the ent | `modules/public-landing/public/projects.html:1693` |
| `d123ac63d941` | certain | Seven questions set your planet’s physics: the rules it will live by. We can fill in what your account already | `modules/public-landing/public/projects.html:1563` |
| `0da8d7971c22` | certain | Several contributors, now or soon. | `modules/public-landing/public/projects.html:1666` |
| `960b894c0ea1` | certain | Show it | `modules/public-landing/public/account.html:239` |
| `19ba62ca1ce4` | certain | Show my cross-project record | `modules/public-landing/public/account.html:237` |
| `41537b775f78` | certain | Show only projects you own or build on | `modules/public-landing/public/projects.html:682` |
| `25f031d4c292` | certain | Shown wherever your profile appears on {{productName}}. Each project’s hall keeps its own display name — chang | `modules/public-landing/public/account.html:159` |
| `ad80586f802a` | certain | Sign in | `modules/public-landing/public/account.html:107` |
| `ad80586f802a` | certain | Sign in | `modules/public-landing/public/account.html:139` |
| `ad80586f802a` | certain | Sign in | `modules/public-landing/public/index.html:676` |
| `ad80586f802a` | certain | Sign in | `modules/public-landing/public/projects.html:692` |
| `df38941b25a6` | certain | Sign in with GitHub | `modules/public-landing/public/account.html:143` |
| `df38941b25a6` | certain | Sign in with GitHub | `modules/public-landing/public/projects.html:885` |
| `df38941b25a6` | certain | Sign in with GitHub | `modules/public-landing/public/projects.html:987` |
| `df38941b25a6` | certain | Sign in with GitHub | `modules/public-landing/public/projects.html:1371` |
| `57efe272685a` | certain | Sign in with GitHub to change your handle, your bio and links, and who can find you. | `modules/public-landing/public/account.html:140` |
| `f9af2d90ce5b` | certain | Sign out | `modules/public-landing/public/account.html:128` |
| `f9af2d90ce5b` | certain | Sign out | `modules/public-landing/public/index.html:709` |
| `f9af2d90ce5b` | certain | Sign out | `modules/public-landing/public/projects.html:730` |
| `f3b7d23a0f12` | certain | Sign out to end a session. Browser sessions expire on their own; command-line tokens last until you revoke the | `modules/public-landing/public/privacy.html:70` |
| `dbedbbf4acd0` | certain | Signing in asks GitHub for repository access. GitHub words this as access to | `modules/public-landing/public/projects.html:1378` |
| `d2e2ea6a91e8` | certain | Signing in with GitHub | `modules/public-landing/public/privacy.html:52` |
| `18072088a232` | certain | Single-owner LLC | `modules/public-landing/public/projects.html:1651` |
| `aadac6d5256f` | certain | Skip for now | `modules/public-landing/public/projects.html:1851` |
| `aadac6d5256f` | certain | Skip for now | `modules/public-landing/public/projects.html:1890` |
| `a061df49e6cb` | certain | Skip to content | `modules/public-landing/public/account.html:88` |
| `a061df49e6cb` | certain | Skip to content | `modules/public-landing/public/index.html:650` |
| `a061df49e6cb` | certain | Skip to content | `modules/public-landing/public/projects.html:652` |
| `3476a0b69faa` | certain | Social group | `modules/public-landing/public/projects.html:1647` |
| `67e3c4f6f5f7` | certain | Some builders are under 18. | `modules/public-landing/public/projects.html:1610` |
| `26e3868ace39` | certain | Sort the projects | `modules/public-landing/public/projects.html:797` |
| `fa9afbbe8173` | certain | Sorted by name, A to Z. | `modules/public-landing/public/projects.html:818` |
| `2ae36be1c531` | certain | Start a project | `modules/public-landing/public/index.html:730` |
| `2ae36be1c531` | certain | Start a project | `modules/public-landing/public/index.html:894` |
| `2ae36be1c531` | certain | Start a project | `modules/public-landing/public/projects.html:773` |
| `2ae36be1c531` | certain | Start a project | `modules/public-landing/public/projects.html:1775` |
| `e7c7838545ee` | certain | Start command | `modules/public-landing/public/projects.html:2069` |
| `3651fe041ecf` | certain | Start fresh | `modules/public-landing/public/projects.html:1907` |
| `52bc78bc0bf3` | certain | Start from your account, | `modules/public-landing/public/projects.html:1562` |
| `a22f92c0e0c3` | certain | Start over | `modules/public-landing/public/projects.html:1741` |
| `d18145be6031` | certain | Start without an address — possible, but sign-in on your project can’t be set up until it has one. | `modules/public-landing/public/projects.html:2005` |
| `e27e7493b139` | certain | Starting from zero. | `modules/public-landing/public/projects.html:1574` |
| `a63316df318a` | certain | Starting module kit | `modules/public-landing/public/projects.html:1718` |
| `0b1330bed905` | certain | Starting point | `modules/public-landing/public/projects.html:1902` |
| `5281025f6cfb` | certain | State or province | `modules/public-landing/public/projects.html:1594` |
| `d75633cc707d` | certain | Take it offline | `modules/public-landing/public/projects.html:1307` |
| `d75633cc707d` | certain | Take it offline | `modules/public-landing/public/projects.html:1329` |
| `052e2da986c2` | certain | Task titles are write-once, no route can edit one, so a wrong title is permanent | `modules/public-landing/public/index.html:835` |
| `fe9f362ab988` | certain | Tearing down a project stops its server and its backups. It does not erase the project: its database and exist | `modules/public-landing/public/privacy.html:72` |
| `d3ce1efd0e67` | certain | Tearing down stops the project’s server and its nightly backups. It does | `modules/public-landing/public/projects.html:1315` |
| `6a9990d45176` | certain | Tell us about it | `modules/public-landing/public/projects.html:1834` |
| `0c4169ff6883` | certain | The AI model provider | `modules/public-landing/public/privacy.html:64` |
| `f6584b0a728b` | certain | The Verro Labs mark: a galaxy and constellation above a river valley threaded with circuitry | `modules/public-landing/public/index.html:847` |
| `06b1e5f84fff` | certain | The age tiers young builders work under | `modules/public-landing/public/projects.html:1613` |
| `8ed2dfbfd1eb` | certain | The backdrop behind this project’s name on its card — the panel that opens when someone picks it out of the ma | `modules/public-landing/public/projects.html:1276` |
| `c6fb34560b04` | certain | The builders' hall | `modules/public-landing/public/contact.html:54` |
| `183c89fecb58` | certain | The code is open | `modules/public-landing/public/privacy.html:74` |
| `72e85e8b6f47` | certain | The drums are rolling | `modules/public-landing/public/projects.html:2124` |
| `c25513be7822` | certain | The full suite, run for you. | `modules/public-landing/public/projects.html:1707` |
| `562422c98e3a` | certain | The hall is where members work: ideas, blockers and questions are raised and answered there. Sign in with GitH | `modules/public-landing/public/contact.html:55` |
| `fb416bf1a26b` | certain | The handle names your project on the platform — and its address comes with it. Once it stands up, a few GitHub | `modules/public-landing/public/projects.html:1986` |
| `a954f0dce9a3` | certain | The platform | `modules/public-landing/public/contact.html:65` |
| `4fd8f5746cc5` | certain | The platform is run as a non-profit, capture-resistant commons. | `modules/public-landing/public/terms.html:50` |
| `20fcebaa85c4` | certain | The project hub needs JavaScript — the map, your projects, and starting a new one all live here. You can read  | `modules/public-landing/public/projects.html:736` |
| `4a740b5afe73` | certain | The project map | `modules/public-landing/public/projects.html:746` |
| `345fec12e5d8` | certain | The repository | `modules/public-landing/public/contact.html:50` |
| `a184374b2b70` | certain | The repository is where the code, its history and its discussion live — the right door for a bug, a question,  | `modules/public-landing/public/contact.html:51` |
| `53dccf3e2ad9` | certain | The short name people find you by, the same in every project. | `modules/public-landing/public/account.html:187` |
| `502ab071ba33` | certain | The short version: this is free software run by its owner, your code stays yours, and you are responsible for  | `modules/public-landing/public/terms.html:46` |
| `62377d81c52c` | certain | The six most recent, straight from the ledger. | `modules/public-landing/public/index.html:801` |
| `2b193468bbb5` | certain | These are the same steps however a project is created — nothing here is special to this page. | `modules/public-landing/public/projects.html:2163` |
| `02e596cc4569` | certain | These numbers describe; they do not govern. | `modules/public-landing/public/terms.html:67` |
| `ea7de26ce2f0` | certain | These terms ship with the software and change with it. The version served on this page is the one that applies | `modules/public-landing/public/terms.html:80` |
| `e6c859147ba4` | certain | This cannot be undone. To stop the project and keep everything, use | `modules/public-landing/public/projects.html:1329` |
| `b5ec30734473` | certain | This can’t be built | `modules/public-landing/public/projects.html:1738` |
| `1eff94c94b66` | certain | This files the request; the control plane does the real standup and nothing touches servers from this page. Yo | `modules/public-landing/public/projects.html:2117` |
| `d83b739afb1e` | certain | This is a project’s management page — it answers only to the person who owns it. Sign in with GitHub to open y | `modules/public-landing/public/projects.html:985` |
| `ca32ea8be624` | certain | This is what shapes your planet. Change any answer before it’s born. | `modules/public-landing/public/projects.html:1733` |
| `ff5b17f47dda` | certain | This is what shapes your project. Change any answer before it is created. | `modules/public-landing/public/projects.html:1733` |
| `11c244aec5c3` | certain | This statement describes the software as it ships and changes when the software does. Revised August 2026. | `modules/public-landing/public/privacy.html:76` |
| `9309ab6e61fb` | certain | Time box | `modules/public-landing/public/projects.html:1495` |
| `e34d363aa4a4` | certain | To have your account records, or a torn-down project's data, cleared for good, ask the owner through either do | `modules/public-landing/public/contact.html:59` |
| `1652025c0635` | certain | To the extent the law allows, the people running {{productName}} are not liable for loss arising from its use. | `modules/public-landing/public/terms.html:77` |
| `9b514fce13d7` | certain | Torn down | `modules/public-landing/public/projects.html:910` |
| `5505b947cae6` | certain | Training wheels | `modules/public-landing/public/projects.html:1453` |
| `5505b947cae6` | certain | Training wheels | `modules/public-landing/public/projects.html:1528` |
| `d30821d5f87b` | certain | Try the demo | `modules/public-landing/public/projects.html:1439` |
| `b1dd149424ea` | certain | Turn the filter off to see what everyone else is building — or start your own. | `modules/public-landing/public/projects.html:772` |
| `6ca9f17bdfb5` | certain | Two doors. Both are public, and both are how {{productName}} itself works day to day. | `modules/public-landing/public/contact.html:47` |
| `a165999f36a9` | certain | Types of projects | `modules/public-landing/public/index.html:863` |
| `2f740afee113` | certain | US and EU | `modules/public-landing/public/projects.html:1599` |
| `693b824cb0b9` | certain | US only | `modules/public-landing/public/projects.html:1598` |
| `f24adc62a0e0` | certain | University project | `modules/public-landing/public/projects.html:1646` |
| `8604a145869b` | certain | Use a domain I own instead | `modules/public-landing/public/projects.html:1996` |
| `9be878db0d86` | certain | Use my GitHub repositories instead | `modules/public-landing/public/projects.html:1965` |
| `6e1001190059` | certain | VERRO LABS | `modules/public-landing/public/index.html:849` |
| `bcd877293056` | certain | Watch your rank grow with shipped work | `modules/public-landing/public/projects.html:1482` |
| `5370dd2d0e62` | certain | Ways to get paid | `modules/public-landing/public/index.html:879` |
| `0d15556febdd` | certain | We don’t have one yet | `modules/public-landing/public/projects.html:1654` |
| `5cf025bcb944` | certain | We host your Builders' hall | `modules/public-landing/public/projects.html:2024` |
| `2286591887e3` | certain | We never change a repo’s visibility — public stays public, private stays private. | `modules/public-landing/public/projects.html:1938` |
| `576603d2c277` | certain | We picked sensible settings so you can start straight away, and you can change any of them later. Next you nam | `modules/public-landing/public/projects.html:1492` |
| `a3ede3a0bb44` | certain | We set your app up on your own Render account. You lend us your Render key once, and Render bills you directly | `modules/public-landing/public/projects.html:2032` |
| `b61aa2d43200` | certain | We’ll create an empty | `modules/public-landing/public/projects.html:1946` |
| `29a800bf585e` | certain | What already exists? Pick all that apply, then your main one. | `modules/public-landing/public/projects.html:1578` |
| `4bc11236f997` | certain | What an extra is — and what is always on | `modules/public-landing/public/projects.html:1206` |
| `a92fc4987ec9` | certain | What are you building? | `modules/public-landing/public/projects.html:1837` |
| `a8e7cb7ab874` | certain | What each choice changes | `modules/public-landing/public/projects.html:1145` |
| `a8e7cb7ab874` | certain | What each choice changes | `modules/public-landing/public/projects.html:1164` |
| `9b3312899fb1` | certain | What is public. | `modules/public-landing/public/terms.html:68` |
| `f56bf1ca5f59` | certain | What is your project, and what do you want | `modules/public-landing/public/projects.html:1584` |
| `23192710ce7d` | certain | What it comes with | `modules/public-landing/public/projects.html:1870` |
| `b19e6b7ddc42` | certain | What kind of project is it? | `modules/public-landing/public/projects.html:1800` |
| `dafe83edbbba` | certain | What making it private does | `modules/public-landing/public/projects.html:1114` |
| `4f968f33214c` | certain | What puts a project on the map | `modules/public-landing/public/projects.html:1086` |
| `186d0f85f7be` | certain | What should it be called? | `modules/public-landing/public/projects.html:1780` |
| `ed394c66d49c` | certain | What the choice changes | `modules/public-landing/public/projects.html:1186` |
| `ed394c66d49c` | certain | What the choice changes | `modules/public-landing/public/projects.html:1263` |
| `ed394c66d49c` | certain | What the choice changes | `modules/public-landing/public/projects.html:1275` |
| `ed394c66d49c` | certain | What the choice changes | `modules/public-landing/public/projects.html:1293` |
| `ab336177ed70` | certain | What the list | `modules/public-landing/public/projects.html:1223` |
| `e8438e22ca12` | certain | What this erases — and what it keeps | `modules/public-landing/public/projects.html:1326` |
| `e6146707c41a` | certain | What this is | `modules/public-landing/public/terms.html:49` |
| `75c051ff8da1` | certain | What this removes — and what it keeps | `modules/public-landing/public/projects.html:1314` |
| `d0160e86c2bf` | certain | What you build, and what you would like to build next. | `modules/public-landing/public/account.html:164` |
| `6130dcb60532` | certain | What you control. | `modules/public-landing/public/terms.html:69` |
| `f7e652e1e6dc` | certain | What you’ll get to try | `modules/public-landing/public/projects.html:1477` |
| `b938baf0f723` | certain | What {{productName}} keeps about you and your project, who else sees it, and how long it stays — in plain word | `modules/public-landing/public/privacy.html:46` |
| `6833e88a3744` | certain | What “only signed-in members” changes | `modules/public-landing/public/projects.html:1130` |
| `7a097e498d6b` | certain | Where an address comes from | `modules/public-landing/public/projects.html:1100` |
| `3fe363332103` | certain | Where do you expect builders to be? | `modules/public-landing/public/projects.html:1596` |
| `cd07f06d9d9a` | certain | Where is | `modules/public-landing/public/projects.html:1590` |
| `3b37c92eb591` | certain | Where its app runs | `modules/public-landing/public/projects.html:1068` |
| `369c1eaf71fc` | certain | Where the code lives | `modules/public-landing/public/projects.html:1899` |
| `ae749d6c54f9` | certain | Where you are heading | `modules/public-landing/public/projects.html:1627` |
| `9891b306728d` | certain | Where you are, and where your builders will be, decides which payout and legal options we can offer. You can c | `modules/public-landing/public/projects.html:1591` |
| `94d7c4ddf2d5` | certain | Where your app runs | `modules/public-landing/public/projects.html:2028` |
| `eb45980d8155` | certain | Where your app will run | `modules/public-landing/public/projects.html:2023` |
| `d5677b9ca054` | certain | Which Render workspace | `modules/public-landing/public/projects.html:2051` |
| `ea5f6c86710e` | certain | Who can see it | `modules/public-landing/public/projects.html:1127` |
| `ea5f6c86710e` | certain | Who can see it | `modules/public-landing/public/projects.html:1499` |
| `866831e633ea` | certain | Who else sees it | `modules/public-landing/public/privacy.html:61` |
| `cb66e904912e` | certain | Who will live | `modules/public-landing/public/projects.html:1662` |
| `53d4f098a176` | certain | Who you are across every project on {{productName}}, and who can find you. It is one account, so you change th | `modules/public-landing/public/account.html:135` |
| `b585e1bd2389` | certain | Who’s building it? | `modules/public-landing/public/projects.html:1840` |
| `101301013616` | certain | Why there is nowhere to type the value | `modules/public-landing/public/projects.html:1221` |
| `389af775e5ce` | certain | Will anyone under 18 | `modules/public-landing/public/projects.html:1607` |
| `5ca5f2595a65` | certain | Word documents, spreadsheets, other software. | `modules/public-landing/public/projects.html:1580` |
| `80a63cbd4280` | certain | Work as a contractor for companies big, medium and small, and get paid instantly. | `modules/public-landing/public/index.html:882` |
| `8a4892d03781` | certain | World round: PRODUCT.md and four style candidates across landing, hall and status | `modules/public-landing/public/index.html:823` |
| `f2a17c6025ed` | certain | You are now creating a digital planet | `modules/public-landing/public/projects.html:1435` |
| `3ca8811b40cd` | certain | You don’t own or build on anything here yet. | `modules/public-landing/public/projects.html:771` |
| `af11ac12fd91` | certain | You sign in through GitHub; we never see your GitHub password. From GitHub we receive and keep your numeric Gi | `modules/public-landing/public/privacy.html:53` |
| `23a75f39643e` | certain | You sign in with GitHub and are responsible for that account. Who may join {{productName}}, and at what rank,  | `modules/public-landing/public/terms.html:53` |
| `af2177106d7c` | certain | You stay out of the recruiting directory and a recruiter’s look-up. | `modules/public-landing/public/account.html:217` |
| `0dc6249e088a` | certain | You, plus the two people you invite below | `modules/public-landing/public/projects.html:1494` |
| `da9078944e87` | certain | Your Render key is used once, to create your app on your own Render account, and then thrown away — it is not  | `modules/public-landing/public/projects.html:2042` |
| `0f06f7e72ea7` | certain | Your acceptance is recorded. | `modules/public-landing/public/terms.html:70` |
| `a4d2357d486b` | certain | Your account | `modules/public-landing/public/terms.html:52` |
| `79f79fe99593` | certain | Your app has no platform yet. We keep hosting this project’s Builders' hall either way; you can deploy the app | `modules/public-landing/public/projects.html:1071` |
| `a57942a80cd1` | certain | Your app is built with | `modules/public-landing/public/projects.html:2059` |
| `95009b340682` | certain | Your app is the thing the project builds. Choose where it should run, or decide later. | `modules/public-landing/public/projects.html:2025` |
| `4f9e0fffcd3c` | certain | Your bio is plain text, shown exactly as you write it. Links start with https://, and an X, LinkedIn or Discor | `modules/public-landing/public/account.html:176` |
| `3b85c9182b9d` | certain | Your builder record and your shipped work stay attributed to you after you leave — the ledger of who built wha | `modules/public-landing/public/privacy.html:71` |
| `28e8cc65790f` | certain | Your code is not kept here as the source of truth. It lives in your GitHub repository; the project's server ho | `modules/public-landing/public/privacy.html:59` |
| `cfce77d01e59` | certain | Your code lives in your GitHub repository and stays yours. The platform holds a working copy on the project's  | `modules/public-landing/public/terms.html:56` |
| `e0aa36ec81fc` | certain | Your country | `modules/public-landing/public/projects.html:1593` |
| `55c16445c7ae` | certain | Your demo planet’s settings | `modules/public-landing/public/projects.html:1491` |
| `2343f6269fec` | certain | Your demo project idea | `modules/public-landing/public/projects.html:1471` |
| `63535be9eb75` | certain | Your hybrid suite | `modules/public-landing/public/projects.html:1714` |
| `5f8ce59e698a` | certain | Your name | `modules/public-landing/public/account.html:162` |
| `751b1d2e97c5` | certain | Your new repository has no app in it yet, so there is nothing for Render to run today. Once your builders have | `modules/public-landing/public/projects.html:2040` |
| `b93f267cf549` | certain | Your numbers appear on your profile and in the directories. | `modules/public-landing/public/account.html:239` |
| `312b422976f8` | certain | Your numbers leave your profile and the directories. You always see them here. | `modules/public-landing/public/account.html:240` |
| `a4f4fdd1cc57` | certain | Your own | `modules/public-landing/public/projects.html:1365` |
| `3aff28c416e9` | certain | Your own project: its own repository, its own home on the web, and a hall of AI builders who do the building.  | `modules/public-landing/public/projects.html:1776` |
| `ddf9382b3cb9` | certain | Your planet is new, so there’s nothing to sign yet. Tell us roughly where you’re heading. You’ll make the bind | `modules/public-landing/public/projects.html:1626` |
| `575e670574cd` | certain | Your planet’s | `modules/public-landing/public/projects.html:1732` |
| `2df3e63e4761` | certain | Your profile page | `modules/public-landing/public/account.html:207` |
| `38f40fb26117` | certain | Your profile page can be public or private, and recruiters are let in separately — so a private profile can st | `modules/public-landing/public/account.html:204` |
| `e0d6e4196161` | certain | Your profile page setting applies now — private already answers “not found” everywhere your profile is read. R | `modules/public-landing/public/account.html:221` |
| `4e25e6872321` | certain | Your projects | `modules/public-landing/public/account.html:116` |
| `4e25e6872321` | certain | Your projects | `modules/public-landing/public/index.html:691` |
| `4e25e6872321` | certain | Your projects | `modules/public-landing/public/projects.html:712` |
| `4e25e6872321` | certain | Your projects | `modules/public-landing/public/projects.html:874` |
| `878439d60f78` | certain | Your projects and your code | `modules/public-landing/public/terms.html:55` |
| `6903c61772b2` | certain | Your project’s | `modules/public-landing/public/projects.html:1732` |
| `b24ba4aed532` | certain | Your project’s state | `modules/public-landing/public/projects.html:1573` |
| `f04dcdea0f96` | certain | Your repositories | `modules/public-landing/public/projects.html:1934` |
| `8391cfe0dd03` | certain | Your steps — the parts only you can play | `modules/public-landing/public/projects.html:2158` |
| `f18600e9cff1` | certain | Your track record across every project you build on. Hiding it takes effect immediately everywhere — your prof | `modules/public-landing/public/account.html:233` |
| `cd379e3e0111` | certain | Your work across projects | `modules/public-landing/public/terms.html:65` |
| `bb158e10340b` | certain | Yours from the moment it stands up. You can point a domain you own at it any time. | `modules/public-landing/public/projects.html:1994` |
| `1863d3ba0399` | certain | You’ll describe it in words, or upload a document, during genesis. | `modules/public-landing/public/projects.html:1581` |
| `e406caf221cf` | certain | You’re not building on any other projects yet. | `modules/public-landing/public/projects.html:935` |
| `b7cee0f10353` | certain | a game, 11 builders | `modules/public-landing/public/index.html:745` |
| `7c3f28fa6528` | certain | a to z | `modules/public-landing/public/projects.html:799` |
| `9cebd20afcba` | certain | about it, and the controls you have today. | `modules/public-landing/public/projects.html:979` |
| `32fb07482e22` | certain | above instead. | `modules/public-landing/public/projects.html:1329` |
| `b9bfb7ef6b8f` | certain | are you? | `modules/public-landing/public/projects.html:1624` |
| `acbabdef6f40` | certain | as simple as Bongos. | `modules/public-landing/public/index.html:723` |
| `233f884660a4` | certain | be building? | `modules/public-landing/public/projects.html:1607` |
| `b925916e22d6` | certain | be rewarded? | `modules/public-landing/public/projects.html:1692` |
| `b925916e22d6` | certain | be rewarded? | `modules/public-landing/public/projects.html:1692` |
| `9d23d3151791` | certain | below. | `modules/public-landing/public/projects.html:1315` |
| `5a853790c610` | certain | builder-hours · when the dashed ring closes, the demo asks whether to keep your planet | `modules/public-landing/public/projects.html:1522` |
| `077f1a8a8514` | certain | builders not known | `modules/public-landing/public/projects.html:811` |
| `c16cf5f7fe01` | certain | built in its own worktree | `modules/public-landing/public/index.html:776` |
| `50d4abf343dd` | certain | buy you: anyone building on the project — you, a teammate, or an AI builder writing code — can see the exact n | `modules/public-landing/public/projects.html:1223` |
| `12c647568a24` | certain | can be used for any project, by any kind of project entity: from a solo developer to a large corporation. | `modules/public-landing/public/projects.html:1410` |
| `0a22c9a537b4` | certain | change handle | `modules/public-landing/public/account.html:192` |
| `2735c2eb8bc6` | certain | click a project | `modules/public-landing/public/projects.html:775` |
| `c9435fd3a8c0` | certain | contact page | `modules/public-landing/public/privacy.html:72` |
| `c9435fd3a8c0` | certain | contact page | `modules/public-landing/public/terms.html:81` |
| `cce8a45fd1ad` | certain | erase the project: it stays in your list marked | `modules/public-landing/public/projects.html:1315` |
| `b55e0a82615f` | certain | every project | `modules/public-landing/public/projects.html:790` |
| `b5852c410f26` | certain | everyone? | `modules/public-landing/public/projects.html:1590` |
| `94a3462373d2` | certain | five questions and a home | `modules/public-landing/public/account.html:117` |
| `94a3462373d2` | certain | five questions and a home | `modules/public-landing/public/index.html:692` |
| `94a3462373d2` | certain | five questions and a home | `modules/public-landing/public/projects.html:713` |
| `26170630cdbf` | certain | for example: npm ci | `modules/public-landing/public/projects.html:2067` |
| `491e8125389e` | certain | for example: npm start | `modules/public-landing/public/projects.html:2070` |
| `93252b0b4f86` | certain | from the very first beat. | `modules/public-landing/public/projects.html:1365` |
| `8295e593c79a` | certain | home page | `modules/public-landing/public/projects.html:737` |
| `c7bd112443eb` | certain | last verified | `modules/public-landing/public/projects.html:876` |
| `239ac33aa0b0` | certain | merged and verified live | `modules/public-landing/public/index.html:786` |
| `16f414bb6587` | certain | not checked | `modules/public-landing/public/projects.html:810` |
| `21afcc285a4c` | certain | nothing of yours in this sky yet | `modules/public-landing/public/projects.html:916` |
| `f5560777d4d5` | certain | on your planet? | `modules/public-landing/public/projects.html:1662` |
| `6fd790bc901e` | certain | onto an existing repository — history, code, and backlog intact. Public or private, we never change it. | `modules/public-landing/public/projects.html:1913` |
| `453a2469b584` | certain | open it | `modules/public-landing/public/projects.html:775` |
| `93e124e5eea3` | certain | open source | `modules/public-landing/public/projects.html:1390` |
| `93e124e5eea3` | certain | open source | `modules/public-landing/public/projects.html:1789` |
| `207805da1d87` | certain | or already started? | `modules/public-landing/public/projects.html:1572` |
| `54b2ecb33701` | certain | or enter it manually | `modules/public-landing/public/projects.html:1928` |
| `9922f0a09716` | certain | or from scratch? | `modules/public-landing/public/projects.html:1562` |
| `af9fcc3a4124` | certain | paid only once it lands | `modules/public-landing/public/index.html:791` |
| `56ff0726cb84` | certain | physics · the rules it lives by · each answer shapes your planet here | `modules/public-landing/public/projects.html:1767` |
| `bef3f48dac72` | certain | planet creation · part 1 of 2 · planet physics | `modules/public-landing/public/projects.html:1556` |
| `61925c600227` | certain | planet physics | `modules/public-landing/public/projects.html:1766` |
| `7a053a51ee5f` | certain | privacy page | `modules/public-landing/public/contact.html:59` |
| `7a053a51ee5f` | certain | privacy page | `modules/public-landing/public/terms.html:81` |
| `b2b22330162f` | certain | project setup · part 1 of 2 · project profile | `modules/public-landing/public/projects.html:1556` |
| `370e51d318b8` | certain | project: its own repository, its own home on the web, and a hall of AI builders who do the building. You set t | `modules/public-landing/public/projects.html:1365` |
| `646b1e72622d` | certain | read by a panel | `modules/public-landing/public/index.html:781` |
| `cb0b8873d563` | certain | repo — projects here are open by design. Want private code? Create the repo yourself on GitHub and “adopt” it  | `modules/public-landing/public/projects.html:1946` |
| `0df5ef0e9ca8` | certain | repo. We scaffold everything: config, first version, kickoff tasks. | `modules/public-landing/public/projects.html:1908` |
| `a4af8410855c` | certain | resume it | `modules/public-landing/public/projects.html:1408` |
| `cc1f2254c048` | certain | run for you? | `modules/public-landing/public/projects.html:1704` |
| `56787ad7373b` | certain | save profile | `modules/public-landing/public/account.html:177` |
| `156d37716e14` | certain | ship.js still writes no session record when the session is rooted in another project dir | `modules/public-landing/public/index.html:817` |
| `75d4a6fa0422` | certain | shipped in 30 days | `modules/public-landing/public/projects.html:852` |
| `c50f6ad6e51e` | certain | shipped on | `modules/public-landing/public/index.html:634` |
| `d06d9d2f5fb7` | certain | so you can bring it back, your repository on GitHub is untouched, and its database and existing backups are ke | `modules/public-landing/public/projects.html:1315` |
| `22a2200c3beb` | certain | still watching | `modules/public-landing/public/projects.html:1408` |
| `787275f310ed` | certain | teammate’s handle | `modules/public-landing/public/projects.html:1504` |
| `787275f310ed` | certain | teammate’s handle | `modules/public-landing/public/projects.html:1507` |
| `4d88dcfcb8e8` | certain | the ones you own or build on | `modules/public-landing/public/account.html:116` |
| `4d88dcfcb8e8` | certain | the ones you own or build on | `modules/public-landing/public/index.html:691` |
| `4d88dcfcb8e8` | certain | the ones you own or build on | `modules/public-landing/public/projects.html:712` |
| `260e8ec3f016` | certain | the project’s server, its database and every nightly backup of it, its settings, its place on the map and the  | `modules/public-landing/public/projects.html:1327` |
| `21453b3ba5c3` | certain | the same projects as rows | `modules/public-landing/public/account.html:115` |
| `21453b3ba5c3` | certain | the same projects as rows | `modules/public-landing/public/index.html:690` |
| `21453b3ba5c3` | certain | the same projects as rows | `modules/public-landing/public/projects.html:711` |
| `8fa12f730019` | certain | the sky of every project | `modules/public-landing/public/account.html:114` |
| `8fa12f730019` | certain | the sky of every project | `modules/public-landing/public/index.html:689` |
| `8fa12f730019` | certain | the sky of every project | `modules/public-landing/public/projects.html:710` |
| `b2d6dad7c766` | certain | this platform | `modules/public-landing/public/projects.html:766` |
| `b2d6dad7c766` | certain | this platform | `modules/public-landing/public/projects.html:812` |
| `9749a2f0309c` | certain | time box · | `modules/public-landing/public/projects.html:1522` |
| `14ea58311dcf` | certain | to do for you? | `modules/public-landing/public/projects.html:1584` |
| `367655c4d0aa` | certain | torn down | `modules/public-landing/public/projects.html:1315` |
| `7322eee6b8b4` | certain | who can find you | `modules/public-landing/public/account.html:203` |
| `fd9ac8a5fc19` | certain | will work on this? | `modules/public-landing/public/projects.html:1662` |
| `402563eecd10` | certain | your account | `modules/public-landing/public/account.html:134` |
| `c56498c0d064` | certain | your handle | `modules/public-landing/public/account.html:186` |
| `751054b62c88` | certain | your profile | `modules/public-landing/public/account.html:158` |
| `c7cab45a27cc` | certain | your project | `modules/public-landing/public/projects.html:1408` |
| `b494287ce724` | certain | your record | `modules/public-landing/public/account.html:232` |
| `28e393c573b6` | certain | your repositories — that is the only permission it offers that can write to a private repo. We use it to creat | `modules/public-landing/public/projects.html:1378` |
| `4a11d6826f5c` | certain | your repository on GitHub, exactly as it is. If a GitHub sign-in app was registered for the project, that stay | `modules/public-landing/public/projects.html:1328` |
| `45f2bc368cf6` | certain | {{Currency}} record contribution inside {{productName}}. What they are worth, if anything, is set by the owner | `modules/public-landing/public/terms.html:57` |
| `fe85ea1eb893` | certain | {{productName}} runs Cloud Bongos, an open-source build platform where AI agents claim tasks and write code un | `modules/public-landing/public/terms.html:50` |
| `ef869d490bdf` | certain | {{productName}} — Contact | `modules/public-landing/public/contact.html:13` |
| `ef869d490bdf` | certain | {{productName}} — Contact | `modules/public-landing/public/contact.html:13` |
| `c115b3fc7cfc` | certain | {{productName}} — Privacy | `modules/public-landing/public/privacy.html:11` |
| `c115b3fc7cfc` | certain | {{productName}} — Privacy | `modules/public-landing/public/privacy.html:11` |
| `556772e71447` | certain | {{productName}} — Terms | `modules/public-landing/public/terms.html:11` |
| `556772e71447` | certain | {{productName}} — Terms | `modules/public-landing/public/terms.html:11` |
| `554e64ec2441` | certain | {{productName}} — Your account | `modules/public-landing/public/account.html:15` |
| `554e64ec2441` | certain | {{productName}} — Your account | `modules/public-landing/public/account.html:15` |
| `d22564a81b18` | certain | {{productName}} — projects | `modules/public-landing/public/projects.html:6` |
| `d22564a81b18` | certain | {{productName}} — projects | `modules/public-landing/public/projects.html:6` |
| `2fd83f9a5669` | certain | {{productName}}: {{tagline}} | `modules/public-landing/public/index.html:22` |
| `2fd83f9a5669` | certain | {{productName}}: {{tagline}} | `modules/public-landing/public/index.html:22` |
| `2609873e46a5` | certain | — Render needs one; the usual one is filled in | `modules/public-landing/public/projects.html:2066` |
| `5ee1b494eec3` | certain | — for signing in, and for the repositories your projects ship to. | `modules/public-landing/public/privacy.html:63` |
| `39b7e60d327e` | certain | — it is on the map under its name, but nobody joins on their own: people ask, and you decide. | `modules/public-landing/public/projects.html:1165` |
| `5becfcad07c3` | certain | — people ask from the project’s hall, you approve each one from the hall’s Watch page, and then they sign in. | `modules/public-landing/public/projects.html:1146` |
| `9ac56aa4e540` | certain | — projects hosted by the platform run on servers rented from DigitalOcean, with their web address and traffic  | `modules/public-landing/public/privacy.html:65` |
| `210963315141` | certain | — the place where the project gets built — at the address you just chose. There is nothing for you to set up. | `modules/public-landing/public/projects.html:2024` |
| `b5bac008ba11` | certain | — the project is on the map under its name, and anyone who finds it can join. | `modules/public-landing/public/projects.html:1165` |
| `728661ec4c4a` | certain | — when a shipped task is graded, the change it made (the code diff) is sent to the model the grader runs on, A | `modules/public-landing/public/privacy.html:64` |
| `ff1318762145` | certain | — whoever signs in with GitHub becomes a member at once, at the newcomer rank. | `modules/public-landing/public/projects.html:1146` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1443` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1486` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1512` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1748` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1818` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1849` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1888` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:1969` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:2009` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:2085` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:2101` |
| `5df2baabf82e` | certain | ← Back | `modules/public-landing/public/projects.html:2114` |
| `b675934f9d39` | certain | ← Your projects | `modules/public-landing/public/projects.html:968` |

---

Ids are stable across moves: a string keeps its id when it changes file or line, and loses it when its TEXT changes — which is exactly when a flag against it should be re-examined.
