# The branding contract (`config/branding.*`)

The branding contract is how a **Cloud Bongos instance** supplies its identity. It is the keystone of the Cloud Bongos decoupling (ADR [0062](adr/0062-medusa-instance-model-decoupling.md) §3; task [#1192](https://example.com/builders#/task/1192) / V4.R53). One config, read through one resolver (`src/branding.js`), so brand strings live in **one place** instead of the ~90 hardcoded sites they occupy today.

> Generalizes the single-config rule of [ADR 0004](adr/0004-example-name-and-trademark-acceptance.md) (the civ name must be one string, never baked into code) from one string to the whole identity surface. Code reads `branding().identity.worldName`, never `"Example"`.

## Resolution precedence (highest wins)

```
env override   →   instance config (config/branding.json)   →   neutral starter (config/branding.neutral.json)
```

- A fresh instance with **no** `config/branding.json` resolves to the **plain neutral identity** — never to a host's brand (fail-to-vanilla).
- `config/branding.neutral.json` is **customer 0** (vanilla Cloud Bongos). `config/branding.json` is the host instance — here, **customer 1** (Example / OTB).
- **Configurable-root ([ADR 0108](adr/0108-instance-composition-configurable-root.md) §1, task 1881/W1 shipped):** `NEUTRAL_PATH` resolves off `resolveCoreRoot()` (the neutral starter ships WITH the core package) and `INSTANCE_PATH` off `resolveInstanceRoot()` (the instance pack is host content) — [`src/instance-config.js`](../src/instance-config.js). Both resolvers return the repo root today, so resolution is unchanged; the split only diverges once a consumer installs the core as a package.
- Env overrides apply only to the operationally-swapped fields (origins + cookie domain) for dev/staging, keyed `<envPrefix>_<FIELD>` (e.g. `OTB_PUBLIC_ORIGIN`). Everything else comes from the committed pack.

## Fields

| Path | Meaning |
|---|---|
| `identity.productName` | The product name (e.g. "Example"). **Required.** |
| `identity.worldName` | The in-world / civilization name rendered at runtime (e.g. "Example"). **Required.** |
| `identity.company` | `{ name, site, tagline }` of the operating company — every field may be empty. `tagline` is the free-text clause that follows the name in the status page footer ("{{worldName}} is the work of **name**, *tagline*."), so put a location there if you want one; there is no separate location field. The footer stamps them as `{{companyName}}` / `{{companySite}}` / `{{companyTagline}}`, and each clause sits in a `<!--brand-if:KEY-->…<!--/brand-if:KEY-->` region that drops whole when its field is empty: no name hides the whole sentence, no site renders the name unlinked, no tagline ends the sentence at the name. (task [#1002853](https://cloudbongos.com/builders#/task/1002853)) |
| `llmProjectName` | The project name injected into grader / architect / onboarding **LLM prompts**, so a non-OTB instance is graded against its own identity. **Required.** |
| `domains.publicOrigin` | Public game/app origin. **Required.** |
| `domains.buildersOrigin` / `statusOrigin` | Hall + status origins. **These three (`publicOrigin`/`buildersOrigin`/`statusOrigin`) are the docs-discovery contract** ([ADR 0114](adr/0114-instance-docs-discovery-contract.md)): the hall is the canonical doc-reading surface, `/docs` on `publicOrigin` renders the API reference, the status page is the outage fallback. `GET <publicOrigin>/api/bongos` re-advertises them (`hall`/`status`/`public`) so an agent resolves the surfaces with no hard-coded host. |
| `domains.statusDataUrl` | **Optional.** The off-box prober's `status.json` URL that the mirrored status page's availability banner polls (ADR 0029). Read by `scripts/status-mirror-sync.js`; `""` (the neutral default) = this instance publishes no off-box mirror, and the publisher REFUSES rather than shipping a banner that points nowhere. (task [#1002510](https://cloudbongos.com/builders#/task/1002510)) |
| `domains.cookieDomain` | Session cookie domain (`""` = host-only — the safe default; never widen to a parent domain by accident). |
| `domains.oauthOrigin` | Canonical sign-in origin. |
| `domains.provisioningOrigin` | **Optional.** Control-plane front-door origin the [provisioning module](../modules/provisioning/CLAUDE.md) uses to build a new customer's GitHub-App `redirect_url`. Set it when the control plane co-hosts a game whose `publicOrigin` is the game's own domain (OTB = customer 0) so the customer's App carries the PLATFORM brand (e.g. `https://get.cloudbongos.com`), not the game's. **Falls back to `publicOrigin` when unset** — an instance whose `publicOrigin` is already the platform needs no override. Env-overridable: `<PREFIX>_PROVISIONING_ORIGIN`. ([#2101](https://example.com/builders#/task/2101)) |
| `domains.instanceBase` | Apex zone new projects get their **auto-assigned** address under (`<slug>.<instanceBase>`, task 1002704 — every project's hall reachable day one; `no_address: true` on the create call opts out). One label under the apex only, so the edge wildcard certificate covers it. Deliberately NOT derived from `publicOrigin` (on a co-hosting control plane that is the game's domain). Empty ⇒ no auto-assign — creates are domainless unless the caller brings a domain. |
| `repo` | `{ owner, name }` GitHub binding. |
| `db.database` | DB name Bongos pool connects to when neither `DATABASE_URL` nor `PGHOST`/`PGDATABASE` is set (`src/bongos/pool.js`, ADR 0062 §5). `null` in the neutral starter = **fail loud** rather than silently target a host DB. |
| `currency` | `{ label, symbol }` — the reward unit label (e.g. "example"). Display only. |
| `reward` | `{ marginPct, usdPeg, mode }` — the per-instance reward POLICY the economy module reads ([ADR 0054](adr/0054-session-token-reward-cost-plus.md) + ADR 0146, tasks 2009/1002270): the cost-plus margin percent (default `20`), the example-per-USD peg (default `1`), and `mode` — `"cost-plus-and-estimate"` (default; pay both the per-task author estimate AND the cost-plus session reward) or `"cost-plus-only"` (suppress the per-task estimate payout; the cost-plus session reward is the sole equity reward). Two per-craft lanes sit beside `mode` and are not derived from it: `ideatorCredit` ([ADR 0172](adr/0172-per-craft-compensation-ideator-credit-lane.md)) and `artistCredit` ([ADR 0341](adr/0341-the-page-is-the-unit-of-tweak-mode.md) D10, an approved page tweak pays its artist), each default on and withheld only by an explicit `false`. A committed, code-reviewed change — not a live UI knob. Omit ⇒ code defaults (20% margin, 1:1 peg, pay both streams, both lanes on). |
| `models` | `{ main, subagentDefault, subagentRoutine }` — the per-instance subagent model-allocation DEFAULT the builder-settings module reads (task 2011): the tier for the main session, subagent-default work, and routine plumbing (tiers: `haiku`/`sonnet`/`opus`/`fable`). A per-builder override resolves over this. Omit ⇒ code defaults (`opus`/`opus`/`haiku`). |
| `tracks` | The configurable version-track set (replaces the hardcoded `product\|internal`). |
| `theme` | `{ palette, mode, ui }` — palette file ref + theme mode, plus `ui`, the WEB look `themeMarkup()` splices into every served page as a plain `:root` after the page's stylesheet: `colors` (the thirteen contract tokens — **light-mode values**; each stylesheet derives its own dark tier from them at `:root[data-mode="dark"]` + its `prefers-color-scheme` twin, which outrank the pack), `fonts` (`display`, `body`, `links`), `favicon`, and `backdrop` — a `body{background:…}` rule that outranks every sheet in **both** modes, so a dual-mode world sets it to `var(--bg)` (the neutral pack does since [task 1003298](https://cloudbongos.com/builders#/task/1003298), ADR 0196) rather than a literal. The neutral values are the chrome world's; `config/design-tokens.neutral.json` must mirror `colors` + `fonts` key for key (`tests/design_tokens_sync.mjs`), and the world's derived recipes are recorded in `DESIGN.md`. The ui-design module's **style library** (`modules/ui-design/styles/`, [ADR 0219](adr/0219-a-look-is-a-branding-pack-the-style-library.md)) ships ready-made `theme.ui` blocks (looks) an instance copies into this field; every served sheet reads only these fifteen, so a look re-themes every surface with no page edit. |
| `copy` | Instance copy keys (tagline, hallName, notFound, …). Full copy pack adoption = task [#1196](https://example.com/builders#/task/1196). |
| `landing.postLogin` | Where a successful web sign-in lands when it carried no explicit `?return=` / same-apex `Referer` (`src/bongos/routes/auth.js` `postLoginLanding`). **Portable default `/builders`** — the hall always exists. A platform-home instance points this at its OWN front door so a visitor who signs in from there returns there instead of being auto-redirected into the hall (cloudbongos.com → `/gate/`, the orbs). Validated through the same open-redirect allowlist as `?return=` (a misconfigured value falls back to `/builders`). Env-overridable: `<PREFIX>_POST_LOGIN_LANDING`. (task [#1002240](https://cloudbongos.com/builders#/task/1002240)) |
| `envPrefix` | Env-var namespace for overrides (`BONGOS` for vanilla, `OTB`, …). Legacy `CLOUDBONGOS_`, `OTB_`, `GDS_` and `PMS_` spellings still resolve, with one deprecation warning per name, until core 1.21 (task 1003703). |

**Not here:** feature-module on/off flags (game, art, discord) are a sibling config owned by R54 (task [#1193](https://example.com/builders#/task/1193)).

## Using it

```js
const { branding } = require('./src/branding');
const b = branding();              // resolved singleton (env → config → neutral)
res.send(`Welcome to ${b.identity.worldName}`);
```

Tests drive the pure resolver with injected objects (no I/O): `resolveBranding({ neutral, instance, env })`. See `tests/branding.mjs`.

### On the client (R56 task [#1195](https://example.com/builders#/task/1195) + R57 task [#1196](https://example.com/builders#/task/1196))

The browser never sees the full pack — only the **client-safe projection** `clientBranding()` (a small allow-list — `{ identity, currency, theme, copy, rankLabels }`; origins, repo, db name, `llmProjectName`, and env prefix stay server-side). It reaches the front-end two ways:

- **On-box (hall + status served from the droplet):** injected synchronously by `mountInternalSurfaces` (`src/bongos/serve-internal.js` → `injectBrandingGlobal`) into the page `<head>` as **`window.__BRANDING__`** (the strings) **plus theme markup** (`themeMarkup` → a `:root` palette/font-var override `<style>`, the web-font `<link>`s, and the favicon `<link>`). The `<style>` lands after the page's own stylesheet so the pack wins. No fetch, no flash-of-default.
- **Off-box (the GitHub-Pages status page):** read cross-origin from **`GET /api/bongos/public/branding`**.

R56 seeded the projection with the configurable **currency label** (`public-builders/brand-apply.js` fills `[data-currency-label]` / `[data-currency-tmpl]` markup + `window.OTBBranding.currencyLabel()`). R57 widens it to the **LOOK** — `theme.ui` (palette + fonts + favicon; note this is the WEB theme, distinct from the server-only `theme.palette` game pixel-art path) — and the **rank display-label map** (`window.OTB.rankLabel()` reads `rankLabels`; the rank ENUM stays Greek by decision, only the label is presentation). The remaining themed **page copy + identity strings** (titles, ledes, world-flavor copy) are tracked as the R57 copy-pack follow-up.

## Branding a new instance

Copy `config/branding.neutral.json` → `config/branding.json` and fill it in. The fastest path is to hand your own LLM the prompt in [`branding-fill-prompt.md`](branding-fill-prompt.md), which interviews you and emits a valid pack.
