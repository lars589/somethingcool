---
name: builder-key
description: >-
  Show which API keys are set; add one via Settings. HARD RULE: never accept a key pasted in chat. Triggers: "/builder-key", "/api-key", "what keys do I have set", "add my art key", "my key isn't working", "No image-generation key found".
plain: >-
  Shows which of your service keys, such as the one for making images, are set up, and walks you to the settings page to add one.
reach-for: >-
  When something says a key is missing, or you want to check your keys.
cost: >-
  Free. It never takes a key in chat; you add keys yourself on the settings page.
---

**Script skill (authoritative).** The core action is `node scripts/gds/key-status.js [--recheck]`. Run it and relay its output — the monospace status list, plus the visual callout it emits for any missing key (rendered per the marker convention below).

You are checking the current builder's API-key coverage (today: the art pipeline's Google AI Studio / Gemini key; the script is written to add more keys without new code).

## HARD RULE — never accept a key in chat (idea 347 / feedback_auth_flows_ui_first)

A key is **never** pasted into chat, and **never** accepted as a CLI argument. The only place a key is ever written is the Settings page (`PUT /me/art-key/own`, driven by the browser). If the user pastes what looks like a key into the conversation:

- **Do not** run it through any tool, echo it back, or forward it anywhere (the transcript is uploaded — a pasted key is now compromised the moment it's typed).
- Refuse, and point them back to Settings: `https://example.com/builders/settings#art-key`.
- `key-status.js` also refuses defensively if a key-looking string reaches it as an argument — that is a backstop, not the primary defense. The primary defense is **you never run it there in the first place**.

## How to use

1. **List status.** Run `node scripts/gds/key-status.js` and relay its output verbatim (the monospace list). It hits `GET /api/bongos/me/art-key` for each known key.

2. **Missing key → the visual callout fires automatically.** When a key is unset, the script calls `scripts/gds/key-card.js` itself and prints `[otb-key-card-html] <path>` — the same marker the `.claude/hooks/lifecycle-card.js` PostToolUse hook scans for on ANY Bash output. The hook injects a render directive right after the tool result:
   - If you have `mcp__visualize__show_widget`: call `mcp__visualize__read_me` once this session (modules `["interactive","mockup"]`) if you haven't, then render the HTML exactly as directed — **once**, no prose recap.
   - If you don't have that tool: the monospace card the script already printed IS the summary — relay it as-is.

3. **Drive the UI-first add flow.** Tell the user to click "Add it in Settings ↗" in the card (or open `https://example.com/builders/settings#art-key` themselves). The key syncs to their box automatically at next session start via `scripts/gds/fetch-art-key.js` — no further action needed from you.

4. **Confirm it resolved.** Once the user says they added it, run `node scripts/gds/key-status.js --recheck` — this re-syncs the local session file immediately (rather than waiting for next session start) and re-checks status. Relay the result: resolved (all set) or still missing (point back to step 2/3).

## Constraints

- **Never** write a script, one-liner, or curl command that takes a key as an argument or env var supplied inline in chat — that's the same violation as pasting it, just automated.
- **Don't invent new key types speculatively** — `KEYS` in `key-status.js` lists only keys that actually have a backing route (today: `gemini`/art-key). Adding a new key type is a small script edit, not a new skill.
- If `GET /me/art-key` is unreachable (offline, API error), say so plainly — don't guess at status.

## Files this skill touches

- Reads: `~/.config/otb/gds-session.json`
- Calls: `GET /api/bongos/me/art-key`, `GET /api/bongos/me` (widgets knob)
- Runs: `scripts/gds/key-status.js`, `scripts/gds/key-card.js` (via the status script), `scripts/gds/fetch-art-key.js` (via `--recheck`)
